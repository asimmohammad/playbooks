# compliance-playbooks

Compliance playbooks and supporting review materials.

## Vigil playbooks

The [`vigil-playbooks/`](vigil-playbooks/README.md) directory contains 42 draft compliance playbooks, machine-readable check manifests, adapter surface types, and a neobank overlap analysis. These materials are AI-drafted and require compliance and engineering review; they do not include detector or rule implementations.
