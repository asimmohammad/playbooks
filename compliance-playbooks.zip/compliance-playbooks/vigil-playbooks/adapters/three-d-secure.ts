/** DRAFT — EMV 3-D Secure 2.x surface (3DS Server / requestor side + fake DS/ACS). Types only; no implementation.
 *  The DS and ACS are in-process fakes: rules script their responses (frictionless, challenge, errors, timeouts,
 *  signatures, versions) through `scriptDirectoryServer` / `scriptAcs` and FaultInjector. */
import type { Id, Money, OpResult } from './common';
import type { CardAuthorizationSystem, ExemptionKind } from './card-authorization';

/** Transaction status values as configured (the adapter maps them to the protocol's literals). */
export type TransStatus = 'Y' | 'N' | 'U' | 'A' | 'C' | 'R' | 'I' | 'D';

export interface AcsScript {
  ares: { transStatus: TransStatus; eci?: string; authenticationValue?: string } | { error: string } | 'malformed';
  /** Results message delivered after a challenge (omit for abandonment). */
  rreq?: { transStatus: TransStatus; eci?: string; authenticationValue?: string; signatureValid: boolean; deliveries?: number; concurrent?: boolean };
  /** Issuer's response to an exemption request (soft decline = SCA required). */
  exemptionResponse?: 'accepted' | 'sca_required';
}
export interface DirectoryScript {
  supportedVersions: readonly string[];
  cardRangeCache?: 'fresh' | 'stale' | 'corrupt';
  /** Version offered by a (possibly hostile) peer, for downgrade checks. */
  offeredVersion?: string;
}

export interface AuthenticationResult {
  threeDsServerTransId: Id;
  status: TransStatus | 'expired' | 'error' | 'timeout';
  flow: 'frictionless' | 'challenge' | 'none';
  eci?: string;
  authenticationValueRef?: Id;
  protocolVersion?: string;
  exemption?: ExemptionKind;
  boundTo: { amount: Money; merchantId: Id; token: string };
  consumed: boolean;
  createdAt: string;
}

export interface ThreeDSecureSystem extends CardAuthorizationSystem {
  scriptDirectoryServer(script: DirectoryScript): void;
  scriptAcs(script: AcsScript): void;
  /** Start authentication for a purchase; returns the server-side transaction id. */
  authenticate(input: {
    token: string; amount: Money; merchantId: Id; channel: 'ecom' | 'recurring' | 'moto';
    requestExemption?: ExemptionKind; initialTransactionId?: Id; issuerRegion?: string; acquirerRegion?: string;
    /** Client-supplied values a rule asserts are ignored. */
    clientAsserted?: { transStatus?: TransStatus; exemption?: ExemptionKind; eci?: string };
  }): Promise<OpResult<AuthenticationResult>>;
  /** Simulate the browser return/redirect with arbitrary (untrusted) parameters. */
  browserReturn(input: { threeDsServerTransId: Id; params: Record<string, string> }): Promise<OpResult>;
  authenticationResult(threeDsServerTransId: Id): Promise<AuthenticationResult | undefined>;
  /** Authorize using a stored authentication result (the system must read ECI/value from storage, not from input). */
  authorizeAuthenticated(input: { threeDsServerTransId: Id; amount: Money; merchantId: Id; token: string; idempotencyKey?: string }): Promise<OpResult<{ authId: Id }>>;
  exemptionCounters(token: string): Promise<{ lowValueCount: number; lowValueAmountMinor: bigint }>;
  refreshCardRanges(): Promise<OpResult>;
  /** Configured ECI / liability matrix version in force (SME-supplied). */
  matrixVersion(): Promise<string | undefined>;
}
