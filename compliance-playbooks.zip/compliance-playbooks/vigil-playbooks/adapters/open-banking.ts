/** DRAFT — PSD2 SCA / XS2A / TPP surface. Types only. */
import type { Id, Money, OpResult } from './common';
import type { MoneySystem } from './money-system';
export interface OpenBankingSystem extends MoneySystem {
  startSca(input: { psu: Id; amount: Money; payee: Id }): Promise<OpResult<{ challengeId: Id }>>;
  completeSca(input: { challengeId: Id; factors: readonly ('knowledge' | 'possession' | 'inherence')[] }): Promise<OpResult<{ authCode: string }>>;
  initiatePayment(input: { psu: Id; amount: Money; payee: Id; authCode?: string; exemption?: string; tpp?: Id; idempotencyKey?: string }): Promise<OpResult<{ paymentId: Id; status: string }>>;
  paymentStatus(paymentId: Id): Promise<{ status: string; history: readonly string[] }>;
  registerTpp(input: { tpp: Id; roles: readonly ('AIS' | 'PIS' | 'CBPII')[]; cert: { serial: string; expiresAt: string; revoked?: boolean; selfSigned?: boolean } }): Promise<OpResult>;
  grantConsent(input: { psu: Id; tpp: Id; accounts: readonly Id[]; validUntil: string; frequencyPerDay: number }): Promise<OpResult<{ consentId: Id }>>;
  revokeConsent(consentId: Id): Promise<OpResult>;
  activeConsents(psu: Id): Promise<readonly { consentId: Id; tpp: Id }[]>;
  xs2a(input: { tpp: Id; consentId?: Id; endpoint: string; psuPresent: boolean; body?: unknown }): Promise<{ status: number; errorCode?: string; body?: unknown }>;
}
