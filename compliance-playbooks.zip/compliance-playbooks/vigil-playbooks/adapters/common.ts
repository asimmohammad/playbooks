/**
 * DRAFT — Vigil adapter-surface conventions (types only; no implementations).
 * AI-drafted (Helix); needs engineering + compliance review before use.
 *
 * Conventions every surface MUST follow so behavioural verdicts stay deterministic:
 *  1. reset(): every rule runs against a FRESH system. reset() drops all state (stores, queues,
 *     fakes, counters) and re-seeds only from the fixture passed in. No state leaks between rules.
 *  2. Controllable clock: implementations read time ONLY from `clock`. No Date.now(), timers, or
 *     wall-clock reads. Deadlines/windows/expiries/cadences are exercised by clock.advance()/set().
 *  3. No randomness affects a verdict: IDs come from `ids` (deterministic sequence) and any
 *     random choice must be seeded from ResetOptions.seed.
 *  4. External dependencies (vendors, registries, feeds, networks) are in-process fakes behind
 *     `faults`, so outage/timeout/corruption scenarios are injected, not hoped for.
 *  5. Path evidence: every surface records which guarded paths it actually drove (`trace`) so a
 *     rule can return CHECKED only when it drove the guard's path, else NOT_EXERCISED.
 *  6. "Configured" parameters (thresholds, windows, rates, matrices) are injected via
 *     ResetOptions.config and echoed in results as parameters_used; SME-flagged matrices may be
 *     absent, in which case the rule reports NOT_EXERCISED (never CHECKED).
 */
export type ISODateTime = string;
export type Id = string;
/** Integer minor units (e.g. cents) — never floating point. */
export interface Money { readonly minor: bigint; readonly currency: string }

export interface Clock { now(): ISODateTime }
export interface ControllableClock extends Clock {
  set(at: ISODateTime): void;
  advance(by: { ms?: number; seconds?: number; minutes?: number; hours?: number; days?: number; businessDays?: number }): void;
}
export interface DeterministicIds { next(prefix: string): Id }

export type FaultMode = 'outage' | 'timeout' | 'error' | 'corrupt' | 'partial' | 'stale' | 'slow';
export interface FaultInjector {
  /** Inject a fault on a named dependency (e.g. 'kyc-vendor', 'list-feed', 'idp'); cleared by reset(). */
  inject(dependency: string, mode: FaultMode, opts?: { count?: number; untilAt?: ISODateTime }): void;
  clear(dependency?: string): void;
}

export interface PathTrace {
  /** Mark a guarded path as driven; rules query it to decide CHECKED vs NOT_EXERCISED. */
  hit(pathId: string): void;
  wasHit(pathId: string): boolean;
  hits(): readonly string[];
}

export interface ResetOptions {
  seed?: number;
  startAt?: ISODateTime;
  /** Configured parameters: thresholds, windows, rate tables, state/SME matrices. */
  config?: Readonly<Record<string, unknown>>;
  /** Surface-specific fixture data. */
  fixture?: Readonly<Record<string, unknown>>;
}

/** Mixed into every extension surface. */
export interface VigilSurface {
  reset(opts?: ResetOptions): Promise<void>;
  readonly clock: ControllableClock;
  readonly ids: DeterministicIds;
  readonly faults: FaultInjector;
  readonly trace: PathTrace;
}

/** Common result envelope for guarded operations. */
export type OpResult<T = unknown> =
  | { ok: true; value: T }
  | { ok: false; code: string; reason?: string };

export interface AuditEvent { id: Id; at: ISODateTime; actor: Id; action: string; resource: string; outcome: string; reason?: string; before?: unknown; after?: unknown }
export interface AuditReader { auditEvents(filter?: { resource?: string; action?: string; actor?: Id }): Promise<readonly AuditEvent[]> }
export interface Task { id: Id; kind: string; subject: Id; dueAt?: ISODateTime; status: 'open' | 'done' | 'overdue' | 'escalated' }
export interface TaskReader { tasks(filter?: { kind?: string; subject?: Id }): Promise<readonly Task[]> }
