/** DRAFT — Regulatory capital / risk-model surface (Basel, Dodd-Frank stress tests, NAIC RBC). Types only.
 *  Risk-weight tables, buffers, factors and action levels are SME-provided matrices injected via ResetOptions.config. */
import type { Id, OpResult, VigilSurface } from './common';
export interface Exposure { id: Id; class: string; amountMinor: bigint; rating?: string; collateral?: string; offBalanceSheet?: boolean; nettingSet?: Id }
export interface CapitalEngine extends VigilSurface {
  loadExposures(batch: readonly Exposure[], opts?: { batchId?: Id }): Promise<OpResult>;
  loadGl(input: { asOf: string; complete: boolean; lines: readonly unknown[] }): Promise<void>;
  computeRwa(asOf: string): Promise<OpResult<{ rwaMinor: bigint; perExposure: readonly { id: Id; weight: number; fallback?: boolean }[]; tableVersion: string }>>;
  computeRatios(asOf: string): Promise<OpResult<{ ratios: Record<string, number>; alerts: readonly string[]; final: boolean; runId: Id }>>;
  computeLeverage(asOf: string): Promise<OpResult<{ ratio: number; exposureMinor: bigint; version: number }>>;
  computeRbc(asOf: string): Promise<OpResult<{ ratio: number; actionLevel: string }>>;
  runStressTest(input: { scenarioId: Id; modelVersion: string; official: boolean }): Promise<OpResult<{ runId: Id; outputs: Record<string, number>; complete: boolean }>>;
}
