/** DRAFT — Wire transfer / security-procedure surface (UCC Article 4A). Types only. */
import type { Id, Money, OpResult } from './common';
import type { MoneySystem } from './money-system';
export interface WireSystem extends MoneySystem {
  agreeSecurityProcedure(input: { customer: Id; steps: readonly string[]; dualControlThreshold?: Money }): Promise<void>;
  submitWire(input: { customer: Id; beneficiary: { name: string; account: string }; amount: Money; idempotencyKey?: string }): Promise<OpResult<{ wireId: Id }>>;
  completeStep(input: { wireId: Id; step: string; actor: Id }): Promise<OpResult>;
  release(wireId: Id): Promise<OpResult<{ status: 'sent' | 'held' | 'blocked' }>>;
  recall(wireId: Id): Promise<OpResult<{ refunded: Money }>>;
}
