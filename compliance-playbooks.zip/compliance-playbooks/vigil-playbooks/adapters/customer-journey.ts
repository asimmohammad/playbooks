/** DRAFT — Customer journey & content surface (FCA Consumer Duty, UDAAP deceptive/abusive, MiCA disclosures). Types only. */
import type { Id, OpResult, VigilSurface } from './common';
export interface CustomerJourneySystem extends VigilSurface {
  setVulnerability(input: { customer: Id; flag: string }): Promise<void>;
  runJourney(input: { customer: Id; journey: 'open' | 'close' | 'cancel' | 'switch' | string; channel: string }): Promise<{ steps: number; treatment?: string; completed: boolean }>;
  publishContent(input: { contentId: Id; claims: readonly string[] }): Promise<OpResult>;
  applyPromotion(input: { customer: Id; promoId: Id }): Promise<{ termsAfterExpiry: Record<string, unknown> }>;
}
