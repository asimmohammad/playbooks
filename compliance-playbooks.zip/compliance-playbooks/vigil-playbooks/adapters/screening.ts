/** DRAFT — Sanctions screening and blocked-property surface (OFAC, BSA). Types only. */
import type { Id, Money, OpResult, TaskReader } from './common';
import type { MoneySystem } from './money-system';
export interface ScreeningSystem extends MoneySystem, TaskReader {
  loadList(input: { version: string; entries: readonly { name: string; aliases?: string[]; wallet?: string; country?: string; ownerOf?: { entity: string; pct: number }[] }[]; checksum?: string }): Promise<OpResult>;
  activeListVersion(): Promise<string>;
  screen(input: { parties: readonly { name: string; address?: string; wallet?: string; country?: string }[]; freeText?: string }): Promise<{ hit: boolean; score: number; listVersion: string; algorithmVersion: string }>;
  addPayee(input: { owner: Id; payee: { name: string; address?: string } }): Promise<OpResult<{ payeeId: Id; status: 'active' | 'held' }>>;
  payout(input: { from: Id; payee: Id; amount: Money; rail: string; idempotencyKey?: string }): Promise<OpResult<{ status: 'released' | 'held' | 'blocked' | 'rejected' }>>;
  clearFalsePositive(input: { alertId: Id; reviewer: Id; rationale: string; expiresAt?: string }): Promise<OpResult>;
  block(input: { accountId: Id; caseId: Id }): Promise<OpResult>;
  unblock(input: { accountId: Id; authorizationRef?: string; approvers: readonly Id[] }): Promise<OpResult>;
  blockedInventory(): Promise<readonly { accountId: Id; owner: Id; amount: Money; blockedAt: string }[]>;
  submitReport(input: { caseId: Id; idempotencyKey: string }): Promise<OpResult<{ status: 'submitted' | 'confirmed' }>>;
}
