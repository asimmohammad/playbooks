/** DRAFT — ACH origination / returns surface (NACHA). Types only. */
import type { Id, Money, OpResult } from './common';
import type { MoneySystem } from './money-system';
export interface AchSystem extends MoneySystem {
  recordAuthorization(input: { account: Id; secCode: string; terms: { amount?: Money; maxAmount?: Money; start: string; end?: string }; evidence: string }): Promise<OpResult<{ authorizationId: Id }>>;
  revokeAuthorization(authorizationId: Id): Promise<OpResult>;
  originate(input: { authorizationId?: Id; account: Id; amount: Money; secCode: string; sameDay?: boolean; effectiveDate?: string; idempotencyKey?: string }): Promise<OpResult<{ entryId: Id; traceNumber: string }>>;
  buildFile(): Promise<OpResult<{ fileId: Id; contents: string }>>;
  transmit(fileId: Id): Promise<OpResult<{ status: 'accepted' | 'rejected' }>>;
  ingestReturns(file: string): Promise<{ applied: number; exceptions: number }>;
  ingestNoc(file: string): Promise<{ applied: number }>;
  unauthorizedReturnRate(originator: Id): Promise<{ rate: number; window: string }>;
}
