/** DRAFT — Card authorization surface (issuer/acquirer auth, capture, refund, token lifecycle). Types only; no implementation.
 *  Shared by the 3ds and card-fraud-stolen playbooks. All time comes from the ControllableClock; all external parties
 *  (card network, token service provider, issuer host) are in-process fakes driven through FaultInjector. */
import type { Id, Money, OpResult, AuditReader } from './common';
import type { CardVaultSystem } from './card-vault';

export type CardStatus = 'active' | 'suspended' | 'lost' | 'stolen' | 'closed';
export type TokenKind = 'device' | 'card_on_file' | 'network' | 'vault';
export interface CardToken { token: string; kind: TokenKind; panRef: Id; status: CardStatus }

/** Authentication evidence attached to an authorization (populated from the stored 3DS result, never the request). */
export interface AuthAuthenticationData {
  threeDsServerTransId?: Id;
  dsTransId?: Id;
  eci?: string;
  /** Opaque handle to the stored authentication value; rules never see the raw value. */
  authenticationValueRef?: Id;
  protocolVersion?: string;
  exemption?: ExemptionKind;
  mit?: { initialTransactionId: Id };
}
export type ExemptionKind = 'TRA' | 'LOW_VALUE' | 'RECURRING_MIT' | 'TRUSTED_BENEFICIARY' | 'OUT_OF_SCOPE';

export interface AuthorizationRequest {
  token: string;
  amount: Money;
  merchantId: Id;
  mcc: string;
  channel: 'ecom' | 'pos' | 'moto' | 'recurring';
  idempotencyKey?: string;
  cvv?: string;
  avs?: { postalCode?: string; street?: string };
  device?: { fingerprint?: string; ip?: string; geo?: { lat: number; lon: number } };
  /** Present only so rules can assert it is IGNORED (client-supplied values must not drive decisions). */
  clientAsserted?: Record<string, unknown>;
}
export interface AuthorizationRecord {
  authId: Id;
  status: 'approved' | 'declined' | 'held' | 'reversed';
  /** External (cardholder/merchant-facing) response code, from the configured code table. */
  responseCode: string;
  amount: Money;
  capturedMinor: bigint;
  recoveredMinor: bigint;
  authentication?: AuthAuthenticationData;
  liabilityShift?: boolean;
  networkMessage: Record<string, unknown>;
}

export interface CardAuthorizationSystem extends CardVaultSystem, AuditReader {
  issueCard(input: { holder: Id; account: Id }): Promise<OpResult<{ panRef: Id; token: string }>>;
  provisionToken(input: { panRef: Id; kind: TokenKind }): Promise<OpResult<CardToken>>;
  tokens(panRef: Id): Promise<readonly CardToken[]>;
  setCardStatus(input: { panRef: Id; status: CardStatus; reason: string; actor: Id }): Promise<OpResult>;
  reissue(input: { panRef: Id; reason: 'lost' | 'stolen' | 'expiry' }): Promise<OpResult<{ newPanRef: Id; newToken: string }>>;
  authorize(input: AuthorizationRequest): Promise<OpResult<AuthorizationRecord>>;
  capture(input: { authId: Id; amount: Money; idempotencyKey?: string }): Promise<OpResult<{ captureId: Id }>>;
  reverse(input: { authId: Id; amount?: Money; reason: string; idempotencyKey?: string }): Promise<OpResult>;
  refund(input: { captureId: Id; amount: Money; destinationToken?: string; idempotencyKey?: string }): Promise<OpResult<{ refundId: Id; destinationToken: string }>>;
  authorization(authId: Id): Promise<AuthorizationRecord | undefined>;
  /** What the token service provider fake has been told (for propagation checks). */
  tspNotifications(panRef: Id): Promise<readonly { token: string; status: CardStatus; delivered: boolean }[]>;
}
