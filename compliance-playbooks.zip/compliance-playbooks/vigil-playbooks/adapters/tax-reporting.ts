/** DRAFT — Information-reporting / withholding surface (IRS 1099/1098/1099-K/backup withholding, FATCA). Rates/thresholds are configured. Types only. */
import type { Id, Money, OpResult } from './common';
import type { MoneySystem } from './money-system';
export interface TaxReportingSystem extends MoneySystem {
  setTinStatus(input: { party: Id; status: 'certified' | 'missing' | 'mismatch-notice' }): Promise<void>;
  setFatcaClassification(input: { party: Id; classification: string; documentedUntil?: string }): Promise<void>;
  pay(input: { to: Id; amount: Money; kind: 'interest' | 'dividend' | 'settlement' | 'other'; paymentId: Id }): Promise<OpResult<{ withheld: Money }>>;
  generateForms(input: { taxYear: number; form: '1099-INT' | '1099-DIV' | '1098' | '1099-K' | 'FATCA' }): Promise<OpResult<{ forms: readonly { payee: Id; boxes: Record<string, bigint>; corrected?: boolean }[] }>>;
}
