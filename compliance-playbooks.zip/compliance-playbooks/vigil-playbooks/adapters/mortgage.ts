/** DRAFT — Mortgage origination/servicing surface (TRID, RESPA, HMDA). Types only. */
import type { Id, Money, OpResult } from './common';
import type { LendingSystem } from './lending';
export interface MortgageSystem extends LendingSystem {
  completeApplication(applicationId: Id): Promise<void>;
  issueLoanEstimate(input: { applicationId: Id; changedCircumstance?: string }): Promise<OpResult<{ leId: Id; deliveredAt: string }>>;
  issueClosingDisclosure(input: { loanId: Id; delivery: 'mail' | 'electronic' }): Promise<OpResult<{ cdId: Id; receivedAt: string }>>;
  scheduleClosing(input: { loanId: Id; at: string }): Promise<OpResult>;
  toleranceCure(loanId: Id): Promise<{ cure: Money; posted: boolean }>;
  referToAffiliate(input: { loanId: Id; affiliate: Id }): Promise<OpResult>;
  escrowAnalysis(loanId: Id): Promise<{ cushion: Money; shortage: Money; surplus: Money; statementIssued: boolean }>;
  runEscrowDisbursements(): Promise<readonly { loanId: Id; item: string; paid: Money; at: string }[]>;
  generateLar(period: string): Promise<{ rows: readonly Record<string, unknown>[]; editFailures: readonly string[] }>;
}
