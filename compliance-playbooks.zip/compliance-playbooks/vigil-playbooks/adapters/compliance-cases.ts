/** DRAFT — AML monitoring, alerts, cases and SAR filing surface (BSA, FinCEN). Types only. */
import type { Id, ISODateTime, OpResult, TaskReader } from './common';
import type { MoneySystem } from './money-system';
export interface Alert { id: Id; ruleId: string; ruleVersion: string; subject: Id; status: 'open' | 'closed' | 'suppressed'; risk: 'low' | 'medium' | 'high' }
export interface ComplianceCaseSystem extends MoneySystem, TaskReader {
  /** Count/value of transactions the monitoring engine ingested (compare with ledger). */
  monitoringPopulation(range?: { from: ISODateTime; to: ISODateTime }): Promise<{ count: number; valueMinor: bigint }>;
  runMonitoring(): Promise<readonly Alert[]>;
  alerts(filter?: { subject?: Id; ruleId?: string }): Promise<readonly Alert[]>;
  closeAlert(input: { alertId: Id; reviewer?: Id; rationale?: string; auto?: boolean }): Promise<OpResult>;
  openCase(input: { alertIds: readonly Id[] }): Promise<OpResult<{ caseId: Id; detectedAt: ISODateTime }>>;
  decideSar(input: { caseId: Id; decision: 'file' | 'no-file'; rationale: string; investigator: Id }): Promise<OpResult>;
  fileSar(input: { caseId: Id; investigator: Id; fields: Record<string, unknown> }): Promise<OpResult<{ filingId: Id; status: 'submitted' | 'acknowledged' }>>;
  /** What a given role/channel can see about a subject (SAR confidentiality). */
  viewAs(input: { role: string; subject: Id }): Promise<Record<string, unknown>>;
}
