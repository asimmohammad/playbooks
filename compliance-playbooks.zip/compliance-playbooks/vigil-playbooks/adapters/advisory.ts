/** DRAFT — Investment-adviser surface (Form ADV disclosures, performance, custody). Types only. */
import type { Id, Money, OpResult, TaskReader } from './common';
import type { MoneySystem } from './money-system';
export interface AdvisorySystem extends MoneySystem, TaskReader {
  recordMaterialChange(input: { field: string; magnitude: number }): Promise<void>;
  onboardClient(input: { client: Id; brochureDelivered?: boolean }): Promise<OpResult>;
  billFees(input: { client: Id; period: string }): Promise<OpResult<{ billed: Money; rateBps: number }>>;
  computePerformance(input: { composite: Id; periods: readonly string[] }): Promise<OpResult<{ gross: number; net: number; runId: Id }>>;
  publishPerformance(runId: Id): Promise<OpResult>;
  reconcileCustody(input: { asOf: string }): Promise<OpResult<{ breaks: readonly { client: Id; diff: Money }[]; complete: boolean }>>;
  deductFee(input: { client: Id; amount: Money; authorityRef?: string }): Promise<OpResult>;
}
