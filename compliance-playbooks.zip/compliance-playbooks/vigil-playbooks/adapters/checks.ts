/** DRAFT — Check deposit / returned-item surface (UCC Article 4). Types only. */
import type { Id, Money, OpResult } from './common';
import type { MoneySystem } from './money-system';
export interface CheckSystem extends MoneySystem {
  deposit(input: { account: Id; image: { routing: string; account: string; serial: string; amount: Money; confidence?: number } }): Promise<OpResult<{ itemId: Id; hold?: string }>>;
  ingestReturns(items: readonly { itemId?: Id; reason: string; receivedAt: string }[]): Promise<{ reversed: number; exceptions: number; late: number }>;
  notices(account: Id): Promise<readonly { itemId: Id; reason: string; amount: Money; sentAt: string }[]>;
}
