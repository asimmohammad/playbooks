/** DRAFT — Financial-controls surface on top of the ledger (SOX approvals, periods, audit chain). Types only. */
import type { Id, Money, OpResult } from './common';
import type { MoneySystem } from './money-system';
export interface LedgerControlsSystem extends MoneySystem {
  submitEntry(input: { initiator: Id; amount: Money; lines: readonly unknown[]; period: string; support?: readonly string[] }): Promise<OpResult<{ entryId: Id; versionHash: string; tier: string }>>;
  editEntry(input: { entryId: Id; actor: Id; changes: Record<string, unknown> }): Promise<OpResult<{ versionHash: string }>>;
  approve(input: { entryId: Id; approver: Id; delegation?: { from: Id; validUntil: string } }): Promise<OpResult>;
  post(entryId: Id): Promise<OpResult>;
  closePeriod(period: string): Promise<OpResult>;
  reopenPeriod(input: { period: string; approvedBy: readonly Id[] }): Promise<OpResult>;
  changeRuleConfig(input: { actor: Id; key: string; value: unknown; ticket?: string }): Promise<OpResult>;
  auditChain(): Promise<{ continuous: boolean; gapsAt: readonly number[] }>;
  migrateOrRestore(kind: 'migrate' | 'restore'): Promise<void>;
  reconcile(input: { source: 'bank' | 'processor' | 'subledger'; lines: readonly unknown[] }): Promise<{ matched: number; breaks: readonly { id: Id; ageDays: number; escalatedTo?: Id }[] }>;
}
