/** DRAFT — Securities/brokerage surface (Reg SCI, FINRA, MiFID II, cost basis, swap reporting). Types only. */
import type { Id, Money, OpResult, AuditReader } from './common';
import type { MoneySystem } from './money-system';
export interface SecuritiesSystem extends MoneySystem, AuditReader {
  submitOrder(input: { client: Id; instrument: string; side: 'buy' | 'sell'; qty: number; idempotencyKey?: string }): Promise<OpResult<{ orderId: Id; venue?: string; price?: Money }>>;
  setVenueQuote(input: { venue: string; instrument: string; price: Money; asOf: string }): Promise<void>;
  allocate(blockOrderId: Id): Promise<readonly { client: Id; qty: number; price: Money }[]>;
  reports(filter?: { tradeId?: Id; regime?: 'FINRA' | 'MiFID' | 'swap' }): Promise<readonly { id: Id; tradeId: Id; status: 'accepted' | 'rejected' | 'late'; fields: Record<string, unknown> }[]>;
  bookSwapEvent(input: { swapId: Id; event: string }): Promise<OpResult>;
  archive(input: { channel: string; message: Record<string, unknown> }): Promise<OpResult<{ recordId: Id }>>;
  purgeExpired(): Promise<{ purged: readonly Id[] }>;
  setLegalHold(recordId: Id, on: boolean): Promise<void>;
  flagForSupervision(input: { item: Id; actor: Id }): Promise<void>;
  signOff(input: { item: Id; reviewer: Id }): Promise<OpResult>;
  lots(account: Id): Promise<readonly { lotId: Id; qty: number; basis: Money; acquiredAt?: string; covered: boolean | 'unknown' }[]>;
  applyCorporateAction(input: { instrument: string; kind: string; ratio?: number }): Promise<void>;
  transferLots(input: { from: Id; to: Id; lots: readonly Id[]; statement?: boolean }): Promise<OpResult>;
  chargeResearch(input: { client: Id; amount: Money }): Promise<OpResult>;
  classifyIncident(input: { system: string; impact: string }): Promise<{ sci: boolean; deMinimis: boolean; tasks: readonly string[] }>;
}
