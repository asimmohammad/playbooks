/** DRAFT — Card fraud decisioning surface (stolen-card fraud: velocity, signals, ATO, holds, reporting, recoveries).
 *  Types only; no implementation and no rules. Decisions must be pure functions of (inputs, configured rule-set /
 *  model version, ControllableClock); vendors (device/geo, model service, network reporting) are FaultInjector fakes. */
import type { Id, Money, OpResult } from './common';
import type { AuthorizationRequest, CardAuthorizationSystem } from './card-authorization';

export interface FraudDecision {
  decisionId: Id;
  authId?: Id;
  outcome: 'approve' | 'decline' | 'challenge' | 'hold' | 'review';
  score?: number;
  /** Internal reason codes; must never appear in external responses. */
  internalReasons: readonly string[];
  externalResponseCode: string;
  ruleSetVersion: string;
  modelVersion?: string;
  featureSnapshotHash: string;
  fallback?: 'rules_only' | 'elevated_risk';
  decidedAt: string;
}
export interface FraudHold { holdId: Id; decisionId: Id; status: 'pending' | 'released' | 'confirmed_fraud' | 'expired'; expiresAt: string }
export interface FraudReport { reportId: Id; authId: Id; schema: string; submittedAt?: string; attempts: number; status: 'queued' | 'submitted' | 'failed' }

export interface FraudDecisionSystem extends CardAuthorizationSystem {
  /** Authorize through the fraud engine and return both the auth outcome and the recorded decision. */
  decide(input: AuthorizationRequest & { source?: { deviceId?: string; ip?: string } }): Promise<OpResult<FraudDecision>>;
  /** Re-run a recorded decision with its pinned versions and clock time (determinism / replay). */
  replay(decisionId: Id): Promise<FraudDecision>;
  decisions(filter?: { token?: string; source?: string }): Promise<readonly FraudDecision[]>;
  velocityCounters(key: { dimension: 'card' | 'device' | 'ip' | 'merchant' | 'bin'; value: string }): Promise<{ count: number; amountMinor: bigint; windowEndsAt: string }>;
  // Account takeover
  changeCredential(input: { customerId: Id; kind: 'password' | 'email' | 'phone' | 'mfa_device'; deviceId?: string }): Promise<OpResult>;
  addCard(input: { customerId: Id; pan: string; deviceId?: string; stepUpPassed?: boolean }): Promise<OpResult<{ token?: string; held: boolean; stepUpRequired: boolean }>>;
  // Holds / false-positive release
  holds(filter?: { status?: FraudHold['status'] }): Promise<readonly FraudHold[]>;
  resolveHold(input: { holdId: Id; resolution: 'release' | 'confirm_fraud'; channel: 'authenticated_app' | 'authenticated_call' | 'unauthenticated'; actor: Id }): Promise<OpResult>;
  feedbackLabels(decisionId: Id): Promise<readonly string[]>;
  // Reporting & chargebacks (network schemas such as TC40 / SAFE only as configured)
  confirmFraud(input: { authId: Id; actor: Id }): Promise<OpResult>;
  fraudReports(filter?: { authId?: Id }): Promise<readonly FraudReport[]>;
  openFraudChargeback(input: { captureId: Id; amount: Money }): Promise<OpResult<{ chargebackId: Id; reasonCode: string }>>;
  /** Fraud-driven reversal of a captured transaction, posted through the ledger. */
  fraudReversal(input: { captureId: Id; amount: Money; idempotencyKey?: string }): Promise<OpResult<{ reversalId: Id }>>;
}
