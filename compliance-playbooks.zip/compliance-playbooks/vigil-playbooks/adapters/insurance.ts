/** DRAFT — Insurance policy/claims/statutory surface (state insurance regs, NAIC). State form/rate/claims matrices are SME-provided config. Types only. */
import type { Id, Money, OpResult, TaskReader } from './common';
import type { MoneySystem } from './money-system';
export interface InsuranceSystem extends MoneySystem, TaskReader {
  loadRateTable(input: { state: string; version: string; status: 'approved' | 'pending'; effective: string; factors: Record<string, number> }): Promise<OpResult>;
  quote(input: { state: string; risk: Record<string, unknown>; renewal?: boolean }): Promise<OpResult<{ premium: Money; rateVersion: string }>>;
  issuePolicy(input: { quoteId: Id }): Promise<OpResult<{ policyId: Id; forms: readonly { form: string; version: string }[] }>>;
  fileClaim(input: { policyId: Id }): Promise<OpResult<{ claimId: Id }>>;
  decideClaim(input: { claimId: Id; decision: 'pay' | 'deny'; notice?: boolean }): Promise<OpResult>;
  payClaim(input: { claimId: Id; amount: Money; idempotencyKey: string }): Promise<OpResult>;
  buildStatutoryStatement(input: { period: string }): Promise<OpResult<{ lines: Record<string, bigint>; final: boolean; crossFoots: boolean }>>;
}
