/** DRAFT — Card vault / CDE surface (PCI-DSS). Types only. */
import type { Id, OpResult, VigilSurface, AuditReader } from './common';
import type { MoneySystem } from './money-system';
export interface CardVaultSystem extends MoneySystem {
  tokenize(input: { pan: string; requester: Id }): Promise<OpResult<{ token: string; vaultRecordId: Id }>>;
  detokenize(input: { token: string; requester: Id; reason: string }): Promise<OpResult<{ pan: string }>>;
  authorizeCard(input: { token: string; amount: { minor: bigint; currency: string }; cvv?: string; pinBlock?: string; track?: string }): Promise<OpResult<{ authId: Id }>>;
  submitFreeText(input: { field: string; value: string; actor: Id }): Promise<OpResult<{ storedValue: string }>>;
  startRekey(input: { newKeyId: Id }): Promise<OpResult<{ jobId: Id }>>;
  rekeyStatus(jobId: Id): Promise<{ done: number; remaining: number; doubleEncrypted: number }>;
  /** Scan every store the surface owns (DB, logs, caches, exports, outbound payloads) for PAN/SAD. */
  scanForSensitive(kind: 'PAN' | 'SAD'): Promise<readonly { location: string; sample: string }[]>;
  hashTruncated(pan: string): Promise<{ truncated: string; hash: string }>;
}
export interface IdentityAccessSystem extends VigilSurface, AuditReader {
  grantRole(input: { principal: Id; role: string; approver?: Id }): Promise<OpResult>;
  revokeRole(input: { principal: Id; role: string }): Promise<OpResult>;
  terminate(principal: Id): Promise<OpResult>;
  login(input: { principal: Id; mfa?: boolean; breakGlass?: { approver: Id } }): Promise<OpResult<{ session: Id }>>;
  request(input: { session: Id; resource: string; action: string }): Promise<OpResult>;
  effectivePermissions(principal: Id): Promise<readonly { resource: string; action: string }[]>;
  /** Customer-verification flow used by support tooling (GLBA pretexting). */
  verifyCaller(input: { customerId: Id; answers: Record<string, string>; channel: string }): Promise<OpResult<{ verificationSession: Id; stepUpRequired: boolean }>>;
  supportLookup(input: { agent: Id; customerId: Id; verificationSession?: Id }): Promise<OpResult<{ fields: Record<string, unknown> }>>;
  recordContactChange(input: { customerId: Id; kind: 'phone' | 'email' | 'sim' }): Promise<void>;
}
