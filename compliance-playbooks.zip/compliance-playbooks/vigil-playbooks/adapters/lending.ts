/** DRAFT — Consumer lending surface (Reg Z, ECOA/FHA, CRA data). Types only. */
import type { Id, Money, OpResult, TaskReader } from './common';
import type { MoneySystem } from './money-system';
export interface LoanTerms { principal: Money; rateBps: number; termMonths: number; fees: readonly { code: string; amount: Money }[]; firstPeriodDays?: number; variable?: { index: string; marginBps: number; capBps?: number } }
export interface LendingSystem extends MoneySystem, TaskReader {
  quote(input: { applicant: Id; terms: LoanTerms; channel?: string }): Promise<OpResult<{ quoteId: Id; aprBps: number; financeCharge: Money; amountFinanced: Money }>>;
  decide(input: { applicationId: Id }): Promise<OpResult<{ action: 'approve' | 'deny' | 'counteroffer' | 'incomplete'; reasons: readonly string[] }>>;
  adverseActionNotices(applicationId: Id): Promise<readonly { reasons: readonly string[]; sentAt: string; channel: string }[]>;
  priceException(input: { quoteId: Id; deltaBps: number; approver: Id; reason: string }): Promise<OpResult>;
  consummate(loanId: Id): Promise<OpResult>;
  rescind(input: { loanId: Id; by: Id }): Promise<OpResult>;
  disburse(loanId: Id): Promise<OpResult>;
  assessFee(input: { loanId: Id; code: string }): Promise<OpResult<{ amount: Money }>>;
  setIndex(input: { index: string; valueBps: number; asOf: string }): Promise<void>;
  /** CRA: geocode + assessment-area assignment and lending-test metrics. */
  assignArea(input: { recordId: Id; address: string }): Promise<OpResult<{ tract?: string; area?: string | 'outside'; definitionVersion: string }>>;
  craMetrics(input: { period: string }): Promise<Record<string, number>>;
}
