/** DRAFT — Governance/GRC surface (FCA SMCR certification permissions, ISO 27001 risk register/supplier gating). SMCR responsibility matrix is SME-provided. Types only. */
import type { Id, OpResult, TaskReader, VigilSurface } from './common';
export interface GovernanceSystem extends VigilSurface, TaskReader {
  certify(input: { person: Id; role: string; expiresAt: string }): Promise<void>;
  permissionsOf(person: Id): Promise<readonly string[]>;
  registerAsset(input: { asset: Id; goLive?: string }): Promise<OpResult<{ goLiveBlocked: boolean }>>;
  recordRisk(input: { asset: Id; score: number; owner?: Id; treatment?: string; dueAt?: string }): Promise<OpResult>;
  shareDataWithSupplier(input: { supplier: Id; assessed: boolean }): Promise<OpResult>;
}
