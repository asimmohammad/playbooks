/** DRAFT — Reg E error-resolution / liability / statements surface. Types only. */
import type { Id, Money, OpResult, TaskReader } from './common';
import type { MoneySystem } from './money-system';
export interface DisputesSystem extends MoneySystem, TaskReader {
  fileDispute(input: { consumer: Id; txnId: Id; channel: string; noticeAt?: string; lossEventId?: Id }): Promise<OpResult<{ disputeId: Id }>>;
  requestDocuments(disputeId: Id): Promise<void>;
  resolve(input: { disputeId: Id; finding: 'error' | 'no-error'; classification?: string }): Promise<OpResult<{ consumerLiability: Money; credited: Money }>>;
  dispute(disputeId: Id): Promise<{ status: string; provisionalCredit?: Money; timers: Record<string, string> }>;
  generateStatement(input: { account: Id; cycle: string }): Promise<OpResult<{ lines: readonly Record<string, unknown>[] }>>;
  deliverDisclosure(input: { consumer: Id; kind: string; channel: 'paper' | 'electronic' }): Promise<OpResult>;
}
