/** DRAFT — Debt-collection communications surface (FDCPA). Types only. */
import type { Id, OpResult, TaskReader } from './common';
import type { MoneySystem } from './money-system';
export interface CollectionsSystem extends MoneySystem, TaskReader {
  placeAccount(input: { debtor: Id; balanceMinor: bigint; timezone?: string }): Promise<OpResult<{ placementId: Id }>>;
  sendValidationNotice(placementId: Id): Promise<OpResult<{ noticeId: Id; itemization: Record<string, bigint> }>>;
  attemptContact(input: { placementId: Id; channel: 'call' | 'sms' | 'email' | 'letter' }): Promise<OpResult>;
  recordDispute(input: { placementId: Id; channel: string }): Promise<OpResult<{ caseId: Id }>>;
  sendVerification(caseId: Id): Promise<OpResult>;
  setFlags(input: { debtor: Id; ceaseRequested?: boolean; attorney?: boolean }): Promise<void>;
  furnished(placementId: Id): Promise<{ disputeIndicator: boolean }>;
}
