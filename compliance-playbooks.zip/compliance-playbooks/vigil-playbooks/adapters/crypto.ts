/** DRAFT — Crypto-asset surface (MiCA reserve/licensing/consumer, FinCEN MSB + travel rule). Types only. */
import type { Id, Money, OpResult, TaskReader } from './common';
import type { MoneySystem } from './money-system';
export interface CryptoSystem extends MoneySystem, TaskReader {
  setReserve(input: { assets: readonly { kind: string; amount: Money }[]; attestedAt: string }): Promise<void>;
  mint(input: { to: Id; amount: Money; idempotencyKey?: string }): Promise<OpResult>;
  redeem(input: { from: Id; amount: Money }): Promise<OpResult<{ paid: Money; paidAt: string }>>;
  outstanding(): Promise<Money>;
  setLicence(input: { service: string; memberState: string; status: 'active' | 'revoked' | 'pending'; effective: string }): Promise<void>;
  offerService(input: { customer: Id; service: string; memberState: string }): Promise<OpResult>;
  purchase(input: { customer: Id; asset: string; amount: Money; acknowledgements: readonly string[] }): Promise<OpResult>;
  transfer(input: { from: Id; toVasp: Id; beneficiary: Record<string, unknown>; amount: Money; transferId: Id }): Promise<OpResult<{ status: 'sent' | 'held'; travelRuleMessages: number }>>;
  receive(input: { fromVasp: Id; originator?: Record<string, unknown>; amount: Money }): Promise<OpResult<{ status: string }>>;
  fileComplaint(input: { customer: Id; text: string }): Promise<OpResult<{ caseId: Id }>>;
}
