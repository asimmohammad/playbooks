/** DRAFT — Privacy / data-subject-rights surface (GDPR, CCPA/CPRA, US state privacy, GLBA disclosure). Types only. */
import type { Id, ISODateTime, OpResult, VigilSurface, AuditReader, TaskReader } from './common';
export type DsrKind = 'access' | 'deletion' | 'portability' | 'correction' | 'opt-out' | 'limit-sensitive' | 'appeal';
export interface DsrCase { id: Id; subject: Id; kind: DsrKind; status: 'received' | 'verified' | 'in-progress' | 'complete' | 'denied' | 'extended'; dueAt: ISODateTime; ruleSetVersion?: string; state?: string }
export interface PrivacySystem extends VigilSurface, AuditReader, TaskReader {
  recordConsent(input: { subject: Id; purpose: string; granted: boolean; noticeVersion: string; channel: string }): Promise<OpResult>;
  consentFor(subject: Id, purpose: string): Promise<{ granted: boolean; version?: string } | undefined>;
  runProcessing(input: { purpose: string; subjects?: readonly Id[] }): Promise<{ processed: readonly Id[]; skipped: readonly Id[] }>;
  setOptOut(input: { subject?: Id; deviceId?: Id; signal?: 'link' | 'gpc' | 'universal'; optOut: boolean }): Promise<OpResult>;
  /** Run a sale/share/marketing feed and return the population actually sent. */
  runSharingFeed(input: { destination: string; classification: 'sale' | 'share' | 'service-provider' | 'nonaffiliated' }): Promise<{ sent: readonly Id[] }>;
  submitDsr(input: { subject: Id; kind: DsrKind; channel: string; verified: boolean; residency?: string; agentFor?: Id }): Promise<OpResult<DsrCase>>;
  dsr(id: Id): Promise<DsrCase>;
  runDsrWorkflow(id: Id): Promise<DsrCase>;
  exportFor(caseId: Id): Promise<{ format: string; records: readonly Record<string, unknown>[]; subjectIds: readonly Id[] }>;
  /** Locate any remaining personal data for a subject across every mapped store. */
  findPersonalData(subject: Id): Promise<readonly { store: string; field: string; retentionException?: string }[]>;
  restoreBackup(snapshotId: Id): Promise<void>;
  openBreach(input: { source: 'indicator' | 'processor' | 'report'; awareAt: ISODateTime; affected?: readonly Id[]; risk?: 'low' | 'high' }): Promise<OpResult<{ caseId: Id }>>;
  breachCase(caseId: Id): Promise<{ id: Id; deadlines: Record<string, ISODateTime>; readyToSend: boolean; notified: readonly Id[] }>;
  /** State-rule matrix (SME/counsel-maintained); injected via ResetOptions.config. */
  ruleSetFor(input: { residency?: string; at: ISODateTime }): Promise<{ version: string; rights: readonly DsrKind[]; deadlineDays: number } | undefined>;
}
