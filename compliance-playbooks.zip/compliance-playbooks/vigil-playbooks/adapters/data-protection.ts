/** DRAFT — Confidential-data / PHI protection surface (SOC 2 confidentiality, HIPAA). Types only. */
import type { Id, OpResult, VigilSurface, AuditReader } from './common';
export interface DataProtectionSystem extends VigilSurface, AuditReader {
  read(input: { principal: Id; role: string; record: Id; purpose?: string }): Promise<OpResult<{ fields: Record<string, unknown> }>>;
  export(input: { principal: Id; records: readonly Id[]; destination: string; vendor?: Id }): Promise<OpResult<{ exportId: Id }>>;
  setBaa(input: { vendor: Id; status: 'active' | 'expired' | 'terminated'; expiresAt?: string }): Promise<void>;
  submitTicket(input: { text: string; attachments?: readonly string[] }): Promise<{ redacted: boolean }>;
  share(input: { document: Id; external: string }): Promise<OpResult>;
  openIncident(input: { affected: readonly Id[]; encrypted: boolean }): Promise<OpResult<{ incidentId: Id; tasks: readonly string[] }>>;
}
