/** DRAFT — Onboarding / KYC / CIP / CDD / KYB / self-certification surface (BSA, PATRIOT, CDD Rule, FATCA DD). Types only. */
import type { Id, OpResult, VigilSurface, AuditReader, TaskReader } from './common';
import type { MoneySystem } from './money-system';
export interface PersonInput { name: string; dob?: string; address?: { line1: string; type?: 'street' | 'po-box' }; idNumber?: string; idType?: string; country?: string }
export interface OnboardingSystem extends MoneySystem, TaskReader {
  applyIndividual(input: { applicant: PersonInput; jointHolders?: readonly PersonInput[]; product: string }): Promise<OpResult<{ applicationId: Id }>>;
  applyEntity(input: { entity: { name: string; type: string }; owners: readonly (PersonInput & { pct: number; via?: Id })[]; controlPersons: readonly PersonInput[] }): Promise<OpResult<{ applicationId: Id }>>;
  updateIdentity(input: { partyId: Id; changes: Partial<PersonInput> }): Promise<OpResult>;
  application(id: Id): Promise<{ status: 'pending' | 'review' | 'approved' | 'declined' | 'held'; partyId?: Id; accountId?: Id; reasons: readonly string[] }>;
  riskProfile(partyId: Id): Promise<{ rating: string; tier: string; version: number; nextRefreshAt?: string; naturePurpose?: string }>;
  recordActivity(input: { partyId: Id; pattern: string }): Promise<void>;
  runRefreshScheduler(): Promise<{ queued: readonly Id[] }>;
  openEdd(input: { partyId: Id; trigger: string }): Promise<OpResult<{ caseId: Id }>>;
  approveEdd(input: { caseId: Id; approver: Id }): Promise<OpResult>;
  selfCertify(input: { partyId: Id; form: string; data: Record<string, unknown> }): Promise<OpResult<{ classification?: string }>>;
  match314a(input: { subjects: readonly PersonInput[] }): Promise<{ matches: readonly Id[] }>;
}
