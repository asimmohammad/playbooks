# Adapter surfaces: DRAFT

Types only (TypeScript). There are no implementations and no detector or rule code. Everything is AI-drafted and needs engineering and compliance review.

## Conventions (see `common.ts`)

- **`reset(opts)`**: every behavioural rule runs against a fresh system. All state, fakes, queues and counters are dropped and re-seeded only from `opts.fixture`, so no state leaks between rules.
- **Controllable clock**: implementations read time only from `clock` (`ControllableClock.set/advance`, including `businessDays`). There are no wall-clock reads or timers. Deadlines, windows, expiries and cadences are driven by advancing the clock.
- **No randomness**: IDs come from `ids` (deterministic sequence). Any random choice is seeded from `opts.seed`.
- **Fault injection**: external dependencies (vendors, registries, feeds, networks) are in-process fakes controlled through `faults.inject(dep, mode)`. That is how outage, timeout and corrupt-feed rows stay deterministic.
- **Path trace**: surfaces record driven guard paths (`trace.hit`). A rule returns CHECKED only if its guard path was hit, otherwise NOT_EXERCISED.
- **Configured parameters**: thresholds, windows, rate tables and SME matrices arrive in `opts.config` and are echoed as `parameters_used`. A ⚑ SME rule with no approved matrix reports NOT_EXERCISED.
- **`money-system.ts` is a placeholder**: the canonical neobank `MoneySystem` shape was not available, so this is an assumed minimal subset. Replace it with a re-export of the real interface and reconcile names.

## Surfaces and the checks they unlock

Today **every** behavioural row is NOT_EXERCISED, because no adapter implements these surfaces yet. *Unlocks* is the number of behavioural rows that become runnable (can return CHECKED/FINDING) once an adapter implements the surface. *Gate-eligible* excludes ⚑ SME rows, which stay NOT_EXERCISED until their matrix exists.

| Surface | Interface | File | Extends | Unlocks (behavioural) | Gate-eligible | ⚑ SME | Playbooks |
| --- | --- | --- | --- | --- | --- | --- | --- |
| MoneySystem | `MoneySystem` | `money-system.ts` | canonical | 11 | 11 |  | sox, soc-2 |
| CardVault | `CardVaultSystem` | `card-vault.ts` | MoneySystem | 8 | 8 |  | pci-dss |
| IdentityAccess | `IdentityAccessSystem` | `card-vault.ts` | VigilSurface | 7 | 7 |  | pci-dss, glba |
| Privacy | `PrivacySystem` | `privacy.ts` | VigilSurface | 41 | 32 | 9 | gdpr, ccpa-cpra, glba, state-privacy |
| OpenBanking | `OpenBankingSystem` | `open-banking.ts` | MoneySystem | 14 | 14 |  | psd2 |
| Onboarding | `OnboardingSystem` | `onboarding.ts` | MoneySystem | 30 | 30 |  | bsa-aml, usa-patriot-act, fatca, cdd-rule |
| ComplianceCases | `ComplianceCaseSystem` | `compliance-cases.ts` | MoneySystem | 11 | 11 |  | bsa-aml, fincen |
| Screening | `ScreeningSystem` | `screening.ts` | MoneySystem | 16 | 16 |  | bsa-aml, ofac |
| LedgerControls | `LedgerControlsSystem` | `ledger-controls.ts` | MoneySystem | 8 | 8 |  | sox |
| Ach | `AchSystem` | `ach.ts` | MoneySystem | 13 | 13 |  | nacha |
| Disputes | `DisputesSystem` | `disputes.ts` | MoneySystem | 11 | 11 |  | reg-e |
| Lending | `LendingSystem` | `lending.ts` | MoneySystem | 21 | 17 | 4 | reg-z, ecoa-fha, cra |
| Mortgage | `MortgageSystem` | `mortgage.ts` | LendingSystem | 16 | 15 | 1 | hmda, respa, trid |
| Collections | `CollectionsSystem` | `collections.ts` | MoneySystem | 6 | 6 |  | fdcpa |
| Securities | `SecuritiesSystem` | `securities.ts` | MoneySystem | 27 | 27 |  | sec-reg-sci, finra, dodd-frank, mifid-ii, cost-basis |
| Advisory | `AdvisorySystem` | `advisory.ts` | MoneySystem | 9 | 9 |  | sec-form-adv |
| CapitalEngine | `CapitalEngine` | `capital-engine.ts` | VigilSurface | 13 | 7 | 6 | dodd-frank, basel, naic |
| Insurance | `InsuranceSystem` | `insurance.ts` | MoneySystem | 10 | 7 | 3 | state-insurance, naic |
| Crypto | `CryptoSystem` | `crypto.ts` | MoneySystem | 10 | 9 | 1 | mica, fincen |
| TaxReporting | `TaxReportingSystem` | `tax-reporting.ts` | MoneySystem | 12 | 12 |  | irs-reporting, fatca |
| Checks | `CheckSystem` | `checks.ts` | MoneySystem | 6 | 6 |  | ucc-article-4 |
| Wires | `WireSystem` | `wires.ts` | MoneySystem | 7 | 7 |  | ucc-article-4a |
| Governance | `GovernanceSystem` | `governance.ts` | VigilSurface | 4 | 3 | 1 | fca-handbook, iso-27001 |
| CustomerJourney | `CustomerJourneySystem` | `customer-journey.ts` | VigilSurface | 6 | 4 | 2 | fca-handbook, mica, udaap |
| Fees | `FeeSystem` | `fees.ts` | MoneySystem | 3 | 3 |  | udaap |
| DataProtection | `DataProtectionSystem` | `data-protection.ts` | VigilSurface | 7 | 7 |  | soc-2, hipaa |
| ThreeDS | `ThreeDSecureSystem` | `three-d-secure.ts` | CardAuthorizationSystem | 24 | 21 | 3 | 3ds |
| CardAuthorization | `CardAuthorizationSystem` | `card-authorization.ts` | CardVaultSystem | 6 | 6 |  | card-fraud-stolen |
| FraudDecision | `FraudDecisionSystem` | `fraud-decision.ts` | CardAuthorizationSystem | 23 | 19 | 4 | card-fraud-stolen |
| **Total** | | | | **380** | **346** | **34** | |

## Check IDs per surface

- **MoneySystem** (11): SOX-INT-01, SOX-INT-02, SOX-INT-04, SOX-INT-05, SOX-INT-06, SOX-INT-07, SOC2-AVL-01, SOC2-PI-01, SOC2-PI-02, SOC2-PI-03, SOC2-PI-04
- **CardVaultSystem** (8): PCI-ENC-02, PCI-ENC-03, PCI-ENC-04, PCI-ENC-06, PCI-ENC-07, PCI-ENC-08, PCI-LOG-01, PCI-LOG-02
- **IdentityAccessSystem** (7): PCI-ACC-01, PCI-ACC-02, PCI-ACC-03, PCI-ACC-04, GLBA-PRE-01, GLBA-PRE-02, GLBA-PRE-03
- **PrivacySystem** (41): GDPR-CON-01, GDPR-CON-03, GDPR-CON-04, GDPR-CON-05, GDPR-DEL-01, GDPR-DEL-02, GDPR-DEL-03, GDPR-DEL-04, GDPR-POR-01, GDPR-POR-02, GDPR-POR-03, GDPR-POR-04, GDPR-BRN-01, GDPR-BRN-02, GDPR-BRN-03, GDPR-BRN-04, CCPA-OPT-01, CCPA-OPT-02, CCPA-OPT-03, CCPA-OPT-04, CCPA-OPT-05, CCPA-ACC-01, CCPA-ACC-02, CCPA-ACC-03, CCPA-ACC-04, CCPA-SAL-01, CCPA-SAL-03, CCPA-SAL-04, GLBA-DIS-01, GLBA-DIS-02, STP-MTX-01, STP-MTX-03, STP-MTX-04, STP-MTX-05, STP-RTS-01, STP-RTS-02, STP-RTS-03, STP-RTS-04, STP-OPT-01, STP-OPT-02, STP-CON-01
- **OpenBankingSystem** (14): PSD2-SCA-01, PSD2-SCA-02, PSD2-SCA-03, PSD2-SCA-04, PSD2-XS2A-01, PSD2-XS2A-02, PSD2-XS2A-03, PSD2-XS2A-04, PSD2-CON-01, PSD2-CON-02, PSD2-CON-03, PSD2-TPP-01, PSD2-TPP-02, PSD2-TPP-03
- **OnboardingSystem** (30): BSA-KYC-02, BSA-KYC-03, BSA-KYC-04, BSA-KYC-05, BSA-KYC-06, PAT-CIP-01, PAT-CIP-02, PAT-CIP-03, PAT-CIP-04, PAT-CIP-05, PAT-CIP-06, PAT-CDD-01, PAT-CDD-02, PAT-CDD-03, PAT-CDD-04, PAT-CDD-05, PAT-EDD-01, PAT-EDD-02, PAT-EDD-03, PAT-BO-01, PAT-BO-02, PAT-BO-03, FATCA-DD-01, FATCA-DD-02, CDD-BO-01, CDD-BO-02, CDD-BO-03, CDD-CDD-01, CDD-CDD-02, CDD-CDD-03
- **ComplianceCaseSystem** (11): BSA-TM-01, BSA-TM-02, BSA-TM-03, BSA-TM-04, BSA-TM-05, BSA-SAR-01, BSA-SAR-02, BSA-SAR-03, BSA-SAR-04, FIN-SAR-01, FIN-SAR-02
- **ScreeningSystem** (16): BSA-OFAC-01, BSA-OFAC-02, BSA-OFAC-03, BSA-OFAC-04, BSA-OFAC-05, OFAC-SCR-02, OFAC-SCR-03, OFAC-SCR-04, OFAC-SCR-05, OFAC-BLK-01, OFAC-BLK-02, OFAC-BLK-03, OFAC-BLK-04, OFAC-REP-01, OFAC-REP-02, OFAC-REP-03
- **LedgerControlsSystem** (8): SOX-CTL-01, SOX-CTL-02, SOX-CTL-03, SOX-CTL-04, SOX-CTL-05, SOX-AUD-01, SOX-AUD-02, SOX-AUD-03
- **AchSystem** (13): NACHA-FMT-02, NACHA-FMT-03, NACHA-FMT-04, NACHA-FMT-05, NACHA-AUTH-01, NACHA-AUTH-02, NACHA-AUTH-03, NACHA-AUTH-04, NACHA-AUTH-05, NACHA-RET-01, NACHA-RET-02, NACHA-RET-03, NACHA-RET-04
- **DisputesSystem** (11): REGE-ERR-01, REGE-ERR-02, REGE-ERR-03, REGE-ERR-04, REGE-ERR-05, REGE-LIA-01, REGE-LIA-02, REGE-LIA-03, REGE-DIS-01, REGE-DIS-02, REGE-DIS-03
- **LendingSystem** (21): REGZ-APR-01, REGZ-APR-02, REGZ-APR-03, REGZ-APR-04, REGZ-FIN-02, REGZ-FIN-03, REGZ-FIN-04, REGZ-FIN-05, REGZ-RES-01, REGZ-RES-02, REGZ-RES-03, ECOA-AA-01, ECOA-AA-02, ECOA-PR-01, ECOA-PR-02, ECOA-PR-03, CRA-AA-01, CRA-LT-01, CRA-LT-02, CRA-CR-01, CRA-CR-02
- **MortgageSystem** (16): HMDA-LAR-01, HMDA-LAR-02, HMDA-LAR-03, HMDA-LAR-04, HMDA-REP-01, HMDA-REP-02, RESPA-DIS-02, RESPA-DIS-03, RESPA-KB-01, RESPA-ESC-01, RESPA-ESC-02, TRID-LE-01, TRID-LE-02, TRID-CD-01, TRID-CD-02, TRID-TIM-01
- **CollectionsSystem** (6): FDCPA-VN-01, FDCPA-VN-02, FDCPA-DSP-01, FDCPA-DSP-02, FDCPA-COM-01, FDCPA-COM-02
- **SecuritiesSystem** (27): SCI-SYS-03, SCI-INC-01, SCI-INC-02, FINRA-BR-01, FINRA-BR-02, FINRA-TR-01, FINRA-TR-02, FINRA-TR-03, FINRA-SUP-01, FINRA-SUP-02, FINRA-SUP-03, DFA-SW-01, DFA-SW-02, MIFID-BX-01, MIFID-BX-02, MIFID-BX-03, MIFID-TR-01, MIFID-TR-02, MIFID-UB-02, MIFID-UB-03, CB-COV-01, CB-COV-02, CB-COV-03, CB-TRF-01, CB-TRF-02, CB-RPT-01, CB-RPT-02
- **AdvisorySystem** (9): ADV-DIS-01, ADV-DIS-02, ADV-DIS-03, ADV-DIS-04, ADV-PERF-02, ADV-PERF-03, ADV-CUS-01, ADV-CUS-02, ADV-CUS-03
- **CapitalEngine** (13): DFA-ST-01, DFA-ST-02, DFA-ST-03, BASEL-RWA-01, BASEL-RWA-02, BASEL-RWA-03, BASEL-CAP-01, BASEL-CAP-02, BASEL-CAP-03, BASEL-LEV-01, BASEL-LEV-02, NAIC-RBC-01, NAIC-RBC-02
- **InsuranceSystem** (10): STINS-RATE-01, STINS-RATE-03, STINS-FORM-01, STINS-FORM-02, STINS-FORM-03, STINS-CLM-01, STINS-CLM-02, STINS-CLM-03, NAIC-FIN-01, NAIC-FIN-02
- **CryptoSystem** (10): MICA-LIC-01, MICA-LIC-02, MICA-RES-01, MICA-RES-02, MICA-RES-03, FIN-MSB-02, FIN-TR-01, FIN-TR-02, FIN-TR-03, FIN-TR-04
- **TaxReportingSystem** (12): IRS-1099-01, IRS-1099-02, IRS-1098-01, IRS-1098-02, IRS-1099K-01, IRS-1099K-02, IRS-BW-01, IRS-BW-02, FATCA-WH-01, FATCA-WH-02, FATCA-RPT-01, FATCA-RPT-02
- **CheckSystem** (6): UCC4-CHK-01, UCC4-CHK-02, UCC4-CHK-03, UCC4-RET-01, UCC4-RET-02, UCC4-NOT-01
- **WireSystem** (7): UCC4A-SEC-01, UCC4A-SEC-02, UCC4A-WIRE-01, UCC4A-WIRE-02, UCC4A-WIRE-03, UCC4A-ERR-01, UCC4A-ERR-02
- **GovernanceSystem** (4): FCA-SMCR-02, ISO-RA-01, ISO-RA-02, ISO-CTL-03
- **CustomerJourneySystem** (6): FCA-CD-02, FCA-CD-03, MICA-CP-01, MICA-CP-03, UDAAP-DEC-02, UDAAP-ABU-02
- **FeeSystem** (3): UDAAP-UNF-01, UDAAP-UNF-02, UDAAP-UNF-03
- **DataProtectionSystem** (7): SOC2-CONF-02, HIPAA-PHI-02, HIPAA-PHI-03, HIPAA-PHI-04, HIPAA-BAA-02, HIPAA-BRN-01, HIPAA-BRN-02
- **ThreeDSecureSystem** (24): 3DS-FLOW-01, 3DS-FLOW-02, 3DS-FLOW-03, 3DS-FLOW-04, 3DS-FLOW-05, 3DS-FLOW-06, 3DS-AV-01, 3DS-AV-02, 3DS-AV-03, 3DS-AV-04, 3DS-LIAB-01, 3DS-LIAB-02, 3DS-EXM-01, 3DS-EXM-02, 3DS-EXM-03, 3DS-EXM-04, 3DS-EXM-05, 3DS-EXM-06, 3DS-EXM-07, 3DS-ERR-01, 3DS-ERR-02, 3DS-ERR-03, 3DS-DATA-02, 3DS-DATA-03
- **CardAuthorizationSystem** (6): FRD-REF-01, FRD-REF-02, FRD-BLK-01, FRD-BLK-02, FRD-BLK-03, FRD-BLK-04
- **FraudDecisionSystem** (23): FRD-VEL-01, FRD-VEL-02, FRD-VEL-03, FRD-VEL-04, FRD-SIG-01, FRD-SIG-02, FRD-ATO-01, FRD-ATO-02, FRD-ATO-03, FRD-DEC-01, FRD-DEC-02, FRD-DEC-03, FRD-DEC-04, FRD-DEC-05, FRD-DEC-06, FRD-REL-01, FRD-REL-02, FRD-RPT-01, FRD-RPT-02, FRD-RPT-03, FRD-RPT-04, FRD-RPT-05, FRD-LEDG-01
