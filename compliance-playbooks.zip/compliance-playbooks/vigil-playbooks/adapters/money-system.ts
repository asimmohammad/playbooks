/**
 * DRAFT PLACEHOLDER — the canonical `MoneySystem` lives in the neobank harness (helix-portable).
 * Its real shape was NOT available when this was drafted; this is an ASSUMED minimal subset so the
 * extension surfaces type-check. Replace this file with a re-export of the canonical interface
 * (e.g. `export type { MoneySystem } from '<helix-portable>/money-system'`) and reconcile names.
 */
import type { Id, Money, OpResult, VigilSurface, AuditReader } from './common';

export interface Posting { account: Id; debit?: Money; credit?: Money }
export interface LedgerTxn { id: Id; at: string; kind: string; postings: readonly Posting[]; idempotencyKey?: string }

export interface MoneySystem extends VigilSurface, AuditReader {
  openAccount(input: { partyId: Id; product: string }): Promise<OpResult<{ accountId: Id }>>;
  balance(accountId: Id): Promise<Money>;
  /** A generic money movement; idempotencyKey replays return the original result. */
  move(input: { from: Id; to: Id; amount: Money; kind: string; idempotencyKey?: string; meta?: Record<string, unknown> }): Promise<OpResult<LedgerTxn>>;
  ledger(filter?: { accountId?: Id; kind?: string }): Promise<readonly LedgerTxn[]>;
  /** Σ debits − Σ credits across the whole ledger (LEDGER-CONSERVE expects zero). */
  trialBalance(): Promise<Money>;
}
