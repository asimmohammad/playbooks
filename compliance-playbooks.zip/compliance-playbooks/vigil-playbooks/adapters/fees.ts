/** DRAFT — Fee-engine surface (UDAAP unfair fees, overdraft/NSF). Fee schedule and ordering policy are configured. Types only. */
import type { Id, Money, OpResult } from './common';
import type { MoneySystem } from './money-system';
export interface FeeSystem extends MoneySystem {
  present(input: { account: Id; itemId: Id; amount: Money; representment?: number }): Promise<OpResult<{ fees: readonly { code: string; amount: Money }[] }>>;
  authorizeThenSettle(input: { account: Id; authAmount: Money; settleAmount: Money }): Promise<OpResult<{ fees: readonly { code: string; amount: Money }[] }>>;
  fees(account: Id): Promise<readonly { code: string; amount: Money; itemId: Id; reversed?: boolean }[]>;
  flagSystemError(input: { since: string }): Promise<{ reversed: number }>;
}
