---
helixPlaybookFormat: helix-playbook/0.1-proposal
playbookId: vigil-glba
title: "GLBA Safeguards, Pretexting & Privacy Notice"
declaredVersion: 0.1.0
intent: draft
applicability:
  languages: [javascript, typescript]
  scenarios: [pretexting-protection, disclosure]
---
# Helix portable playbook — DRAFT manifest · GLBA Safeguards, Pretexting & Privacy Notice

> **DRAFT — not LOCKED.** Proposed GLBA (Data Protection) playbook converted from Vigil skill `SK-GLBA-001`: one runner, two layers, **7 harness checks (2 static, incl. 2 static backstops, + 5 behavioural)**, plus 5 manual/evidence items listed separately because neither layer can verify them. Every invariant, layer and determinism call is **AI-drafted (Helix) and needs compliance review**. No detector or rule code exists yet. Before this manifest can be LOCKED, each row needs its detector/rule, a review, and a commit that adds the check alongside its row.

## Layers

- **static**: a repo-agnostic source scanner parameterised by a `VIGIL_GLBA` preset (no app specifics in the detector). It reads source / SQL / config / IaC / git-diff, **fails CLOSED** on a match, and runs with **no adapter**, so it is the CI gate. *Static backstops* (IDs `-5x`) prove a supporting source invariant for a named behavioural check, the way N-CAP-01 / N-STATE-01 back neobank behaviour. They fire even when the adapter never drives that path. Backstops of ⚑ SME checks stay out of the gate.
- **behavioural**: a rule written once against the canonical `MoneySystem` interface (or a DRAFT extension surface in `adapters/`) and driven through the app adapter. Surfaces needed: **IdentityAccessSystem** (`adapters/card-vault.ts`), **PrivacySystem** (`adapters/privacy.ts`). Every behavioural row reports NOT_EXERCISED until an adapter implements its surface. It returns **CHECKED only when it actually drove the guard's path**.
- **manual/evidence**: organisational process, live-infrastructure, statistical or retention evidence that no source scan or adapter-driven rule can prove. These are **outside the harness**, report `NOT_APPLICABLE` to it, and are tracked as evidence tasks, never as passes.

## Verdicts

`CHECKED` the path ran and the guard held · `FINDING` the guard was violated · `NOT_APPLICABLE` the invariant cannot apply here (incl. every manual/evidence item) · `NOT_EXERCISED` (glyph `????`) the adapter did not drive the path, so nothing is proven. NOT_EXERCISED is **surfaced distinctly and never counted as a pass** (no fake coverage). A ⚑ SME check with no approved parameter matrix reports `NOT_EXERCISED`, never `CHECKED`.

## How to run

- **Not runnable yet**: this draft defines invariants only (no detector/rule code). The intended shape mirrors the neobank playbook:
  - CI gate (adapter-free, blocks on any static FINDING): `run-static` with preset `VIGIL_GLBA`.
  - Full combined table (static + behavioural via the adapter): `run-all`.
- Machine-readable rows: `checks.json` (same IDs; includes source-scenario traceability and neobank overlaps).

## The draft inventory: 2 static + 5 behavioural = 7 checks

| ID | Layer | Deterministic | Invariant (one line) | Covers (automation point · common failure · regulation) |
| --- | --- | --- | --- | --- |
| **GLBA-PRE-01** | behavioural | yes | No customer information is disclosed or changed without passing verification; verification-vendor outage fails closed. | Pretexting protection · general control (no source failure) · GLBA |
| **GLBA-PRE-51** | static | yes | Support-tool account read/change endpoints require a verification-session token; verification-vendor errors deny. | backstop for GLBA-PRE-01 · Pretexting protection · general control (no source failure) · GLBA |
| **GLBA-PRE-02** | behavioural | yes | SIM-swap or recent contact change triggers step-up/cooling-off before high-risk actions; brute-force verification locks out at the configured count. | Pretexting protection · general control (no source failure) · GLBA |
| **GLBA-PRE-03** | behavioural | yes | Support-tool customer lookups are rate-limited and flagged above the configured volume. | Pretexting protection · general control (no source failure) · GLBA |
| **GLBA-DIS-01** | behavioural | yes | Opted-out customers are excluded from nonaffiliated sharing (configured exceptions only); the latest of concurrent preference changes wins downstream. | Disclosure · improper disclosure · GLBA |
| **GLBA-DIS-51** | static | yes | Nonaffiliated sharing feeds read the GLBA opt-out list at send time. | backstop for GLBA-DIS-01 · Disclosure · improper disclosure · GLBA |
| **GLBA-DIS-02** | behavioural | yes | The privacy notice is delivered at relationship start and a revised notice before a practice change; delivery failures retry via an alternate channel; a sharing change creates a notice-update task. | Disclosure · improper disclosure · GLBA |

## Outside the harness: manual/evidence (5)

These items are not harness checks. Each reports `NOT_APPLICABLE` to the runner and needs an owner and evidence on a schedule.

| ID | Layer | Deterministic | Invariant (one line) | Covers (automation point · common failure · regulation) |
| --- | --- | --- | --- | --- |
| **GLBA-SAF-01** | manual/evidence | no (manual) | All NPI systems meet the control baseline (MFA, session timeout and concurrent-session limits at configured values); NPI vendors have current assessments. | Safeguards rule · Missing safeguards · GLBA |
| **GLBA-SAF-02** | manual/evidence | no (manual) | Anomalous NPI access alerts within the configured window; a security event opens an incident with notification tasks and deadlines. | Safeguards rule · Missing safeguards · GLBA |
| **GLBA-SAF-03** | manual/evidence | no (manual) | Customer information is securely disposed after the configured period except under legal hold. | Safeguards rule · general control (no source failure) · GLBA |
| **GLBA-PRE-04** | manual/evidence | no (manual) | Verification attempts are retained. | Pretexting protection · general control (no source failure) · GLBA |
| **GLBA-DIS-03** | manual/evidence | no (manual) | Notice delivery records (version, channel, date) are retained. | Disclosure · general control (no source failure) · GLBA |

### Determinism

Every harness row (static and behavioural) is drafted as deterministic. Static detectors, including backstops, are pure functions of the committed source/config/diff. Behavioural rules each run against a **fresh `reset()` MoneySystem** (no state leaks between rules), driven by a **controllable clock**; deadlines, windows, expiries and cadences are asserted by advancing that clock, never by wall-clock reads, and no randomness affects a verdict. External dependencies (vendors, registries, feeds) are faked inside the adapter, which is how fault-injection rows stay deterministic. Manual/evidence rows are not deterministic and are not gate checks.

### Coverage note

Converted from 24 AI-drafted source scenarios of `SK-GLBA-001`; each source scenario maps to exactly one non-backstop row (see the appendix). Static backstops add no scenarios and trace through the check they back. The scenarios were merged into crisp invariants by automation point and failure mode, across categories (positive, negative, boundary, failure/recovery, concurrency/idempotency, retention/audit, common failure, core). Automation points covered: Safeguards rule, Pretexting protection, Disclosure. Source common failures: Missing safeguards, improper disclosure. Thresholds, windows and deadlines are *configured* parameters, not asserted statutory values. No regulation or citation was added beyond the source sheet.

### Overlap with the locked neobank playbook (19 checks)

None. This playbook's invariants are not covered by the neobank set.

### Review flags

- No SME-flagged rows. All rows still need compliance review.

## Appendix: traceability to source scenarios

| Check ID | Source scenario IDs | Categories merged |
| --- | --- | --- |
| GLBA-SAF-01 | SC-GLBA-001-01, SC-GLBA-001-14, SC-GLBA-001-15, SC-GLBA-001-16, SC-GLBA-001-05 | Boundary/Edge, Common Failure, Concurrency/Idempotency, Core, Positive |
| GLBA-SAF-02 | SC-GLBA-001-06, SC-GLBA-001-07 | Failure/Recovery, Negative |
| GLBA-SAF-03 | SC-GLBA-001-04 | Retention/Audit |
| GLBA-PRE-01 | SC-GLBA-001-02, SC-GLBA-001-17, SC-GLBA-001-19 | Core, Failure/Recovery, Positive |
| GLBA-PRE-51 | — (static backstop; traced via GLBA-PRE-01) | — |
| GLBA-PRE-02 | SC-GLBA-001-08, SC-GLBA-001-18, SC-GLBA-001-09 | Boundary/Edge, Common Failure, Negative |
| GLBA-PRE-03 | SC-GLBA-001-10 | Concurrency/Idempotency |
| GLBA-PRE-04 | SC-GLBA-001-20 | Retention/Audit |
| GLBA-DIS-01 | SC-GLBA-001-11, SC-GLBA-001-21, SC-GLBA-001-23 | Concurrency/Idempotency, Negative, Positive |
| GLBA-DIS-51 | — (static backstop; traced via GLBA-DIS-01) | — |
| GLBA-DIS-02 | SC-GLBA-001-03, SC-GLBA-001-12, SC-GLBA-001-22, SC-GLBA-001-24 | Boundary/Edge, Common Failure, Core, Failure/Recovery |
| GLBA-DIS-03 | SC-GLBA-001-13 | Retention/Audit |

# Helix review rules

Generated from `checks.json` (7 static and behavioural checks; manual/evidence items are not code-reviewable and are omitted). Severity is derived from the playbook priority (P1 -> MEDIUM); Category MM marks money-movement checks. Rule text is the source invariant, unchanged; it is AI-drafted and needs compliance review.

## Rule GLBA-PRE-01: No customer information is disclosed or changed without passing verification
Severity: MEDIUM
Category: NON_MM
Scenario: pretexting-protection
Requirement: MUST
Invariant: No customer information is disclosed or changed without passing verification; verification-vendor outage fails closed.

Source check `GLBA-PRE-01` from `checks.json` (behavioural; deterministic: yes). Covers: Pretexting protection · None · GLBA. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-GLBA-003, RR-GLBA-002.

## Rule GLBA-PRE-51: Support-tool account read/change endpoints require a verification-session token
Severity: MEDIUM
Category: NON_MM
Scenario: pretexting-protection
Requirement: MUST
Invariant: Support-tool account read/change endpoints require a verification-session token; verification-vendor errors deny.

Source check `GLBA-PRE-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: Pretexting protection · None · GLBA. Backstop for GLBA-PRE-01. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-GLBA-003, RR-GLBA-002.

## Rule GLBA-PRE-02: SIM-swap or recent contact change triggers step-up/cooling-off before high-risk actions
Severity: MEDIUM
Category: NON_MM
Scenario: pretexting-protection
Requirement: MUST
Invariant: SIM-swap or recent contact change triggers step-up/cooling-off before high-risk actions; brute-force verification locks out at the configured count.

Source check `GLBA-PRE-02` from `checks.json` (behavioural; deterministic: yes). Covers: Pretexting protection · None · GLBA. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-GLBA-003, RR-FFIEC-002.

## Rule GLBA-PRE-03: Support-tool customer lookups are rate-limited and flagged above the configured volume
Severity: MEDIUM
Category: NON_MM
Scenario: pretexting-protection
Requirement: MUST
Invariant: Support-tool customer lookups are rate-limited and flagged above the configured volume.

Source check `GLBA-PRE-03` from `checks.json` (behavioural; deterministic: yes). Covers: Pretexting protection · None · GLBA. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-GLBA-003, RR-GLBA-002.

## Rule GLBA-DIS-01: Opted-out customers are excluded from nonaffiliated sharing (configured exceptions only)
Severity: MEDIUM
Category: NON_MM
Scenario: disclosure
Requirement: MUST
Invariant: Opted-out customers are excluded from nonaffiliated sharing (configured exceptions only); the latest of concurrent preference changes wins downstream.

Source check `GLBA-DIS-01` from `checks.json` (behavioural; deterministic: yes). Covers: Disclosure · improper disclosure · GLBA. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-GLBA-001.

## Rule GLBA-DIS-51: Nonaffiliated sharing feeds read the GLBA opt-out list at send time
Severity: MEDIUM
Category: NON_MM
Scenario: disclosure
Requirement: MUST
Invariant: Nonaffiliated sharing feeds read the GLBA opt-out list at send time.

Source check `GLBA-DIS-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: Disclosure · improper disclosure · GLBA. Backstop for GLBA-DIS-01. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-GLBA-001.

## Rule GLBA-DIS-02: The privacy notice is delivered at relationship start and a revised notice before a practice change
Severity: MEDIUM
Category: NON_MM
Scenario: disclosure
Requirement: MUST
Invariant: The privacy notice is delivered at relationship start and a revised notice before a practice change; delivery failures retry via an alternate channel; a sharing change creates a notice-update task.

Source check `GLBA-DIS-02` from `checks.json` (behavioural; deterministic: yes). Covers: Disclosure · improper disclosure · GLBA. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-GLBA-001.
