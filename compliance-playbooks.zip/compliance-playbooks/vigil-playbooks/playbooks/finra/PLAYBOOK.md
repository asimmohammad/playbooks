---
helixPlaybookFormat: helix-playbook/0.1-proposal
playbookId: vigil-finra
title: "FINRA Books & Records, Trade Reporting, Supervision"
declaredVersion: 0.1.0
intent: draft
applicability:
  languages: [javascript, typescript]
  scenarios: [books-records, trade-reporting, supervision]
---
# Helix portable playbook — DRAFT manifest · FINRA Books & Records, Trade Reporting, Supervision

> **DRAFT — not LOCKED.** Proposed FINRA Rules (Securities) playbook converted from Vigil skill `SK-FINRA-001`: one runner, two layers, **12 harness checks (4 static, incl. 3 static backstops, + 8 behavioural)**, plus 2 manual/evidence items listed separately because neither layer can verify them. Every invariant, layer and determinism call is **AI-drafted (Helix) and needs compliance review**. No detector or rule code exists yet. Before this manifest can be LOCKED, each row needs its detector/rule, a review, and a commit that adds the check alongside its row.

## Layers

- **static**: a repo-agnostic source scanner parameterised by a `VIGIL_FINRA` preset (no app specifics in the detector). It reads source / SQL / config / IaC / git-diff, **fails CLOSED** on a match, and runs with **no adapter**, so it is the CI gate. *Static backstops* (IDs `-5x`) prove a supporting source invariant for a named behavioural check, the way N-CAP-01 / N-STATE-01 back neobank behaviour. They fire even when the adapter never drives that path. Backstops of ⚑ SME checks stay out of the gate.
- **behavioural**: a rule written once against the canonical `MoneySystem` interface (or a DRAFT extension surface in `adapters/`) and driven through the app adapter. Surfaces needed: **SecuritiesSystem** (`adapters/securities.ts`). Every behavioural row reports NOT_EXERCISED until an adapter implements its surface. It returns **CHECKED only when it actually drove the guard's path**.
- **manual/evidence**: organisational process, live-infrastructure, statistical or retention evidence that no source scan or adapter-driven rule can prove. These are **outside the harness**, report `NOT_APPLICABLE` to it, and are tracked as evidence tasks, never as passes.

## Verdicts

`CHECKED` the path ran and the guard held · `FINDING` the guard was violated · `NOT_APPLICABLE` the invariant cannot apply here (incl. every manual/evidence item) · `NOT_EXERCISED` (glyph `????`) the adapter did not drive the path, so nothing is proven. NOT_EXERCISED is **surfaced distinctly and never counted as a pass** (no fake coverage). A ⚑ SME check with no approved parameter matrix reports `NOT_EXERCISED`, never `CHECKED`.

## How to run

- **Not runnable yet**: this draft defines invariants only (no detector/rule code). The intended shape mirrors the neobank playbook:
  - CI gate (adapter-free, blocks on any static FINDING): `run-static` with preset `VIGIL_FINRA`.
  - Full combined table (static + behavioural via the adapter): `run-all`.
- Machine-readable rows: `checks.json` (same IDs; includes source-scenario traceability and neobank overlaps).

## The draft inventory: 4 static + 8 behavioural = 12 checks

| ID | Layer | Deterministic | Invariant (one line) | Covers (automation point · common failure · regulation) |
| --- | --- | --- | --- | --- |
| **FINRA-BR-01** | behavioural | yes | Every approved business-communication channel is archived once (incl. concurrent writes) with metadata, immutable and retrievable within SLA; a failed archive write retries and alerts. | Books & records · Missing record · FINRA Rules |
| **FINRA-BR-02** | behavioural | yes | Records are deletable only after the configured retention expiry (controllable clock) and never while under legal hold. | Books & records · Missing record · FINRA Rules |
| **FINRA-BR-51** | static | yes | The record-purge job filters out legal-hold records and records younger than the configured retention. | backstop for FINRA-BR-02 · Books & records · Missing record · FINRA Rules |
| **FINRA-BR-03** | static | yes | A new communication channel in config is either capture-configured or blocked. | Books & records · Missing record · FINRA Rules |
| **FINRA-TR-01** | behavioural | yes | Each reportable trade yields exactly one correctly formatted report within the configured deadline (non-reportable yields none); corrections/cancels reference the original. | Trade reporting · late reporting · FINRA Rules |
| **FINRA-TR-02** | behavioural | yes | Retries never produce a second accepted report for a trade event. | Trade reporting · late reporting · FINRA Rules |
| **FINRA-TR-51** | static | yes | Trade-report submission is keyed by a unique trade-event ID (no second accepted report). | backstop for FINRA-TR-02 · Trade reporting · late reporting · FINRA Rules |
| **FINRA-TR-03** | behavioural | yes | On adapter outage reports queue and submit in order; those past deadline are flagged late with reason and escalated (controllable clock). | Trade reporting · late reporting · FINRA Rules |
| **FINRA-SUP-01** | behavioural | yes | Every flagged item (incl. lexicon hits) routes to a qualified supervisor other than the actor; self- or unqualified sign-off is rejected. | Supervision · general control (no source failure) · FINRA Rules |
| **FINRA-SUP-51** | static | yes | The supervisory sign-off handler rejects reviewer = actor and checks the qualified-supervisor role. | backstop for FINRA-SUP-01 · Supervision · general control (no source failure) · FINRA Rules |
| **FINRA-SUP-02** | behavioural | yes | An item gets exactly one recorded supervisory decision under concurrency. | Supervision · general control (no source failure) · FINRA Rules |
| **FINRA-SUP-03** | behavioural | yes | Reviews escalate at the configured SLA boundary and an unavailable supervisor's queue reassigns to a qualified backup. | Supervision · general control (no source failure) · FINRA Rules |

## Outside the harness: manual/evidence (2)

These items are not harness checks. Each reports `NOT_APPLICABLE` to the runner and needs an owner and evidence on a schedule.

| ID | Layer | Deterministic | Invariant (one line) | Covers (automation point · common failure · regulation) |
| --- | --- | --- | --- | --- |
| **FINRA-TR-04** | manual/evidence | no (manual) | Report timestamps are at the configured granularity with clock drift alerts; reports and acknowledgements retained. | Trade reporting · late reporting · FINRA Rules |
| **FINRA-SUP-04** | manual/evidence | no (manual) | Supervisory review evidence (reviewer, timestamp, action) is retained. | Supervision · general control (no source failure) · FINRA Rules |

### Determinism

Every harness row (static and behavioural) is drafted as deterministic. Static detectors, including backstops, are pure functions of the committed source/config/diff. Behavioural rules each run against a **fresh `reset()` MoneySystem** (no state leaks between rules), driven by a **controllable clock**; deadlines, windows, expiries and cadences are asserted by advancing that clock, never by wall-clock reads, and no randomness affects a verdict. External dependencies (vendors, registries, feeds) are faked inside the adapter, which is how fault-injection rows stay deterministic. Manual/evidence rows are not deterministic and are not gate checks.

### Coverage note

Converted from 24 AI-drafted source scenarios of `SK-FINRA-001`; each source scenario maps to exactly one non-backstop row (see the appendix). Static backstops add no scenarios and trace through the check they back. The scenarios were merged into crisp invariants by automation point and failure mode, across categories (positive, negative, boundary, failure/recovery, concurrency/idempotency, retention/audit, common failure, core). Automation points covered: Books & records, Trade reporting, Supervision. Source common failures: Missing record, late reporting. Thresholds, windows and deadlines are *configured* parameters, not asserted statutory values. No regulation or citation was added beyond the source sheet.

### Overlap with the locked neobank playbook (19 checks)

| This check | Neobank check | Strength | Why |
| --- | --- | --- | --- |
| FINRA-TR-02 | N-IDEMP-01 | related | one accepted report per event |
| FINRA-TR-51 | N-IDEMP-01 | related | unique-key dedupe on the write path |
| FINRA-SUP-02 | N-CAS-01 | related | one decision per item |

`same` means the neobank check already enforces this invariant, so reuse it instead of re-implementing. `related` means the same defect class, but this check needs its own rule or preset.

### Review flags

- No SME-flagged rows. All rows still need compliance review.

## Appendix: traceability to source scenarios

| Check ID | Source scenario IDs | Categories merged |
| --- | --- | --- |
| FINRA-BR-01 | SC-FINRA-001-01, SC-FINRA-001-04, SC-FINRA-001-06, SC-FINRA-001-15, SC-FINRA-001-16 | Concurrency/Idempotency, Core, Failure/Recovery, Positive, Retention/Audit |
| FINRA-BR-02 | SC-FINRA-001-14, SC-FINRA-001-05 | Boundary/Edge, Negative |
| FINRA-BR-51 | — (static backstop; traced via FINRA-BR-02) | — |
| FINRA-BR-03 | SC-FINRA-001-17 | Common Failure |
| FINRA-TR-01 | SC-FINRA-001-02, SC-FINRA-001-07, SC-FINRA-001-18 | Core, Negative, Positive |
| FINRA-TR-02 | SC-FINRA-001-09 | Concurrency/Idempotency |
| FINRA-TR-51 | — (static backstop; traced via FINRA-TR-02) | — |
| FINRA-TR-03 | SC-FINRA-001-08, SC-FINRA-001-20 | Common Failure, Failure/Recovery |
| FINRA-TR-04 | SC-FINRA-001-10, SC-FINRA-001-19 | Boundary/Edge, Retention/Audit |
| FINRA-SUP-01 | SC-FINRA-001-03, SC-FINRA-001-11, SC-FINRA-001-12, SC-FINRA-001-24 | Common Failure, Core, Negative, Positive |
| FINRA-SUP-51 | — (static backstop; traced via FINRA-SUP-01) | — |
| FINRA-SUP-02 | SC-FINRA-001-23 | Concurrency/Idempotency |
| FINRA-SUP-03 | SC-FINRA-001-21, SC-FINRA-001-22 | Boundary/Edge, Failure/Recovery |
| FINRA-SUP-04 | SC-FINRA-001-13 | Retention/Audit |

# Helix review rules

Generated from `checks.json` (12 static and behavioural checks; manual/evidence items are not code-reviewable and are omitted). Severity is derived from the playbook priority (P1 -> MEDIUM); Category MM marks money-movement checks. Rule text is the source invariant, unchanged; it is AI-drafted and needs compliance review.

## Rule FINRA-BR-01: Every approved business-communication channel is archived once (incl
Severity: MEDIUM
Category: NON_MM
Scenario: books-records
Requirement: MUST
Invariant: Every approved business-communication channel is archived once (incl. concurrent writes) with metadata, immutable and retrievable within SLA; a failed archive write retries and alerts.

Source check `FINRA-BR-01` from `checks.json` (behavioural; deterministic: yes). Covers: Books & records · Missing record · FINRA Rules. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-FINRA-002, RR-SEC-003.

## Rule FINRA-BR-02: Records are deletable only after the configured retention expiry (controllable clock) and never w...
Severity: MEDIUM
Category: NON_MM
Scenario: books-records
Requirement: MUST
Invariant: Records are deletable only after the configured retention expiry (controllable clock) and never while under legal hold.

Source check `FINRA-BR-02` from `checks.json` (behavioural; deterministic: yes). Covers: Books & records · Missing record · FINRA Rules. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-FINRA-002, RR-SEC-003.

## Rule FINRA-BR-51: The record-purge job filters out legal-hold records and records younger than the configured reten...
Severity: MEDIUM
Category: NON_MM
Scenario: books-records
Requirement: MUST
Invariant: The record-purge job filters out legal-hold records and records younger than the configured retention.

Source check `FINRA-BR-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: Books & records · Missing record · FINRA Rules. Backstop for FINRA-BR-02. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-FINRA-002, RR-SEC-003.

## Rule FINRA-BR-03: A new communication channel in config is either capture-configured or blocked
Severity: MEDIUM
Category: NON_MM
Scenario: books-records
Requirement: MUST
Invariant: A new communication channel in config is either capture-configured or blocked.

Source check `FINRA-BR-03` from `checks.json` (static; deterministic: yes). Covers: Books & records · Missing record · FINRA Rules. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-FINRA-002, RR-SEC-003.

## Rule FINRA-TR-01: Each reportable trade yields exactly one correctly formatted report within the configured deadlin...
Severity: MEDIUM
Category: NON_MM
Scenario: trade-reporting
Requirement: MUST
Invariant: Each reportable trade yields exactly one correctly formatted report within the configured deadline (non-reportable yields none); corrections/cancels reference the original.

Source check `FINRA-TR-01` from `checks.json` (behavioural; deterministic: yes). Covers: Trade reporting · late reporting · FINRA Rules. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-FINRA-004.

## Rule FINRA-TR-02: Retries never produce a second accepted report for a trade event
Severity: MEDIUM
Category: NON_MM
Scenario: trade-reporting
Requirement: MUST
Invariant: Retries never produce a second accepted report for a trade event.

Source check `FINRA-TR-02` from `checks.json` (behavioural; deterministic: yes). Covers: Trade reporting · late reporting · FINRA Rules. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-FINRA-004.

## Rule FINRA-TR-51: Trade-report submission is keyed by a unique trade-event ID (no second accepted report)
Severity: MEDIUM
Category: NON_MM
Scenario: trade-reporting
Requirement: MUST
Invariant: Trade-report submission is keyed by a unique trade-event ID (no second accepted report).

Source check `FINRA-TR-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: Trade reporting · late reporting · FINRA Rules. Backstop for FINRA-TR-02. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-FINRA-004.

## Rule FINRA-TR-03: On adapter outage reports queue and submit in order
Severity: MEDIUM
Category: NON_MM
Scenario: trade-reporting
Requirement: MUST
Invariant: On adapter outage reports queue and submit in order; those past deadline are flagged late with reason and escalated (controllable clock).

Source check `FINRA-TR-03` from `checks.json` (behavioural; deterministic: yes). Covers: Trade reporting · late reporting · FINRA Rules. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-FINRA-004.

## Rule FINRA-SUP-01: Every flagged item (incl
Severity: MEDIUM
Category: NON_MM
Scenario: supervision
Requirement: MUST
Invariant: Every flagged item (incl. lexicon hits) routes to a qualified supervisor other than the actor; self- or unqualified sign-off is rejected.

Source check `FINRA-SUP-01` from `checks.json` (behavioural; deterministic: yes). Covers: Supervision · None · FINRA Rules. Review status in source: Drafted (AI) – needs compliance review.

## Rule FINRA-SUP-51: The supervisory sign-off handler rejects reviewer = actor and checks the qualified-supervisor role
Severity: MEDIUM
Category: NON_MM
Scenario: supervision
Requirement: MUST
Invariant: The supervisory sign-off handler rejects reviewer = actor and checks the qualified-supervisor role.

Source check `FINRA-SUP-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: Supervision · None · FINRA Rules. Backstop for FINRA-SUP-01. Review status in source: Drafted (AI) – needs compliance review.

## Rule FINRA-SUP-02: An item gets exactly one recorded supervisory decision under concurrency
Severity: MEDIUM
Category: NON_MM
Scenario: supervision
Requirement: MUST
Invariant: An item gets exactly one recorded supervisory decision under concurrency.

Source check `FINRA-SUP-02` from `checks.json` (behavioural; deterministic: yes). Covers: Supervision · None · FINRA Rules. Review status in source: Drafted (AI) – needs compliance review.

## Rule FINRA-SUP-03: Reviews escalate at the configured SLA boundary and an unavailable supervisor's queue reassigns t...
Severity: MEDIUM
Category: NON_MM
Scenario: supervision
Requirement: MUST
Invariant: Reviews escalate at the configured SLA boundary and an unavailable supervisor's queue reassigns to a qualified backup.

Source check `FINRA-SUP-03` from `checks.json` (behavioural; deterministic: yes). Covers: Supervision · None · FINRA Rules. Review status in source: Drafted (AI) – needs compliance review.
