---
helixPlaybookFormat: helix-playbook/0.1-proposal
playbookId: vigil-hipaa
title: "HIPAA PHI Protection, BAAs & Breach"
declaredVersion: 0.1.0
intent: draft
applicability:
  languages: [javascript, typescript]
  scenarios: [phi-protection, baas, breach-notification]
---
# Helix portable playbook — DRAFT manifest · HIPAA PHI Protection, BAAs & Breach

> **DRAFT — not LOCKED.** Proposed HIPAA (Healthcare FinTech) playbook converted from Vigil skill `SK-HIPAA-001`: one runner, two layers, **11 harness checks (5 static, incl. 3 static backstops, + 6 behavioural)**, plus 3 manual/evidence items listed separately because neither layer can verify them. Every invariant, layer and determinism call is **AI-drafted (Helix) and needs compliance review**. No detector or rule code exists yet. Before this manifest can be LOCKED, each row needs its detector/rule, a review, and a commit that adds the check alongside its row.

## Layers

- **static**: a repo-agnostic source scanner parameterised by a `VIGIL_HIPAA` preset (no app specifics in the detector). It reads source / SQL / config / IaC / git-diff, **fails CLOSED** on a match, and runs with **no adapter**, so it is the CI gate. *Static backstops* (IDs `-5x`) prove a supporting source invariant for a named behavioural check, the way N-CAP-01 / N-STATE-01 back neobank behaviour. They fire even when the adapter never drives that path. Backstops of ⚑ SME checks stay out of the gate.
- **behavioural**: a rule written once against the canonical `MoneySystem` interface (or a DRAFT extension surface in `adapters/`) and driven through the app adapter. Surfaces needed: **DataProtectionSystem** (`adapters/data-protection.ts`). Every behavioural row reports NOT_EXERCISED until an adapter implements its surface. It returns **CHECKED only when it actually drove the guard's path**.
- **manual/evidence**: organisational process, live-infrastructure, statistical or retention evidence that no source scan or adapter-driven rule can prove. These are **outside the harness**, report `NOT_APPLICABLE` to it, and are tracked as evidence tasks, never as passes.

## Verdicts

`CHECKED` the path ran and the guard held · `FINDING` the guard was violated · `NOT_APPLICABLE` the invariant cannot apply here (incl. every manual/evidence item) · `NOT_EXERCISED` (glyph `????`) the adapter did not drive the path, so nothing is proven. NOT_EXERCISED is **surfaced distinctly and never counted as a pass** (no fake coverage). A ⚑ SME check with no approved parameter matrix reports `NOT_EXERCISED`, never `CHECKED`.

## How to run

- **Not runnable yet**: this draft defines invariants only (no detector/rule code). The intended shape mirrors the neobank playbook:
  - CI gate (adapter-free, blocks on any static FINDING): `run-static` with preset `VIGIL_HIPAA`.
  - Full combined table (static + behavioural via the adapter): `run-all`.
- Machine-readable rows: `checks.json` (same IDs; includes source-scenario traceability and neobank overlaps).

## The draft inventory: 5 static + 6 behavioural = 11 checks

| ID | Layer | Deterministic | Invariant (one line) | Covers (automation point · common failure · regulation) |
| --- | --- | --- | --- | --- |
| **HIPAA-PHI-01** | static | yes | PHI fields are encrypted in every store and in transit, and PHI never reaches logs or non-approved stores. | PHI protection · Unencrypted PHI · HIPAA |
| **HIPAA-PHI-02** | behavioural | yes | Each role receives only its configured minimum-necessary PHI fields; every access is logged with purpose; denials logged. | PHI protection · Unencrypted PHI · HIPAA |
| **HIPAA-PHI-51** | static | yes | PHI read endpoints use role-scoped field projections (no SELECT * on PHI tables) and log access with purpose. | backstop for HIPAA-PHI-02 · PHI protection · Unencrypted PHI · HIPAA |
| **HIPAA-PHI-03** | behavioural | yes | Encryption-key outage fails closed for PHI — no plaintext fallback. | PHI protection · Unencrypted PHI · HIPAA |
| **HIPAA-PHI-52** | static | yes | Encryption-key failure handling for PHI throws — no plaintext fallback. | backstop for HIPAA-PHI-03 · PHI protection · Unencrypted PHI · HIPAA |
| **HIPAA-PHI-04** | behavioural | yes | Every PHI export, including concurrent ones, is logged; no unlogged copy. | PHI protection · general control (no source failure) · HIPAA |
| **HIPAA-BAA-01** | static | yes | An integration sending PHI to a vendor without a BAA mapping is blocked pre-deploy. | BAAs · missing BAA · HIPAA |
| **HIPAA-BAA-02** | behavioural | yes | PHI flows only to vendors with an active BAA (BAA ID recorded per transfer); expiry/termination suspends flows; an unavailable BAA register blocks transfers. | BAAs · missing BAA · HIPAA |
| **HIPAA-BAA-51** | static | yes | PHI transfer code checks the BAA register's active status/expiry before sending. | backstop for HIPAA-BAA-02 · BAAs · missing BAA · HIPAA |
| **HIPAA-BRN-01** | behavioural | yes | Breach discovery starts the configured notification clocks per audience and size threshold; confirmed breaches create tasks, low-risk incidents document rationale without notifying; deadlines escalate. | Breach notification · general control (no source failure) · HIPAA |
| **HIPAA-BRN-02** | behavioural | yes | Multiple incidents affecting the same individuals do not duplicate notifications. | Breach notification · general control (no source failure) · HIPAA |

## Outside the harness: manual/evidence (3)

These items are not harness checks. Each reports `NOT_APPLICABLE` to the runner and needs an owner and evidence on a schedule.

| ID | Layer | Deterministic | Invariant (one line) | Covers (automation point · common failure · regulation) |
| --- | --- | --- | --- | --- |
| **HIPAA-PHI-05** | manual/evidence | no (manual) | PHI access audit logs are immutable and retained. | PHI protection · general control (no source failure) · HIPAA |
| **HIPAA-BAA-03** | manual/evidence | no (manual) | BAAs and vendor assessments are retained. | BAAs · general control (no source failure) · HIPAA |
| **HIPAA-BRN-03** | manual/evidence | no (manual) | Encrypted-data incidents document the encryption/key-status risk assessment; breach assessments are retained. | Breach notification · general control (no source failure) · HIPAA |

### Determinism

Every harness row (static and behavioural) is drafted as deterministic. Static detectors, including backstops, are pure functions of the committed source/config/diff. Behavioural rules each run against a **fresh `reset()` MoneySystem** (no state leaks between rules), driven by a **controllable clock**; deadlines, windows, expiries and cadences are asserted by advancing that clock, never by wall-clock reads, and no randomness affects a verdict. External dependencies (vendors, registries, feeds) are faked inside the adapter, which is how fault-injection rows stay deterministic. Manual/evidence rows are not deterministic and are not gate checks.

### Coverage note

Converted from 24 AI-drafted source scenarios of `SK-HIPAA-001`; each source scenario maps to exactly one non-backstop row (see the appendix). Static backstops add no scenarios and trace through the check they back. The scenarios were merged into crisp invariants by automation point and failure mode, across categories (positive, negative, boundary, failure/recovery, concurrency/idempotency, retention/audit, common failure, core). Automation points covered: PHI protection, BAAs, Breach notification. Source common failures: Unencrypted PHI, missing BAA. Thresholds, windows and deadlines are *configured* parameters, not asserted statutory values. No regulation or citation was added beyond the source sheet.

### Overlap with the locked neobank playbook (19 checks)

None. This playbook's invariants are not covered by the neobank set.

### Review flags

- No SME-flagged rows. All rows still need compliance review.

## Appendix: traceability to source scenarios

| Check ID | Source scenario IDs | Categories merged |
| --- | --- | --- |
| HIPAA-PHI-01 | SC-HIPAA-001-01, SC-HIPAA-001-04 | Common Failure, Core |
| HIPAA-PHI-02 | SC-HIPAA-001-05, SC-HIPAA-001-11, SC-HIPAA-001-12 | Boundary/Edge, Negative, Positive |
| HIPAA-PHI-51 | — (static backstop; traced via HIPAA-PHI-02) | — |
| HIPAA-PHI-03 | SC-HIPAA-001-13 | Failure/Recovery |
| HIPAA-PHI-52 | — (static backstop; traced via HIPAA-PHI-03) | — |
| HIPAA-PHI-04 | SC-HIPAA-001-14 | Concurrency/Idempotency |
| HIPAA-PHI-05 | SC-HIPAA-001-06 | Retention/Audit |
| HIPAA-BAA-01 | SC-HIPAA-001-07, SC-HIPAA-001-19 | Common Failure, Negative |
| HIPAA-BAA-02 | SC-HIPAA-001-02, SC-HIPAA-001-15, SC-HIPAA-001-08, SC-HIPAA-001-17, SC-HIPAA-001-16 | Boundary/Edge, Concurrency/Idempotency, Core, Failure/Recovery, Positive |
| HIPAA-BAA-51 | — (static backstop; traced via HIPAA-BAA-02) | — |
| HIPAA-BAA-03 | SC-HIPAA-001-18 | Retention/Audit |
| HIPAA-BRN-01 | SC-HIPAA-001-03, SC-HIPAA-001-09, SC-HIPAA-001-20, SC-HIPAA-001-21, SC-HIPAA-001-24 | Boundary/Edge, Common Failure, Core, Negative, Positive |
| HIPAA-BRN-02 | SC-HIPAA-001-22 | Concurrency/Idempotency |
| HIPAA-BRN-03 | SC-HIPAA-001-10, SC-HIPAA-001-23 | Failure/Recovery, Retention/Audit |

# Helix review rules

Generated from `checks.json` (11 static and behavioural checks; manual/evidence items are not code-reviewable and are omitted). Severity is derived from the playbook priority (P2 -> LOW); Category MM marks money-movement checks. Rule text is the source invariant, unchanged; it is AI-drafted and needs compliance review.

## Rule HIPAA-PHI-01: PHI fields are encrypted in every store and in transit, and PHI never reaches logs or non-approve...
Severity: LOW
Category: NON_MM
Scenario: phi-protection
Requirement: MUST
Invariant: PHI fields are encrypted in every store and in transit, and PHI never reaches logs or non-approved stores.

Source check `HIPAA-PHI-01` from `checks.json` (static; deterministic: yes). Covers: PHI protection · Unencrypted PHI · HIPAA. Review status in source: Drafted (AI) – needs compliance review.

## Rule HIPAA-PHI-02: Each role receives only its configured minimum-necessary PHI fields
Severity: LOW
Category: NON_MM
Scenario: phi-protection
Requirement: MUST
Invariant: Each role receives only its configured minimum-necessary PHI fields; every access is logged with purpose; denials logged.

Source check `HIPAA-PHI-02` from `checks.json` (behavioural; deterministic: yes). Covers: PHI protection · Unencrypted PHI · HIPAA. Review status in source: Drafted (AI) – needs compliance review.

## Rule HIPAA-PHI-51: PHI read endpoints use role-scoped field projections (no SELECT * on PHI tables) and log access w...
Severity: LOW
Category: NON_MM
Scenario: phi-protection
Requirement: MUST
Invariant: PHI read endpoints use role-scoped field projections (no SELECT * on PHI tables) and log access with purpose.

Source check `HIPAA-PHI-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: PHI protection · Unencrypted PHI · HIPAA. Backstop for HIPAA-PHI-02. Review status in source: Drafted (AI) – needs compliance review.

## Rule HIPAA-PHI-03: Encryption-key outage fails closed for PHI — no plaintext fallback
Severity: LOW
Category: NON_MM
Scenario: phi-protection
Requirement: MUST
Invariant: Encryption-key outage fails closed for PHI — no plaintext fallback.

Source check `HIPAA-PHI-03` from `checks.json` (behavioural; deterministic: yes). Covers: PHI protection · Unencrypted PHI · HIPAA. Review status in source: Drafted (AI) – needs compliance review.

## Rule HIPAA-PHI-52: Encryption-key failure handling for PHI throws — no plaintext fallback
Severity: LOW
Category: NON_MM
Scenario: phi-protection
Requirement: MUST
Invariant: Encryption-key failure handling for PHI throws — no plaintext fallback.

Source check `HIPAA-PHI-52` from `checks.json` (static, static backstop; deterministic: yes). Covers: PHI protection · Unencrypted PHI · HIPAA. Backstop for HIPAA-PHI-03. Review status in source: Drafted (AI) – needs compliance review.

## Rule HIPAA-PHI-04: Every PHI export, including concurrent ones, is logged
Severity: LOW
Category: NON_MM
Scenario: phi-protection
Requirement: MUST
Invariant: Every PHI export, including concurrent ones, is logged; no unlogged copy.

Source check `HIPAA-PHI-04` from `checks.json` (behavioural; deterministic: yes). Covers: PHI protection · None · HIPAA. Review status in source: Drafted (AI) – needs compliance review.

## Rule HIPAA-BAA-01: An integration sending PHI to a vendor without a BAA mapping is blocked pre-deploy
Severity: LOW
Category: NON_MM
Scenario: baas
Requirement: MUST
Invariant: An integration sending PHI to a vendor without a BAA mapping is blocked pre-deploy.

Source check `HIPAA-BAA-01` from `checks.json` (static; deterministic: yes). Covers: BAAs · missing BAA · HIPAA. Review status in source: Drafted (AI) – needs compliance review.

## Rule HIPAA-BAA-02: PHI flows only to vendors with an active BAA (BAA ID recorded per transfer)
Severity: LOW
Category: NON_MM
Scenario: baas
Requirement: MUST
Invariant: PHI flows only to vendors with an active BAA (BAA ID recorded per transfer); expiry/termination suspends flows; an unavailable BAA register blocks transfers.

Source check `HIPAA-BAA-02` from `checks.json` (behavioural; deterministic: yes). Covers: BAAs · missing BAA · HIPAA. Review status in source: Drafted (AI) – needs compliance review.

## Rule HIPAA-BAA-51: PHI transfer code checks the BAA register's active status/expiry before sending
Severity: LOW
Category: NON_MM
Scenario: baas
Requirement: MUST
Invariant: PHI transfer code checks the BAA register's active status/expiry before sending.

Source check `HIPAA-BAA-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: BAAs · missing BAA · HIPAA. Backstop for HIPAA-BAA-02. Review status in source: Drafted (AI) – needs compliance review.

## Rule HIPAA-BRN-01: Breach discovery starts the configured notification clocks per audience and size threshold
Severity: LOW
Category: NON_MM
Scenario: breach-notification
Requirement: MUST
Invariant: Breach discovery starts the configured notification clocks per audience and size threshold; confirmed breaches create tasks, low-risk incidents document rationale without notifying; deadlines escalate.

Source check `HIPAA-BRN-01` from `checks.json` (behavioural; deterministic: yes). Covers: Breach notification · None · HIPAA. Review status in source: Drafted (AI) – needs compliance review.

## Rule HIPAA-BRN-02: Multiple incidents affecting the same individuals do not duplicate notifications
Severity: LOW
Category: NON_MM
Scenario: breach-notification
Requirement: MUST
Invariant: Multiple incidents affecting the same individuals do not duplicate notifications.

Source check `HIPAA-BRN-02` from `checks.json` (behavioural; deterministic: yes). Covers: Breach notification · None · HIPAA. Review status in source: Drafted (AI) – needs compliance review.
