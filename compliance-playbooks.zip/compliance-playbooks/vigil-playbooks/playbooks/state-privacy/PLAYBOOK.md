---
helixPlaybookFormat: helix-playbook/0.1-proposal
playbookId: vigil-state-privacy
title: "US State Privacy Laws Consent / Opt-out / Access"
declaredVersion: 0.1.0
intent: draft
applicability:
  languages: [javascript, typescript]
  scenarios: [virginia, multi-state-cross-cutting, other-states-etc, connecticut, utah]
---
# Helix portable playbook — DRAFT manifest · US State Privacy Laws Consent / Opt-out / Access

> **DRAFT — not LOCKED.** Proposed State Privacy Laws (US Privacy) playbook converted from Vigil skill `SK-STPRIV-001`: one runner, two layers, **16 harness checks (5 static, incl. 4 static backstops, + 11 behavioural)**, plus 1 manual/evidence items listed separately because neither layer can verify them. Every invariant, layer and determinism call is **AI-drafted (Helix) and needs compliance review**; 15 check(s) are **⚑ SME-flagged** and cannot gate until an SME/counsel supplies their parameter matrix. No detector or rule code exists yet. Before this manifest can be LOCKED, each row needs its detector/rule, a review, and a commit that adds the check alongside its row.

## Layers

- **static**: a repo-agnostic source scanner parameterised by a `VIGIL_STPRIV` preset (no app specifics in the detector). It reads source / SQL / config / IaC / git-diff, **fails CLOSED** on a match, and runs with **no adapter**, so it is the CI gate. *Static backstops* (IDs `-5x`) prove a supporting source invariant for a named behavioural check, the way N-CAP-01 / N-STATE-01 back neobank behaviour. They fire even when the adapter never drives that path. Backstops of ⚑ SME checks stay out of the gate.
- **behavioural**: a rule written once against the canonical `MoneySystem` interface (or a DRAFT extension surface in `adapters/`) and driven through the app adapter. Surfaces needed: **PrivacySystem** (`adapters/privacy.ts`). Every behavioural row reports NOT_EXERCISED until an adapter implements its surface. It returns **CHECKED only when it actually drove the guard's path**.
- **manual/evidence**: organisational process, live-infrastructure, statistical or retention evidence that no source scan or adapter-driven rule can prove. These are **outside the harness**, report `NOT_APPLICABLE` to it, and are tracked as evidence tasks, never as passes.

## Verdicts

`CHECKED` the path ran and the guard held · `FINDING` the guard was violated · `NOT_APPLICABLE` the invariant cannot apply here (incl. every manual/evidence item) · `NOT_EXERCISED` (glyph `????`) the adapter did not drive the path, so nothing is proven. NOT_EXERCISED is **surfaced distinctly and never counted as a pass** (no fake coverage). A ⚑ SME check with no approved parameter matrix reports `NOT_EXERCISED`, never `CHECKED`.

## How to run

- **Not runnable yet**: this draft defines invariants only (no detector/rule code). The intended shape mirrors the neobank playbook:
  - CI gate (adapter-free, blocks on any static FINDING): `run-static` with preset `VIGIL_STPRIV`.
  - Full combined table (static + behavioural via the adapter): `run-all`.
- Machine-readable rows: `checks.json` (same IDs; includes source-scenario traceability and neobank overlaps).

## The draft inventory: 5 static + 11 behavioural = 16 checks

| ID | Layer | Deterministic | Invariant (one line) | Covers (automation point · common failure · regulation) |
| --- | --- | --- | --- | --- |
| **STP-MTX-01** | behavioural | yes ⚑ SME | Each resident's rights set, deadlines and appeal path come solely from the versioned state-rule matrix (SME/counsel-provided) — every matrix row has executed tests and a new state activates from its effective date with no code change. | Virginia / Colorado / Connecticut / Utah / Other states (etc.) / Multi-state (cross-cutting) · Missing consent · State Privacy Laws |
| **STP-MTX-51** | static | yes ⚑ SME | No state-specific branching appears in code; state behaviour is read only from the versioned matrix. | backstop for STP-MTX-01 · Virginia / Colorado / Connecticut / Utah / Other states (etc.) / Multi-state (cross-cutting) · Missing consent · State Privacy Laws |
| **STP-MTX-02** | static | yes ⚑ SME | State-rule matrix changes are versioned with approver and effective date; no hard-coded state logic; the privacy notice stays in sync with the matrix and never promises rights the matrix omits. | Multi-state (cross-cutting) / Utah · incomplete opt-out · State Privacy Laws |
| **STP-MTX-03** | behavioural | yes ⚑ SME | Unknown, ambiguous or missing residency applies the configured most-protective default and flags the gap; inter-state conflicts resolve by the configured precedence. | Other states (etc.) / Multi-state (cross-cutting) · general control (no source failure) · State Privacy Laws |
| **STP-MTX-52** | static | yes ⚑ SME | Residency resolution falls back to the configured most-protective rule set when unknown (no permissive default). | backstop for STP-MTX-03 · Other states (etc.) / Multi-state (cross-cutting) · general control (no source failure) · State Privacy Laws |
| **STP-MTX-04** | behavioural | yes ⚑ SME | The rule set for a request is fixed per configured policy (e.g. at submission) even if residency changes mid-request. | Multi-state (cross-cutting) / Other states (etc.) · general control (no source failure) · State Privacy Laws |
| **STP-MTX-05** | behavioural | yes | Matrix service unavailability fails safe — requests are queued or the most-protective default applies; none dropped. | Multi-state (cross-cutting) · general control (no source failure) · State Privacy Laws |
| **STP-RTS-01** | behavioural | yes ⚑ SME | Access/deletion requests are complete and answered within each state's matrix deadline (alerts before; extension only with notice; controllable clock) and include the appeal path where the matrix requires. | Multi-state (cross-cutting) / Virginia / Colorado / Connecticut · incomplete opt-out · State Privacy Laws |
| **STP-RTS-02** | behavioural | yes ⚑ SME | Unverifiable requesters get no data; concurrent deletion and access requests resolve in configured order with a consistent response. | Virginia / Connecticut · general control (no source failure) · State Privacy Laws |
| **STP-RTS-03** | behavioural | yes | Duplicate requests across channels yield one tracked case and one response; a workflow outage resumes with the deadline clock preserved. | Multi-state (cross-cutting) / Virginia · general control (no source failure) · State Privacy Laws |
| **STP-RTS-04** | behavioural | yes ⚑ SME | State applicability thresholds switch exactly at the matrix-configured values. | Connecticut · general control (no source failure) · State Privacy Laws |
| **STP-OPT-01** | behavioural | yes ⚑ SME | Opt-outs (incl. universal opt-out signals where the matrix requires) stop targeted advertising/sale and propagate to every configured processor within the matrix window, retrying on partner failure. | Multi-state (cross-cutting) / Colorado / Utah / Connecticut · incomplete opt-out · State Privacy Laws |
| **STP-OPT-51** | static | yes ⚑ SME | Every processor/partner integration consumes the state opt-out suppression feed. | backstop for STP-OPT-01 · Multi-state (cross-cutting) / Colorado / Utah / Connecticut · incomplete opt-out · State Privacy Laws |
| **STP-OPT-02** | behavioural | yes ⚑ SME | Repeated opt-outs are idempotent and rapid opt-out/consent changes resolve to the latest by timestamp downstream; signals missed during an outage are reconciled or fail safe as opt-out. | Utah / Colorado · incomplete opt-out · State Privacy Laws |
| **STP-CON-01** | behavioural | yes ⚑ SME | Sensitive-data processing is blocked until consent is captured where the state matrix requires opt-in. | Multi-state (cross-cutting) / Colorado / Connecticut · Missing consent · State Privacy Laws |
| **STP-CON-51** | static | yes ⚑ SME | Sensitive-data processing call sites check the matrix consent requirement before processing. | backstop for STP-CON-01 · Multi-state (cross-cutting) / Colorado / Connecticut · Missing consent · State Privacy Laws |

## Outside the harness: manual/evidence (1)

These items are not harness checks. Each reports `NOT_APPLICABLE` to the runner and needs an owner and evidence on a schedule.

| ID | Layer | Deterministic | Invariant (one line) | Covers (automation point · common failure · regulation) |
| --- | --- | --- | --- | --- |
| **STP-REC-01** | manual/evidence | no (manual) | Request, consent and opt-out records and matrix versions are retained for each state's matrix retention period and linked to each request. | Multi-state (cross-cutting) / Virginia / Colorado / Connecticut / Utah / Other states (etc.) · general control (no source failure) · State Privacy Laws |

### Determinism

Every harness row (static and behavioural) is drafted as deterministic. Static detectors, including backstops, are pure functions of the committed source/config/diff. Behavioural rules each run against a **fresh `reset()` MoneySystem** (no state leaks between rules), driven by a **controllable clock**; deadlines, windows, expiries and cadences are asserted by advancing that clock, never by wall-clock reads, and no randomness affects a verdict. External dependencies (vendors, registries, feeds) are faked inside the adapter, which is how fault-injection rows stay deterministic. Manual/evidence rows are not deterministic and are not gate checks. ⚑ SME rows are deterministic once parameters exist, but are excluded from the gate until then.

### Coverage note

Converted from 52 AI-drafted source scenarios of `SK-STPRIV-001`; each source scenario maps to exactly one non-backstop row (see the appendix). Static backstops add no scenarios and trace through the check they back. The scenarios were merged into crisp invariants by automation point and failure mode, across categories (positive, negative, boundary, failure/recovery, concurrency/idempotency, retention/audit, common failure, core). Automation points covered: Virginia, Colorado, Connecticut, Utah, Other states (etc.), Multi-state (cross-cutting). Source common failures: Missing consent, incomplete opt-out. Thresholds, windows and deadlines are *configured* parameters, not asserted statutory values. No regulation or citation was added beyond the source sheet.

### Overlap with the locked neobank playbook (19 checks)

| This check | Neobank check | Strength | Why |
| --- | --- | --- | --- |
| STP-RTS-03 | N-IDEMP-01 | related | duplicate requests |
| STP-OPT-02 | N-IDEMP-01 | related | repeat opt-out |

`same` means the neobank check already enforces this invariant, so reuse it instead of re-implementing. `related` means the same defect class, but this check needs its own rule or preset.

### Review flags

- ⚑ **STP-MTX-01**: needs an SME/counsel parameter matrix (source scenarios carry review status "+ SME input").
- ⚑ **STP-MTX-51**: needs an SME/counsel parameter matrix (source scenarios carry review status "+ SME input").
- ⚑ **STP-MTX-02**: needs an SME/counsel parameter matrix (source scenarios carry review status "+ SME input").
- ⚑ **STP-MTX-03**: needs an SME/counsel parameter matrix (source scenarios carry review status "+ SME input").
- ⚑ **STP-MTX-52**: needs an SME/counsel parameter matrix (source scenarios carry review status "+ SME input").
- ⚑ **STP-MTX-04**: needs an SME/counsel parameter matrix (source scenarios carry review status "+ SME input").
- ⚑ **STP-RTS-01**: needs an SME/counsel parameter matrix (source scenarios carry review status "+ SME input").
- ⚑ **STP-RTS-02**: needs an SME/counsel parameter matrix (source scenarios carry review status "+ SME input").
- ⚑ **STP-RTS-04**: needs an SME/counsel parameter matrix (source scenarios carry review status "+ SME input").
- ⚑ **STP-OPT-01**: needs an SME/counsel parameter matrix (source scenarios carry review status "+ SME input").
- ⚑ **STP-OPT-51**: needs an SME/counsel parameter matrix (source scenarios carry review status "+ SME input").
- ⚑ **STP-OPT-02**: needs an SME/counsel parameter matrix (source scenarios carry review status "+ SME input").
- ⚑ **STP-CON-01**: needs an SME/counsel parameter matrix (source scenarios carry review status "+ SME input").
- ⚑ **STP-CON-51**: needs an SME/counsel parameter matrix (source scenarios carry review status "+ SME input").
- ⚑ **STP-REC-01**: needs an SME/counsel parameter matrix (source scenarios carry review status "+ SME input").

## Appendix: traceability to source scenarios

| Check ID | Source scenario IDs | Categories merged |
| --- | --- | --- |
| STP-MTX-01 | SC-STPRIV-001-04, SC-STPRIV-001-23, SC-STPRIV-001-29, SC-STPRIV-001-35, SC-STPRIV-001-41, SC-STPRIV-001-47, SC-STPRIV-001-11, SC-STPRIV-001-42, SC-STPRIV-001-10, SC-STPRIV-001-48 | Boundary/Edge, Core, Positive |
| STP-MTX-51 | — (static backstop; traced via STP-MTX-01) | — |
| STP-MTX-02 | SC-STPRIV-001-16, SC-STPRIV-001-52, SC-STPRIV-001-36 | Common Failure, Negative, Retention/Audit |
| STP-MTX-03 | SC-STPRIV-001-12, SC-STPRIV-001-43, SC-STPRIV-001-49, SC-STPRIV-001-50, SC-STPRIV-001-46 | Boundary/Edge, Common Failure, Failure/Recovery, Negative |
| STP-MTX-52 | — (static backstop; traced via STP-MTX-03) | — |
| STP-MTX-04 | SC-STPRIV-001-13, SC-STPRIV-001-44 | Concurrency/Idempotency |
| STP-MTX-05 | SC-STPRIV-001-51 | Failure/Recovery |
| STP-RTS-01 | SC-STPRIV-001-03, SC-STPRIV-001-05, SC-STPRIV-001-24, SC-STPRIV-001-30, SC-STPRIV-001-08, SC-STPRIV-001-22 | Boundary/Edge, Common Failure, Core, Failure/Recovery, Positive |
| STP-RTS-02 | SC-STPRIV-001-18, SC-STPRIV-001-33 | Concurrency/Idempotency, Negative |
| STP-RTS-03 | SC-STPRIV-001-14, SC-STPRIV-001-20, SC-STPRIV-001-19 | Concurrency/Idempotency, Failure/Recovery |
| STP-RTS-04 | SC-STPRIV-001-32 | Boundary/Edge |
| STP-OPT-01 | SC-STPRIV-001-02, SC-STPRIV-001-06, SC-STPRIV-001-17, SC-STPRIV-001-28, SC-STPRIV-001-09, SC-STPRIV-001-37, SC-STPRIV-001-40 | Common Failure, Core, Failure/Recovery, Positive |
| STP-OPT-51 | — (static backstop; traced via STP-OPT-01) | — |
| STP-OPT-02 | SC-STPRIV-001-38, SC-STPRIV-001-26, SC-STPRIV-001-25 | Concurrency/Idempotency, Failure/Recovery |
| STP-CON-01 | SC-STPRIV-001-01, SC-STPRIV-001-07, SC-STPRIV-001-31 | Core, Negative |
| STP-CON-51 | — (static backstop; traced via STP-CON-01) | — |
| STP-REC-01 | SC-STPRIV-001-15, SC-STPRIV-001-21, SC-STPRIV-001-27, SC-STPRIV-001-34, SC-STPRIV-001-39, SC-STPRIV-001-45 | Retention/Audit |

# Helix review rules

Generated from `checks.json` (16 static and behavioural checks; manual/evidence items are not code-reviewable and are omitted). Severity is derived from the playbook priority (P1 -> MEDIUM); Category MM marks money-movement checks. Rule text is the source invariant, unchanged; it is AI-drafted and needs compliance review.

## Rule STP-MTX-01: Each resident's rights set, deadlines and appeal path come solely from the versioned state-rule m...
Severity: MEDIUM
Category: NON_MM
Scenario: virginia
Requirement: MUST
Invariant: Each resident's rights set, deadlines and appeal path come solely from the versioned state-rule matrix (SME/counsel-provided) — every matrix row has executed tests and a new state activates from its effective date with no code change.

Source check `STP-MTX-01` from `checks.json` (behavioural; deterministic: yes). Covers: Virginia, Colorado, Connecticut, Utah, Other states (etc.), Multi-state (cross-cutting) · Missing consent · State Privacy Laws. Flagged for SME input in the source; needs an approved parameter matrix. Review status in source: Drafted (AI) – needs compliance review + SME input.

## Rule STP-MTX-51: No state-specific branching appears in code
Severity: MEDIUM
Category: NON_MM
Scenario: virginia
Requirement: MUST
Invariant: No state-specific branching appears in code; state behaviour is read only from the versioned matrix.

Source check `STP-MTX-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: Virginia, Colorado, Connecticut, Utah, Other states (etc.), Multi-state (cross-cutting) · Missing consent · State Privacy Laws. Backstop for STP-MTX-01. Flagged for SME input in the source; needs an approved parameter matrix. Review status in source: Drafted (AI) – needs compliance review + SME input.

## Rule STP-MTX-02: State-rule matrix changes are versioned with approver and effective date
Severity: MEDIUM
Category: NON_MM
Scenario: multi-state-cross-cutting
Requirement: MUST
Invariant: State-rule matrix changes are versioned with approver and effective date; no hard-coded state logic; the privacy notice stays in sync with the matrix and never promises rights the matrix omits.

Source check `STP-MTX-02` from `checks.json` (static; deterministic: yes). Covers: Multi-state (cross-cutting), Utah · incomplete opt-out · State Privacy Laws. Flagged for SME input in the source; needs an approved parameter matrix. Review status in source: Drafted (AI) – needs compliance review + SME input.

## Rule STP-MTX-03: Unknown, ambiguous or missing residency applies the configured most-protective default and flags...
Severity: MEDIUM
Category: NON_MM
Scenario: other-states-etc
Requirement: MUST
Invariant: Unknown, ambiguous or missing residency applies the configured most-protective default and flags the gap; inter-state conflicts resolve by the configured precedence.

Source check `STP-MTX-03` from `checks.json` (behavioural; deterministic: yes). Covers: Other states (etc.), Multi-state (cross-cutting) · None · State Privacy Laws. Flagged for SME input in the source; needs an approved parameter matrix. Review status in source: Drafted (AI) – needs compliance review + SME input.

## Rule STP-MTX-52: Residency resolution falls back to the configured most-protective rule set when unknown (no permi...
Severity: MEDIUM
Category: NON_MM
Scenario: other-states-etc
Requirement: MUST
Invariant: Residency resolution falls back to the configured most-protective rule set when unknown (no permissive default).

Source check `STP-MTX-52` from `checks.json` (static, static backstop; deterministic: yes). Covers: Other states (etc.), Multi-state (cross-cutting) · None · State Privacy Laws. Backstop for STP-MTX-03. Flagged for SME input in the source; needs an approved parameter matrix. Review status in source: Drafted (AI) – needs compliance review + SME input.

## Rule STP-MTX-04: The rule set for a request is fixed per configured policy (e.g
Severity: MEDIUM
Category: NON_MM
Scenario: multi-state-cross-cutting
Requirement: MUST
Invariant: The rule set for a request is fixed per configured policy (e.g. at submission) even if residency changes mid-request.

Source check `STP-MTX-04` from `checks.json` (behavioural; deterministic: yes). Covers: Multi-state (cross-cutting), Other states (etc.) · None · State Privacy Laws. Flagged for SME input in the source; needs an approved parameter matrix. Review status in source: Drafted (AI) – needs compliance review + SME input.

## Rule STP-MTX-05: Matrix service unavailability fails safe — requests are queued or the most-protective default app...
Severity: MEDIUM
Category: NON_MM
Scenario: multi-state-cross-cutting
Requirement: MUST
Invariant: Matrix service unavailability fails safe — requests are queued or the most-protective default applies; none dropped.

Source check `STP-MTX-05` from `checks.json` (behavioural; deterministic: yes). Covers: Multi-state (cross-cutting) · None · State Privacy Laws. Review status in source: Drafted (AI) – needs compliance review.

## Rule STP-RTS-01: Access/deletion requests are complete and answered within each state's matrix deadline (alerts be...
Severity: MEDIUM
Category: NON_MM
Scenario: multi-state-cross-cutting
Requirement: MUST
Invariant: Access/deletion requests are complete and answered within each state's matrix deadline (alerts before; extension only with notice; controllable clock) and include the appeal path where the matrix requires.

Source check `STP-RTS-01` from `checks.json` (behavioural; deterministic: yes). Covers: Multi-state (cross-cutting), Virginia, Colorado, Connecticut · incomplete opt-out · State Privacy Laws. Flagged for SME input in the source; needs an approved parameter matrix. Review status in source: Drafted (AI) – needs compliance review + SME input.

## Rule STP-RTS-02: Unverifiable requesters get no data
Severity: MEDIUM
Category: NON_MM
Scenario: virginia
Requirement: MUST
Invariant: Unverifiable requesters get no data; concurrent deletion and access requests resolve in configured order with a consistent response.

Source check `STP-RTS-02` from `checks.json` (behavioural; deterministic: yes). Covers: Virginia, Connecticut · None · State Privacy Laws. Flagged for SME input in the source; needs an approved parameter matrix. Review status in source: Drafted (AI) – needs compliance review + SME input.

## Rule STP-RTS-03: Duplicate requests across channels yield one tracked case and one response
Severity: MEDIUM
Category: NON_MM
Scenario: multi-state-cross-cutting
Requirement: MUST
Invariant: Duplicate requests across channels yield one tracked case and one response; a workflow outage resumes with the deadline clock preserved.

Source check `STP-RTS-03` from `checks.json` (behavioural; deterministic: yes). Covers: Multi-state (cross-cutting), Virginia · None · State Privacy Laws. Review status in source: Drafted (AI) – needs compliance review.

## Rule STP-RTS-04: State applicability thresholds switch exactly at the matrix-configured values
Severity: MEDIUM
Category: NON_MM
Scenario: connecticut
Requirement: MUST
Invariant: State applicability thresholds switch exactly at the matrix-configured values.

Source check `STP-RTS-04` from `checks.json` (behavioural; deterministic: yes). Covers: Connecticut · None · State Privacy Laws. Flagged for SME input in the source; needs an approved parameter matrix. Review status in source: Drafted (AI) – needs compliance review + SME input.

## Rule STP-OPT-01: Opt-outs (incl
Severity: MEDIUM
Category: NON_MM
Scenario: multi-state-cross-cutting
Requirement: MUST
Invariant: Opt-outs (incl. universal opt-out signals where the matrix requires) stop targeted advertising/sale and propagate to every configured processor within the matrix window, retrying on partner failure.

Source check `STP-OPT-01` from `checks.json` (behavioural; deterministic: yes). Covers: Multi-state (cross-cutting), Colorado, Utah, Connecticut · incomplete opt-out · State Privacy Laws. Flagged for SME input in the source; needs an approved parameter matrix. Review status in source: Drafted (AI) – needs compliance review + SME input.

## Rule STP-OPT-51: Every processor/partner integration consumes the state opt-out suppression feed
Severity: MEDIUM
Category: NON_MM
Scenario: multi-state-cross-cutting
Requirement: MUST
Invariant: Every processor/partner integration consumes the state opt-out suppression feed.

Source check `STP-OPT-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: Multi-state (cross-cutting), Colorado, Utah, Connecticut · incomplete opt-out · State Privacy Laws. Backstop for STP-OPT-01. Flagged for SME input in the source; needs an approved parameter matrix. Review status in source: Drafted (AI) – needs compliance review + SME input.

## Rule STP-OPT-02: Repeated opt-outs are idempotent and rapid opt-out/consent changes resolve to the latest by times...
Severity: MEDIUM
Category: NON_MM
Scenario: utah
Requirement: MUST
Invariant: Repeated opt-outs are idempotent and rapid opt-out/consent changes resolve to the latest by timestamp downstream; signals missed during an outage are reconciled or fail safe as opt-out.

Source check `STP-OPT-02` from `checks.json` (behavioural; deterministic: yes). Covers: Utah, Colorado · incomplete opt-out · State Privacy Laws. Flagged for SME input in the source; needs an approved parameter matrix. Review status in source: Drafted (AI) – needs compliance review + SME input.

## Rule STP-CON-01: Sensitive-data processing is blocked until consent is captured where the state matrix requires op...
Severity: MEDIUM
Category: NON_MM
Scenario: multi-state-cross-cutting
Requirement: MUST
Invariant: Sensitive-data processing is blocked until consent is captured where the state matrix requires opt-in.

Source check `STP-CON-01` from `checks.json` (behavioural; deterministic: yes). Covers: Multi-state (cross-cutting), Colorado, Connecticut · Missing consent · State Privacy Laws. Flagged for SME input in the source; needs an approved parameter matrix. Review status in source: Drafted (AI) – needs compliance review + SME input.

## Rule STP-CON-51: Sensitive-data processing call sites check the matrix consent requirement before processing
Severity: MEDIUM
Category: NON_MM
Scenario: multi-state-cross-cutting
Requirement: MUST
Invariant: Sensitive-data processing call sites check the matrix consent requirement before processing.

Source check `STP-CON-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: Multi-state (cross-cutting), Colorado, Connecticut · Missing consent · State Privacy Laws. Backstop for STP-CON-01. Flagged for SME input in the source; needs an approved parameter matrix. Review status in source: Drafted (AI) – needs compliance review + SME input.
