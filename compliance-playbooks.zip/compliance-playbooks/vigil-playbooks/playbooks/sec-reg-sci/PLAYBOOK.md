---
helixPlaybookFormat: helix-playbook/0.1-proposal
playbookId: vigil-sec-reg-sci
title: "SEC Reg SCI System Integrity & BCP"
declaredVersion: 0.1.0
intent: draft
applicability:
  languages: [javascript, typescript]
  scenarios: [system-integrity, incident-response]
---
# Helix portable playbook — DRAFT manifest · SEC Reg SCI System Integrity & BCP

> **DRAFT — not LOCKED.** Proposed SEC Reg SCI (Securities) playbook converted from Vigil skill `SK-REGSCI-001`: one runner, two layers, **4 harness checks (1 static, incl. 0 static backstops, + 3 behavioural)**, plus 6 manual/evidence items listed separately because neither layer can verify them. Every invariant, layer and determinism call is **AI-drafted (Helix) and needs compliance review**. No detector or rule code exists yet. Before this manifest can be LOCKED, each row needs its detector/rule, a review, and a commit that adds the check alongside its row.

## Layers

- **static**: a repo-agnostic source scanner parameterised by a `VIGIL_REGSCI` preset (no app specifics in the detector). It reads source / SQL / config / IaC / git-diff, **fails CLOSED** on a match, and runs with **no adapter**, so it is the CI gate. *Static backstops* (IDs `-5x`) prove a supporting source invariant for a named behavioural check, the way N-CAP-01 / N-STATE-01 back neobank behaviour. They fire even when the adapter never drives that path. Backstops of ⚑ SME checks stay out of the gate.
- **behavioural**: a rule written once against the canonical `MoneySystem` interface (or a DRAFT extension surface in `adapters/`) and driven through the app adapter. Surfaces needed: **SecuritiesSystem** (`adapters/securities.ts`). Every behavioural row reports NOT_EXERCISED until an adapter implements its surface. It returns **CHECKED only when it actually drove the guard's path**.
- **manual/evidence**: organisational process, live-infrastructure, statistical or retention evidence that no source scan or adapter-driven rule can prove. These are **outside the harness**, report `NOT_APPLICABLE` to it, and are tracked as evidence tasks, never as passes.

## Verdicts

`CHECKED` the path ran and the guard held · `FINDING` the guard was violated · `NOT_APPLICABLE` the invariant cannot apply here (incl. every manual/evidence item) · `NOT_EXERCISED` (glyph `????`) the adapter did not drive the path, so nothing is proven. NOT_EXERCISED is **surfaced distinctly and never counted as a pass** (no fake coverage). A ⚑ SME check with no approved parameter matrix reports `NOT_EXERCISED`, never `CHECKED`.

## How to run

- **Not runnable yet**: this draft defines invariants only (no detector/rule code). The intended shape mirrors the neobank playbook:
  - CI gate (adapter-free, blocks on any static FINDING): `run-static` with preset `VIGIL_REGSCI`.
  - Full combined table (static + behavioural via the adapter): `run-all`.
- Machine-readable rows: `checks.json` (same IDs; includes source-scenario traceability and neobank overlaps).

## The draft inventory: 1 static + 3 behavioural = 4 checks

| ID | Layer | Deterministic | Invariant (one line) | Covers (automation point · common failure · regulation) |
| --- | --- | --- | --- | --- |
| **SCI-SYS-01** | static | yes | A change to an SCI system cannot deploy without linked test evidence; exceptions need documented approval. | System integrity · Missing test · SEC Reg SCI |
| **SCI-SYS-03** | behavioural | yes | A concurrent order/message surge processes every unique message exactly once, in order where required, with duplicates suppressed. | System integrity · general control (no source failure) · SEC Reg SCI |
| **SCI-INC-01** | behavioural | yes | Events are classified SCI/non-SCI and de minimis/reportable exactly at configured boundaries, creating notification tasks with configured deadlines only for SCI events. | Incident response · general control (no source failure) · SEC Reg SCI |
| **SCI-INC-02** | behavioural | yes | Concurrent incidents keep separate records and timelines; closure is blocked until required fields are complete. | Incident response · general control (no source failure) · SEC Reg SCI |

## Outside the harness: manual/evidence (6)

These items are not harness checks. Each reports `NOT_APPLICABLE` to the runner and needs an owner and evidence on a schedule.

| ID | Layer | Deterministic | Invariant (one line) | Covers (automation point · common failure · regulation) |
| --- | --- | --- | --- | --- |
| **SCI-SYS-02** | manual/evidence | no (manual) | SCI systems meet configured capacity/integrity headroom at the configured peak multiple before release (performance test); results documented and retained. | System integrity · Missing test · SEC Reg SCI |
| **SCI-SYS-04** | manual/evidence | no (manual) | Health-check breaches trigger automated rollback and an incident record. | System integrity · general control (no source failure) · SEC Reg SCI |
| **SCI-BCP-01** | manual/evidence | no (manual) | Planned and unplanned failover to the backup site resume critical functions within configured RTO/RPO with no data inconsistency; pass/fail flips exactly at RTO. | Business continuity · failed BCP · SEC Reg SCI |
| **SCI-BCP-02** | manual/evidence | no (manual) | Failover is blocked/flagged when the backup site is stale, and fencing prevents dual-primary (split-brain). | Business continuity · failed BCP · SEC Reg SCI |
| **SCI-BCP-03** | manual/evidence | no (manual) | Designated-participant BC/DR test participation is recorded and gaps flagged. | Business continuity · failed BCP · SEC Reg SCI |
| **SCI-INC-03** | manual/evidence | no (manual) | Paging-tool outage falls back to an alternate channel within the escalation window; tabletop exercises produce required escalations; incident records retained. | Incident response · general control (no source failure) · SEC Reg SCI |

### Determinism

Every harness row (static and behavioural) is drafted as deterministic. Static detectors, including backstops, are pure functions of the committed source/config/diff. Behavioural rules each run against a **fresh `reset()` MoneySystem** (no state leaks between rules), driven by a **controllable clock**; deadlines, windows, expiries and cadences are asserted by advancing that clock, never by wall-clock reads, and no randomness affects a verdict. External dependencies (vendors, registries, feeds) are faked inside the adapter, which is how fault-injection rows stay deterministic. Manual/evidence rows are not deterministic and are not gate checks.

### Coverage note

Converted from 24 AI-drafted source scenarios of `SK-REGSCI-001`; each source scenario maps to exactly one non-backstop row (see the appendix). Static backstops add no scenarios and trace through the check they back. The scenarios were merged into crisp invariants by automation point and failure mode, across categories (positive, negative, boundary, failure/recovery, concurrency/idempotency, retention/audit, common failure, core). Automation points covered: System integrity, Business continuity, Incident response. Source common failures: Missing test, failed BCP. Thresholds, windows and deadlines are *configured* parameters, not asserted statutory values. No regulation or citation was added beyond the source sheet.

### Overlap with the locked neobank playbook (19 checks)

| This check | Neobank check | Strength | Why |
| --- | --- | --- | --- |
| SCI-SYS-03 | N-IDEMP-01 | related | each message once |

`same` means the neobank check already enforces this invariant, so reuse it instead of re-implementing. `related` means the same defect class, but this check needs its own rule or preset.

### Review flags

- No SME-flagged rows. All rows still need compliance review.

## Appendix: traceability to source scenarios

| Check ID | Source scenario IDs | Categories merged |
| --- | --- | --- |
| SCI-SYS-01 | SC-REGSCI-001-05, SC-REGSCI-001-15 | Common Failure, Negative |
| SCI-SYS-02 | SC-REGSCI-001-01, SC-REGSCI-001-04, SC-REGSCI-001-11, SC-REGSCI-001-14 | Boundary/Edge, Core, Positive, Retention/Audit |
| SCI-SYS-03 | SC-REGSCI-001-13 | Concurrency/Idempotency |
| SCI-SYS-04 | SC-REGSCI-001-12 | Failure/Recovery |
| SCI-BCP-01 | SC-REGSCI-001-02, SC-REGSCI-001-06, SC-REGSCI-001-16, SC-REGSCI-001-18 | Boundary/Edge, Core, Failure/Recovery, Positive |
| SCI-BCP-02 | SC-REGSCI-001-17, SC-REGSCI-001-19 | Concurrency/Idempotency, Negative |
| SCI-BCP-03 | SC-REGSCI-001-07, SC-REGSCI-001-20 | Common Failure, Retention/Audit |
| SCI-INC-01 | SC-REGSCI-001-08, SC-REGSCI-001-09, SC-REGSCI-001-21 | Boundary/Edge, Negative, Positive |
| SCI-INC-02 | SC-REGSCI-001-23, SC-REGSCI-001-24 | Common Failure, Concurrency/Idempotency |
| SCI-INC-03 | SC-REGSCI-001-22, SC-REGSCI-001-03, SC-REGSCI-001-10 | Core, Failure/Recovery, Retention/Audit |

# Helix review rules

Generated from `checks.json` (4 static and behavioural checks; manual/evidence items are not code-reviewable and are omitted). Severity is derived from the playbook priority (P2 -> LOW); Category MM marks money-movement checks. Rule text is the source invariant, unchanged; it is AI-drafted and needs compliance review.

## Rule SCI-SYS-01: A change to an SCI system cannot deploy without linked test evidence
Severity: LOW
Category: NON_MM
Scenario: system-integrity
Requirement: MUST
Invariant: A change to an SCI system cannot deploy without linked test evidence; exceptions need documented approval.

Source check `SCI-SYS-01` from `checks.json` (static; deterministic: yes). Covers: System integrity · Missing test · SEC Reg SCI. Review status in source: Drafted (AI) – needs compliance review.

## Rule SCI-SYS-03: A concurrent order/message surge processes every unique message exactly once, in order where requ...
Severity: LOW
Category: NON_MM
Scenario: system-integrity
Requirement: MUST
Invariant: A concurrent order/message surge processes every unique message exactly once, in order where required, with duplicates suppressed.

Source check `SCI-SYS-03` from `checks.json` (behavioural; deterministic: yes). Covers: System integrity · None · SEC Reg SCI. Review status in source: Drafted (AI) – needs compliance review.

## Rule SCI-INC-01: Events are classified SCI/non-SCI and de minimis/reportable exactly at configured boundaries, cre...
Severity: LOW
Category: NON_MM
Scenario: incident-response
Requirement: MUST
Invariant: Events are classified SCI/non-SCI and de minimis/reportable exactly at configured boundaries, creating notification tasks with configured deadlines only for SCI events.

Source check `SCI-INC-01` from `checks.json` (behavioural; deterministic: yes). Covers: Incident response · None · SEC Reg SCI. Review status in source: Drafted (AI) – needs compliance review.

## Rule SCI-INC-02: Concurrent incidents keep separate records and timelines
Severity: LOW
Category: NON_MM
Scenario: incident-response
Requirement: MUST
Invariant: Concurrent incidents keep separate records and timelines; closure is blocked until required fields are complete.

Source check `SCI-INC-02` from `checks.json` (behavioural; deterministic: yes). Covers: Incident response · None · SEC Reg SCI. Review status in source: Drafted (AI) – needs compliance review.
