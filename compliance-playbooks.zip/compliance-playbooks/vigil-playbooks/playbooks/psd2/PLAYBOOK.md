---
helixPlaybookFormat: helix-playbook/0.1-proposal
playbookId: vigil-psd2
title: "PSD2 SCA & Open Banking API Assurance"
declaredVersion: 0.1.0
intent: draft
applicability:
  languages: [javascript, typescript]
  scenarios: [sca, xs2a, consent, tpp-registration]
---
# Helix portable playbook — DRAFT manifest · PSD2 SCA & Open Banking API Assurance

> **DRAFT — not LOCKED.** Proposed PSD2 (EU) (Payment Services) playbook converted from Vigil skill `SK-PSD2-001`: one runner, two layers, **20 harness checks (6 static, incl. 6 static backstops, + 14 behavioural)**, plus 4 manual/evidence items listed separately because neither layer can verify them. Every invariant, layer and determinism call is **AI-drafted (Helix) and needs compliance review**. No detector or rule code exists yet. Before this manifest can be LOCKED, each row needs its detector/rule, a review, and a commit that adds the check alongside its row.

## Layers

- **static**: a repo-agnostic source scanner parameterised by a `VIGIL_PSD2` preset (no app specifics in the detector). It reads source / SQL / config / IaC / git-diff, **fails CLOSED** on a match, and runs with **no adapter**, so it is the CI gate. *Static backstops* (IDs `-5x`) prove a supporting source invariant for a named behavioural check, the way N-CAP-01 / N-STATE-01 back neobank behaviour. They fire even when the adapter never drives that path. Backstops of ⚑ SME checks stay out of the gate.
- **behavioural**: a rule written once against the canonical `MoneySystem` interface (or a DRAFT extension surface in `adapters/`) and driven through the app adapter. Surfaces needed: **OpenBankingSystem** (`adapters/open-banking.ts`). Every behavioural row reports NOT_EXERCISED until an adapter implements its surface. It returns **CHECKED only when it actually drove the guard's path**.
- **manual/evidence**: organisational process, live-infrastructure, statistical or retention evidence that no source scan or adapter-driven rule can prove. These are **outside the harness**, report `NOT_APPLICABLE` to it, and are tracked as evidence tasks, never as passes.

## Verdicts

`CHECKED` the path ran and the guard held · `FINDING` the guard was violated · `NOT_APPLICABLE` the invariant cannot apply here (incl. every manual/evidence item) · `NOT_EXERCISED` (glyph `????`) the adapter did not drive the path, so nothing is proven. NOT_EXERCISED is **surfaced distinctly and never counted as a pass** (no fake coverage). A ⚑ SME check with no approved parameter matrix reports `NOT_EXERCISED`, never `CHECKED`.

## How to run

- **Not runnable yet**: this draft defines invariants only (no detector/rule code). The intended shape mirrors the neobank playbook:
  - CI gate (adapter-free, blocks on any static FINDING): `run-static` with preset `VIGIL_PSD2`.
  - Full combined table (static + behavioural via the adapter): `run-all`.
- Machine-readable rows: `checks.json` (same IDs; includes source-scenario traceability and neobank overlaps).

## The draft inventory: 6 static + 14 behavioural = 20 checks

| ID | Layer | Deterministic | Invariant (one line) | Covers (automation point · common failure · regulation) |
| --- | --- | --- | --- | --- |
| **PSD2-SCA-01** | behavioural | yes | A payment executes only after two independent SCA factors with an auth code bound to amount and payee; altered amount/payee invalidates it. | SCA · Missing SCA · PSD2 (EU) |
| **PSD2-SCA-51** | static | yes | Payment execution verifies the SCA auth code against the stored amount+payee binding inside the execute path; amount/payee are not taken from the request after SCA. | backstop for PSD2-SCA-01 · SCA · Missing SCA · PSD2 (EU) |
| **PSD2-SCA-02** | behavioural | yes | An SCA authentication code authorises exactly one payment; concurrent reuse is rejected. | SCA · Missing SCA · PSD2 (EU) |
| **PSD2-SCA-52** | static | yes | SCA auth codes are consumed with a single-use conditional update (consumed_at IS NULL) and success is reported only when a row changed. | backstop for PSD2-SCA-02 · SCA · Missing SCA · PSD2 (EU) |
| **PSD2-SCA-03** | behavioural | yes | An SCA exemption applies only when every configured condition holds (low-value amount/count/cumulative limits, trusted beneficiary added under SCA); otherwise full SCA. | SCA · Missing SCA · PSD2 (EU) |
| **PSD2-SCA-53** | static | yes | Exemption counters/limits are read and incremented inside the payment transaction under a lock — never from client-supplied values. | backstop for PSD2-SCA-03 · SCA · Missing SCA · PSD2 (EU) |
| **PSD2-SCA-04** | behavioural | yes | Failed-attempt lockout triggers at the configured count; expired challenges cannot complete and idle sessions re-authenticate (controllable clock). | SCA · Missing SCA · PSD2 (EU) |
| **PSD2-XS2A-01** | behavioural | yes | XS2A responses conform to the published spec: malformed requests get spec error codes with no partial processing or data leakage; data parity with the PSU channel. | XS2A · API non-compliance · PSD2 (EU) |
| **PSD2-XS2A-02** | behavioural | yes | Payment-initiation status transitions follow the spec lifecycle and the final status matches the ledger. | XS2A · API non-compliance · PSD2 (EU) |
| **PSD2-XS2A-03** | behavioural | yes | Duplicate payment initiation with the same idempotency key creates one payment and no double debit; PIS retries after an outage do not duplicate. | XS2A · API non-compliance · PSD2 (EU) |
| **PSD2-XS2A-51** | static | yes | Payment-initiation routes require an idempotency key with read-first/replay semantics. | backstop for PSD2-XS2A-03 · XS2A · API non-compliance · PSD2 (EU) |
| **PSD2-XS2A-04** | behavioural | yes | Unattended AIS requests above the configured frequency limit are rejected; PSU-present requests unaffected. | XS2A · API non-compliance · PSD2 (EU) |
| **PSD2-CON-01** | behavioural | yes | A TPP accesses only consented accounts within consent validity and frequency limits; expired/revoked consent returns consent-invalid with no data. | Consent · general control (no source failure) · PSD2 (EU) |
| **PSD2-CON-02** | behavioural | yes | A PSU revocation from the dashboard rejects the TPP's next request; the dashboard lists every active consent. | Consent · general control (no source failure) · PSD2 (EU) |
| **PSD2-CON-03** | behavioural | yes | Consent store outage fails closed — no default-allow and no stale cached grant beyond TTL. | Consent · general control (no source failure) · PSD2 (EU) |
| **PSD2-CON-51** | static | yes | Consent-store failure handling denies access; cached grants carry an explicit TTL check. | backstop for PSD2-CON-03 · Consent · general control (no source failure) · PSD2 (EU) |
| **PSD2-TPP-01** | behavioural | yes | Access is permitted only for roles in the TPP's certificate/register (AIS/PIS/CBPII matrix matches config exactly). | TPP registration · API non-compliance · PSD2 (EU) |
| **PSD2-TPP-02** | behavioural | yes | Expired, revoked or self-signed TPP certificates are rejected on the next request; revocation-check failure fails closed. | TPP registration · API non-compliance · PSD2 (EU) |
| **PSD2-TPP-51** | static | yes | TLS/client-cert verification is not disabled anywhere (no insecure-skip, self-signed allow or revocation-check bypass flags). | backstop for PSD2-TPP-02 · TPP registration · API non-compliance · PSD2 (EU) |
| **PSD2-TPP-03** | behavioural | yes | Registry lookup failure never admits an unverified TPP; cached status used only within TTL; register revocation blocks new calls after ingestion. | TPP registration · API non-compliance · PSD2 (EU) |

## Outside the harness: manual/evidence (4)

These items are not harness checks. Each reports `NOT_APPLICABLE` to the runner and needs an owner and evidence on a schedule.

| ID | Layer | Deterministic | Invariant (one line) | Covers (automation point · common failure · regulation) |
| --- | --- | --- | --- | --- |
| **PSD2-SCA-05** | manual/evidence | no (manual) | Each payment's SCA method/factors or exemption reason is stored and retained for the configured period. | SCA · general control (no source failure) · PSD2 (EU) |
| **PSD2-XS2A-05** | manual/evidence | no (manual) | Dedicated-interface availability/performance stays within the configured parity target (synthetic monitoring); request/response audit retained. | XS2A · API non-compliance · PSD2 (EU) |
| **PSD2-CON-04** | manual/evidence | no (manual) | Consent lifecycle history is retained with timestamp, actor and channel. | Consent · general control (no source failure) · PSD2 (EU) |
| **PSD2-TPP-04** | manual/evidence | no (manual) | TPP onboarding and certificate checks are retained. | TPP registration · general control (no source failure) · PSD2 (EU) |

### Determinism

Every harness row (static and behavioural) is drafted as deterministic. Static detectors, including backstops, are pure functions of the committed source/config/diff. Behavioural rules each run against a **fresh `reset()` MoneySystem** (no state leaks between rules), driven by a **controllable clock**; deadlines, windows, expiries and cadences are asserted by advancing that clock, never by wall-clock reads, and no randomness affects a verdict. External dependencies (vendors, registries, feeds) are faked inside the adapter, which is how fault-injection rows stay deterministic. Manual/evidence rows are not deterministic and are not gate checks.

### Coverage note

Converted from 34 AI-drafted source scenarios of `SK-PSD2-001`; each source scenario maps to exactly one non-backstop row (see the appendix). Static backstops add no scenarios and trace through the check they back. The scenarios were merged into crisp invariants by automation point and failure mode, across categories (positive, negative, boundary, failure/recovery, concurrency/idempotency, retention/audit, common failure, core). Automation points covered: SCA, XS2A, Consent, TPP registration. Source common failures: Missing SCA, API non-compliance. Thresholds, windows and deadlines are *configured* parameters, not asserted statutory values. No regulation or citation was added beyond the source sheet.

### Overlap with the locked neobank playbook (19 checks)

| This check | Neobank check | Strength | Why |
| --- | --- | --- | --- |
| PSD2-SCA-02 | N-IDEMP-01 | related | auth code single-use |
| PSD2-SCA-52 | N-IDEMP-01 | same | conditional update reports success only when a row changed |
| PSD2-SCA-03 | N-CAP-01 | related | cumulative exemption limits enforced server-side |
| PSD2-SCA-53 | N-CAP-01 | same | limits read under lock in the txn, never from payload |
| PSD2-XS2A-02 | N-CAS-01 | related | status lifecycle transitions |
| PSD2-XS2A-03 | N-IDEMP-01 | same | idempotency key → one payment, no double debit |
| PSD2-XS2A-51 | N-IDEMP-01 | same | PIS routes gate on Idempotency-Key |
| PSD2-CON-02 | N-STATE-01 | related | revoked consent rejected |
| PSD2-TPP-02 | N-AUTHN | related | untrusted TPP certificate rejected before effect |

`same` means the neobank check already enforces this invariant, so reuse it instead of re-implementing. `related` means the same defect class, but this check needs its own rule or preset.

### Review flags

- No SME-flagged rows. All rows still need compliance review.

## Appendix: traceability to source scenarios

| Check ID | Source scenario IDs | Categories merged |
| --- | --- | --- |
| PSD2-SCA-01 | SC-PSD2-001-01, SC-PSD2-001-19 | Core, Positive |
| PSD2-SCA-51 | — (static backstop; traced via PSD2-SCA-01) | — |
| PSD2-SCA-02 | SC-PSD2-001-08 | Concurrency/Idempotency |
| PSD2-SCA-52 | — (static backstop; traced via PSD2-SCA-02) | — |
| PSD2-SCA-03 | SC-PSD2-001-04, SC-PSD2-001-05, SC-PSD2-001-20 | Boundary/Edge, Common Failure, Negative |
| PSD2-SCA-53 | — (static backstop; traced via PSD2-SCA-03) | — |
| PSD2-SCA-04 | SC-PSD2-001-06, SC-PSD2-001-07 | Boundary/Edge, Failure/Recovery |
| PSD2-SCA-05 | SC-PSD2-001-09 | Retention/Audit |
| PSD2-XS2A-01 | SC-PSD2-001-03, SC-PSD2-001-10, SC-PSD2-001-21 | Core, Negative, Positive |
| PSD2-XS2A-02 | SC-PSD2-001-12 | Positive |
| PSD2-XS2A-03 | SC-PSD2-001-22, SC-PSD2-001-13 | Concurrency/Idempotency, Failure/Recovery |
| PSD2-XS2A-51 | — (static backstop; traced via PSD2-XS2A-03) | — |
| PSD2-XS2A-04 | SC-PSD2-001-11 | Boundary/Edge |
| PSD2-XS2A-05 | SC-PSD2-001-24, SC-PSD2-001-23 | Common Failure, Retention/Audit |
| PSD2-CON-01 | SC-PSD2-001-02, SC-PSD2-001-25, SC-PSD2-001-26, SC-PSD2-001-14 | Boundary/Edge, Core, Negative, Positive |
| PSD2-CON-02 | SC-PSD2-001-15, SC-PSD2-001-29 | Common Failure, Concurrency/Idempotency |
| PSD2-CON-03 | SC-PSD2-001-27 | Failure/Recovery |
| PSD2-CON-51 | — (static backstop; traced via PSD2-CON-03) | — |
| PSD2-CON-04 | SC-PSD2-001-28 | Retention/Audit |
| PSD2-TPP-01 | SC-PSD2-001-16, SC-PSD2-001-30, SC-PSD2-001-34 | Core, Negative, Positive |
| PSD2-TPP-02 | SC-PSD2-001-17, SC-PSD2-001-33 | Boundary/Edge, Common Failure |
| PSD2-TPP-51 | — (static backstop; traced via PSD2-TPP-02) | — |
| PSD2-TPP-03 | SC-PSD2-001-18, SC-PSD2-001-31 | Concurrency/Idempotency, Failure/Recovery |
| PSD2-TPP-04 | SC-PSD2-001-32 | Retention/Audit |

# Helix review rules

Generated from `checks.json` (20 static and behavioural checks; manual/evidence items are not code-reviewable and are omitted). Severity is derived from the playbook priority (P1 -> MEDIUM); Category MM marks money-movement checks. Rule text is the source invariant, unchanged; it is AI-drafted and needs compliance review.

## Rule PSD2-SCA-01: A payment executes only after two independent SCA factors with an auth code bound to amount and p...
Severity: MEDIUM
Category: MM
Scenario: sca
Requirement: MUST
Invariant: A payment executes only after two independent SCA factors with an auth code bound to amount and payee; altered amount/payee invalidates it.

Source check `PSD2-SCA-01` from `checks.json` (behavioural; deterministic: yes). Covers: SCA · Missing SCA · PSD2 (EU). Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-PSD2-001.

## Rule PSD2-SCA-51: Payment execution verifies the SCA auth code against the stored amount+payee binding inside the e...
Severity: MEDIUM
Category: MM
Scenario: sca
Requirement: MUST
Invariant: Payment execution verifies the SCA auth code against the stored amount+payee binding inside the execute path; amount/payee are not taken from the request after SCA.

Source check `PSD2-SCA-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: SCA · Missing SCA · PSD2 (EU). Backstop for PSD2-SCA-01. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-PSD2-001.

## Rule PSD2-SCA-02: An SCA authentication code authorises exactly one payment
Severity: MEDIUM
Category: MM
Scenario: sca
Requirement: MUST
Invariant: An SCA authentication code authorises exactly one payment; concurrent reuse is rejected.

Source check `PSD2-SCA-02` from `checks.json` (behavioural; deterministic: yes). Covers: SCA · Missing SCA · PSD2 (EU). Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-PSD2-001.

## Rule PSD2-SCA-52: SCA auth codes are consumed with a single-use conditional update (consumed_at IS NULL) and succes...
Severity: MEDIUM
Category: MM
Scenario: sca
Requirement: MUST
Invariant: SCA auth codes are consumed with a single-use conditional update (consumed_at IS NULL) and success is reported only when a row changed.

Source check `PSD2-SCA-52` from `checks.json` (static, static backstop; deterministic: yes). Covers: SCA · Missing SCA · PSD2 (EU). Backstop for PSD2-SCA-02. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-PSD2-001.

## Rule PSD2-SCA-03: An SCA exemption applies only when every configured condition holds (low-value amount/count/cumul...
Severity: MEDIUM
Category: MM
Scenario: sca
Requirement: MUST
Invariant: An SCA exemption applies only when every configured condition holds (low-value amount/count/cumulative limits, trusted beneficiary added under SCA); otherwise full SCA.

Source check `PSD2-SCA-03` from `checks.json` (behavioural; deterministic: yes). Covers: SCA · Missing SCA · PSD2 (EU). Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-PSD2-002, RR-PSD2-006.

## Rule PSD2-SCA-53: Exemption counters/limits are read and incremented inside the payment transaction under a lock —...
Severity: MEDIUM
Category: MM
Scenario: sca
Requirement: MUST
Invariant: Exemption counters/limits are read and incremented inside the payment transaction under a lock — never from client-supplied values.

Source check `PSD2-SCA-53` from `checks.json` (static, static backstop; deterministic: yes). Covers: SCA · Missing SCA · PSD2 (EU). Backstop for PSD2-SCA-03. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-PSD2-002, RR-PSD2-006.

## Rule PSD2-SCA-04: Failed-attempt lockout triggers at the configured count
Severity: MEDIUM
Category: MM
Scenario: sca
Requirement: MUST
Invariant: Failed-attempt lockout triggers at the configured count; expired challenges cannot complete and idle sessions re-authenticate (controllable clock).

Source check `PSD2-SCA-04` from `checks.json` (behavioural; deterministic: yes). Covers: SCA · Missing SCA · PSD2 (EU). Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-PSD2-001.

## Rule PSD2-XS2A-01: XS2A responses conform to the published spec
Severity: MEDIUM
Category: MM
Scenario: xs2a
Requirement: MUST
Invariant: XS2A responses conform to the published spec: malformed requests get spec error codes with no partial processing or data leakage; data parity with the PSU channel.

Source check `PSD2-XS2A-01` from `checks.json` (behavioural; deterministic: yes). Covers: XS2A · API non-compliance · PSD2 (EU). Review status in source: Drafted (AI) – needs compliance review.

## Rule PSD2-XS2A-02: Payment-initiation status transitions follow the spec lifecycle and the final status matches the...
Severity: MEDIUM
Category: MM
Scenario: xs2a
Requirement: MUST
Invariant: Payment-initiation status transitions follow the spec lifecycle and the final status matches the ledger.

Source check `PSD2-XS2A-02` from `checks.json` (behavioural; deterministic: yes). Covers: XS2A · API non-compliance · PSD2 (EU). Review status in source: Drafted (AI) – needs compliance review.

## Rule PSD2-XS2A-03: Duplicate payment initiation with the same idempotency key creates one payment and no double debit
Severity: MEDIUM
Category: MM
Scenario: xs2a
Requirement: MUST
Invariant: Duplicate payment initiation with the same idempotency key creates one payment and no double debit; PIS retries after an outage do not duplicate.

Source check `PSD2-XS2A-03` from `checks.json` (behavioural; deterministic: yes). Covers: XS2A · API non-compliance · PSD2 (EU). Review status in source: Drafted (AI) – needs compliance review.

## Rule PSD2-XS2A-51: Payment-initiation routes require an idempotency key with read-first/replay semantics
Severity: MEDIUM
Category: MM
Scenario: xs2a
Requirement: MUST
Invariant: Payment-initiation routes require an idempotency key with read-first/replay semantics.

Source check `PSD2-XS2A-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: XS2A · API non-compliance · PSD2 (EU). Backstop for PSD2-XS2A-03. Review status in source: Drafted (AI) – needs compliance review.

## Rule PSD2-XS2A-04: Unattended AIS requests above the configured frequency limit are rejected
Severity: MEDIUM
Category: MM
Scenario: xs2a
Requirement: MUST
Invariant: Unattended AIS requests above the configured frequency limit are rejected; PSU-present requests unaffected.

Source check `PSD2-XS2A-04` from `checks.json` (behavioural; deterministic: yes). Covers: XS2A · API non-compliance · PSD2 (EU). Review status in source: Drafted (AI) – needs compliance review.

## Rule PSD2-CON-01: A TPP accesses only consented accounts within consent validity and frequency limits
Severity: MEDIUM
Category: MM
Scenario: consent
Requirement: MUST
Invariant: A TPP accesses only consented accounts within consent validity and frequency limits; expired/revoked consent returns consent-invalid with no data.

Source check `PSD2-CON-01` from `checks.json` (behavioural; deterministic: yes). Covers: Consent · None · PSD2 (EU). Review status in source: Drafted (AI) – needs compliance review.

## Rule PSD2-CON-02: A PSU revocation from the dashboard rejects the TPP's next request
Severity: MEDIUM
Category: MM
Scenario: consent
Requirement: MUST
Invariant: A PSU revocation from the dashboard rejects the TPP's next request; the dashboard lists every active consent.

Source check `PSD2-CON-02` from `checks.json` (behavioural; deterministic: yes). Covers: Consent · None · PSD2 (EU). Review status in source: Drafted (AI) – needs compliance review.

## Rule PSD2-CON-03: Consent store outage fails closed — no default-allow and no stale cached grant beyond TTL
Severity: MEDIUM
Category: MM
Scenario: consent
Requirement: MUST
Invariant: Consent store outage fails closed — no default-allow and no stale cached grant beyond TTL.

Source check `PSD2-CON-03` from `checks.json` (behavioural; deterministic: yes). Covers: Consent · None · PSD2 (EU). Review status in source: Drafted (AI) – needs compliance review.

## Rule PSD2-CON-51: Consent-store failure handling denies access
Severity: MEDIUM
Category: MM
Scenario: consent
Requirement: MUST
Invariant: Consent-store failure handling denies access; cached grants carry an explicit TTL check.

Source check `PSD2-CON-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: Consent · None · PSD2 (EU). Backstop for PSD2-CON-03. Review status in source: Drafted (AI) – needs compliance review.

## Rule PSD2-TPP-01: Access is permitted only for roles in the TPP's certificate/register (AIS/PIS/CBPII matrix matche...
Severity: MEDIUM
Category: MM
Scenario: tpp-registration
Requirement: MUST
Invariant: Access is permitted only for roles in the TPP's certificate/register (AIS/PIS/CBPII matrix matches config exactly).

Source check `PSD2-TPP-01` from `checks.json` (behavioural; deterministic: yes). Covers: TPP registration · API non-compliance · PSD2 (EU). Review status in source: Drafted (AI) – needs compliance review.

## Rule PSD2-TPP-02: Expired, revoked or self-signed TPP certificates are rejected on the next request
Severity: MEDIUM
Category: MM
Scenario: tpp-registration
Requirement: MUST
Invariant: Expired, revoked or self-signed TPP certificates are rejected on the next request; revocation-check failure fails closed.

Source check `PSD2-TPP-02` from `checks.json` (behavioural; deterministic: yes). Covers: TPP registration · API non-compliance · PSD2 (EU). Review status in source: Drafted (AI) – needs compliance review.

## Rule PSD2-TPP-51: TLS/client-cert verification is not disabled anywhere (no insecure-skip, self-signed allow or rev...
Severity: MEDIUM
Category: MM
Scenario: tpp-registration
Requirement: MUST
Invariant: TLS/client-cert verification is not disabled anywhere (no insecure-skip, self-signed allow or revocation-check bypass flags).

Source check `PSD2-TPP-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: TPP registration · API non-compliance · PSD2 (EU). Backstop for PSD2-TPP-02. Review status in source: Drafted (AI) – needs compliance review.

## Rule PSD2-TPP-03: Registry lookup failure never admits an unverified TPP
Severity: MEDIUM
Category: MM
Scenario: tpp-registration
Requirement: MUST
Invariant: Registry lookup failure never admits an unverified TPP; cached status used only within TTL; register revocation blocks new calls after ingestion.

Source check `PSD2-TPP-03` from `checks.json` (behavioural; deterministic: yes). Covers: TPP registration · API non-compliance · PSD2 (EU). Review status in source: Drafted (AI) – needs compliance review.
