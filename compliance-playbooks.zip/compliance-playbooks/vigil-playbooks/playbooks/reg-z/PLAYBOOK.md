---
helixPlaybookFormat: helix-playbook/0.1-proposal
playbookId: vigil-reg-z
title: "Reg Z APR, Finance Charge & Rescission"
declaredVersion: 0.1.0
intent: draft
applicability:
  languages: [javascript, typescript]
  scenarios: [apr-calculation, finance-charge, right-of-rescission]
---
# Helix portable playbook — DRAFT manifest · Reg Z APR, Finance Charge & Rescission

> **DRAFT — not LOCKED.** Proposed TILA / Reg Z (Consumer Protection) playbook converted from Vigil skill `SK-REGZ-001`: one runner, two layers, **15 harness checks (4 static, incl. 3 static backstops, + 11 behavioural)**, plus 3 manual/evidence items listed separately because neither layer can verify them. Every invariant, layer and determinism call is **AI-drafted (Helix) and needs compliance review**. No detector or rule code exists yet. Before this manifest can be LOCKED, each row needs its detector/rule, a review, and a commit that adds the check alongside its row.

## Layers

- **static**: a repo-agnostic source scanner parameterised by a `VIGIL_REGZ` preset (no app specifics in the detector). It reads source / SQL / config / IaC / git-diff, **fails CLOSED** on a match, and runs with **no adapter**, so it is the CI gate. *Static backstops* (IDs `-5x`) prove a supporting source invariant for a named behavioural check, the way N-CAP-01 / N-STATE-01 back neobank behaviour. They fire even when the adapter never drives that path. Backstops of ⚑ SME checks stay out of the gate.
- **behavioural**: a rule written once against the canonical `MoneySystem` interface (or a DRAFT extension surface in `adapters/`) and driven through the app adapter. Surfaces needed: **LendingSystem** (`adapters/lending.ts`). Every behavioural row reports NOT_EXERCISED until an adapter implements its surface. It returns **CHECKED only when it actually drove the guard's path**.
- **manual/evidence**: organisational process, live-infrastructure, statistical or retention evidence that no source scan or adapter-driven rule can prove. These are **outside the harness**, report `NOT_APPLICABLE` to it, and are tracked as evidence tasks, never as passes.

## Verdicts

`CHECKED` the path ran and the guard held · `FINDING` the guard was violated · `NOT_APPLICABLE` the invariant cannot apply here (incl. every manual/evidence item) · `NOT_EXERCISED` (glyph `????`) the adapter did not drive the path, so nothing is proven. NOT_EXERCISED is **surfaced distinctly and never counted as a pass** (no fake coverage). A ⚑ SME check with no approved parameter matrix reports `NOT_EXERCISED`, never `CHECKED`.

## How to run

- **Not runnable yet**: this draft defines invariants only (no detector/rule code). The intended shape mirrors the neobank playbook:
  - CI gate (adapter-free, blocks on any static FINDING): `run-static` with preset `VIGIL_REGZ`.
  - Full combined table (static + behavioural via the adapter): `run-all`.
- Machine-readable rows: `checks.json` (same IDs; includes source-scenario traceability and neobank overlaps).

## The draft inventory: 4 static + 11 behavioural = 15 checks

| ID | Layer | Deterministic | Invariant (one line) | Covers (automation point · common failure · regulation) |
| --- | --- | --- | --- | --- |
| **REGZ-APR-01** | behavioural | yes | The disclosed APR is within the configured tolerance of a reference APR for every loan shape (irregular first period, odd days, at the tolerance boundary), including after fee-schedule changes. | APR calculation · Wrong APR · TILA / Reg Z |
| **REGZ-APR-02** | behavioural | yes | Invalid loan inputs produce validation errors and no APR disclosure. | APR calculation · Wrong APR · TILA / Reg Z |
| **REGZ-APR-03** | behavioural | yes | Variable-rate APR updates per configured margin/caps from a fresh index; a stale/missing index feed blocks rate changes and disclosures. | APR calculation · Wrong APR · TILA / Reg Z |
| **REGZ-APR-51** | static | yes | The rate-change job checks index-feed freshness (as-of timestamp) before computing; stale data aborts. | backstop for REGZ-APR-03 · APR calculation · Wrong APR · TILA / Reg Z |
| **REGZ-APR-04** | behavioural | yes | A pricing change recalculates the APR once and the final disclosure reflects the latest terms. | APR calculation · Wrong APR · TILA / Reg Z |
| **REGZ-FIN-01** | static | yes | Every fee type in the fee table carries a finance-charge classification; an unclassified new fee fails config validation. | Finance charge · missing disclosure · TILA / Reg Z |
| **REGZ-FIN-02** | behavioural | yes | The finance charge includes every fee classified as finance charge, amount financed reconciles, and open-end interest equals the reference method. | Finance charge · missing disclosure · TILA / Reg Z |
| **REGZ-FIN-03** | behavioural | yes | Penalty/late fees never exceed the configured cap or the minimum payment due. | Finance charge · missing disclosure · TILA / Reg Z |
| **REGZ-FIN-51** | static | yes | Late/penalty fee computation applies min(configured cap, minimum payment due) in the fee engine. | backstop for REGZ-FIN-03 · Finance charge · missing disclosure · TILA / Reg Z |
| **REGZ-FIN-04** | behavioural | yes | Fee refunds/waivers adjust disclosed and year-to-date totals; fee-posting replay never double-counts finance charge. | Finance charge · missing disclosure · TILA / Reg Z |
| **REGZ-FIN-05** | behavioural | yes | Credit use is blocked until required disclosures are delivered (timestamp stored). | Finance charge · missing disclosure · TILA / Reg Z |
| **REGZ-RES-01** | behavioural | yes | No funds disburse until the rescission period expires (business-day definition across holidays); disbursement attempts inside the window are rejected. | Right of rescission · general control (no source failure) · TILA / Reg Z |
| **REGZ-RES-51** | static | yes | The disbursement path checks rescission-window expiry via the business-day calendar service and rescission status inside the same transaction. | backstop for REGZ-RES-01 · Right of rescission · general control (no source failure) · TILA / Reg Z |
| **REGZ-RES-02** | behavioural | yes | A timely rescission by any entitled owner — even during an outage or a racing disbursement — cancels the transaction with no partial disbursement. | Right of rescission · general control (no source failure) · TILA / Reg Z |
| **REGZ-RES-03** | behavioural | yes | Each person with the right receives the rescission notice; a missing notice extends the right per configuration. | Right of rescission · general control (no source failure) · TILA / Reg Z |

## Outside the harness: manual/evidence (3)

These items are not harness checks. Each reports `NOT_APPLICABLE` to the runner and needs an owner and evidence on a schedule.

| ID | Layer | Deterministic | Invariant (one line) | Covers (automation point · common failure · regulation) |
| --- | --- | --- | --- | --- |
| **REGZ-APR-05** | manual/evidence | no (manual) | APR inputs and engine version are retained so each disclosure is reproducible. | APR calculation · general control (no source failure) · TILA / Reg Z |
| **REGZ-FIN-06** | manual/evidence | no (manual) | Fee classification table versions are retained and linked to each disclosure. | Finance charge · general control (no source failure) · TILA / Reg Z |
| **REGZ-RES-04** | manual/evidence | no (manual) | Rescission evidence is retained with timestamps. | Right of rescission · general control (no source failure) · TILA / Reg Z |

### Determinism

Every harness row (static and behavioural) is drafted as deterministic. Static detectors, including backstops, are pure functions of the committed source/config/diff. Behavioural rules each run against a **fresh `reset()` MoneySystem** (no state leaks between rules), driven by a **controllable clock**; deadlines, windows, expiries and cadences are asserted by advancing that clock, never by wall-clock reads, and no randomness affects a verdict. External dependencies (vendors, registries, feeds) are faked inside the adapter, which is how fault-injection rows stay deterministic. Manual/evidence rows are not deterministic and are not gate checks.

### Coverage note

Converted from 25 AI-drafted source scenarios of `SK-REGZ-001`; each source scenario maps to exactly one non-backstop row (see the appendix). Static backstops add no scenarios and trace through the check they back. The scenarios were merged into crisp invariants by automation point and failure mode, across categories (positive, negative, boundary, failure/recovery, concurrency/idempotency, retention/audit, common failure, core). Automation points covered: APR calculation, Finance charge, Right of rescission. Source common failures: Wrong APR, missing disclosure. Thresholds, windows and deadlines are *configured* parameters, not asserted statutory values. No regulation or citation was added beyond the source sheet.

### Overlap with the locked neobank playbook (19 checks)

| This check | Neobank check | Strength | Why |
| --- | --- | --- | --- |
| REGZ-FIN-03 | N-CAP-01 | related | fee cap |
| REGZ-FIN-04 | N-RWD-04 | related | fee refunds adjust totals |
| REGZ-RES-02 | N-ATOMIC | related | no partial disbursement under race |

`same` means the neobank check already enforces this invariant, so reuse it instead of re-implementing. `related` means the same defect class, but this check needs its own rule or preset.

### Review flags

- No SME-flagged rows. All rows still need compliance review.

## Appendix: traceability to source scenarios

| Check ID | Source scenario IDs | Categories merged |
| --- | --- | --- |
| REGZ-APR-01 | SC-REGZ-001-01, SC-REGZ-001-04, SC-REGZ-001-05, SC-REGZ-001-19 | Boundary/Edge, Common Failure, Core |
| REGZ-APR-02 | SC-REGZ-001-16 | Negative |
| REGZ-APR-03 | SC-REGZ-001-06, SC-REGZ-001-07 | Failure/Recovery, Positive |
| REGZ-APR-51 | — (static backstop; traced via REGZ-APR-03) | — |
| REGZ-APR-04 | SC-REGZ-001-17 | Concurrency/Idempotency |
| REGZ-APR-05 | SC-REGZ-001-18 | Retention/Audit |
| REGZ-FIN-01 | SC-REGZ-001-22 | Common Failure |
| REGZ-FIN-02 | SC-REGZ-001-02, SC-REGZ-001-08 | Core, Positive |
| REGZ-FIN-03 | SC-REGZ-001-09 | Boundary/Edge |
| REGZ-FIN-51 | — (static backstop; traced via REGZ-FIN-03) | — |
| REGZ-FIN-04 | SC-REGZ-001-10, SC-REGZ-001-20 | Concurrency/Idempotency, Failure/Recovery |
| REGZ-FIN-05 | SC-REGZ-001-11 | Negative |
| REGZ-FIN-06 | SC-REGZ-001-21 | Retention/Audit |
| REGZ-RES-01 | SC-REGZ-001-03, SC-REGZ-001-12, SC-REGZ-001-23 | Boundary/Edge, Core, Negative |
| REGZ-RES-51 | — (static backstop; traced via REGZ-RES-01) | — |
| REGZ-RES-02 | SC-REGZ-001-14, SC-REGZ-001-24 | Concurrency/Idempotency, Failure/Recovery |
| REGZ-RES-03 | SC-REGZ-001-13, SC-REGZ-001-25 | Common Failure, Positive |
| REGZ-RES-04 | SC-REGZ-001-15 | Retention/Audit |

# Helix review rules

Generated from `checks.json` (15 static and behavioural checks; manual/evidence items are not code-reviewable and are omitted). Severity is derived from the playbook priority (P1 -> MEDIUM); Category MM marks money-movement checks. Rule text is the source invariant, unchanged; it is AI-drafted and needs compliance review.

## Rule REGZ-APR-01: The disclosed APR is within the configured tolerance of a reference APR for every loan shape (irr...
Severity: MEDIUM
Category: NON_MM
Scenario: apr-calculation
Requirement: MUST
Invariant: The disclosed APR is within the configured tolerance of a reference APR for every loan shape (irregular first period, odd days, at the tolerance boundary), including after fee-schedule changes.

Source check `REGZ-APR-01` from `checks.json` (behavioural; deterministic: yes). Covers: APR calculation · Wrong APR · TILA / Reg Z. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-REGZ-004.

## Rule REGZ-APR-02: Invalid loan inputs produce validation errors and no APR disclosure
Severity: MEDIUM
Category: NON_MM
Scenario: apr-calculation
Requirement: MUST
Invariant: Invalid loan inputs produce validation errors and no APR disclosure.

Source check `REGZ-APR-02` from `checks.json` (behavioural; deterministic: yes). Covers: APR calculation · Wrong APR · TILA / Reg Z. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-REGZ-004.

## Rule REGZ-APR-03: Variable-rate APR updates per configured margin/caps from a fresh index
Severity: MEDIUM
Category: NON_MM
Scenario: apr-calculation
Requirement: MUST
Invariant: Variable-rate APR updates per configured margin/caps from a fresh index; a stale/missing index feed blocks rate changes and disclosures.

Source check `REGZ-APR-03` from `checks.json` (behavioural; deterministic: yes). Covers: APR calculation · Wrong APR · TILA / Reg Z. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-REGZ-004.

## Rule REGZ-APR-51: The rate-change job checks index-feed freshness (as-of timestamp) before computing
Severity: MEDIUM
Category: NON_MM
Scenario: apr-calculation
Requirement: MUST
Invariant: The rate-change job checks index-feed freshness (as-of timestamp) before computing; stale data aborts.

Source check `REGZ-APR-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: APR calculation · Wrong APR · TILA / Reg Z. Backstop for REGZ-APR-03. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-REGZ-004.

## Rule REGZ-APR-04: A pricing change recalculates the APR once and the final disclosure reflects the latest terms
Severity: MEDIUM
Category: NON_MM
Scenario: apr-calculation
Requirement: MUST
Invariant: A pricing change recalculates the APR once and the final disclosure reflects the latest terms.

Source check `REGZ-APR-04` from `checks.json` (behavioural; deterministic: yes). Covers: APR calculation · Wrong APR · TILA / Reg Z. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-REGZ-004.

## Rule REGZ-FIN-01: Every fee type in the fee table carries a finance-charge classification
Severity: MEDIUM
Category: NON_MM
Scenario: finance-charge
Requirement: MUST
Invariant: Every fee type in the fee table carries a finance-charge classification; an unclassified new fee fails config validation.

Source check `REGZ-FIN-01` from `checks.json` (static; deterministic: yes). Covers: Finance charge · missing disclosure · TILA / Reg Z. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-REGZ-004, RR-REGZ-005.

## Rule REGZ-FIN-02: The finance charge includes every fee classified as finance charge, amount financed reconciles, a...
Severity: MEDIUM
Category: NON_MM
Scenario: finance-charge
Requirement: MUST
Invariant: The finance charge includes every fee classified as finance charge, amount financed reconciles, and open-end interest equals the reference method.

Source check `REGZ-FIN-02` from `checks.json` (behavioural; deterministic: yes). Covers: Finance charge · missing disclosure · TILA / Reg Z. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-REGZ-004, RR-REGZ-005.

## Rule REGZ-FIN-03: Penalty/late fees never exceed the configured cap or the minimum payment due
Severity: MEDIUM
Category: NON_MM
Scenario: finance-charge
Requirement: MUST
Invariant: Penalty/late fees never exceed the configured cap or the minimum payment due.

Source check `REGZ-FIN-03` from `checks.json` (behavioural; deterministic: yes). Covers: Finance charge · missing disclosure · TILA / Reg Z. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-REGZ-017.

## Rule REGZ-FIN-51: Late/penalty fee computation applies min(configured cap, minimum payment due) in the fee engine
Severity: MEDIUM
Category: NON_MM
Scenario: finance-charge
Requirement: MUST
Invariant: Late/penalty fee computation applies min(configured cap, minimum payment due) in the fee engine.

Source check `REGZ-FIN-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: Finance charge · missing disclosure · TILA / Reg Z. Backstop for REGZ-FIN-03. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-REGZ-017.

## Rule REGZ-FIN-04: Fee refunds/waivers adjust disclosed and year-to-date totals
Severity: MEDIUM
Category: NON_MM
Scenario: finance-charge
Requirement: MUST
Invariant: Fee refunds/waivers adjust disclosed and year-to-date totals; fee-posting replay never double-counts finance charge.

Source check `REGZ-FIN-04` from `checks.json` (behavioural; deterministic: yes). Covers: Finance charge · missing disclosure · TILA / Reg Z. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-REGZ-005.

## Rule REGZ-FIN-05: Credit use is blocked until required disclosures are delivered (timestamp stored)
Severity: MEDIUM
Category: NON_MM
Scenario: finance-charge
Requirement: MUST
Invariant: Credit use is blocked until required disclosures are delivered (timestamp stored).

Source check `REGZ-FIN-05` from `checks.json` (behavioural; deterministic: yes). Covers: Finance charge · missing disclosure · TILA / Reg Z. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-REGZ-004, RR-REGZ-005.

## Rule REGZ-RES-01: No funds disburse until the rescission period expires (business-day definition across holidays)
Severity: MEDIUM
Category: NON_MM
Scenario: right-of-rescission
Requirement: MUST
Invariant: No funds disburse until the rescission period expires (business-day definition across holidays); disbursement attempts inside the window are rejected.

Source check `REGZ-RES-01` from `checks.json` (behavioural; deterministic: yes). Covers: Right of rescission · None · TILA / Reg Z. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-REGZ-014.

## Rule REGZ-RES-51: The disbursement path checks rescission-window expiry via the business-day calendar service and r...
Severity: MEDIUM
Category: NON_MM
Scenario: right-of-rescission
Requirement: MUST
Invariant: The disbursement path checks rescission-window expiry via the business-day calendar service and rescission status inside the same transaction.

Source check `REGZ-RES-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: Right of rescission · None · TILA / Reg Z. Backstop for REGZ-RES-01. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-REGZ-014.

## Rule REGZ-RES-02: A timely rescission by any entitled owner — even during an outage or a racing disbursement — canc...
Severity: MEDIUM
Category: NON_MM
Scenario: right-of-rescission
Requirement: MUST
Invariant: A timely rescission by any entitled owner — even during an outage or a racing disbursement — cancels the transaction with no partial disbursement.

Source check `REGZ-RES-02` from `checks.json` (behavioural; deterministic: yes). Covers: Right of rescission · None · TILA / Reg Z. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-REGZ-014.

## Rule REGZ-RES-03: Each person with the right receives the rescission notice
Severity: MEDIUM
Category: NON_MM
Scenario: right-of-rescission
Requirement: MUST
Invariant: Each person with the right receives the rescission notice; a missing notice extends the right per configuration.

Source check `REGZ-RES-03` from `checks.json` (behavioural; deterministic: yes). Covers: Right of rescission · None · TILA / Reg Z. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-REGZ-014.
