---
helixPlaybookFormat: helix-playbook/0.1-proposal
playbookId: vigil-cra
title: "CRA Assessment Area & Lending Test Data"
declaredVersion: 0.1.0
intent: draft
applicability:
  languages: [javascript, typescript]
  scenarios: [assessment-area, lending-test, community-reinvestment]
---
# Helix portable playbook — DRAFT manifest · CRA Assessment Area & Lending Test Data

> **DRAFT — not LOCKED.** Proposed CRA (Lending) playbook converted from Vigil skill `SK-CRA-001`: one runner, two layers, **6 harness checks (1 static, incl. 1 static backstops, + 5 behavioural)**, plus 3 manual/evidence items listed separately because neither layer can verify them. Every invariant, layer and determinism call is **AI-drafted (Helix) and needs compliance review**; 5 check(s) are **⚑ SME-flagged** and cannot gate until an SME/counsel supplies their parameter matrix. No detector or rule code exists yet. Before this manifest can be LOCKED, each row needs its detector/rule, a review, and a commit that adds the check alongside its row.

## Layers

- **static**: a repo-agnostic source scanner parameterised by a `VIGIL_CRA` preset (no app specifics in the detector). It reads source / SQL / config / IaC / git-diff, **fails CLOSED** on a match, and runs with **no adapter**, so it is the CI gate. *Static backstops* (IDs `-5x`) prove a supporting source invariant for a named behavioural check, the way N-CAP-01 / N-STATE-01 back neobank behaviour. They fire even when the adapter never drives that path. Backstops of ⚑ SME checks stay out of the gate.
- **behavioural**: a rule written once against the canonical `MoneySystem` interface (or a DRAFT extension surface in `adapters/`) and driven through the app adapter. Surfaces needed: **LendingSystem** (`adapters/lending.ts`). Every behavioural row reports NOT_EXERCISED until an adapter implements its surface. It returns **CHECKED only when it actually drove the guard's path**.
- **manual/evidence**: organisational process, live-infrastructure, statistical or retention evidence that no source scan or adapter-driven rule can prove. These are **outside the harness**, report `NOT_APPLICABLE` to it, and are tracked as evidence tasks, never as passes.

## Verdicts

`CHECKED` the path ran and the guard held · `FINDING` the guard was violated · `NOT_APPLICABLE` the invariant cannot apply here (incl. every manual/evidence item) · `NOT_EXERCISED` (glyph `????`) the adapter did not drive the path, so nothing is proven. NOT_EXERCISED is **surfaced distinctly and never counted as a pass** (no fake coverage). A ⚑ SME check with no approved parameter matrix reports `NOT_EXERCISED`, never `CHECKED`.

## How to run

- **Not runnable yet**: this draft defines invariants only (no detector/rule code). The intended shape mirrors the neobank playbook:
  - CI gate (adapter-free, blocks on any static FINDING): `run-static` with preset `VIGIL_CRA`.
  - Full combined table (static + behavioural via the adapter): `run-all`.
- Machine-readable rows: `checks.json` (same IDs; includes source-scenario traceability and neobank overlaps).

## The draft inventory: 1 static + 5 behavioural = 6 checks

| ID | Layer | Deterministic | Invariant (one line) | Covers (automation point · common failure · regulation) |
| --- | --- | --- | --- | --- |
| **CRA-AA-01** | behavioural | yes ⚑ SME | Each record is geocoded to the correct tract and assessment area using one consistent versioned definition; addresses outside all areas are classified outside; geocoder failures are queued, never defaulted. | Assessment area · general control (no source failure) · CRA |
| **CRA-AA-51** | static | yes ⚑ SME | Assessment-area assignment reads one pinned definition version per run; geocoder failure never assigns a default area. | backstop for CRA-AA-01 · Assessment area · general control (no source failure) · CRA |
| **CRA-LT-01** | behavioural | yes ⚑ SME | Lending-test metrics computed per the SME-configured method are reproducible and idempotent, match an independent calculation, and classify income tracts at configured boundaries. | Lending test · failing test · CRA |
| **CRA-LT-02** | behavioural | yes ⚑ SME | Missing tract income data is flagged and excluded per rule — never silently defaulted; metrics below the configured target alert/escalate. | Lending test · failing test · CRA |
| **CRA-CR-01** | behavioural | yes ⚑ SME | Only qualifying activities with configured required attributes and evidence are counted; multi-period/multi-area activities are allocated per rule with totals conserved (no double count). | Community reinvestment · Missing investment · CRA |
| **CRA-CR-02** | behavioural | yes | A finance-feed failure flags the report incomplete. | Community reinvestment · Missing investment · CRA |

## Outside the harness: manual/evidence (3)

These items are not harness checks. Each reports `NOT_APPLICABLE` to the runner and needs an owner and evidence on a schedule.

| ID | Layer | Deterministic | Invariant (one line) | Covers (automation point · common failure · regulation) |
| --- | --- | --- | --- | --- |
| **CRA-AA-02** | manual/evidence | no (manual) | Assessment-area geography matches the branch/deposit footprint (SME-defined criteria); definitions and assignments retained. | Assessment area · general control (no source failure) · CRA |
| **CRA-LT-03** | manual/evidence | no (manual) | Metric inputs, outputs and parameters are retained. | Lending test · general control (no source failure) · CRA |
| **CRA-CR-03** | manual/evidence | no (manual) | CRA records and the public file are retained. | Community reinvestment · general control (no source failure) · CRA |

### Determinism

Every harness row (static and behavioural) is drafted as deterministic. Static detectors, including backstops, are pure functions of the committed source/config/diff. Behavioural rules each run against a **fresh `reset()` MoneySystem** (no state leaks between rules), driven by a **controllable clock**; deadlines, windows, expiries and cadences are asserted by advancing that clock, never by wall-clock reads, and no randomness affects a verdict. External dependencies (vendors, registries, feeds) are faked inside the adapter, which is how fault-injection rows stay deterministic. Manual/evidence rows are not deterministic and are not gate checks. ⚑ SME rows are deterministic once parameters exist, but are excluded from the gate until then.

### Coverage note

Converted from 24 AI-drafted source scenarios of `SK-CRA-001`; each source scenario maps to exactly one non-backstop row (see the appendix). Static backstops add no scenarios and trace through the check they back. The scenarios were merged into crisp invariants by automation point and failure mode, across categories (positive, negative, boundary, failure/recovery, concurrency/idempotency, retention/audit, common failure, core). Automation points covered: Community reinvestment, Assessment area, Lending test. Source common failures: Missing investment, failing test. Thresholds, windows and deadlines are *configured* parameters, not asserted statutory values. No regulation or citation was added beyond the source sheet.

### Overlap with the locked neobank playbook (19 checks)

None. This playbook's invariants are not covered by the neobank set.

### Review flags

- ⚑ **CRA-AA-01**: needs an SME/counsel parameter matrix (source scenarios carry review status "+ SME input").
- ⚑ **CRA-AA-51**: needs an SME/counsel parameter matrix (source scenarios carry review status "+ SME input").
- ⚑ **CRA-LT-01**: needs an SME/counsel parameter matrix (source scenarios carry review status "+ SME input").
- ⚑ **CRA-LT-02**: needs an SME/counsel parameter matrix (source scenarios carry review status "+ SME input").
- ⚑ **CRA-CR-01**: needs an SME/counsel parameter matrix (source scenarios carry review status "+ SME input").

## Appendix: traceability to source scenarios

| Check ID | Source scenario IDs | Categories merged |
| --- | --- | --- |
| CRA-AA-01 | SC-CRA-001-01, SC-CRA-001-05, SC-CRA-001-15, SC-CRA-001-16, SC-CRA-001-17, SC-CRA-001-18 | Boundary/Edge, Concurrency/Idempotency, Core, Failure/Recovery, Negative, Positive |
| CRA-AA-51 | — (static backstop; traced via CRA-AA-01) | — |
| CRA-AA-02 | SC-CRA-001-04, SC-CRA-001-19 | Common Failure, Retention/Audit |
| CRA-LT-01 | SC-CRA-001-02, SC-CRA-001-06, SC-CRA-001-20, SC-CRA-001-22 | Boundary/Edge, Concurrency/Idempotency, Core, Positive |
| CRA-LT-02 | SC-CRA-001-21, SC-CRA-001-07, SC-CRA-001-24 | Common Failure, Failure/Recovery, Negative |
| CRA-LT-03 | SC-CRA-001-23 | Retention/Audit |
| CRA-CR-01 | SC-CRA-001-03, SC-CRA-001-10, SC-CRA-001-11, SC-CRA-001-08, SC-CRA-001-12, SC-CRA-001-14 | Boundary/Edge, Common Failure, Concurrency/Idempotency, Core, Negative, Positive |
| CRA-CR-02 | SC-CRA-001-13 | Failure/Recovery |
| CRA-CR-03 | SC-CRA-001-09 | Retention/Audit |

# Helix review rules

Generated from `checks.json` (6 static and behavioural checks; manual/evidence items are not code-reviewable and are omitted). Severity is derived from the playbook priority (P2 -> LOW); Category MM marks money-movement checks. Rule text is the source invariant, unchanged; it is AI-drafted and needs compliance review.

## Rule CRA-AA-01: Each record is geocoded to the correct tract and assessment area using one consistent versioned d...
Severity: LOW
Category: NON_MM
Scenario: assessment-area
Requirement: MUST
Invariant: Each record is geocoded to the correct tract and assessment area using one consistent versioned definition; addresses outside all areas are classified outside; geocoder failures are queued, never defaulted.

Source check `CRA-AA-01` from `checks.json` (behavioural; deterministic: yes). Covers: Assessment area · None · CRA. Flagged for SME input in the source; needs an approved parameter matrix. Review status in source: Drafted (AI) – needs compliance review + SME input.

## Rule CRA-AA-51: Assessment-area assignment reads one pinned definition version per run
Severity: LOW
Category: NON_MM
Scenario: assessment-area
Requirement: MUST
Invariant: Assessment-area assignment reads one pinned definition version per run; geocoder failure never assigns a default area.

Source check `CRA-AA-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: Assessment area · None · CRA. Backstop for CRA-AA-01. Flagged for SME input in the source; needs an approved parameter matrix. Review status in source: Drafted (AI) – needs compliance review + SME input.

## Rule CRA-LT-01: Lending-test metrics computed per the SME-configured method are reproducible and idempotent, matc...
Severity: LOW
Category: NON_MM
Scenario: lending-test
Requirement: MUST
Invariant: Lending-test metrics computed per the SME-configured method are reproducible and idempotent, match an independent calculation, and classify income tracts at configured boundaries.

Source check `CRA-LT-01` from `checks.json` (behavioural; deterministic: yes). Covers: Lending test · failing test · CRA. Flagged for SME input in the source; needs an approved parameter matrix. Review status in source: Drafted (AI) – needs compliance review + SME input.

## Rule CRA-LT-02: Missing tract income data is flagged and excluded per rule — never silently defaulted
Severity: LOW
Category: NON_MM
Scenario: lending-test
Requirement: MUST
Invariant: Missing tract income data is flagged and excluded per rule — never silently defaulted; metrics below the configured target alert/escalate.

Source check `CRA-LT-02` from `checks.json` (behavioural; deterministic: yes). Covers: Lending test · failing test · CRA. Flagged for SME input in the source; needs an approved parameter matrix. Review status in source: Drafted (AI) – needs compliance review + SME input.

## Rule CRA-CR-01: Only qualifying activities with configured required attributes and evidence are counted
Severity: LOW
Category: NON_MM
Scenario: community-reinvestment
Requirement: MUST
Invariant: Only qualifying activities with configured required attributes and evidence are counted; multi-period/multi-area activities are allocated per rule with totals conserved (no double count).

Source check `CRA-CR-01` from `checks.json` (behavioural; deterministic: yes). Covers: Community reinvestment · Missing investment · CRA. Flagged for SME input in the source; needs an approved parameter matrix. Review status in source: Drafted (AI) – needs compliance review + SME input.

## Rule CRA-CR-02: A finance-feed failure flags the report incomplete
Severity: LOW
Category: NON_MM
Scenario: community-reinvestment
Requirement: MUST
Invariant: A finance-feed failure flags the report incomplete.

Source check `CRA-CR-02` from `checks.json` (behavioural; deterministic: yes). Covers: Community reinvestment · Missing investment · CRA. Review status in source: Drafted (AI) – needs compliance review.
