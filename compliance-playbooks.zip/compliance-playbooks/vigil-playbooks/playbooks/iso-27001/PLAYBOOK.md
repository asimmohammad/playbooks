---
helixPlaybookFormat: helix-playbook/0.1-proposal
playbookId: vigil-iso-27001
title: "ISO 27001 ISMS Risk & Control Assurance"
declaredVersion: 0.1.0
intent: draft
applicability:
  languages: [javascript, typescript]
  scenarios: [risk-assessment, control-implementation]
---
# Helix portable playbook — DRAFT manifest · ISO 27001 ISMS Risk & Control Assurance

> **DRAFT — not LOCKED.** Proposed ISO 27001 (Information Security) playbook converted from Vigil skill `SK-ISO-001`: one runner, two layers, **4 harness checks (1 static, incl. 0 static backstops, + 3 behavioural)**, plus 4 manual/evidence items listed separately because neither layer can verify them. Every invariant, layer and determinism call is **AI-drafted (Helix) and needs compliance review**. No detector or rule code exists yet. Before this manifest can be LOCKED, each row needs its detector/rule, a review, and a commit that adds the check alongside its row.

## Layers

- **static**: a repo-agnostic source scanner parameterised by a `VIGIL_ISO` preset (no app specifics in the detector). It reads source / SQL / config / IaC / git-diff, **fails CLOSED** on a match, and runs with **no adapter**, so it is the CI gate. *Static backstops* (IDs `-5x`) prove a supporting source invariant for a named behavioural check, the way N-CAP-01 / N-STATE-01 back neobank behaviour. They fire even when the adapter never drives that path. Backstops of ⚑ SME checks stay out of the gate.
- **behavioural**: a rule written once against the canonical `MoneySystem` interface (or a DRAFT extension surface in `adapters/`) and driven through the app adapter. Surfaces needed: **GovernanceSystem** (`adapters/governance.ts`). Every behavioural row reports NOT_EXERCISED until an adapter implements its surface. It returns **CHECKED only when it actually drove the guard's path**.
- **manual/evidence**: organisational process, live-infrastructure, statistical or retention evidence that no source scan or adapter-driven rule can prove. These are **outside the harness**, report `NOT_APPLICABLE` to it, and are tracked as evidence tasks, never as passes.

## Verdicts

`CHECKED` the path ran and the guard held · `FINDING` the guard was violated · `NOT_APPLICABLE` the invariant cannot apply here (incl. every manual/evidence item) · `NOT_EXERCISED` (glyph `????`) the adapter did not drive the path, so nothing is proven. NOT_EXERCISED is **surfaced distinctly and never counted as a pass** (no fake coverage). A ⚑ SME check with no approved parameter matrix reports `NOT_EXERCISED`, never `CHECKED`.

## How to run

- **Not runnable yet**: this draft defines invariants only (no detector/rule code). The intended shape mirrors the neobank playbook:
  - CI gate (adapter-free, blocks on any static FINDING): `run-static` with preset `VIGIL_ISO`.
  - Full combined table (static + behavioural via the adapter): `run-all`.
- Machine-readable rows: `checks.json` (same IDs; includes source-scenario traceability and neobank overlaps).

## The draft inventory: 1 static + 3 behavioural = 4 checks

| ID | Layer | Deterministic | Invariant (one line) | Covers (automation point · common failure · regulation) |
| --- | --- | --- | --- | --- |
| **ISO-RA-01** | behavioural | yes | A new asset/system creates a risk-assessment task and go-live is blocked until assessed; a risk without owner/treatment is rejected. | Risk assessment · Missing assessment · ISO 27001 |
| **ISO-RA-02** | behavioural | yes | Above the configured score threshold a treatment plan and owner are required; overdue treatment and stale assessments escalate (controllable clock). | Risk assessment · Missing assessment · ISO 27001 |
| **ISO-CTL-01** | static | yes | Technical control settings in config/IaC hold at their configured thresholds; drift from baseline is detected and ticketed. | Control implementation · control gap · ISO 27001 |
| **ISO-CTL-03** | behavioural | yes | Data flows to a supplier are blocked until the supplier is assessed. | Control implementation · control gap · ISO 27001 |

## Outside the harness: manual/evidence (4)

These items are not harness checks. Each reports `NOT_APPLICABLE` to the runner and needs an owner and evidence on a schedule.

| ID | Layer | Deterministic | Invariant (one line) | Covers (automation point · common failure · regulation) |
| --- | --- | --- | --- | --- |
| **ISO-ISMS-01** | manual/evidence | no (manual) | ISMS scope and asset register cover every in-scope production asset; policies are reviewed within the configured cycle with versions kept. | ISMS · control gap · ISO 27001 |
| **ISO-ISMS-02** | manual/evidence | no (manual) | Nonconformities close only with corrective-action evidence; a failed evidence collector flags missing evidence; audit and management-review evidence is retrievable. | ISMS · control gap · ISO 27001 |
| **ISO-RA-03** | manual/evidence | no (manual) | Every in-scope asset has a current versioned risk assessment, retained. | Risk assessment · Missing assessment · ISO 27001 |
| **ISO-CTL-02** | manual/evidence | no (manual) | Each applicable control passes an automated check or has a tracked nonconformity; the SoA matches implemented controls; parallel remediation converges; results retained. | Control implementation · control gap · ISO 27001 |

### Determinism

Every harness row (static and behavioural) is drafted as deterministic. Static detectors, including backstops, are pure functions of the committed source/config/diff. Behavioural rules each run against a **fresh `reset()` MoneySystem** (no state leaks between rules), driven by a **controllable clock**; deadlines, windows, expiries and cadences are asserted by advancing that clock, never by wall-clock reads, and no randomness affects a verdict. External dependencies (vendors, registries, feeds) are faked inside the adapter, which is how fault-injection rows stay deterministic. Manual/evidence rows are not deterministic and are not gate checks.

### Coverage note

Converted from 25 AI-drafted source scenarios of `SK-ISO-001`; each source scenario maps to exactly one non-backstop row (see the appendix). Static backstops add no scenarios and trace through the check they back. The scenarios were merged into crisp invariants by automation point and failure mode, across categories (positive, negative, boundary, failure/recovery, concurrency/idempotency, retention/audit, common failure, core). Automation points covered: ISMS, Risk assessment, Control implementation. Source common failures: Missing assessment, control gap. Thresholds, windows and deadlines are *configured* parameters, not asserted statutory values. No regulation or citation was added beyond the source sheet.

### Overlap with the locked neobank playbook (19 checks)

None. This playbook's invariants are not covered by the neobank set.

### Review flags

- No SME-flagged rows. All rows still need compliance review.

## Appendix: traceability to source scenarios

| Check ID | Source scenario IDs | Categories merged |
| --- | --- | --- |
| ISO-ISMS-01 | SC-ISO-001-04, SC-ISO-001-05, SC-ISO-001-14, SC-ISO-001-16 | Boundary/Edge, Common Failure, Concurrency/Idempotency, Positive |
| ISO-ISMS-02 | SC-ISO-001-06, SC-ISO-001-15, SC-ISO-001-03, SC-ISO-001-07 | Core, Failure/Recovery, Negative, Retention/Audit |
| ISO-RA-01 | SC-ISO-001-08, SC-ISO-001-17 | Negative, Positive |
| ISO-RA-02 | SC-ISO-001-09, SC-ISO-001-10, SC-ISO-001-20 | Boundary/Edge, Common Failure, Failure/Recovery |
| ISO-RA-03 | SC-ISO-001-01, SC-ISO-001-18, SC-ISO-001-19 | Concurrency/Idempotency, Core, Retention/Audit |
| ISO-CTL-01 | SC-ISO-001-22, SC-ISO-001-12, SC-ISO-001-23 | Boundary/Edge, Failure/Recovery, Negative |
| ISO-CTL-02 | SC-ISO-001-02, SC-ISO-001-21, SC-ISO-001-11, SC-ISO-001-24, SC-ISO-001-25 | Common Failure, Concurrency/Idempotency, Core, Positive, Retention/Audit |
| ISO-CTL-03 | SC-ISO-001-13 | Negative |

# Helix review rules

Generated from `checks.json` (4 static and behavioural checks; manual/evidence items are not code-reviewable and are omitted). Severity is derived from the playbook priority (P1 -> MEDIUM); Category MM marks money-movement checks. Rule text is the source invariant, unchanged; it is AI-drafted and needs compliance review.

## Rule ISO-RA-01: A new asset/system creates a risk-assessment task and go-live is blocked until assessed
Severity: MEDIUM
Category: NON_MM
Scenario: risk-assessment
Requirement: MUST
Invariant: A new asset/system creates a risk-assessment task and go-live is blocked until assessed; a risk without owner/treatment is rejected.

Source check `ISO-RA-01` from `checks.json` (behavioural; deterministic: yes). Covers: Risk assessment · Missing assessment · ISO 27001. Review status in source: Drafted (AI) – needs compliance review.

## Rule ISO-RA-02: Above the configured score threshold a treatment plan and owner are required
Severity: MEDIUM
Category: NON_MM
Scenario: risk-assessment
Requirement: MUST
Invariant: Above the configured score threshold a treatment plan and owner are required; overdue treatment and stale assessments escalate (controllable clock).

Source check `ISO-RA-02` from `checks.json` (behavioural; deterministic: yes). Covers: Risk assessment · Missing assessment · ISO 27001. Review status in source: Drafted (AI) – needs compliance review.

## Rule ISO-CTL-01: Technical control settings in config/IaC hold at their configured thresholds
Severity: MEDIUM
Category: NON_MM
Scenario: control-implementation
Requirement: MUST
Invariant: Technical control settings in config/IaC hold at their configured thresholds; drift from baseline is detected and ticketed.

Source check `ISO-CTL-01` from `checks.json` (static; deterministic: yes). Covers: Control implementation · control gap · ISO 27001. Review status in source: Drafted (AI) – needs compliance review.

## Rule ISO-CTL-03: Data flows to a supplier are blocked until the supplier is assessed
Severity: MEDIUM
Category: NON_MM
Scenario: control-implementation
Requirement: MUST
Invariant: Data flows to a supplier are blocked until the supplier is assessed.

Source check `ISO-CTL-03` from `checks.json` (behavioural; deterministic: yes). Covers: Control implementation · control gap · ISO 27001. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-TPRM-002.
