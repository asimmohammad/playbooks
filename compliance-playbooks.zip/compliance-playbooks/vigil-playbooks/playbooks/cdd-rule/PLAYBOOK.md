---
helixPlaybookFormat: helix-playbook/0.1-proposal
playbookId: vigil-cdd-rule
title: "FinCEN CDD Rule Beneficial Ownership"
declaredVersion: 0.1.0
intent: draft
applicability:
  languages: [javascript, typescript]
  scenarios: [beneficial-ownership, customer-due-diligence]
---
# Helix portable playbook — DRAFT manifest · FinCEN CDD Rule Beneficial Ownership

> **DRAFT — not LOCKED.** Proposed CDD Rule (FinCEN) playbook converted from Vigil skill `SK-CDD-001`: one runner, two layers, **8 harness checks (2 static, incl. 2 static backstops, + 6 behavioural)**, plus 2 manual/evidence items listed separately because neither layer can verify them. Every invariant, layer and determinism call is **AI-drafted (Helix) and needs compliance review**. No detector or rule code exists yet. Before this manifest can be LOCKED, each row needs its detector/rule, a review, and a commit that adds the check alongside its row.

## Layers

- **static**: a repo-agnostic source scanner parameterised by a `VIGIL_CDD` preset (no app specifics in the detector). It reads source / SQL / config / IaC / git-diff, **fails CLOSED** on a match, and runs with **no adapter**, so it is the CI gate. *Static backstops* (IDs `-5x`) prove a supporting source invariant for a named behavioural check, the way N-CAP-01 / N-STATE-01 back neobank behaviour. They fire even when the adapter never drives that path. Backstops of ⚑ SME checks stay out of the gate.
- **behavioural**: a rule written once against the canonical `MoneySystem` interface (or a DRAFT extension surface in `adapters/`) and driven through the app adapter. Surfaces needed: **OnboardingSystem** (`adapters/onboarding.ts`). Every behavioural row reports NOT_EXERCISED until an adapter implements its surface. It returns **CHECKED only when it actually drove the guard's path**.
- **manual/evidence**: organisational process, live-infrastructure, statistical or retention evidence that no source scan or adapter-driven rule can prove. These are **outside the harness**, report `NOT_APPLICABLE` to it, and are tracked as evidence tasks, never as passes.

## Verdicts

`CHECKED` the path ran and the guard held · `FINDING` the guard was violated · `NOT_APPLICABLE` the invariant cannot apply here (incl. every manual/evidence item) · `NOT_EXERCISED` (glyph `????`) the adapter did not drive the path, so nothing is proven. NOT_EXERCISED is **surfaced distinctly and never counted as a pass** (no fake coverage). A ⚑ SME check with no approved parameter matrix reports `NOT_EXERCISED`, never `CHECKED`.

## How to run

- **Not runnable yet**: this draft defines invariants only (no detector/rule code). The intended shape mirrors the neobank playbook:
  - CI gate (adapter-free, blocks on any static FINDING): `run-static` with preset `VIGIL_CDD`.
  - Full combined table (static + behavioural via the adapter): `run-all`.
- Machine-readable rows: `checks.json` (same IDs; includes source-scenario traceability and neobank overlaps).

## The draft inventory: 2 static + 6 behavioural = 8 checks

| ID | Layer | Deterministic | Invariant (one line) | Covers (automation point · common failure · regulation) |
| --- | --- | --- | --- | --- |
| **CDD-BO-01** | behavioural | yes | Entity onboarding completes only after every owner at/above the configured threshold (incl. indirect, aggregated per configured method) and at least one control person is captured and verified. | Beneficial ownership · Missing ownership · CDD Rule |
| **CDD-BO-51** | static | yes | Entity activation checks owner coverage per the configured threshold method plus ≥1 control person. | backstop for CDD-BO-01 · Beneficial ownership · Missing ownership · CDD Rule |
| **CDD-BO-02** | behavioural | yes | Exemptions apply only to configured entity types with justification recorded. | Beneficial ownership · Missing ownership · CDD Rule |
| **CDD-BO-03** | behavioural | yes | KYB vendor outage holds onboarding; concurrent ownership updates are versioned with the latest applied. | Beneficial ownership · Missing ownership · CDD Rule |
| **CDD-CDD-01** | behavioural | yes | A risk profile with nature/purpose and rating is required at onboarding; trigger events and expected-profile deviations update it and queue refresh; tiered refresh is due at the configured interval. | Customer due diligence · stale CDD · CDD Rule |
| **CDD-CDD-02** | behavioural | yes | An EDD case holds restricted activity until approval. | Customer due diligence · stale CDD · CDD Rule |
| **CDD-CDD-03** | behavioural | yes | Concurrent profile updates merge without lost update; a verification outage keeps refresh 'pending' (never 'complete') and escalates after the configured time. | Customer due diligence · stale CDD · CDD Rule |
| **CDD-CDD-51** | static | yes | Profile updates use optimistic-version or locked updates; verification errors set status 'pending'. | backstop for CDD-CDD-03 · Customer due diligence · stale CDD · CDD Rule |

## Outside the harness: manual/evidence (2)

These items are not harness checks. Each reports `NOT_APPLICABLE` to the runner and needs an owner and evidence on a schedule.

| ID | Layer | Deterministic | Invariant (one line) | Covers (automation point · common failure · regulation) |
| --- | --- | --- | --- | --- |
| **CDD-BO-04** | manual/evidence | no (manual) | Ownership certification versions and verification evidence are retained. | Beneficial ownership · general control (no source failure) · CDD Rule |
| **CDD-CDD-04** | manual/evidence | no (manual) | CDD profiles and refresh history are retained. | Customer due diligence · general control (no source failure) · CDD Rule |

### Determinism

Every harness row (static and behavioural) is drafted as deterministic. Static detectors, including backstops, are pure functions of the committed source/config/diff. Behavioural rules each run against a **fresh `reset()` MoneySystem** (no state leaks between rules), driven by a **controllable clock**; deadlines, windows, expiries and cadences are asserted by advancing that clock, never by wall-clock reads, and no randomness affects a verdict. External dependencies (vendors, registries, feeds) are faked inside the adapter, which is how fault-injection rows stay deterministic. Manual/evidence rows are not deterministic and are not gate checks.

### Coverage note

Converted from 17 AI-drafted source scenarios of `SK-CDD-001`; each source scenario maps to exactly one non-backstop row (see the appendix). Static backstops add no scenarios and trace through the check they back. The scenarios were merged into crisp invariants by automation point and failure mode, across categories (positive, negative, boundary, failure/recovery, concurrency/idempotency, retention/audit, common failure, core). Automation points covered: Beneficial ownership, Customer due diligence. Source common failures: Missing ownership, stale CDD. Thresholds, windows and deadlines are *configured* parameters, not asserted statutory values. No regulation or citation was added beyond the source sheet.

### Overlap with the locked neobank playbook (19 checks)

| This check | Neobank check | Strength | Why |
| --- | --- | --- | --- |
| CDD-BO-01 | PARTY-SCREEN | related | entity owners captured & verified before activation |
| CDD-CDD-03 | N-CAS-01 | related | no lost update |
| CDD-CDD-51 | N-CAS-01 | related | versioned/locked update |

`same` means the neobank check already enforces this invariant, so reuse it instead of re-implementing. `related` means the same defect class, but this check needs its own rule or preset.

### Review flags

- No SME-flagged rows. All rows still need compliance review.

## Appendix: traceability to source scenarios

| Check ID | Source scenario IDs | Categories merged |
| --- | --- | --- |
| CDD-BO-01 | SC-CDD-001-01, SC-CDD-001-04, SC-CDD-001-05, SC-CDD-001-06 | Boundary/Edge, Common Failure, Core, Negative |
| CDD-BO-51 | — (static backstop; traced via CDD-BO-01) | — |
| CDD-BO-02 | SC-CDD-001-07 | Positive |
| CDD-BO-03 | SC-CDD-001-14, SC-CDD-001-15 | Concurrency/Idempotency, Failure/Recovery |
| CDD-BO-04 | SC-CDD-001-08 | Retention/Audit |
| CDD-CDD-01 | SC-CDD-001-02, SC-CDD-001-09, SC-CDD-001-16, SC-CDD-001-10, SC-CDD-001-11 | Boundary/Edge, Common Failure, Core, Negative, Positive |
| CDD-CDD-02 | SC-CDD-001-03 | Core |
| CDD-CDD-03 | SC-CDD-001-12, SC-CDD-001-13 | Concurrency/Idempotency, Failure/Recovery |
| CDD-CDD-51 | — (static backstop; traced via CDD-CDD-03) | — |
| CDD-CDD-04 | SC-CDD-001-17 | Retention/Audit |

# Helix review rules

Generated from `checks.json` (8 static and behavioural checks; manual/evidence items are not code-reviewable and are omitted). Severity is derived from the playbook priority (P1 -> MEDIUM); Category MM marks money-movement checks. Rule text is the source invariant, unchanged; it is AI-drafted and needs compliance review.

## Rule CDD-BO-01: Entity onboarding completes only after every owner at/above the configured threshold (incl
Severity: MEDIUM
Category: NON_MM
Scenario: beneficial-ownership
Requirement: MUST
Invariant: Entity onboarding completes only after every owner at/above the configured threshold (incl. indirect, aggregated per configured method) and at least one control person is captured and verified.

Source check `CDD-BO-01` from `checks.json` (behavioural; deterministic: yes). Covers: Beneficial ownership · Missing ownership · CDD Rule. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-AML-008.

## Rule CDD-BO-51: Entity activation checks owner coverage per the configured threshold method plus ≥1 control person
Severity: MEDIUM
Category: NON_MM
Scenario: beneficial-ownership
Requirement: MUST
Invariant: Entity activation checks owner coverage per the configured threshold method plus ≥1 control person.

Source check `CDD-BO-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: Beneficial ownership · Missing ownership · CDD Rule. Backstop for CDD-BO-01. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-AML-008.

## Rule CDD-BO-02: Exemptions apply only to configured entity types with justification recorded
Severity: MEDIUM
Category: NON_MM
Scenario: beneficial-ownership
Requirement: MUST
Invariant: Exemptions apply only to configured entity types with justification recorded.

Source check `CDD-BO-02` from `checks.json` (behavioural; deterministic: yes). Covers: Beneficial ownership · Missing ownership · CDD Rule. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-AML-008.

## Rule CDD-BO-03: KYB vendor outage holds onboarding
Severity: MEDIUM
Category: NON_MM
Scenario: beneficial-ownership
Requirement: MUST
Invariant: KYB vendor outage holds onboarding; concurrent ownership updates are versioned with the latest applied.

Source check `CDD-BO-03` from `checks.json` (behavioural; deterministic: yes). Covers: Beneficial ownership · Missing ownership · CDD Rule. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-AML-008.

## Rule CDD-CDD-01: A risk profile with nature/purpose and rating is required at onboarding
Severity: MEDIUM
Category: NON_MM
Scenario: customer-due-diligence
Requirement: MUST
Invariant: A risk profile with nature/purpose and rating is required at onboarding; trigger events and expected-profile deviations update it and queue refresh; tiered refresh is due at the configured interval.

Source check `CDD-CDD-01` from `checks.json` (behavioural; deterministic: yes). Covers: Customer due diligence · stale CDD · CDD Rule. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-AML-001.

## Rule CDD-CDD-02: An EDD case holds restricted activity until approval
Severity: MEDIUM
Category: NON_MM
Scenario: customer-due-diligence
Requirement: MUST
Invariant: An EDD case holds restricted activity until approval.

Source check `CDD-CDD-02` from `checks.json` (behavioural; deterministic: yes). Covers: Customer due diligence · stale CDD · CDD Rule. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-AML-001.

## Rule CDD-CDD-03: Concurrent profile updates merge without lost update
Severity: MEDIUM
Category: NON_MM
Scenario: customer-due-diligence
Requirement: MUST
Invariant: Concurrent profile updates merge without lost update; a verification outage keeps refresh 'pending' (never 'complete') and escalates after the configured time.

Source check `CDD-CDD-03` from `checks.json` (behavioural; deterministic: yes). Covers: Customer due diligence · stale CDD · CDD Rule. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-AML-001.

## Rule CDD-CDD-51: Profile updates use optimistic-version or locked updates
Severity: MEDIUM
Category: NON_MM
Scenario: customer-due-diligence
Requirement: MUST
Invariant: Profile updates use optimistic-version or locked updates; verification errors set status 'pending'.

Source check `CDD-CDD-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: Customer due diligence · stale CDD · CDD Rule. Backstop for CDD-CDD-03. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-AML-001.
