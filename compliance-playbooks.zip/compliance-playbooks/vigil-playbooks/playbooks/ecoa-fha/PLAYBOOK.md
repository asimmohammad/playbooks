---
helixPlaybookFormat: helix-playbook/0.1-proposal
playbookId: vigil-ecoa-fha
title: "ECOA / FHA Adverse Action & Fair Pricing"
declaredVersion: 0.1.0
intent: draft
applicability:
  languages: [javascript, typescript]
  scenarios: [adverse-action, fair-lending-analysis, pricing]
---
# Helix portable playbook — DRAFT manifest · ECOA / FHA Adverse Action & Fair Pricing

> **DRAFT — not LOCKED.** Proposed ECOA / FHA (Fair Lending) playbook converted from Vigil skill `SK-ECOA-001`: one runner, two layers, **8 harness checks (3 static, incl. 2 static backstops, + 5 behavioural)**, plus 4 manual/evidence items listed separately because neither layer can verify them. Every invariant, layer and determinism call is **AI-drafted (Helix) and needs compliance review**; 1 check(s) are **⚑ SME-flagged** and cannot gate until an SME/counsel supplies their parameter matrix. No detector or rule code exists yet. Before this manifest can be LOCKED, each row needs its detector/rule, a review, and a commit that adds the check alongside its row.

## Layers

- **static**: a repo-agnostic source scanner parameterised by a `VIGIL_ECOA` preset (no app specifics in the detector). It reads source / SQL / config / IaC / git-diff, **fails CLOSED** on a match, and runs with **no adapter**, so it is the CI gate. *Static backstops* (IDs `-5x`) prove a supporting source invariant for a named behavioural check, the way N-CAP-01 / N-STATE-01 back neobank behaviour. They fire even when the adapter never drives that path. Backstops of ⚑ SME checks stay out of the gate.
- **behavioural**: a rule written once against the canonical `MoneySystem` interface (or a DRAFT extension surface in `adapters/`) and driven through the app adapter. Surfaces needed: **LendingSystem** (`adapters/lending.ts`). Every behavioural row reports NOT_EXERCISED until an adapter implements its surface. It returns **CHECKED only when it actually drove the guard's path**.
- **manual/evidence**: organisational process, live-infrastructure, statistical or retention evidence that no source scan or adapter-driven rule can prove. These are **outside the harness**, report `NOT_APPLICABLE` to it, and are tracked as evidence tasks, never as passes.

## Verdicts

`CHECKED` the path ran and the guard held · `FINDING` the guard was violated · `NOT_APPLICABLE` the invariant cannot apply here (incl. every manual/evidence item) · `NOT_EXERCISED` (glyph `????`) the adapter did not drive the path, so nothing is proven. NOT_EXERCISED is **surfaced distinctly and never counted as a pass** (no fake coverage). A ⚑ SME check with no approved parameter matrix reports `NOT_EXERCISED`, never `CHECKED`.

## How to run

- **Not runnable yet**: this draft defines invariants only (no detector/rule code). The intended shape mirrors the neobank playbook:
  - CI gate (adapter-free, blocks on any static FINDING): `run-static` with preset `VIGIL_ECOA`.
  - Full combined table (static + behavioural via the adapter): `run-all`.
- Machine-readable rows: `checks.json` (same IDs; includes source-scenario traceability and neobank overlaps).

## The draft inventory: 3 static + 5 behavioural = 8 checks

| ID | Layer | Deterministic | Invariant (one line) | Covers (automation point · common failure · regulation) |
| --- | --- | --- | --- | --- |
| **ECOA-AA-01** | behavioural | yes | Every adverse action (incl. an unaccepted counteroffer) produces exactly one notice reflecting the final action, with specific model-traceable principal reasons, within the configured window. | Adverse action · Missing notice · ECOA / FHA |
| **ECOA-AA-51** | static | yes | Every adverse-action reason code emitted by the decision model maps to a specific notice reason; generic codes are absent from the mapping. | backstop for ECOA-AA-01 · Adverse action · Missing notice · ECOA / FHA |
| **ECOA-AA-02** | behavioural | yes | Incomplete-application notices are sent within the configured window (controllable clock); delivery failure falls back to another channel and still meets or escalates the deadline. | Adverse action · Missing notice · ECOA / FHA |
| **ECOA-FL-01** | static | yes | Prohibited-basis attributes are absent from decision-model features; flagged proxies are documented. | Fair lending analysis · pricing disparity · ECOA / FHA |
| **ECOA-PR-01** | behavioural | yes | Matched applicant pairs receive identical pricing — including concurrent quotes and across channels unless a documented channel policy applies. | Pricing · pricing disparity · ECOA / FHA |
| **ECOA-PR-02** | behavioural | yes | Discretionary pricing exceptions beyond the configured limit are blocked; every exception logs reason and approver. | Pricing · pricing disparity · ECOA / FHA |
| **ECOA-PR-03** | behavioural | yes | Pricing service failure blocks the quote — no fallback to unapproved pricing. | Pricing · pricing disparity · ECOA / FHA |
| **ECOA-PR-51** | static | yes | Pricing-service error handling blocks the quote — no fallback price table. | backstop for ECOA-PR-03 · Pricing · pricing disparity · ECOA / FHA |

## Outside the harness: manual/evidence (4)

These items are not harness checks. Each reports `NOT_APPLICABLE` to the runner and needs an owner and evidence on a schedule.

| ID | Layer | Deterministic | Invariant (one line) | Covers (automation point · common failure · regulation) |
| --- | --- | --- | --- | --- |
| **ECOA-AA-03** | manual/evidence | no (manual) | Application and notice records are retained. | Adverse action · general control (no source failure) · ECOA / FHA |
| **ECOA-FL-02** | manual/evidence | no (manual) | Fair-lending disparity analysis runs per the SME-defined method on each model release and periodically, flags at the configured threshold, and is reproducible and idempotent; missing proxy data marks it incomplete. | Fair lending analysis · pricing disparity · ECOA / FHA |
| **ECOA-FL-03** | manual/evidence | no (manual) | Manual override rates are monitored with reasons and outliers flagged. | Fair lending analysis / Pricing · pricing disparity · ECOA / FHA |
| **ECOA-PR-04** | manual/evidence | no (manual) | Pricing model releases are gated on a disparity backtest against configured thresholds; pricing decisions and overrides are retained. | Pricing · pricing disparity · ECOA / FHA |

### Determinism

Every harness row (static and behavioural) is drafted as deterministic. Static detectors, including backstops, are pure functions of the committed source/config/diff. Behavioural rules each run against a **fresh `reset()` MoneySystem** (no state leaks between rules), driven by a **controllable clock**; deadlines, windows, expiries and cadences are asserted by advancing that clock, never by wall-clock reads, and no randomness affects a verdict. External dependencies (vendors, registries, feeds) are faked inside the adapter, which is how fault-injection rows stay deterministic. Manual/evidence rows are not deterministic and are not gate checks. ⚑ SME rows are deterministic once parameters exist, but are excluded from the gate until then.

### Coverage note

Converted from 24 AI-drafted source scenarios of `SK-ECOA-001`; each source scenario maps to exactly one non-backstop row (see the appendix). Static backstops add no scenarios and trace through the check they back. The scenarios were merged into crisp invariants by automation point and failure mode, across categories (positive, negative, boundary, failure/recovery, concurrency/idempotency, retention/audit, common failure, core). Automation points covered: Adverse action, Fair lending analysis, Pricing. Source common failures: Missing notice, pricing disparity. Thresholds, windows and deadlines are *configured* parameters, not asserted statutory values. No regulation or citation was added beyond the source sheet.

### Overlap with the locked neobank playbook (19 checks)

| This check | Neobank check | Strength | Why |
| --- | --- | --- | --- |
| ECOA-PR-02 | N-CAP-01 | related | pricing exception limit |

`same` means the neobank check already enforces this invariant, so reuse it instead of re-implementing. `related` means the same defect class, but this check needs its own rule or preset.

### Review flags

- ⚑ **ECOA-FL-02**: needs an SME/counsel parameter matrix (source scenarios carry review status "+ SME input").
- **ECOA-PR-01**: expert input noted in source feasibility: needs fair-lending SME thresholds.

## Appendix: traceability to source scenarios

| Check ID | Source scenario IDs | Categories merged |
| --- | --- | --- |
| ECOA-AA-01 | SC-ECOA-001-01, SC-ECOA-001-03, SC-ECOA-001-05, SC-ECOA-001-14, SC-ECOA-001-15 | Common Failure, Concurrency/Idempotency, Core, Negative, Positive |
| ECOA-AA-51 | — (static backstop; traced via ECOA-AA-01) | — |
| ECOA-AA-02 | SC-ECOA-001-04, SC-ECOA-001-06 | Boundary/Edge, Failure/Recovery |
| ECOA-AA-03 | SC-ECOA-001-07 | Retention/Audit |
| ECOA-FL-01 | SC-ECOA-001-08 | Negative |
| ECOA-FL-02 | SC-ECOA-001-09, SC-ECOA-001-16, SC-ECOA-001-17, SC-ECOA-001-18, SC-ECOA-001-19, SC-ECOA-001-20 | Boundary/Edge, Concurrency/Idempotency, Core, Failure/Recovery, Positive, Retention/Audit |
| ECOA-FL-03 | SC-ECOA-001-10, SC-ECOA-001-24 | Common Failure |
| ECOA-PR-01 | SC-ECOA-001-02, SC-ECOA-001-13, SC-ECOA-001-22 | Concurrency/Idempotency, Core, Negative |
| ECOA-PR-02 | SC-ECOA-001-11 | Boundary/Edge |
| ECOA-PR-03 | SC-ECOA-001-21 | Failure/Recovery |
| ECOA-PR-51 | — (static backstop; traced via ECOA-PR-03) | — |
| ECOA-PR-04 | SC-ECOA-001-12, SC-ECOA-001-23 | Positive, Retention/Audit |

# Helix review rules

Generated from `checks.json` (8 static and behavioural checks; manual/evidence items are not code-reviewable and are omitted). Severity is derived from the playbook priority (P1 -> MEDIUM); Category MM marks money-movement checks. Rule text is the source invariant, unchanged; it is AI-drafted and needs compliance review.

## Rule ECOA-AA-01: Every adverse action (incl
Severity: MEDIUM
Category: NON_MM
Scenario: adverse-action
Requirement: MUST
Invariant: Every adverse action (incl. an unaccepted counteroffer) produces exactly one notice reflecting the final action, with specific model-traceable principal reasons, within the configured window.

Source check `ECOA-AA-01` from `checks.json` (behavioural; deterministic: yes). Covers: Adverse action · Missing notice · ECOA / FHA. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-REGB-001, RR-CFPB-005.

## Rule ECOA-AA-51: Every adverse-action reason code emitted by the decision model maps to a specific notice reason
Severity: MEDIUM
Category: NON_MM
Scenario: adverse-action
Requirement: MUST
Invariant: Every adverse-action reason code emitted by the decision model maps to a specific notice reason; generic codes are absent from the mapping.

Source check `ECOA-AA-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: Adverse action · Missing notice · ECOA / FHA. Backstop for ECOA-AA-01. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-REGB-001, RR-CFPB-005.

## Rule ECOA-AA-02: Incomplete-application notices are sent within the configured window (controllable clock)
Severity: MEDIUM
Category: NON_MM
Scenario: adverse-action
Requirement: MUST
Invariant: Incomplete-application notices are sent within the configured window (controllable clock); delivery failure falls back to another channel and still meets or escalates the deadline.

Source check `ECOA-AA-02` from `checks.json` (behavioural; deterministic: yes). Covers: Adverse action · Missing notice · ECOA / FHA. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-REGB-001.

## Rule ECOA-FL-01: Prohibited-basis attributes are absent from decision-model features
Severity: MEDIUM
Category: NON_MM
Scenario: fair-lending-analysis
Requirement: MUST
Invariant: Prohibited-basis attributes are absent from decision-model features; flagged proxies are documented.

Source check `ECOA-FL-01` from `checks.json` (static; deterministic: yes). Covers: Fair lending analysis · pricing disparity · ECOA / FHA. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-REGB-002.

## Rule ECOA-PR-01: Matched applicant pairs receive identical pricing — including concurrent quotes and across channe...
Severity: MEDIUM
Category: NON_MM
Scenario: pricing
Requirement: MUST
Invariant: Matched applicant pairs receive identical pricing — including concurrent quotes and across channels unless a documented channel policy applies.

Source check `ECOA-PR-01` from `checks.json` (behavioural; deterministic: yes). Covers: Pricing · pricing disparity · ECOA / FHA. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-REGB-002.

## Rule ECOA-PR-02: Discretionary pricing exceptions beyond the configured limit are blocked
Severity: MEDIUM
Category: NON_MM
Scenario: pricing
Requirement: MUST
Invariant: Discretionary pricing exceptions beyond the configured limit are blocked; every exception logs reason and approver.

Source check `ECOA-PR-02` from `checks.json` (behavioural; deterministic: yes). Covers: Pricing · pricing disparity · ECOA / FHA. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-REGB-002.

## Rule ECOA-PR-03: Pricing service failure blocks the quote — no fallback to unapproved pricing
Severity: MEDIUM
Category: NON_MM
Scenario: pricing
Requirement: MUST
Invariant: Pricing service failure blocks the quote — no fallback to unapproved pricing.

Source check `ECOA-PR-03` from `checks.json` (behavioural; deterministic: yes). Covers: Pricing · pricing disparity · ECOA / FHA. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-REGB-002.

## Rule ECOA-PR-51: Pricing-service error handling blocks the quote — no fallback price table
Severity: MEDIUM
Category: NON_MM
Scenario: pricing
Requirement: MUST
Invariant: Pricing-service error handling blocks the quote — no fallback price table.

Source check `ECOA-PR-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: Pricing · pricing disparity · ECOA / FHA. Backstop for ECOA-PR-03. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-REGB-002.
