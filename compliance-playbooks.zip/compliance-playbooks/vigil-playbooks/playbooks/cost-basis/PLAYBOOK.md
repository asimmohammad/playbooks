---
helixPlaybookFormat: helix-playbook/0.1-proposal
playbookId: vigil-cost-basis
title: "Cost Basis Tracking & Reporting"
declaredVersion: 0.1.0
intent: draft
applicability:
  languages: [javascript, typescript]
  scenarios: [covered-securities, transfer, reporting]
---
# Helix portable playbook — DRAFT manifest · Cost Basis Tracking & Reporting

> **DRAFT — not LOCKED.** Proposed Cost Basis Reporting (Tax) playbook converted from Vigil skill `SK-COSTB-001`: one runner, two layers, **9 harness checks (2 static, incl. 2 static backstops, + 7 behavioural)**, plus 2 manual/evidence items listed separately because neither layer can verify them. Every invariant, layer and determinism call is **AI-drafted (Helix) and needs compliance review**. No detector or rule code exists yet. Before this manifest can be LOCKED, each row needs its detector/rule, a review, and a commit that adds the check alongside its row.

## Layers

- **static**: a repo-agnostic source scanner parameterised by a `VIGIL_COSTB` preset (no app specifics in the detector). It reads source / SQL / config / IaC / git-diff, **fails CLOSED** on a match, and runs with **no adapter**, so it is the CI gate. *Static backstops* (IDs `-5x`) prove a supporting source invariant for a named behavioural check, the way N-CAP-01 / N-STATE-01 back neobank behaviour. They fire even when the adapter never drives that path. Backstops of ⚑ SME checks stay out of the gate.
- **behavioural**: a rule written once against the canonical `MoneySystem` interface (or a DRAFT extension surface in `adapters/`) and driven through the app adapter. Surfaces needed: **SecuritiesSystem** (`adapters/securities.ts`). Every behavioural row reports NOT_EXERCISED until an adapter implements its surface. It returns **CHECKED only when it actually drove the guard's path**.
- **manual/evidence**: organisational process, live-infrastructure, statistical or retention evidence that no source scan or adapter-driven rule can prove. These are **outside the harness**, report `NOT_APPLICABLE` to it, and are tracked as evidence tasks, never as passes.

## Verdicts

`CHECKED` the path ran and the guard held · `FINDING` the guard was violated · `NOT_APPLICABLE` the invariant cannot apply here (incl. every manual/evidence item) · `NOT_EXERCISED` (glyph `????`) the adapter did not drive the path, so nothing is proven. NOT_EXERCISED is **surfaced distinctly and never counted as a pass** (no fake coverage). A ⚑ SME check with no approved parameter matrix reports `NOT_EXERCISED`, never `CHECKED`.

## How to run

- **Not runnable yet**: this draft defines invariants only (no detector/rule code). The intended shape mirrors the neobank playbook:
  - CI gate (adapter-free, blocks on any static FINDING): `run-static` with preset `VIGIL_COSTB`.
  - Full combined table (static + behavioural via the adapter): `run-all`.
- Machine-readable rows: `checks.json` (same IDs; includes source-scenario traceability and neobank overlaps).

## The draft inventory: 2 static + 7 behavioural = 9 checks

| ID | Layer | Deterministic | Invariant (one line) | Covers (automation point · common failure · regulation) |
| --- | --- | --- | --- | --- |
| **CB-COV-01** | behavioural | yes | Covered vs noncovered status follows the configured acquisition-date rule; a missing acquisition date is flagged, never defaulted to covered; noncovered lots are never reported with basis as covered. | Covered securities · Wrong basis · Cost Basis Reporting |
| **CB-COV-52** | static | yes | Missing acquisition date maps to 'noncovered/unknown', never to a covered default. | backstop for CB-COV-01 · Covered securities · Wrong basis · Cost Basis Reporting |
| **CB-COV-02** | behavioural | yes | Corporate actions and wash sales adjust basis/quantity per configured rules with total basis conserved where required. | Covered securities / Reporting · Wrong basis · Cost Basis Reporting |
| **CB-COV-03** | behavioural | yes | A lot is consumed once under concurrent sells; relief follows the elected method consistently. | Covered securities / Reporting · Wrong basis · Cost Basis Reporting |
| **CB-COV-51** | static | yes | Lot relief selects and decrements lots under a row lock (FOR UPDATE) within the sell transaction. | backstop for CB-COV-03 · Covered securities / Reporting · Wrong basis · Cost Basis Reporting |
| **CB-TRF-01** | behavioural | yes | Transferred lots carry their basis (no lot loses basis; partial transfers create no duplicate lots); inbound lots without a statement are marked basis-unknown with follow-up at the configured window. | Transfer · missing transfer · Cost Basis Reporting |
| **CB-TRF-02** | behavioural | yes | An outbound transfer statement with lot detail is delivered within the configured window. | Transfer · missing transfer · Cost Basis Reporting |
| **CB-RPT-01** | behavioural | yes | Year-end report totals equal realised gains and adjusted basis matches the reference, with short/long-term classification at the configured holding-period boundary. | Reporting · Wrong basis · Cost Basis Reporting |
| **CB-RPT-02** | behavioural | yes | Reports are blocked while basis exceptions are open; basis adjustments after filing issue a corrected report and retain the original. | Reporting · Wrong basis · Cost Basis Reporting |

## Outside the harness: manual/evidence (2)

These items are not harness checks. Each reports `NOT_APPLICABLE` to the runner and needs an owner and evidence on a schedule.

| ID | Layer | Deterministic | Invariant (one line) | Covers (automation point · common failure · regulation) |
| --- | --- | --- | --- | --- |
| **CB-COV-04** | manual/evidence | no (manual) | Lot history is retained. | Covered securities · general control (no source failure) · Cost Basis Reporting |
| **CB-TRF-03** | manual/evidence | no (manual) | Transfer statements are retained. | Transfer · general control (no source failure) · Cost Basis Reporting |

### Determinism

Every harness row (static and behavioural) is drafted as deterministic. Static detectors, including backstops, are pure functions of the committed source/config/diff. Behavioural rules each run against a **fresh `reset()` MoneySystem** (no state leaks between rules), driven by a **controllable clock**; deadlines, windows, expiries and cadences are asserted by advancing that clock, never by wall-clock reads, and no randomness affects a verdict. External dependencies (vendors, registries, feeds) are faked inside the adapter, which is how fault-injection rows stay deterministic. Manual/evidence rows are not deterministic and are not gate checks.

### Coverage note

Converted from 24 AI-drafted source scenarios of `SK-COSTB-001`; each source scenario maps to exactly one non-backstop row (see the appendix). Static backstops add no scenarios and trace through the check they back. The scenarios were merged into crisp invariants by automation point and failure mode, across categories (positive, negative, boundary, failure/recovery, concurrency/idempotency, retention/audit, common failure, core). Automation points covered: Covered securities, Transfer, Reporting. Source common failures: Wrong basis, missing transfer. Thresholds, windows and deadlines are *configured* parameters, not asserted statutory values. No regulation or citation was added beyond the source sheet.

### Overlap with the locked neobank playbook (19 checks)

| This check | Neobank check | Strength | Why |
| --- | --- | --- | --- |
| CB-COV-03 | N-ATOMIC | related | lot consumed once under concurrent sells |
| CB-COV-51 | N-CAS-01 | related | row lock before decrement |

`same` means the neobank check already enforces this invariant, so reuse it instead of re-implementing. `related` means the same defect class, but this check needs its own rule or preset.

### Review flags

- No SME-flagged rows. All rows still need compliance review.

## Appendix: traceability to source scenarios

| Check ID | Source scenario IDs | Categories merged |
| --- | --- | --- |
| CB-COV-01 | SC-COSTB-001-01, SC-COSTB-001-04, SC-COSTB-001-12, SC-COSTB-001-11 | Boundary/Edge, Core, Failure/Recovery, Negative |
| CB-COV-52 | — (static backstop; traced via CB-COV-01) | — |
| CB-COV-02 | SC-COSTB-001-06, SC-COSTB-001-05, SC-COSTB-001-24 | Common Failure, Positive |
| CB-COV-03 | SC-COSTB-001-13, SC-COSTB-001-09 | Concurrency/Idempotency |
| CB-COV-51 | — (static backstop; traced via CB-COV-03) | — |
| CB-COV-04 | SC-COSTB-001-14 | Retention/Audit |
| CB-TRF-01 | SC-COSTB-001-02, SC-COSTB-001-15, SC-COSTB-001-17, SC-COSTB-001-08, SC-COSTB-001-16 | Concurrency/Idempotency, Core, Failure/Recovery, Negative, Positive |
| CB-TRF-02 | SC-COSTB-001-07, SC-COSTB-001-19 | Boundary/Edge, Common Failure |
| CB-TRF-03 | SC-COSTB-001-18 | Retention/Audit |
| CB-RPT-01 | SC-COSTB-001-03, SC-COSTB-001-20, SC-COSTB-001-22 | Boundary/Edge, Core, Positive |
| CB-RPT-02 | SC-COSTB-001-21, SC-COSTB-001-23, SC-COSTB-001-10 | Failure/Recovery, Negative, Retention/Audit |

# Helix review rules

Generated from `checks.json` (9 static and behavioural checks; manual/evidence items are not code-reviewable and are omitted). Severity is derived from the playbook priority (P2 -> LOW); Category MM marks money-movement checks. Rule text is the source invariant, unchanged; it is AI-drafted and needs compliance review.

## Rule CB-COV-01: Covered vs noncovered status follows the configured acquisition-date rule
Severity: LOW
Category: NON_MM
Scenario: covered-securities
Requirement: MUST
Invariant: Covered vs noncovered status follows the configured acquisition-date rule; a missing acquisition date is flagged, never defaulted to covered; noncovered lots are never reported with basis as covered.

Source check `CB-COV-01` from `checks.json` (behavioural; deterministic: yes). Covers: Covered securities · Wrong basis · Cost Basis Reporting. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-IRS-002.

## Rule CB-COV-52: Missing acquisition date maps to 'noncovered/unknown', never to a covered default
Severity: LOW
Category: NON_MM
Scenario: covered-securities
Requirement: MUST
Invariant: Missing acquisition date maps to 'noncovered/unknown', never to a covered default.

Source check `CB-COV-52` from `checks.json` (static, static backstop; deterministic: yes). Covers: Covered securities · Wrong basis · Cost Basis Reporting. Backstop for CB-COV-01. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-IRS-002.

## Rule CB-COV-02: Corporate actions and wash sales adjust basis/quantity per configured rules with total basis cons...
Severity: LOW
Category: NON_MM
Scenario: covered-securities
Requirement: MUST
Invariant: Corporate actions and wash sales adjust basis/quantity per configured rules with total basis conserved where required.

Source check `CB-COV-02` from `checks.json` (behavioural; deterministic: yes). Covers: Covered securities, Reporting · Wrong basis · Cost Basis Reporting. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-IRS-002, RR-IRS-010.

## Rule CB-COV-03: A lot is consumed once under concurrent sells
Severity: LOW
Category: NON_MM
Scenario: covered-securities
Requirement: MUST
Invariant: A lot is consumed once under concurrent sells; relief follows the elected method consistently.

Source check `CB-COV-03` from `checks.json` (behavioural; deterministic: yes). Covers: Covered securities, Reporting · Wrong basis · Cost Basis Reporting. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-IRS-002.

## Rule CB-COV-51: Lot relief selects and decrements lots under a row lock (FOR UPDATE) within the sell transaction
Severity: LOW
Category: NON_MM
Scenario: covered-securities
Requirement: MUST
Invariant: Lot relief selects and decrements lots under a row lock (FOR UPDATE) within the sell transaction.

Source check `CB-COV-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: Covered securities, Reporting · Wrong basis · Cost Basis Reporting. Backstop for CB-COV-03. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-IRS-002.

## Rule CB-TRF-01: Transferred lots carry their basis (no lot loses basis
Severity: LOW
Category: NON_MM
Scenario: transfer
Requirement: MUST
Invariant: Transferred lots carry their basis (no lot loses basis; partial transfers create no duplicate lots); inbound lots without a statement are marked basis-unknown with follow-up at the configured window.

Source check `CB-TRF-01` from `checks.json` (behavioural; deterministic: yes). Covers: Transfer · missing transfer · Cost Basis Reporting. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-IRS-002.

## Rule CB-TRF-02: An outbound transfer statement with lot detail is delivered within the configured window
Severity: LOW
Category: NON_MM
Scenario: transfer
Requirement: MUST
Invariant: An outbound transfer statement with lot detail is delivered within the configured window.

Source check `CB-TRF-02` from `checks.json` (behavioural; deterministic: yes). Covers: Transfer · missing transfer · Cost Basis Reporting. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-IRS-002.

## Rule CB-RPT-01: Year-end report totals equal realised gains and adjusted basis matches the reference, with short/...
Severity: LOW
Category: NON_MM
Scenario: reporting
Requirement: MUST
Invariant: Year-end report totals equal realised gains and adjusted basis matches the reference, with short/long-term classification at the configured holding-period boundary.

Source check `CB-RPT-01` from `checks.json` (behavioural; deterministic: yes). Covers: Reporting · Wrong basis · Cost Basis Reporting. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-IRS-002, RR-IRS-009.

## Rule CB-RPT-02: Reports are blocked while basis exceptions are open
Severity: LOW
Category: NON_MM
Scenario: reporting
Requirement: MUST
Invariant: Reports are blocked while basis exceptions are open; basis adjustments after filing issue a corrected report and retain the original.

Source check `CB-RPT-02` from `checks.json` (behavioural; deterministic: yes). Covers: Reporting · Wrong basis · Cost Basis Reporting. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-IRS-002.
