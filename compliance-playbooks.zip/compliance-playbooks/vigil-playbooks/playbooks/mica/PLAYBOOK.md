---
helixPlaybookFormat: helix-playbook/0.1-proposal
playbookId: vigil-mica
title: "MiCA Reserve Backing, Disclosure & Complaints"
declaredVersion: 0.1.0
intent: draft
applicability:
  languages: [javascript, typescript]
  scenarios: [casp-licensing, reserve-backing, consumer-protection]
---
# Helix portable playbook — DRAFT manifest · MiCA Reserve Backing, Disclosure & Complaints

> **DRAFT — not LOCKED.** Proposed MiCA (Crypto) (EU Regulation) playbook converted from Vigil skill `SK-MICA-001`: one runner, two layers, **12 harness checks (5 static, incl. 3 static backstops, + 7 behavioural)**, plus 3 manual/evidence items listed separately because neither layer can verify them. Every invariant, layer and determinism call is **AI-drafted (Helix) and needs compliance review**; 3 check(s) are **⚑ SME-flagged** and cannot gate until an SME/counsel supplies their parameter matrix. No detector or rule code exists yet. Before this manifest can be LOCKED, each row needs its detector/rule, a review, and a commit that adds the check alongside its row.

## Layers

- **static**: a repo-agnostic source scanner parameterised by a `VIGIL_MICA` preset (no app specifics in the detector). It reads source / SQL / config / IaC / git-diff, **fails CLOSED** on a match, and runs with **no adapter**, so it is the CI gate. *Static backstops* (IDs `-5x`) prove a supporting source invariant for a named behavioural check, the way N-CAP-01 / N-STATE-01 back neobank behaviour. They fire even when the adapter never drives that path. Backstops of ⚑ SME checks stay out of the gate.
- **behavioural**: a rule written once against the canonical `MoneySystem` interface (or a DRAFT extension surface in `adapters/`) and driven through the app adapter. Surfaces needed: **CryptoSystem** (`adapters/crypto.ts`), **CustomerJourneySystem** (`adapters/customer-journey.ts`). Every behavioural row reports NOT_EXERCISED until an adapter implements its surface. It returns **CHECKED only when it actually drove the guard's path**.
- **manual/evidence**: organisational process, live-infrastructure, statistical or retention evidence that no source scan or adapter-driven rule can prove. These are **outside the harness**, report `NOT_APPLICABLE` to it, and are tracked as evidence tasks, never as passes.

## Verdicts

`CHECKED` the path ran and the guard held · `FINDING` the guard was violated · `NOT_APPLICABLE` the invariant cannot apply here (incl. every manual/evidence item) · `NOT_EXERCISED` (glyph `????`) the adapter did not drive the path, so nothing is proven. NOT_EXERCISED is **surfaced distinctly and never counted as a pass** (no fake coverage). A ⚑ SME check with no approved parameter matrix reports `NOT_EXERCISED`, never `CHECKED`.

## How to run

- **Not runnable yet**: this draft defines invariants only (no detector/rule code). The intended shape mirrors the neobank playbook:
  - CI gate (adapter-free, blocks on any static FINDING): `run-static` with preset `VIGIL_MICA`.
  - Full combined table (static + behavioural via the adapter): `run-all`.
- Machine-readable rows: `checks.json` (same IDs; includes source-scenario traceability and neobank overlaps).

## The draft inventory: 5 static + 7 behavioural = 12 checks

| ID | Layer | Deterministic | Invariant (one line) | Covers (automation point · common failure · regulation) |
| --- | --- | --- | --- | --- |
| **MICA-LIC-01** | behavioural | yes ⚑ SME | A crypto service is available only where the register shows active authorisation for that service and member state (SME-provided scope matrix), from the licence effective date. | CASP licensing · general control (no source failure) · MiCA (Crypto) |
| **MICA-LIC-51** | static | yes ⚑ SME | Service availability flags derive from the licence-scope register (service × member state) — no hard-coded enablement. | backstop for MICA-LIC-01 · CASP licensing · general control (no source failure) · MiCA (Crypto) |
| **MICA-LIC-02** | behavioural | yes | A licence revocation or status change blocks new activity after ingestion, within the configured time. | CASP licensing · general control (no source failure) · MiCA (Crypto) |
| **MICA-LIC-03** | static | yes | A new service launch without a register entry fails the release gate. | CASP licensing · general control (no source failure) · MiCA (Crypto) |
| **MICA-RES-01** | behavioural | yes | Reserve assets ≥ outstanding token liabilities at every committed state, including concurrent mint/redeem — no over-mint from a race. | Reserve backing · Insufficient reserve · MiCA (Crypto) |
| **MICA-RES-51** | static | yes | The mint path checks reserve ≥ outstanding + mint amount inside the same locked transaction as the mint. | backstop for MICA-RES-01 · Reserve backing · Insufficient reserve · MiCA (Crypto) |
| **MICA-RES-02** | behavioural | yes | Minting halts when reserve data is stale/unavailable, composition breaches configured limits, or a shortfall alerts. | Reserve backing · Insufficient reserve · MiCA (Crypto) |
| **MICA-RES-52** | static | yes | The mint path checks reserve-attestation freshness and composition-limit status; stale or unavailable data aborts. | backstop for MICA-RES-02 · Reserve backing · Insufficient reserve · MiCA (Crypto) |
| **MICA-RES-03** | behavioural | yes | Redemption pays the configured par value within the configured window. | Reserve backing · Insufficient reserve · MiCA (Crypto) |
| **MICA-CP-01** | behavioural | yes | Purchase is blocked until risk warnings and disclosures consistent with live parameters are displayed and acknowledged. | Consumer protection · missing disclosure · MiCA (Crypto) |
| **MICA-CP-02** | static | yes | No marketing claim contradicts the white paper (mismatch blocks publish). | Consumer protection · missing disclosure · MiCA (Crypto) |
| **MICA-CP-03** | behavioural | yes ⚑ SME | Complaints are logged (queued during outage), deduplicated and resolved within configured timelines; the withdrawal/cancellation window follows the SME-provided rule. | Consumer protection · general control (no source failure) · MiCA (Crypto) |

## Outside the harness: manual/evidence (3)

These items are not harness checks. Each reports `NOT_APPLICABLE` to the runner and needs an owner and evidence on a schedule.

| ID | Layer | Deterministic | Invariant (one line) | Covers (automation point · common failure · regulation) |
| --- | --- | --- | --- | --- |
| **MICA-LIC-04** | manual/evidence | no (manual) | Licence and passport records are retained. | CASP licensing · general control (no source failure) · MiCA (Crypto) |
| **MICA-RES-04** | manual/evidence | no (manual) | Each period has a reserve attestation with underlying reconciliation data retained. | Reserve backing · general control (no source failure) · MiCA (Crypto) |
| **MICA-CP-04** | manual/evidence | no (manual) | Complaint records are retained. | Consumer protection · general control (no source failure) · MiCA (Crypto) |

### Determinism

Every harness row (static and behavioural) is drafted as deterministic. Static detectors, including backstops, are pure functions of the committed source/config/diff. Behavioural rules each run against a **fresh `reset()` MoneySystem** (no state leaks between rules), driven by a **controllable clock**; deadlines, windows, expiries and cadences are asserted by advancing that clock, never by wall-clock reads, and no randomness affects a verdict. External dependencies (vendors, registries, feeds) are faked inside the adapter, which is how fault-injection rows stay deterministic. Manual/evidence rows are not deterministic and are not gate checks. ⚑ SME rows are deterministic once parameters exist, but are excluded from the gate until then.

### Coverage note

Converted from 25 AI-drafted source scenarios of `SK-MICA-001`; each source scenario maps to exactly one non-backstop row (see the appendix). Static backstops add no scenarios and trace through the check they back. The scenarios were merged into crisp invariants by automation point and failure mode, across categories (positive, negative, boundary, failure/recovery, concurrency/idempotency, retention/audit, common failure, core). Automation points covered: CASP licensing, Reserve backing, Consumer protection. Source common failures: Insufficient reserve, missing disclosure. Thresholds, windows and deadlines are *configured* parameters, not asserted statutory values. No regulation or citation was added beyond the source sheet.

### Overlap with the locked neobank playbook (19 checks)

| This check | Neobank check | Strength | Why |
| --- | --- | --- | --- |
| MICA-LIC-02 | N-STATE-01 | related | revoked licence blocks new activity |
| MICA-RES-01 | N-ATOMIC | related | competing mint/redeem never break reserve ≥ liabilities |
| MICA-RES-51 | N-ATOMIC | related | reserve check + mint in one locked txn |
| MICA-RES-51 | N-CAP-01 | related | cap-style guard under lock |
| MICA-RES-03 | LEDGER-CONSERVE | related | redemption at par |

`same` means the neobank check already enforces this invariant, so reuse it instead of re-implementing. `related` means the same defect class, but this check needs its own rule or preset.

### Review flags

- ⚑ **MICA-LIC-01**: needs an SME/counsel parameter matrix (source scenarios carry review status "+ SME input").
- ⚑ **MICA-LIC-51**: needs an SME/counsel parameter matrix (source scenarios carry review status "+ SME input").
- ⚑ **MICA-CP-03**: needs an SME/counsel parameter matrix (source scenarios carry review status "+ SME input").

## Appendix: traceability to source scenarios

| Check ID | Source scenario IDs | Categories merged |
| --- | --- | --- |
| MICA-LIC-01 | SC-MICA-001-04, SC-MICA-001-18, SC-MICA-001-14, SC-MICA-001-17 | Boundary/Edge, Common Failure, Core, Positive |
| MICA-LIC-51 | — (static backstop; traced via MICA-LIC-01) | — |
| MICA-LIC-02 | SC-MICA-001-05, SC-MICA-001-15 | Concurrency/Idempotency, Failure/Recovery |
| MICA-LIC-03 | SC-MICA-001-06 | Negative |
| MICA-LIC-04 | SC-MICA-001-16 | Retention/Audit |
| MICA-RES-01 | SC-MICA-001-01, SC-MICA-001-07 | Concurrency/Idempotency, Core |
| MICA-RES-51 | — (static backstop; traced via MICA-RES-01) | — |
| MICA-RES-02 | SC-MICA-001-10, SC-MICA-001-19, SC-MICA-001-09, SC-MICA-001-20 | Boundary/Edge, Common Failure, Failure/Recovery, Negative |
| MICA-RES-52 | — (static backstop; traced via MICA-RES-02) | — |
| MICA-RES-03 | SC-MICA-001-08 | Positive |
| MICA-RES-04 | SC-MICA-001-11 | Retention/Audit |
| MICA-CP-01 | SC-MICA-001-02, SC-MICA-001-12, SC-MICA-001-21 | Core, Negative, Positive |
| MICA-CP-02 | SC-MICA-001-13 | Common Failure |
| MICA-CP-03 | SC-MICA-001-03, SC-MICA-001-23, SC-MICA-001-24, SC-MICA-001-22 | Boundary/Edge, Concurrency/Idempotency, Core, Failure/Recovery |
| MICA-CP-04 | SC-MICA-001-25 | Retention/Audit |

# Helix review rules

Generated from `checks.json` (12 static and behavioural checks; manual/evidence items are not code-reviewable and are omitted). Severity is derived from the playbook priority (P1 -> MEDIUM); Category MM marks money-movement checks. Rule text is the source invariant, unchanged; it is AI-drafted and needs compliance review.

## Rule MICA-LIC-01: A crypto service is available only where the register shows active authorisation for that service...
Severity: MEDIUM
Category: NON_MM
Scenario: casp-licensing
Requirement: MUST
Invariant: A crypto service is available only where the register shows active authorisation for that service and member state (SME-provided scope matrix), from the licence effective date.

Source check `MICA-LIC-01` from `checks.json` (behavioural; deterministic: yes). Covers: CASP licensing · None · MiCA (Crypto). Flagged for SME input in the source; needs an approved parameter matrix. Review status in source: Drafted (AI) – needs compliance review + SME input.

Regulation references: RR-CRYPTO-001.

## Rule MICA-LIC-51: Service availability flags derive from the licence-scope register (service × member state) — no h...
Severity: MEDIUM
Category: NON_MM
Scenario: casp-licensing
Requirement: MUST
Invariant: Service availability flags derive from the licence-scope register (service × member state) — no hard-coded enablement.

Source check `MICA-LIC-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: CASP licensing · None · MiCA (Crypto). Backstop for MICA-LIC-01. Flagged for SME input in the source; needs an approved parameter matrix. Review status in source: Drafted (AI) – needs compliance review + SME input.

Regulation references: RR-CRYPTO-001.

## Rule MICA-LIC-02: A licence revocation or status change blocks new activity after ingestion, within the configured...
Severity: MEDIUM
Category: NON_MM
Scenario: casp-licensing
Requirement: MUST
Invariant: A licence revocation or status change blocks new activity after ingestion, within the configured time.

Source check `MICA-LIC-02` from `checks.json` (behavioural; deterministic: yes). Covers: CASP licensing · None · MiCA (Crypto). Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-CRYPTO-001.

## Rule MICA-LIC-03: A new service launch without a register entry fails the release gate
Severity: MEDIUM
Category: NON_MM
Scenario: casp-licensing
Requirement: MUST
Invariant: A new service launch without a register entry fails the release gate.

Source check `MICA-LIC-03` from `checks.json` (static; deterministic: yes). Covers: CASP licensing · None · MiCA (Crypto). Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-CRYPTO-001.

## Rule MICA-RES-01: Reserve assets ≥ outstanding token liabilities at every committed state, including concurrent min...
Severity: MEDIUM
Category: NON_MM
Scenario: reserve-backing
Requirement: MUST
Invariant: Reserve assets ≥ outstanding token liabilities at every committed state, including concurrent mint/redeem — no over-mint from a race.

Source check `MICA-RES-01` from `checks.json` (behavioural; deterministic: yes). Covers: Reserve backing · Insufficient reserve · MiCA (Crypto). Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-CRYPTO-001.

## Rule MICA-RES-51: The mint path checks reserve ≥ outstanding + mint amount inside the same locked transaction as th...
Severity: MEDIUM
Category: NON_MM
Scenario: reserve-backing
Requirement: MUST
Invariant: The mint path checks reserve ≥ outstanding + mint amount inside the same locked transaction as the mint.

Source check `MICA-RES-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: Reserve backing · Insufficient reserve · MiCA (Crypto). Backstop for MICA-RES-01. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-CRYPTO-001.

## Rule MICA-RES-02: Minting halts when reserve data is stale/unavailable, composition breaches configured limits, or...
Severity: MEDIUM
Category: NON_MM
Scenario: reserve-backing
Requirement: MUST
Invariant: Minting halts when reserve data is stale/unavailable, composition breaches configured limits, or a shortfall alerts.

Source check `MICA-RES-02` from `checks.json` (behavioural; deterministic: yes). Covers: Reserve backing · Insufficient reserve · MiCA (Crypto). Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-CRYPTO-001.

## Rule MICA-RES-52: The mint path checks reserve-attestation freshness and composition-limit status
Severity: MEDIUM
Category: NON_MM
Scenario: reserve-backing
Requirement: MUST
Invariant: The mint path checks reserve-attestation freshness and composition-limit status; stale or unavailable data aborts.

Source check `MICA-RES-52` from `checks.json` (static, static backstop; deterministic: yes). Covers: Reserve backing · Insufficient reserve · MiCA (Crypto). Backstop for MICA-RES-02. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-CRYPTO-001.

## Rule MICA-RES-03: Redemption pays the configured par value within the configured window
Severity: MEDIUM
Category: NON_MM
Scenario: reserve-backing
Requirement: MUST
Invariant: Redemption pays the configured par value within the configured window.

Source check `MICA-RES-03` from `checks.json` (behavioural; deterministic: yes). Covers: Reserve backing · Insufficient reserve · MiCA (Crypto). Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-CRYPTO-001, RR-CRYPTO-010.

## Rule MICA-CP-01: Purchase is blocked until risk warnings and disclosures consistent with live parameters are displ...
Severity: MEDIUM
Category: NON_MM
Scenario: consumer-protection
Requirement: MUST
Invariant: Purchase is blocked until risk warnings and disclosures consistent with live parameters are displayed and acknowledged.

Source check `MICA-CP-01` from `checks.json` (behavioural; deterministic: yes). Covers: Consumer protection · missing disclosure · MiCA (Crypto). Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-CRYPTO-001.

## Rule MICA-CP-02: No marketing claim contradicts the white paper (mismatch blocks publish)
Severity: MEDIUM
Category: NON_MM
Scenario: consumer-protection
Requirement: MUST
Invariant: No marketing claim contradicts the white paper (mismatch blocks publish).

Source check `MICA-CP-02` from `checks.json` (static; deterministic: yes). Covers: Consumer protection · missing disclosure · MiCA (Crypto). Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-CRYPTO-001.

## Rule MICA-CP-03: Complaints are logged (queued during outage), deduplicated and resolved within configured timelines
Severity: MEDIUM
Category: NON_MM
Scenario: consumer-protection
Requirement: MUST
Invariant: Complaints are logged (queued during outage), deduplicated and resolved within configured timelines; the withdrawal/cancellation window follows the SME-provided rule.

Source check `MICA-CP-03` from `checks.json` (behavioural; deterministic: yes). Covers: Consumer protection · None · MiCA (Crypto). Flagged for SME input in the source; needs an approved parameter matrix. Review status in source: Drafted (AI) – needs compliance review + SME input.

Regulation references: RR-CRYPTO-001.
