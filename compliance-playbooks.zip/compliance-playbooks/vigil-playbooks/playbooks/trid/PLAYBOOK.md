---
helixPlaybookFormat: helix-playbook/0.1-proposal
playbookId: vigil-trid
title: "TRID Loan Estimate / Closing Disclosure Timing"
declaredVersion: 0.1.0
intent: draft
applicability:
  languages: [javascript, typescript]
  scenarios: [loan-estimate, closing-disclosure, timing]
---
# Helix portable playbook — DRAFT manifest · TRID Loan Estimate / Closing Disclosure Timing

> **DRAFT — not LOCKED.** Proposed TILA-RESPA Integrated Disclosures (TRID) (Mortgage) playbook converted from Vigil skill `SK-TRID-001`: one runner, two layers, **8 harness checks (3 static, incl. 2 static backstops, + 5 behavioural)**, plus 3 manual/evidence items listed separately because neither layer can verify them. Every invariant, layer and determinism call is **AI-drafted (Helix) and needs compliance review**. No detector or rule code exists yet. Before this manifest can be LOCKED, each row needs its detector/rule, a review, and a commit that adds the check alongside its row.

## Layers

- **static**: a repo-agnostic source scanner parameterised by a `VIGIL_TRID` preset (no app specifics in the detector). It reads source / SQL / config / IaC / git-diff, **fails CLOSED** on a match, and runs with **no adapter**, so it is the CI gate. *Static backstops* (IDs `-5x`) prove a supporting source invariant for a named behavioural check, the way N-CAP-01 / N-STATE-01 back neobank behaviour. They fire even when the adapter never drives that path. Backstops of ⚑ SME checks stay out of the gate.
- **behavioural**: a rule written once against the canonical `MoneySystem` interface (or a DRAFT extension surface in `adapters/`) and driven through the app adapter. Surfaces needed: **MortgageSystem** (`adapters/mortgage.ts`). Every behavioural row reports NOT_EXERCISED until an adapter implements its surface. It returns **CHECKED only when it actually drove the guard's path**.
- **manual/evidence**: organisational process, live-infrastructure, statistical or retention evidence that no source scan or adapter-driven rule can prove. These are **outside the harness**, report `NOT_APPLICABLE` to it, and are tracked as evidence tasks, never as passes.

## Verdicts

`CHECKED` the path ran and the guard held · `FINDING` the guard was violated · `NOT_APPLICABLE` the invariant cannot apply here (incl. every manual/evidence item) · `NOT_EXERCISED` (glyph `????`) the adapter did not drive the path, so nothing is proven. NOT_EXERCISED is **surfaced distinctly and never counted as a pass** (no fake coverage). A ⚑ SME check with no approved parameter matrix reports `NOT_EXERCISED`, never `CHECKED`.

## How to run

- **Not runnable yet**: this draft defines invariants only (no detector/rule code). The intended shape mirrors the neobank playbook:
  - CI gate (adapter-free, blocks on any static FINDING): `run-static` with preset `VIGIL_TRID`.
  - Full combined table (static + behavioural via the adapter): `run-all`.
- Machine-readable rows: `checks.json` (same IDs; includes source-scenario traceability and neobank overlaps).

## The draft inventory: 3 static + 5 behavioural = 8 checks

| ID | Layer | Deterministic | Invariant (one line) | Covers (automation point · common failure · regulation) |
| --- | --- | --- | --- | --- |
| **TRID-LE-01** | behavioural | yes | A Loan Estimate is generated when the application is complete and delivered within the configured business-day window (versioned calendar), with fields exactly matching the pricing engine; generation failure escalates before the deadline. | Loan estimate · Late disclosure · TILA-RESPA Integrated Disclosures (TRID) |
| **TRID-LE-02** | behavioural | yes | A revised LE is issued only for a valid changed circumstance — concurrent circumstances yield one revision — and the tolerance baseline is unchanged otherwise. | Loan estimate · tolerance exceedance · TILA-RESPA Integrated Disclosures (TRID) |
| **TRID-LE-51** | static | yes | LE revision requires a changed-circumstance reason code from the configured valid list. | backstop for TRID-LE-02 · Loan estimate · tolerance exceedance · TILA-RESPA Integrated Disclosures (TRID) |
| **TRID-CD-01** | behavioural | yes | Closing cannot be scheduled until CD receipt is recorded the configured business days before consummation; changes needing a new waiting period re-block closing (including concurrent revisions). | Closing disclosure · Late disclosure · TILA-RESPA Integrated Disclosures (TRID) |
| **TRID-CD-51** | static | yes | Closing scheduling checks the CD-receipt timestamp plus configured business days via the calendar service. | backstop for TRID-CD-01 · Closing disclosure · Late disclosure · TILA-RESPA Integrated Disclosures (TRID) |
| **TRID-CD-02** | behavioural | yes | Fee increases beyond each tolerance bucket compute the correct cure, which posts to the ledger and is refunded within the window with a corrected CD; within-tolerance fees need no cure. | Timing / Closing disclosure · tolerance exceedance · TILA-RESPA Integrated Disclosures (TRID) |
| **TRID-CD-03** | static | yes | Every fee type maps to a tolerance bucket (CI fails if missing). | Timing · tolerance exceedance · TILA-RESPA Integrated Disclosures (TRID) |
| **TRID-TIM-01** | behavioural | yes | Deadlines use the configured business-day calendar and delivery-method receipt assumptions; e-delivery without e-consent is rejected; timing keys on the single latest disclosure version. | Timing · Late disclosure · TILA-RESPA Integrated Disclosures (TRID) |

## Outside the harness: manual/evidence (3)

These items are not harness checks. Each reports `NOT_APPLICABLE` to the runner and needs an owner and evidence on a schedule.

| ID | Layer | Deterministic | Invariant (one line) | Covers (automation point · common failure · regulation) |
| --- | --- | --- | --- | --- |
| **TRID-LE-03** | manual/evidence | no (manual) | LE versions are retained. | Loan estimate · general control (no source failure) · TILA-RESPA Integrated Disclosures (TRID) |
| **TRID-CD-04** | manual/evidence | no (manual) | CD versions are retained. | Closing disclosure · general control (no source failure) · TILA-RESPA Integrated Disclosures (TRID) |
| **TRID-TIM-02** | manual/evidence | no (manual) | Disclosure delivery evidence is retained. | Timing · general control (no source failure) · TILA-RESPA Integrated Disclosures (TRID) |

### Determinism

Every harness row (static and behavioural) is drafted as deterministic. Static detectors, including backstops, are pure functions of the committed source/config/diff. Behavioural rules each run against a **fresh `reset()` MoneySystem** (no state leaks between rules), driven by a **controllable clock**; deadlines, windows, expiries and cadences are asserted by advancing that clock, never by wall-clock reads, and no randomness affects a verdict. External dependencies (vendors, registries, feeds) are faked inside the adapter, which is how fault-injection rows stay deterministic. Manual/evidence rows are not deterministic and are not gate checks.

### Coverage note

Converted from 24 AI-drafted source scenarios of `SK-TRID-001`; each source scenario maps to exactly one non-backstop row (see the appendix). Static backstops add no scenarios and trace through the check they back. The scenarios were merged into crisp invariants by automation point and failure mode, across categories (positive, negative, boundary, failure/recovery, concurrency/idempotency, retention/audit, common failure, core). Automation points covered: Loan estimate, Closing disclosure, Timing. Source common failures: Late disclosure, tolerance exceedance. Thresholds, windows and deadlines are *configured* parameters, not asserted statutory values. No regulation or citation was added beyond the source sheet.

### Overlap with the locked neobank playbook (19 checks)

| This check | Neobank check | Strength | Why |
| --- | --- | --- | --- |
| TRID-CD-02 | LEDGER-CONSERVE | related | cure posts to ledger |

`same` means the neobank check already enforces this invariant, so reuse it instead of re-implementing. `related` means the same defect class, but this check needs its own rule or preset.

### Review flags

- No SME-flagged rows. All rows still need compliance review.

## Appendix: traceability to source scenarios

| Check ID | Source scenario IDs | Categories merged |
| --- | --- | --- |
| TRID-LE-01 | SC-TRID-001-01, SC-TRID-001-04, SC-TRID-001-14, SC-TRID-001-06, SC-TRID-001-15 | Boundary/Edge, Common Failure, Core, Failure/Recovery, Positive |
| TRID-LE-02 | SC-TRID-001-05, SC-TRID-001-16 | Concurrency/Idempotency, Negative |
| TRID-LE-51 | — (static backstop; traced via TRID-LE-02) | — |
| TRID-LE-03 | SC-TRID-001-17 | Retention/Audit |
| TRID-CD-01 | SC-TRID-001-02, SC-TRID-001-18, SC-TRID-001-21, SC-TRID-001-09, SC-TRID-001-19 | Common Failure, Concurrency/Idempotency, Core, Negative, Positive |
| TRID-CD-51 | — (static backstop; traced via TRID-CD-01) | — |
| TRID-CD-02 | SC-TRID-001-03, SC-TRID-001-07, SC-TRID-001-08, SC-TRID-001-22, SC-TRID-001-23 | Boundary/Edge, Core, Failure/Recovery, Positive |
| TRID-CD-03 | SC-TRID-001-24 | Common Failure |
| TRID-CD-04 | SC-TRID-001-20 | Retention/Audit |
| TRID-TIM-01 | SC-TRID-001-10, SC-TRID-001-11, SC-TRID-001-12 | Boundary/Edge, Concurrency/Idempotency, Negative |
| TRID-TIM-02 | SC-TRID-001-13 | Retention/Audit |

# Helix review rules

Generated from `checks.json` (8 static and behavioural checks; manual/evidence items are not code-reviewable and are omitted). Severity is derived from the playbook priority (P1 -> MEDIUM); Category MM marks money-movement checks. Rule text is the source invariant, unchanged; it is AI-drafted and needs compliance review.

## Rule TRID-LE-01: A Loan Estimate is generated when the application is complete and delivered within the configured...
Severity: MEDIUM
Category: NON_MM
Scenario: loan-estimate
Requirement: MUST
Invariant: A Loan Estimate is generated when the application is complete and delivered within the configured business-day window (versioned calendar), with fields exactly matching the pricing engine; generation failure escalates before the deadline.

Source check `TRID-LE-01` from `checks.json` (behavioural; deterministic: yes). Covers: Loan estimate · Late disclosure · TILA-RESPA Integrated Disclosures (TRID). Review status in source: Drafted (AI) – needs compliance review.

## Rule TRID-LE-02: A revised LE is issued only for a valid changed circumstance — concurrent circumstances yield one...
Severity: MEDIUM
Category: NON_MM
Scenario: loan-estimate
Requirement: MUST
Invariant: A revised LE is issued only for a valid changed circumstance — concurrent circumstances yield one revision — and the tolerance baseline is unchanged otherwise.

Source check `TRID-LE-02` from `checks.json` (behavioural; deterministic: yes). Covers: Loan estimate · tolerance exceedance · TILA-RESPA Integrated Disclosures (TRID). Review status in source: Drafted (AI) – needs compliance review.

## Rule TRID-LE-51: LE revision requires a changed-circumstance reason code from the configured valid list
Severity: MEDIUM
Category: NON_MM
Scenario: loan-estimate
Requirement: MUST
Invariant: LE revision requires a changed-circumstance reason code from the configured valid list.

Source check `TRID-LE-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: Loan estimate · tolerance exceedance · TILA-RESPA Integrated Disclosures (TRID). Backstop for TRID-LE-02. Review status in source: Drafted (AI) – needs compliance review.

## Rule TRID-CD-01: Closing cannot be scheduled until CD receipt is recorded the configured business days before cons...
Severity: MEDIUM
Category: NON_MM
Scenario: closing-disclosure
Requirement: MUST
Invariant: Closing cannot be scheduled until CD receipt is recorded the configured business days before consummation; changes needing a new waiting period re-block closing (including concurrent revisions).

Source check `TRID-CD-01` from `checks.json` (behavioural; deterministic: yes). Covers: Closing disclosure · Late disclosure · TILA-RESPA Integrated Disclosures (TRID). Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-REGZ-013.

## Rule TRID-CD-51: Closing scheduling checks the CD-receipt timestamp plus configured business days via the calendar...
Severity: MEDIUM
Category: NON_MM
Scenario: closing-disclosure
Requirement: MUST
Invariant: Closing scheduling checks the CD-receipt timestamp plus configured business days via the calendar service.

Source check `TRID-CD-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: Closing disclosure · Late disclosure · TILA-RESPA Integrated Disclosures (TRID). Backstop for TRID-CD-01. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-REGZ-013.

## Rule TRID-CD-02: Fee increases beyond each tolerance bucket compute the correct cure, which posts to the ledger an...
Severity: MEDIUM
Category: NON_MM
Scenario: timing
Requirement: MUST
Invariant: Fee increases beyond each tolerance bucket compute the correct cure, which posts to the ledger and is refunded within the window with a corrected CD; within-tolerance fees need no cure.

Source check `TRID-CD-02` from `checks.json` (behavioural; deterministic: yes). Covers: Timing, Closing disclosure · tolerance exceedance · TILA-RESPA Integrated Disclosures (TRID). Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-REGZ-013.

## Rule TRID-CD-03: Every fee type maps to a tolerance bucket (CI fails if missing)
Severity: MEDIUM
Category: NON_MM
Scenario: timing
Requirement: MUST
Invariant: Every fee type maps to a tolerance bucket (CI fails if missing).

Source check `TRID-CD-03` from `checks.json` (static; deterministic: yes). Covers: Timing · tolerance exceedance · TILA-RESPA Integrated Disclosures (TRID). Review status in source: Drafted (AI) – needs compliance review.

## Rule TRID-TIM-01: Deadlines use the configured business-day calendar and delivery-method receipt assumptions
Severity: MEDIUM
Category: NON_MM
Scenario: timing
Requirement: MUST
Invariant: Deadlines use the configured business-day calendar and delivery-method receipt assumptions; e-delivery without e-consent is rejected; timing keys on the single latest disclosure version.

Source check `TRID-TIM-01` from `checks.json` (behavioural; deterministic: yes). Covers: Timing · Late disclosure · TILA-RESPA Integrated Disclosures (TRID). Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-REGZ-013, RR-ESIGN-001.
