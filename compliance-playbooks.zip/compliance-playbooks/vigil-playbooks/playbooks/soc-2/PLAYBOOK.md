---
helixPlaybookFormat: helix-playbook/0.1-proposal
playbookId: vigil-soc-2
title: "SOC 2 Type II Continuous Control Evidence"
declaredVersion: 0.1.0
intent: draft
applicability:
  languages: [javascript, typescript]
  scenarios: [security, availability, processing-integrity, confidentiality]
---
# Helix portable playbook — DRAFT manifest · SOC 2 Type II Continuous Control Evidence

> **DRAFT — not LOCKED.** Proposed SOC 2 Type II (Service Organization) playbook converted from Vigil skill `SK-SOC2-001`: one runner, two layers, **12 harness checks (6 static, incl. 3 static backstops, + 6 behavioural)**, plus 7 manual/evidence items listed separately because neither layer can verify them. Every invariant, layer and determinism call is **AI-drafted (Helix) and needs compliance review**. No detector or rule code exists yet. Before this manifest can be LOCKED, each row needs its detector/rule, a review, and a commit that adds the check alongside its row.

## Layers

- **static**: a repo-agnostic source scanner parameterised by a `VIGIL_SOC2` preset (no app specifics in the detector). It reads source / SQL / config / IaC / git-diff, **fails CLOSED** on a match, and runs with **no adapter**, so it is the CI gate. *Static backstops* (IDs `-5x`) prove a supporting source invariant for a named behavioural check, the way N-CAP-01 / N-STATE-01 back neobank behaviour. They fire even when the adapter never drives that path. Backstops of ⚑ SME checks stay out of the gate.
- **behavioural**: a rule written once against the canonical `MoneySystem` interface (or a DRAFT extension surface in `adapters/`) and driven through the app adapter. Surfaces needed: **MoneySystem** (`adapters/money-system.ts`), **DataProtectionSystem** (`adapters/data-protection.ts`). Every behavioural row reports NOT_EXERCISED until an adapter implements its surface. It returns **CHECKED only when it actually drove the guard's path**.
- **manual/evidence**: organisational process, live-infrastructure, statistical or retention evidence that no source scan or adapter-driven rule can prove. These are **outside the harness**, report `NOT_APPLICABLE` to it, and are tracked as evidence tasks, never as passes.

## Verdicts

`CHECKED` the path ran and the guard held · `FINDING` the guard was violated · `NOT_APPLICABLE` the invariant cannot apply here (incl. every manual/evidence item) · `NOT_EXERCISED` (glyph `????`) the adapter did not drive the path, so nothing is proven. NOT_EXERCISED is **surfaced distinctly and never counted as a pass** (no fake coverage). A ⚑ SME check with no approved parameter matrix reports `NOT_EXERCISED`, never `CHECKED`.

## How to run

- **Not runnable yet**: this draft defines invariants only (no detector/rule code). The intended shape mirrors the neobank playbook:
  - CI gate (adapter-free, blocks on any static FINDING): `run-static` with preset `VIGIL_SOC2`.
  - Full combined table (static + behavioural via the adapter): `run-all`.
- Machine-readable rows: `checks.json` (same IDs; includes source-scenario traceability and neobank overlaps).

## The draft inventory: 6 static + 6 behavioural = 12 checks

| ID | Layer | Deterministic | Invariant (one line) | Covers (automation point · common failure · regulation) |
| --- | --- | --- | --- | --- |
| **SOC2-SEC-01** | static | yes | No secret is committed to source control (PR blocked; detected secret must be rotated). | Security · Control failure · SOC 2 Type II |
| **SOC2-AVL-01** | behavioural | yes | A dependency outage degrades to controlled errors or queued work with no data loss and no duplicate money movement. | Availability · Control failure · SOC 2 Type II |
| **SOC2-AVL-51** | static | yes | Calls to irreversible external payment APIs happen after the local durable commit. | backstop for SOC2-AVL-01 · Availability · Control failure · SOC 2 Type II |
| **SOC2-PI-01** | behavioural | yes | Every valid payment input is processed exactly once, completely and accurately (inputs = outputs), including at the configured maximum batch size. | Processing integrity · Control failure · SOC 2 Type II |
| **SOC2-PI-02** | behavioural | yes | A payment API idempotency key creates exactly one payment; replays return the original; key reuse with a different body is rejected. | Processing integrity · Control failure · SOC 2 Type II |
| **SOC2-PI-51** | static | yes | Every payment-creating route requires an idempotency key and rejects key reuse with a different body hash. | backstop for SOC2-PI-02 · Processing integrity · Control failure · SOC 2 Type II |
| **SOC2-PI-03** | behavioural | yes | Malformed payment inputs are rejected with deterministic errors and nothing persisted. | Processing integrity · Control failure · SOC 2 Type II |
| **SOC2-PI-04** | behavioural | yes | A poison or failed message lands in the DLQ with an alert — never silently dropped; missed/failed scheduled jobs are detected within the configured window. | Processing integrity · Control failure · SOC 2 Type II |
| **SOC2-PI-52** | static | yes | Every queue consumer has a DLQ configured, and catch blocks re-raise or DLQ rather than ack-and-drop. | backstop for SOC2-PI-04 · Processing integrity · Control failure · SOC 2 Type II |
| **SOC2-PI-05** | static | yes | Production changes are reviewed, tested and traceable (approval + passing CI on every deploy; emergency changes get retro-approval); processing recons retained. | Processing integrity · missing evidence · SOC 2 Type II |
| **SOC2-CONF-01** | static | yes | Confidential data stores are declared encrypted, non-public and access-restricted by classification tags enforced by policy-as-code; labels apply correctly at rule boundaries. | Confidentiality · general control (no source failure) · SOC 2 Type II |
| **SOC2-CONF-02** | behavioural | yes | Confidential data is detected and redacted in support tickets/attachments, and external sharing is blocked or approval-gated — including when DLP is down and across concurrent exports. | Confidentiality · general control (no source failure) · SOC 2 Type II |

## Outside the harness: manual/evidence (7)

These items are not harness checks. Each reports `NOT_APPLICABLE` to the runner and needs an owner and evidence on a schedule.

| ID | Layer | Deterministic | Invariant (one line) | Covers (automation point · common failure · regulation) |
| --- | --- | --- | --- | --- |
| **SOC2-SEC-02** | manual/evidence | no (manual) | MFA is enforced on production/cloud consoles with legacy auth disabled, and password/MFA policy holds at its boundary values. | Security · Control failure · SOC 2 Type II |
| **SOC2-SEC-03** | manual/evidence | no (manual) | Every control has passing evidence for each operating period; terminated users are deprovisioned within SLA; access reviews, grants and vendor reviews are complete on cadence. | Security · missing evidence · SOC 2 Type II |
| **SOC2-SEC-04** | manual/evidence | no (manual) | Vulnerability/pen-test findings close within severity SLAs (retest evidence); scanner outages alert; security alerts are triaged within SLA; training evidence is current. | Security · missing evidence · SOC 2 Type II |
| **SOC2-SEC-05** | manual/evidence | no (manual) | The auditor sample population is complete and stored as an immutable snapshot. | Security · missing evidence · SOC 2 Type II |
| **SOC2-AVL-02** | manual/evidence | no (manual) | Availability meets SLO under load; capacity alerts fire before saturation; SLO breaches auto-create incidents; probes are meta-monitored; metrics retained. | Availability · Control failure · SOC 2 Type II |
| **SOC2-AVL-03** | manual/evidence | no (manual) | Backup restore and DR failover meet the configured RTO/RPO with integrity checks passing. | Availability · general control (no source failure) · SOC 2 Type II |
| **SOC2-CONF-03** | manual/evidence | no (manual) | Non-prod contains only synthetic/masked data; offboarding disposal produces a log/certificate; incidents are handled per runbook within SLA. | Confidentiality · general control (no source failure) · SOC 2 Type II |

### Determinism

Every harness row (static and behavioural) is drafted as deterministic. Static detectors, including backstops, are pure functions of the committed source/config/diff. Behavioural rules each run against a **fresh `reset()` MoneySystem** (no state leaks between rules), driven by a **controllable clock**; deadlines, windows, expiries and cadences are asserted by advancing that clock, never by wall-clock reads, and no randomness affects a verdict. External dependencies (vendors, registries, feeds) are faked inside the adapter, which is how fault-injection rows stay deterministic. Manual/evidence rows are not deterministic and are not gate checks.

### Coverage note

Converted from 43 AI-drafted source scenarios of `SK-SOC2-001`; each source scenario maps to exactly one non-backstop row (see the appendix). Static backstops add no scenarios and trace through the check they back. The scenarios were merged into crisp invariants by automation point and failure mode, across categories (positive, negative, boundary, failure/recovery, concurrency/idempotency, retention/audit, common failure, core). Automation points covered: Security, Availability, Processing integrity, Confidentiality. Source common failures: Control failure, missing evidence. Thresholds, windows and deadlines are *configured* parameters, not asserted statutory values. No regulation or citation was added beyond the source sheet.

### Overlap with the locked neobank playbook (19 checks)

| This check | Neobank check | Strength | Why |
| --- | --- | --- | --- |
| SOC2-AVL-01 | N-ORDER-01 | related | outage never duplicates money movement |
| SOC2-AVL-51 | N-ORDER-01 | same | durable commit before irreversible external call |
| SOC2-PI-01 | LEDGER-CONSERVE | related | inputs = outputs |
| SOC2-PI-02 | N-IDEMP-01 | same | idempotency key → exactly one payment |
| SOC2-PI-51 | N-IDEMP-01 | same | payment routes gate on Idempotency-Key |

`same` means the neobank check already enforces this invariant, so reuse it instead of re-implementing. `related` means the same defect class, but this check needs its own rule or preset.

### Review flags

- No SME-flagged rows. All rows still need compliance review.

## Appendix: traceability to source scenarios

| Check ID | Source scenario IDs | Categories merged |
| --- | --- | --- |
| SOC2-SEC-01 | SC-SOC2-001-04 | Negative |
| SOC2-SEC-02 | SC-SOC2-001-05, SC-SOC2-001-20 | Boundary/Edge, Positive |
| SOC2-SEC-03 | SC-SOC2-001-01, DR-SOC2-001-01, DR-SOC2-001-02, SC-SOC2-001-22, DR-SOC2-001-07 | Concurrency/Idempotency, Core |
| SOC2-SEC-04 | DR-SOC2-001-04, SC-SOC2-001-06, SC-SOC2-001-21, DR-SOC2-001-09, SC-SOC2-001-07 | Common Failure, Core, Failure/Recovery, Retention/Audit |
| SOC2-SEC-05 | SC-SOC2-001-17 | Retention/Audit |
| SOC2-AVL-01 | SC-SOC2-001-08 | Failure/Recovery |
| SOC2-AVL-51 | — (static backstop; traced via SOC2-AVL-01) | — |
| SOC2-AVL-02 | SC-SOC2-001-03, SC-SOC2-001-10, SC-SOC2-001-24, SC-SOC2-001-26, SC-SOC2-001-23, SC-SOC2-001-25 | Common Failure, Concurrency/Idempotency, Core, Negative, Positive, Retention/Audit |
| SOC2-AVL-03 | DR-SOC2-001-05, SC-SOC2-001-09 | Boundary/Edge, Core |
| SOC2-PI-01 | DR-SOC2-001-08, SC-SOC2-001-27, SC-SOC2-001-28 | Boundary/Edge, Core, Positive |
| SOC2-PI-02 | SC-SOC2-001-11 | Concurrency/Idempotency |
| SOC2-PI-51 | — (static backstop; traced via SOC2-PI-02) | — |
| SOC2-PI-03 | SC-SOC2-001-12 | Negative |
| SOC2-PI-04 | SC-SOC2-001-30, SC-SOC2-001-13 | Common Failure, Failure/Recovery |
| SOC2-PI-52 | — (static backstop; traced via SOC2-PI-04) | — |
| SOC2-PI-05 | DR-SOC2-001-03, SC-SOC2-001-29 | Core, Retention/Audit |
| SOC2-CONF-01 | DR-SOC2-001-06, SC-SOC2-001-31, SC-SOC2-001-16, SC-SOC2-001-32 | Boundary/Edge, Core, Negative, Positive |
| SOC2-CONF-02 | SC-SOC2-001-18, SC-SOC2-001-19, SC-SOC2-001-33, SC-SOC2-001-34 | Common Failure, Concurrency/Idempotency, Failure/Recovery, Negative |
| SOC2-CONF-03 | SC-SOC2-001-14, SC-SOC2-001-15, SC-SOC2-001-02 | Common Failure, Core, Retention/Audit |

# Helix review rules

Generated from `checks.json` (12 static and behavioural checks; manual/evidence items are not code-reviewable and are omitted). Severity is derived from the playbook priority (P0 -> HIGH); Category MM marks money-movement checks. Rule text is the source invariant, unchanged; it is AI-drafted and needs compliance review.

## Rule SOC2-SEC-01: No secret is committed to source control (PR blocked
Severity: HIGH
Category: NON_MM
Scenario: security
Requirement: MUST
Invariant: No secret is committed to source control (PR blocked; detected secret must be rotated).

Source check `SOC2-SEC-01` from `checks.json` (static; deterministic: yes). Covers: Security · Control failure · SOC 2 Type II. Review status in source: Drafted (AI) – needs compliance review.

## Rule SOC2-AVL-01: A dependency outage degrades to controlled errors or queued work with no data loss and no duplica...
Severity: HIGH
Category: MM
Scenario: availability
Requirement: MUST
Invariant: A dependency outage degrades to controlled errors or queued work with no data loss and no duplicate money movement.

Source check `SOC2-AVL-01` from `checks.json` (behavioural; deterministic: yes). Covers: Availability · Control failure · SOC 2 Type II. Review status in source: Drafted (AI) – needs compliance review.

## Rule SOC2-AVL-51: Calls to irreversible external payment APIs happen after the local durable commit
Severity: HIGH
Category: NON_MM
Scenario: availability
Requirement: MUST
Invariant: Calls to irreversible external payment APIs happen after the local durable commit.

Source check `SOC2-AVL-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: Availability · Control failure · SOC 2 Type II. Backstop for SOC2-AVL-01. Review status in source: Drafted (AI) – needs compliance review.

## Rule SOC2-PI-01: Every valid payment input is processed exactly once, completely and accurately (inputs = outputs)...
Severity: HIGH
Category: MM
Scenario: processing-integrity
Requirement: MUST
Invariant: Every valid payment input is processed exactly once, completely and accurately (inputs = outputs), including at the configured maximum batch size.

Source check `SOC2-PI-01` from `checks.json` (behavioural; deterministic: yes). Covers: Processing integrity · Control failure · SOC 2 Type II. Review status in source: Drafted (AI) – needs compliance review.

## Rule SOC2-PI-02: A payment API idempotency key creates exactly one payment
Severity: HIGH
Category: MM
Scenario: processing-integrity
Requirement: MUST
Invariant: A payment API idempotency key creates exactly one payment; replays return the original; key reuse with a different body is rejected.

Source check `SOC2-PI-02` from `checks.json` (behavioural; deterministic: yes). Covers: Processing integrity · Control failure · SOC 2 Type II. Review status in source: Drafted (AI) – needs compliance review.

## Rule SOC2-PI-51: Every payment-creating route requires an idempotency key and rejects key reuse with a different b...
Severity: HIGH
Category: NON_MM
Scenario: processing-integrity
Requirement: MUST
Invariant: Every payment-creating route requires an idempotency key and rejects key reuse with a different body hash.

Source check `SOC2-PI-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: Processing integrity · Control failure · SOC 2 Type II. Backstop for SOC2-PI-02. Review status in source: Drafted (AI) – needs compliance review.

## Rule SOC2-PI-03: Malformed payment inputs are rejected with deterministic errors and nothing persisted
Severity: HIGH
Category: MM
Scenario: processing-integrity
Requirement: MUST
Invariant: Malformed payment inputs are rejected with deterministic errors and nothing persisted.

Source check `SOC2-PI-03` from `checks.json` (behavioural; deterministic: yes). Covers: Processing integrity · Control failure · SOC 2 Type II. Review status in source: Drafted (AI) – needs compliance review.

## Rule SOC2-PI-04: A poison or failed message lands in the DLQ with an alert — never silently dropped
Severity: HIGH
Category: MM
Scenario: processing-integrity
Requirement: MUST
Invariant: A poison or failed message lands in the DLQ with an alert — never silently dropped; missed/failed scheduled jobs are detected within the configured window.

Source check `SOC2-PI-04` from `checks.json` (behavioural; deterministic: yes). Covers: Processing integrity · Control failure · SOC 2 Type II. Review status in source: Drafted (AI) – needs compliance review.

## Rule SOC2-PI-52: Every queue consumer has a DLQ configured, and catch blocks re-raise or DLQ rather than ack-and-drop
Severity: HIGH
Category: NON_MM
Scenario: processing-integrity
Requirement: MUST
Invariant: Every queue consumer has a DLQ configured, and catch blocks re-raise or DLQ rather than ack-and-drop.

Source check `SOC2-PI-52` from `checks.json` (static, static backstop; deterministic: yes). Covers: Processing integrity · Control failure · SOC 2 Type II. Backstop for SOC2-PI-04. Review status in source: Drafted (AI) – needs compliance review.

## Rule SOC2-PI-05: Production changes are reviewed, tested and traceable (approval + passing CI on every deploy
Severity: HIGH
Category: NON_MM
Scenario: processing-integrity
Requirement: MUST
Invariant: Production changes are reviewed, tested and traceable (approval + passing CI on every deploy; emergency changes get retro-approval); processing recons retained.

Source check `SOC2-PI-05` from `checks.json` (static; deterministic: yes). Covers: Processing integrity · missing evidence · SOC 2 Type II. Review status in source: Drafted (AI) – needs compliance review.

## Rule SOC2-CONF-01: Confidential data stores are declared encrypted, non-public and access-restricted by classificati...
Severity: HIGH
Category: NON_MM
Scenario: confidentiality
Requirement: MUST
Invariant: Confidential data stores are declared encrypted, non-public and access-restricted by classification tags enforced by policy-as-code; labels apply correctly at rule boundaries.

Source check `SOC2-CONF-01` from `checks.json` (static; deterministic: yes). Covers: Confidentiality · None · SOC 2 Type II. Review status in source: Drafted (AI) – needs compliance review.

## Rule SOC2-CONF-02: Confidential data is detected and redacted in support tickets/attachments, and external sharing i...
Severity: HIGH
Category: NON_MM
Scenario: confidentiality
Requirement: MUST
Invariant: Confidential data is detected and redacted in support tickets/attachments, and external sharing is blocked or approval-gated — including when DLP is down and across concurrent exports.

Source check `SOC2-CONF-02` from `checks.json` (behavioural; deterministic: yes). Covers: Confidentiality · None · SOC 2 Type II. Review status in source: Drafted (AI) – needs compliance review.
