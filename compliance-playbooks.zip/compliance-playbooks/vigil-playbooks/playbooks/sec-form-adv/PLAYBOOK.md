---
helixPlaybookFormat: helix-playbook/0.1-proposal
playbookId: vigil-sec-form-adv
title: "SEC Form ADV Disclosure, Performance & Custody"
declaredVersion: 0.1.0
intent: draft
applicability:
  languages: [javascript, typescript]
  scenarios: [disclosure, performance-advertising, custody]
---
# Helix portable playbook — DRAFT manifest · SEC Form ADV Disclosure, Performance & Custody

> **DRAFT — not LOCKED.** Proposed SEC Form ADV (Investment Advisers) playbook converted from Vigil skill `SK-ADV-001`: one runner, two layers, **12 harness checks (3 static, incl. 2 static backstops, + 9 behavioural)**, plus 2 manual/evidence items listed separately because neither layer can verify them. Every invariant, layer and determinism call is **AI-drafted (Helix) and needs compliance review**. No detector or rule code exists yet. Before this manifest can be LOCKED, each row needs its detector/rule, a review, and a commit that adds the check alongside its row.

## Layers

- **static**: a repo-agnostic source scanner parameterised by a `VIGIL_ADV` preset (no app specifics in the detector). It reads source / SQL / config / IaC / git-diff, **fails CLOSED** on a match, and runs with **no adapter**, so it is the CI gate. *Static backstops* (IDs `-5x`) prove a supporting source invariant for a named behavioural check, the way N-CAP-01 / N-STATE-01 back neobank behaviour. They fire even when the adapter never drives that path. Backstops of ⚑ SME checks stay out of the gate.
- **behavioural**: a rule written once against the canonical `MoneySystem` interface (or a DRAFT extension surface in `adapters/`) and driven through the app adapter. Surfaces needed: **AdvisorySystem** (`adapters/advisory.ts`). Every behavioural row reports NOT_EXERCISED until an adapter implements its surface. It returns **CHECKED only when it actually drove the guard's path**.
- **manual/evidence**: organisational process, live-infrastructure, statistical or retention evidence that no source scan or adapter-driven rule can prove. These are **outside the harness**, report `NOT_APPLICABLE` to it, and are tracked as evidence tasks, never as passes.

## Verdicts

`CHECKED` the path ran and the guard held · `FINDING` the guard was violated · `NOT_APPLICABLE` the invariant cannot apply here (incl. every manual/evidence item) · `NOT_EXERCISED` (glyph `????`) the adapter did not drive the path, so nothing is proven. NOT_EXERCISED is **surfaced distinctly and never counted as a pass** (no fake coverage). A ⚑ SME check with no approved parameter matrix reports `NOT_EXERCISED`, never `CHECKED`.

## How to run

- **Not runnable yet**: this draft defines invariants only (no detector/rule code). The intended shape mirrors the neobank playbook:
  - CI gate (adapter-free, blocks on any static FINDING): `run-static` with preset `VIGIL_ADV`.
  - Full combined table (static + behavioural via the adapter): `run-all`.
- Machine-readable rows: `checks.json` (same IDs; includes source-scenario traceability and neobank overlaps).

## The draft inventory: 3 static + 9 behavioural = 12 checks

| ID | Layer | Deterministic | Invariant (one line) | Covers (automation point · common failure · regulation) |
| --- | --- | --- | --- | --- |
| **ADV-DIS-01** | behavioural | yes | A material change at the configured threshold creates exactly one ADV update task with deadline, and client delivery is tracked. | Disclosure · Stale ADV · SEC Form ADV |
| **ADV-DIS-02** | behavioural | yes | Billing never exceeds the disclosed fee rate. | Disclosure · Stale ADV · SEC Form ADV |
| **ADV-DIS-51** | static | yes | The billing engine reads fee rates from the same disclosed-fee table the ADV content renders from (single source). | backstop for ADV-DIS-02 · Disclosure · Stale ADV · SEC Form ADV |
| **ADV-DIS-03** | behavioural | yes | Onboarding is blocked until brochure delivery is recorded. | Disclosure · general control (no source failure) · SEC Form ADV |
| **ADV-DIS-04** | behavioural | yes | A source-feed failure marks the ADV consistency check incomplete, never 'consistent'; concurrent draft edits are versioned. | Disclosure · Stale ADV · SEC Form ADV |
| **ADV-PERF-01** | static | yes | Performance content cannot render without net-of-fee alongside gross and required periods (no cherry-picked windows). | Performance advertising · misleading performance · SEC Form ADV |
| **ADV-PERF-02** | behavioural | yes | Calculated returns match a reference within tolerance and are reproducible from one consistent run of retained inputs. | Performance advertising · misleading performance · SEC Form ADV |
| **ADV-PERF-03** | behavioural | yes | A pricing-data gap halts performance publication. | Performance advertising · misleading performance · SEC Form ADV |
| **ADV-CUS-01** | behavioural | yes | Client holdings and cash reconcile to custodian statements daily; breaks at the configured tolerance are flagged and in-flight movements cause no false breaks. | Custody · general control (no source failure) · SEC Form ADV |
| **ADV-CUS-02** | behavioural | yes | Fee deductions and asset movements without verified authority are blocked. | Custody · general control (no source failure) · SEC Form ADV |
| **ADV-CUS-51** | static | yes | Fee-deduction and asset-movement paths require a recorded authority reference. | backstop for ADV-CUS-02 · Custody · general control (no source failure) · SEC Form ADV |
| **ADV-CUS-03** | behavioural | yes | A custodian-feed outage marks the reconciliation incomplete, never passed. | Custody · general control (no source failure) · SEC Form ADV |

## Outside the harness: manual/evidence (2)

These items are not harness checks. Each reports `NOT_APPLICABLE` to the runner and needs an owner and evidence on a schedule.

| ID | Layer | Deterministic | Invariant (one line) | Covers (automation point · common failure · regulation) |
| --- | --- | --- | --- | --- |
| **ADV-DIS-05** | manual/evidence | no (manual) | ADV versions and delivery records are retained. | Disclosure · general control (no source failure) · SEC Form ADV |
| **ADV-CUS-04** | manual/evidence | no (manual) | Custody records and reconciliations are retained. | Custody · general control (no source failure) · SEC Form ADV |

### Determinism

Every harness row (static and behavioural) is drafted as deterministic. Static detectors, including backstops, are pure functions of the committed source/config/diff. Behavioural rules each run against a **fresh `reset()` MoneySystem** (no state leaks between rules), driven by a **controllable clock**; deadlines, windows, expiries and cadences are asserted by advancing that clock, never by wall-clock reads, and no randomness affects a verdict. External dependencies (vendors, registries, feeds) are faked inside the adapter, which is how fault-injection rows stay deterministic. Manual/evidence rows are not deterministic and are not gate checks.

### Coverage note

Converted from 24 AI-drafted source scenarios of `SK-ADV-001`; each source scenario maps to exactly one non-backstop row (see the appendix). Static backstops add no scenarios and trace through the check they back. The scenarios were merged into crisp invariants by automation point and failure mode, across categories (positive, negative, boundary, failure/recovery, concurrency/idempotency, retention/audit, common failure, core). Automation points covered: Disclosure, Performance advertising, Custody. Source common failures: Stale ADV, misleading performance. Thresholds, windows and deadlines are *configured* parameters, not asserted statutory values. No regulation or citation was added beyond the source sheet.

### Overlap with the locked neobank playbook (19 checks)

| This check | Neobank check | Strength | Why |
| --- | --- | --- | --- |
| ADV-DIS-02 | N-CAP-01 | related | billing ≤ disclosed rate |
| ADV-CUS-01 | LEDGER-CONSERVE | related | holdings reconcile to custodian |

`same` means the neobank check already enforces this invariant, so reuse it instead of re-implementing. `related` means the same defect class, but this check needs its own rule or preset.

### Review flags

- No SME-flagged rows. All rows still need compliance review.

## Appendix: traceability to source scenarios

| Check ID | Source scenario IDs | Categories merged |
| --- | --- | --- |
| ADV-DIS-01 | SC-ADV-001-01, SC-ADV-001-04, SC-ADV-001-13 | Boundary/Edge, Common Failure, Core |
| ADV-DIS-02 | SC-ADV-001-05 | Negative |
| ADV-DIS-51 | — (static backstop; traced via ADV-DIS-02) | — |
| ADV-DIS-03 | SC-ADV-001-06 | Positive |
| ADV-DIS-04 | SC-ADV-001-14, SC-ADV-001-15 | Concurrency/Idempotency, Failure/Recovery |
| ADV-DIS-05 | SC-ADV-001-16 | Retention/Audit |
| ADV-PERF-01 | SC-ADV-001-07, SC-ADV-001-08, SC-ADV-001-20 | Boundary/Edge, Common Failure, Negative |
| ADV-PERF-02 | SC-ADV-001-02, SC-ADV-001-09, SC-ADV-001-17, SC-ADV-001-19 | Concurrency/Idempotency, Core, Positive, Retention/Audit |
| ADV-PERF-03 | SC-ADV-001-18 | Failure/Recovery |
| ADV-CUS-01 | SC-ADV-001-03, SC-ADV-001-10, SC-ADV-001-21, SC-ADV-001-22, SC-ADV-001-23 | Boundary/Edge, Common Failure, Concurrency/Idempotency, Core, Positive |
| ADV-CUS-02 | SC-ADV-001-11 | Negative |
| ADV-CUS-51 | — (static backstop; traced via ADV-CUS-02) | — |
| ADV-CUS-03 | SC-ADV-001-12 | Failure/Recovery |
| ADV-CUS-04 | SC-ADV-001-24 | Retention/Audit |

# Helix review rules

Generated from `checks.json` (12 static and behavioural checks; manual/evidence items are not code-reviewable and are omitted). Severity is derived from the playbook priority (P2 -> LOW); Category MM marks money-movement checks. Rule text is the source invariant, unchanged; it is AI-drafted and needs compliance review.

## Rule ADV-DIS-01: A material change at the configured threshold creates exactly one ADV update task with deadline,...
Severity: LOW
Category: NON_MM
Scenario: disclosure
Requirement: MUST
Invariant: A material change at the configured threshold creates exactly one ADV update task with deadline, and client delivery is tracked.

Source check `ADV-DIS-01` from `checks.json` (behavioural; deterministic: yes). Covers: Disclosure · Stale ADV · SEC Form ADV. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-SEC-023.

## Rule ADV-DIS-02: Billing never exceeds the disclosed fee rate
Severity: LOW
Category: NON_MM
Scenario: disclosure
Requirement: MUST
Invariant: Billing never exceeds the disclosed fee rate.

Source check `ADV-DIS-02` from `checks.json` (behavioural; deterministic: yes). Covers: Disclosure · Stale ADV · SEC Form ADV. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-SEC-023.

## Rule ADV-DIS-51: The billing engine reads fee rates from the same disclosed-fee table the ADV content renders from...
Severity: LOW
Category: NON_MM
Scenario: disclosure
Requirement: MUST
Invariant: The billing engine reads fee rates from the same disclosed-fee table the ADV content renders from (single source).

Source check `ADV-DIS-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: Disclosure · Stale ADV · SEC Form ADV. Backstop for ADV-DIS-02. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-SEC-023.

## Rule ADV-DIS-03: Onboarding is blocked until brochure delivery is recorded
Severity: LOW
Category: NON_MM
Scenario: disclosure
Requirement: MUST
Invariant: Onboarding is blocked until brochure delivery is recorded.

Source check `ADV-DIS-03` from `checks.json` (behavioural; deterministic: yes). Covers: Disclosure · None · SEC Form ADV. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-SEC-023.

## Rule ADV-DIS-04: A source-feed failure marks the ADV consistency check incomplete, never 'consistent'
Severity: LOW
Category: NON_MM
Scenario: disclosure
Requirement: MUST
Invariant: A source-feed failure marks the ADV consistency check incomplete, never 'consistent'; concurrent draft edits are versioned.

Source check `ADV-DIS-04` from `checks.json` (behavioural; deterministic: yes). Covers: Disclosure · Stale ADV · SEC Form ADV. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-SEC-023.

## Rule ADV-PERF-01: Performance content cannot render without net-of-fee alongside gross and required periods (no che...
Severity: LOW
Category: NON_MM
Scenario: performance-advertising
Requirement: MUST
Invariant: Performance content cannot render without net-of-fee alongside gross and required periods (no cherry-picked windows).

Source check `ADV-PERF-01` from `checks.json` (static; deterministic: yes). Covers: Performance advertising · misleading performance · SEC Form ADV. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-SEC-007.

## Rule ADV-PERF-02: Calculated returns match a reference within tolerance and are reproducible from one consistent ru...
Severity: LOW
Category: NON_MM
Scenario: performance-advertising
Requirement: MUST
Invariant: Calculated returns match a reference within tolerance and are reproducible from one consistent run of retained inputs.

Source check `ADV-PERF-02` from `checks.json` (behavioural; deterministic: yes). Covers: Performance advertising · misleading performance · SEC Form ADV. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-SEC-007.

## Rule ADV-PERF-03: A pricing-data gap halts performance publication
Severity: LOW
Category: NON_MM
Scenario: performance-advertising
Requirement: MUST
Invariant: A pricing-data gap halts performance publication.

Source check `ADV-PERF-03` from `checks.json` (behavioural; deterministic: yes). Covers: Performance advertising · misleading performance · SEC Form ADV. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-SEC-007.

## Rule ADV-CUS-01: Client holdings and cash reconcile to custodian statements daily
Severity: LOW
Category: NON_MM
Scenario: custody
Requirement: MUST
Invariant: Client holdings and cash reconcile to custodian statements daily; breaks at the configured tolerance are flagged and in-flight movements cause no false breaks.

Source check `ADV-CUS-01` from `checks.json` (behavioural; deterministic: yes). Covers: Custody · None · SEC Form ADV. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-SEC-006, RR-SEC-019.

## Rule ADV-CUS-02: Fee deductions and asset movements without verified authority are blocked
Severity: LOW
Category: NON_MM
Scenario: custody
Requirement: MUST
Invariant: Fee deductions and asset movements without verified authority are blocked.

Source check `ADV-CUS-02` from `checks.json` (behavioural; deterministic: yes). Covers: Custody · None · SEC Form ADV. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-SEC-006.

## Rule ADV-CUS-51: Fee-deduction and asset-movement paths require a recorded authority reference
Severity: LOW
Category: NON_MM
Scenario: custody
Requirement: MUST
Invariant: Fee-deduction and asset-movement paths require a recorded authority reference.

Source check `ADV-CUS-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: Custody · None · SEC Form ADV. Backstop for ADV-CUS-02. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-SEC-006.

## Rule ADV-CUS-03: A custodian-feed outage marks the reconciliation incomplete, never passed
Severity: LOW
Category: NON_MM
Scenario: custody
Requirement: MUST
Invariant: A custodian-feed outage marks the reconciliation incomplete, never passed.

Source check `ADV-CUS-03` from `checks.json` (behavioural; deterministic: yes). Covers: Custody · None · SEC Form ADV. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-SEC-006, RR-SEC-019.
