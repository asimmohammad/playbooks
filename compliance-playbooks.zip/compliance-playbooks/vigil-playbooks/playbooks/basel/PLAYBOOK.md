---
helixPlaybookFormat: helix-playbook/0.1-proposal
playbookId: vigil-basel
title: "Basel Capital, RWA & Leverage Calculations"
declaredVersion: 0.1.0
intent: draft
applicability:
  languages: [javascript, typescript]
  scenarios: [risk-weighted-assets, capital-adequacy, leverage-ratio]
---
# Helix portable playbook — DRAFT manifest · Basel Capital, RWA & Leverage Calculations

> **DRAFT — not LOCKED.** Proposed Basel Capital Requirements (Basel III/IV) playbook converted from Vigil skill `SK-BASEL-001`: one runner, two layers, **11 harness checks (3 static, incl. 3 static backstops, + 8 behavioural)**, plus 3 manual/evidence items listed separately because neither layer can verify them. Every invariant, layer and determinism call is **AI-drafted (Helix) and needs compliance review**; 6 check(s) are **⚑ SME-flagged** and cannot gate until an SME/counsel supplies their parameter matrix. No detector or rule code exists yet. Before this manifest can be LOCKED, each row needs its detector/rule, a review, and a commit that adds the check alongside its row.

## Layers

- **static**: a repo-agnostic source scanner parameterised by a `VIGIL_BASEL` preset (no app specifics in the detector). It reads source / SQL / config / IaC / git-diff, **fails CLOSED** on a match, and runs with **no adapter**, so it is the CI gate. *Static backstops* (IDs `-5x`) prove a supporting source invariant for a named behavioural check, the way N-CAP-01 / N-STATE-01 back neobank behaviour. They fire even when the adapter never drives that path. Backstops of ⚑ SME checks stay out of the gate.
- **behavioural**: a rule written once against the canonical `MoneySystem` interface (or a DRAFT extension surface in `adapters/`) and driven through the app adapter. Surfaces needed: **CapitalEngine** (`adapters/capital-engine.ts`). Every behavioural row reports NOT_EXERCISED until an adapter implements its surface. It returns **CHECKED only when it actually drove the guard's path**.
- **manual/evidence**: organisational process, live-infrastructure, statistical or retention evidence that no source scan or adapter-driven rule can prove. These are **outside the harness**, report `NOT_APPLICABLE` to it, and are tracked as evidence tasks, never as passes.

## Verdicts

`CHECKED` the path ran and the guard held · `FINDING` the guard was violated · `NOT_APPLICABLE` the invariant cannot apply here (incl. every manual/evidence item) · `NOT_EXERCISED` (glyph `????`) the adapter did not drive the path, so nothing is proven. NOT_EXERCISED is **surfaced distinctly and never counted as a pass** (no fake coverage). A ⚑ SME check with no approved parameter matrix reports `NOT_EXERCISED`, never `CHECKED`.

## How to run

- **Not runnable yet**: this draft defines invariants only (no detector/rule code). The intended shape mirrors the neobank playbook:
  - CI gate (adapter-free, blocks on any static FINDING): `run-static` with preset `VIGIL_BASEL`.
  - Full combined table (static + behavioural via the adapter): `run-all`.
- Machine-readable rows: `checks.json` (same IDs; includes source-scenario traceability and neobank overlaps).

## The draft inventory: 3 static + 8 behavioural = 11 checks

| ID | Layer | Deterministic | Invariant (one line) | Covers (automation point · common failure · regulation) |
| --- | --- | --- | --- | --- |
| **BASEL-RWA-01** | behavioural | yes ⚑ SME | RWA = Σ exposure × configured weight per exposure class (SME-provided table); an unmapped exposure fails the run. | Risk-weighted assets · Wrong RWA · Basel Capital Requirements |
| **BASEL-RWA-51** | static | yes ⚑ SME | Every exposure class enum value has a risk-weight table entry; unmapped classes raise rather than default to zero. | backstop for BASEL-RWA-01 · Risk-weighted assets · Wrong RWA · Basel Capital Requirements |
| **BASEL-RWA-02** | behavioural | yes ⚑ SME | Missing collateral/rating data applies the configured conservative fallback weight and is flagged — never a silent zero weight; rating changes reweight at the configured as-of point. | Risk-weighted assets · Wrong RWA · Basel Capital Requirements |
| **BASEL-RWA-52** | static | yes ⚑ SME | Missing rating/collateral handling applies the configured fallback weight; no `?? 0` / default-zero weight path. | backstop for BASEL-RWA-02 · Risk-weighted assets · Wrong RWA · Basel Capital Requirements |
| **BASEL-RWA-03** | behavioural | yes | Reprocessing an exposure batch is idempotent — RWA unchanged. | Risk-weighted assets · Wrong RWA · Basel Capital Requirements |
| **BASEL-CAP-01** | behavioural | yes ⚑ SME | Capital ratios computed from approved, eligible components match the reference workbook; ineligible instruments are excluded with reasons. | Capital adequacy · capital shortfall · Basel Capital Requirements |
| **BASEL-CAP-02** | behavioural | yes | Breach and buffer-usage alerts fire at the configured minimum + buffer levels and route to owners. | Capital adequacy · capital shortfall · Basel Capital Requirements |
| **BASEL-CAP-03** | behavioural | yes | A missing GL feed blocks final ratio publication; concurrent recalculation publishes one consistent run. | Capital adequacy · capital shortfall · Basel Capital Requirements |
| **BASEL-CAP-51** | static | yes | Final ratio publication requires a complete-feed flag; concurrent recalculation is serialised by a lock or version. | backstop for BASEL-CAP-03 · Capital adequacy · capital shortfall · Basel Capital Requirements |
| **BASEL-LEV-01** | behavioural | yes ⚑ SME | Leverage ratio = Tier 1 / total exposure incl. off-balance-sheet items at configured factors and gross where netting is disallowed; matches reference and alerts exactly at the minimum. | Leverage ratio · capital shortfall · Basel Capital Requirements |
| **BASEL-LEV-02** | behavioural | yes | Late-arriving trades/adjustments restate the ratio in a new version from a consistent snapshot, retaining prior values. | Leverage ratio · general control (no source failure) · Basel Capital Requirements |

## Outside the harness: manual/evidence (3)

These items are not harness checks. Each reports `NOT_APPLICABLE` to the runner and needs an owner and evidence on a schedule.

| ID | Layer | Deterministic | Invariant (one line) | Covers (automation point · common failure · regulation) |
| --- | --- | --- | --- | --- |
| **BASEL-RWA-04** | manual/evidence | no (manual) | RWA inputs/outputs and table versions are archived and reproducible. | Risk-weighted assets · general control (no source failure) · Basel Capital Requirements |
| **BASEL-CAP-04** | manual/evidence | no (manual) | GL-to-capital reconciliation differences are within tolerance with documented adjustments. | Capital adequacy · general control (no source failure) · Basel Capital Requirements |
| **BASEL-LEV-03** | manual/evidence | no (manual) | Leverage calculations are retained with parameter versions. | Leverage ratio · general control (no source failure) · Basel Capital Requirements |

### Determinism

Every harness row (static and behavioural) is drafted as deterministic. Static detectors, including backstops, are pure functions of the committed source/config/diff. Behavioural rules each run against a **fresh `reset()` MoneySystem** (no state leaks between rules), driven by a **controllable clock**; deadlines, windows, expiries and cadences are asserted by advancing that clock, never by wall-clock reads, and no randomness affects a verdict. External dependencies (vendors, registries, feeds) are faked inside the adapter, which is how fault-injection rows stay deterministic. Manual/evidence rows are not deterministic and are not gate checks. ⚑ SME rows are deterministic once parameters exist, but are excluded from the gate until then.

### Coverage note

Converted from 24 AI-drafted source scenarios of `SK-BASEL-001`; each source scenario maps to exactly one non-backstop row (see the appendix). Static backstops add no scenarios and trace through the check they back. The scenarios were merged into crisp invariants by automation point and failure mode, across categories (positive, negative, boundary, failure/recovery, concurrency/idempotency, retention/audit, common failure, core). Automation points covered: Capital adequacy, Risk-weighted assets, Leverage ratio. Source common failures: Wrong RWA, capital shortfall. Thresholds, windows and deadlines are *configured* parameters, not asserted statutory values. No regulation or citation was added beyond the source sheet.

### Overlap with the locked neobank playbook (19 checks)

| This check | Neobank check | Strength | Why |
| --- | --- | --- | --- |
| BASEL-RWA-03 | N-IDEMP-01 | related | reprocessing idempotent |

`same` means the neobank check already enforces this invariant, so reuse it instead of re-implementing. `related` means the same defect class, but this check needs its own rule or preset.

### Review flags

- ⚑ **BASEL-RWA-01**: needs an SME/counsel parameter matrix (source scenarios carry review status "+ SME input").
- ⚑ **BASEL-RWA-51**: needs an SME/counsel parameter matrix (source scenarios carry review status "+ SME input").
- ⚑ **BASEL-RWA-02**: needs an SME/counsel parameter matrix (source scenarios carry review status "+ SME input").
- ⚑ **BASEL-RWA-52**: needs an SME/counsel parameter matrix (source scenarios carry review status "+ SME input").
- ⚑ **BASEL-CAP-01**: needs an SME/counsel parameter matrix (source scenarios carry review status "+ SME input").
- ⚑ **BASEL-LEV-01**: needs an SME/counsel parameter matrix (source scenarios carry review status "+ SME input").

## Appendix: traceability to source scenarios

| Check ID | Source scenario IDs | Categories merged |
| --- | --- | --- |
| BASEL-RWA-01 | SC-BASEL-001-01, SC-BASEL-001-04, SC-BASEL-001-16 | Common Failure, Core, Positive |
| BASEL-RWA-51 | — (static backstop; traced via BASEL-RWA-01) | — |
| BASEL-RWA-02 | SC-BASEL-001-06, SC-BASEL-001-17, SC-BASEL-001-05 | Boundary/Edge, Failure/Recovery, Negative |
| BASEL-RWA-52 | — (static backstop; traced via BASEL-RWA-02) | — |
| BASEL-RWA-03 | SC-BASEL-001-18 | Concurrency/Idempotency |
| BASEL-RWA-04 | SC-BASEL-001-19 | Retention/Audit |
| BASEL-CAP-01 | SC-BASEL-001-02, SC-BASEL-001-11, SC-BASEL-001-12 | Core, Negative, Positive |
| BASEL-CAP-02 | SC-BASEL-001-07, SC-BASEL-001-15 | Boundary/Edge, Common Failure |
| BASEL-CAP-03 | SC-BASEL-001-13, SC-BASEL-001-14 | Concurrency/Idempotency, Failure/Recovery |
| BASEL-CAP-51 | — (static backstop; traced via BASEL-CAP-03) | — |
| BASEL-CAP-04 | SC-BASEL-001-08 | Retention/Audit |
| BASEL-LEV-01 | SC-BASEL-001-03, SC-BASEL-001-09, SC-BASEL-001-20, SC-BASEL-001-21, SC-BASEL-001-22 | Boundary/Edge, Common Failure, Core, Negative, Positive |
| BASEL-LEV-02 | SC-BASEL-001-10, SC-BASEL-001-23 | Concurrency/Idempotency, Failure/Recovery |
| BASEL-LEV-03 | SC-BASEL-001-24 | Retention/Audit |

# Helix review rules

Generated from `checks.json` (11 static and behavioural checks; manual/evidence items are not code-reviewable and are omitted). Severity is derived from the playbook priority (P2 -> LOW); Category MM marks money-movement checks. Rule text is the source invariant, unchanged; it is AI-drafted and needs compliance review.

## Rule BASEL-RWA-01: RWA = Σ exposure × configured weight per exposure class (SME-provided table)
Severity: LOW
Category: NON_MM
Scenario: risk-weighted-assets
Requirement: MUST
Invariant: RWA = Σ exposure × configured weight per exposure class (SME-provided table); an unmapped exposure fails the run.

Source check `BASEL-RWA-01` from `checks.json` (behavioural; deterministic: yes). Covers: Risk-weighted assets · Wrong RWA · Basel Capital Requirements. Flagged for SME input in the source; needs an approved parameter matrix. Review status in source: Drafted (AI) – needs compliance review + SME input.

## Rule BASEL-RWA-51: Every exposure class enum value has a risk-weight table entry
Severity: LOW
Category: NON_MM
Scenario: risk-weighted-assets
Requirement: MUST
Invariant: Every exposure class enum value has a risk-weight table entry; unmapped classes raise rather than default to zero.

Source check `BASEL-RWA-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: Risk-weighted assets · Wrong RWA · Basel Capital Requirements. Backstop for BASEL-RWA-01. Flagged for SME input in the source; needs an approved parameter matrix. Review status in source: Drafted (AI) – needs compliance review + SME input.

## Rule BASEL-RWA-02: Missing collateral/rating data applies the configured conservative fallback weight and is flagged...
Severity: LOW
Category: NON_MM
Scenario: risk-weighted-assets
Requirement: MUST
Invariant: Missing collateral/rating data applies the configured conservative fallback weight and is flagged — never a silent zero weight; rating changes reweight at the configured as-of point.

Source check `BASEL-RWA-02` from `checks.json` (behavioural; deterministic: yes). Covers: Risk-weighted assets · Wrong RWA · Basel Capital Requirements. Flagged for SME input in the source; needs an approved parameter matrix. Review status in source: Drafted (AI) – needs compliance review + SME input.

## Rule BASEL-RWA-52: Missing rating/collateral handling applies the configured fallback weight
Severity: LOW
Category: NON_MM
Scenario: risk-weighted-assets
Requirement: MUST
Invariant: Missing rating/collateral handling applies the configured fallback weight; no `?? 0` / default-zero weight path.

Source check `BASEL-RWA-52` from `checks.json` (static, static backstop; deterministic: yes). Covers: Risk-weighted assets · Wrong RWA · Basel Capital Requirements. Backstop for BASEL-RWA-02. Flagged for SME input in the source; needs an approved parameter matrix. Review status in source: Drafted (AI) – needs compliance review + SME input.

## Rule BASEL-RWA-03: Reprocessing an exposure batch is idempotent — RWA unchanged
Severity: LOW
Category: NON_MM
Scenario: risk-weighted-assets
Requirement: MUST
Invariant: Reprocessing an exposure batch is idempotent — RWA unchanged.

Source check `BASEL-RWA-03` from `checks.json` (behavioural; deterministic: yes). Covers: Risk-weighted assets · Wrong RWA · Basel Capital Requirements. Review status in source: Drafted (AI) – needs compliance review.

## Rule BASEL-CAP-01: Capital ratios computed from approved, eligible components match the reference workbook
Severity: LOW
Category: NON_MM
Scenario: capital-adequacy
Requirement: MUST
Invariant: Capital ratios computed from approved, eligible components match the reference workbook; ineligible instruments are excluded with reasons.

Source check `BASEL-CAP-01` from `checks.json` (behavioural; deterministic: yes). Covers: Capital adequacy · capital shortfall · Basel Capital Requirements. Flagged for SME input in the source; needs an approved parameter matrix. Review status in source: Drafted (AI) – needs compliance review + SME input.

## Rule BASEL-CAP-02: Breach and buffer-usage alerts fire at the configured minimum + buffer levels and route to owners
Severity: LOW
Category: NON_MM
Scenario: capital-adequacy
Requirement: MUST
Invariant: Breach and buffer-usage alerts fire at the configured minimum + buffer levels and route to owners.

Source check `BASEL-CAP-02` from `checks.json` (behavioural; deterministic: yes). Covers: Capital adequacy · capital shortfall · Basel Capital Requirements. Review status in source: Drafted (AI) – needs compliance review.

## Rule BASEL-CAP-03: A missing GL feed blocks final ratio publication
Severity: LOW
Category: NON_MM
Scenario: capital-adequacy
Requirement: MUST
Invariant: A missing GL feed blocks final ratio publication; concurrent recalculation publishes one consistent run.

Source check `BASEL-CAP-03` from `checks.json` (behavioural; deterministic: yes). Covers: Capital adequacy · capital shortfall · Basel Capital Requirements. Review status in source: Drafted (AI) – needs compliance review.

## Rule BASEL-CAP-51: Final ratio publication requires a complete-feed flag
Severity: LOW
Category: NON_MM
Scenario: capital-adequacy
Requirement: MUST
Invariant: Final ratio publication requires a complete-feed flag; concurrent recalculation is serialised by a lock or version.

Source check `BASEL-CAP-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: Capital adequacy · capital shortfall · Basel Capital Requirements. Backstop for BASEL-CAP-03. Review status in source: Drafted (AI) – needs compliance review.

## Rule BASEL-LEV-01: Leverage ratio = Tier 1 / total exposure incl
Severity: LOW
Category: NON_MM
Scenario: leverage-ratio
Requirement: MUST
Invariant: Leverage ratio = Tier 1 / total exposure incl. off-balance-sheet items at configured factors and gross where netting is disallowed; matches reference and alerts exactly at the minimum.

Source check `BASEL-LEV-01` from `checks.json` (behavioural; deterministic: yes). Covers: Leverage ratio · capital shortfall · Basel Capital Requirements. Flagged for SME input in the source; needs an approved parameter matrix. Review status in source: Drafted (AI) – needs compliance review + SME input.

## Rule BASEL-LEV-02: Late-arriving trades/adjustments restate the ratio in a new version from a consistent snapshot, r...
Severity: LOW
Category: NON_MM
Scenario: leverage-ratio
Requirement: MUST
Invariant: Late-arriving trades/adjustments restate the ratio in a new version from a consistent snapshot, retaining prior values.

Source check `BASEL-LEV-02` from `checks.json` (behavioural; deterministic: yes). Covers: Leverage ratio · None · Basel Capital Requirements. Review status in source: Drafted (AI) – needs compliance review.
