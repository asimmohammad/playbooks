---
helixPlaybookFormat: helix-playbook/0.1-proposal
playbookId: vigil-ucc-article-4a
title: "UCC Art. 4A Wire Security & Error Detection"
declaredVersion: 0.1.0
intent: draft
applicability:
  languages: [javascript, typescript]
  scenarios: [security-procedures, wire-transfers, error-detection]
---
# Helix portable playbook — DRAFT manifest · UCC Art. 4A Wire Security & Error Detection

> **DRAFT — not LOCKED.** Proposed UCC Article 4A (Commercial Payments) playbook converted from Vigil skill `SK-UCC4A-001`: one runner, two layers, **11 harness checks (4 static, incl. 3 static backstops, + 7 behavioural)**, plus 3 manual/evidence items listed separately because neither layer can verify them. Every invariant, layer and determinism call is **AI-drafted (Helix) and needs compliance review**. No detector or rule code exists yet. Before this manifest can be LOCKED, each row needs its detector/rule, a review, and a commit that adds the check alongside its row.

## Layers

- **static**: a repo-agnostic source scanner parameterised by a `VIGIL_UCC4A` preset (no app specifics in the detector). It reads source / SQL / config / IaC / git-diff, **fails CLOSED** on a match, and runs with **no adapter**, so it is the CI gate. *Static backstops* (IDs `-5x`) prove a supporting source invariant for a named behavioural check, the way N-CAP-01 / N-STATE-01 back neobank behaviour. They fire even when the adapter never drives that path. Backstops of ⚑ SME checks stay out of the gate.
- **behavioural**: a rule written once against the canonical `MoneySystem` interface (or a DRAFT extension surface in `adapters/`) and driven through the app adapter. Surfaces needed: **WireSystem** (`adapters/wires.ts`). Every behavioural row reports NOT_EXERCISED until an adapter implements its surface. It returns **CHECKED only when it actually drove the guard's path**.
- **manual/evidence**: organisational process, live-infrastructure, statistical or retention evidence that no source scan or adapter-driven rule can prove. These are **outside the harness**, report `NOT_APPLICABLE` to it, and are tracked as evidence tasks, never as passes.

## Verdicts

`CHECKED` the path ran and the guard held · `FINDING` the guard was violated · `NOT_APPLICABLE` the invariant cannot apply here (incl. every manual/evidence item) · `NOT_EXERCISED` (glyph `????`) the adapter did not drive the path, so nothing is proven. NOT_EXERCISED is **surfaced distinctly and never counted as a pass** (no fake coverage). A ⚑ SME check with no approved parameter matrix reports `NOT_EXERCISED`, never `CHECKED`.

## How to run

- **Not runnable yet**: this draft defines invariants only (no detector/rule code). The intended shape mirrors the neobank playbook:
  - CI gate (adapter-free, blocks on any static FINDING): `run-static` with preset `VIGIL_UCC4A`.
  - Full combined table (static + behavioural via the adapter): `run-all`.
- Machine-readable rows: `checks.json` (same IDs; includes source-scenario traceability and neobank overlaps).

## The draft inventory: 4 static + 7 behavioural = 11 checks

| ID | Layer | Deterministic | Invariant (one line) | Covers (automation point · common failure · regulation) |
| --- | --- | --- | --- | --- |
| **UCC4A-SEC-01** | behavioural | yes | A wire is released only when the customer's full agreed security procedure is satisfied, with each step logged; bypass attempts and MFA-provider outages block release. | Security procedures · missing procedure · UCC Article 4A |
| **UCC4A-SEC-51** | static | yes | Wire release requires all security-procedure step records for the customer's agreement; MFA-provider errors block. | backstop for UCC4A-SEC-01 · Security procedures · missing procedure · UCC Article 4A |
| **UCC4A-SEC-02** | behavioural | yes | At/above the configured dual-control threshold a second, distinct approver is required — one approver cannot satisfy both controls concurrently. | Security procedures · missing procedure · UCC Article 4A |
| **UCC4A-SEC-52** | static | yes | Dual-control checks approver1 ≠ approver2 at or above the threshold read from config. | backstop for UCC4A-SEC-02 · Security procedures · missing procedure · UCC Article 4A |
| **UCC4A-SEC-03** | static | yes | Wire capability (incl. a new channel) is disabled in config until an agreed security procedure is recorded. | Security procedures / Error detection · missing procedure · UCC Article 4A |
| **UCC4A-WIRE-01** | behavioural | yes | A wire is sent exactly once: duplicate submissions and concurrent identical orders release one; network timeouts reconcile status before retry. | Wire transfers / Error detection · Unauthorized wire · UCC Article 4A |
| **UCC4A-WIRE-51** | static | yes | Wire submission requires an idempotency key; network-timeout handling queries status before any resend. | backstop for UCC4A-WIRE-01 · Wire transfers / Error detection · Unauthorized wire · UCC Article 4A |
| **UCC4A-WIRE-02** | behavioural | yes | An authorised wire executes with correct details and ledger debit; wires to sanctioned beneficiaries are held, and failed callbacks hold and alert. | Wire transfers · Unauthorized wire · UCC Article 4A |
| **UCC4A-WIRE-03** | behavioural | yes | Execution date follows the configured cutoff time. | Wire transfers · general control (no source failure) · UCC Article 4A |
| **UCC4A-ERR-01** | behavioural | yes | Amount/beneficiary name-account mismatches and duplicates within the configured window are flagged before release, with decisions logged. | Error detection · Unauthorized wire · UCC Article 4A |
| **UCC4A-ERR-02** | behavioural | yes | An erroneous wire's recall and refund (plus configured interest) post correctly and the ledger stays balanced. | Wire transfers / Error detection · Unauthorized wire · UCC Article 4A |

## Outside the harness: manual/evidence (3)

These items are not harness checks. Each reports `NOT_APPLICABLE` to the runner and needs an owner and evidence on a schedule.

| ID | Layer | Deterministic | Invariant (one line) | Covers (automation point · common failure · regulation) |
| --- | --- | --- | --- | --- |
| **UCC4A-SEC-04** | manual/evidence | no (manual) | Security procedure agreements are retained. | Security procedures · general control (no source failure) · UCC Article 4A |
| **UCC4A-WIRE-04** | manual/evidence | no (manual) | Wire messages are retained. | Wire transfers · general control (no source failure) · UCC Article 4A |
| **UCC4A-ERR-03** | manual/evidence | no (manual) | Wire and security-procedure evidence is retained. | Error detection · general control (no source failure) · UCC Article 4A |

### Determinism

Every harness row (static and behavioural) is drafted as deterministic. Static detectors, including backstops, are pure functions of the committed source/config/diff. Behavioural rules each run against a **fresh `reset()` MoneySystem** (no state leaks between rules), driven by a **controllable clock**; deadlines, windows, expiries and cadences are asserted by advancing that clock, never by wall-clock reads, and no randomness affects a verdict. External dependencies (vendors, registries, feeds) are faked inside the adapter, which is how fault-injection rows stay deterministic. Manual/evidence rows are not deterministic and are not gate checks.

### Coverage note

Converted from 24 AI-drafted source scenarios of `SK-UCC4A-001`; each source scenario maps to exactly one non-backstop row (see the appendix). Static backstops add no scenarios and trace through the check they back. The scenarios were merged into crisp invariants by automation point and failure mode, across categories (positive, negative, boundary, failure/recovery, concurrency/idempotency, retention/audit, common failure, core). Automation points covered: Wire transfers, Security procedures, Error detection. Source common failures: Unauthorized wire, missing procedure. Thresholds, windows and deadlines are *configured* parameters, not asserted statutory values. No regulation or citation was added beyond the source sheet.

### Overlap with the locked neobank playbook (19 checks)

| This check | Neobank check | Strength | Why |
| --- | --- | --- | --- |
| UCC4A-WIRE-01 | N-IDEMP-01 | same | one wire per order |
| UCC4A-WIRE-01 | N-ORDER-01 | related | reconcile external status before retry |
| UCC4A-WIRE-51 | N-IDEMP-01 | same | wire route gates on Idempotency-Key |
| UCC4A-WIRE-51 | N-ORDER-01 | related | status query before external resend |
| UCC4A-WIRE-02 | PARTY-SCREEN | related | sanctioned beneficiary held |
| UCC4A-ERR-02 | LEDGER-CONSERVE | related | recall/refund keeps ledger balanced |

`same` means the neobank check already enforces this invariant, so reuse it instead of re-implementing. `related` means the same defect class, but this check needs its own rule or preset.

### Review flags

- No SME-flagged rows. All rows still need compliance review.

## Appendix: traceability to source scenarios

| Check ID | Source scenario IDs | Categories merged |
| --- | --- | --- |
| UCC4A-SEC-01 | SC-UCC4A-001-01, SC-UCC4A-001-04, SC-UCC4A-001-16, SC-UCC4A-001-18 | Core, Failure/Recovery, Negative, Positive |
| UCC4A-SEC-51 | — (static backstop; traced via UCC4A-SEC-01) | — |
| UCC4A-SEC-02 | SC-UCC4A-001-17, SC-UCC4A-001-19 | Boundary/Edge, Concurrency/Idempotency |
| UCC4A-SEC-52 | — (static backstop; traced via UCC4A-SEC-02) | — |
| UCC4A-SEC-03 | SC-UCC4A-001-05, SC-UCC4A-001-24 | Common Failure |
| UCC4A-SEC-04 | SC-UCC4A-001-20 | Retention/Audit |
| UCC4A-WIRE-01 | SC-UCC4A-001-06, SC-UCC4A-001-13, SC-UCC4A-001-23, SC-UCC4A-001-02 | Concurrency/Idempotency, Core, Failure/Recovery |
| UCC4A-WIRE-51 | — (static backstop; traced via UCC4A-WIRE-01) | — |
| UCC4A-WIRE-02 | SC-UCC4A-001-11, SC-UCC4A-001-12, SC-UCC4A-001-15 | Common Failure, Negative, Positive |
| UCC4A-WIRE-03 | SC-UCC4A-001-07 | Boundary/Edge |
| UCC4A-WIRE-04 | SC-UCC4A-001-14 | Retention/Audit |
| UCC4A-ERR-01 | SC-UCC4A-001-08, SC-UCC4A-001-21, SC-UCC4A-001-22 | Boundary/Edge, Negative, Positive |
| UCC4A-ERR-02 | SC-UCC4A-001-03, SC-UCC4A-001-09 | Core, Failure/Recovery |
| UCC4A-ERR-03 | SC-UCC4A-001-10 | Retention/Audit |

# Helix review rules

Generated from `checks.json` (11 static and behavioural checks; manual/evidence items are not code-reviewable and are omitted). Severity is derived from the playbook priority (P2 -> LOW); Category MM marks money-movement checks. Rule text is the source invariant, unchanged; it is AI-drafted and needs compliance review.

## Rule UCC4A-SEC-01: A wire is released only when the customer's full agreed security procedure is satisfied, with eac...
Severity: LOW
Category: MM
Scenario: security-procedures
Requirement: MUST
Invariant: A wire is released only when the customer's full agreed security procedure is satisfied, with each step logged; bypass attempts and MFA-provider outages block release.

Source check `UCC4A-SEC-01` from `checks.json` (behavioural; deterministic: yes). Covers: Security procedures · missing procedure · UCC Article 4A. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-UCC-001.

## Rule UCC4A-SEC-51: Wire release requires all security-procedure step records for the customer's agreement
Severity: LOW
Category: MM
Scenario: security-procedures
Requirement: MUST
Invariant: Wire release requires all security-procedure step records for the customer's agreement; MFA-provider errors block.

Source check `UCC4A-SEC-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: Security procedures · missing procedure · UCC Article 4A. Backstop for UCC4A-SEC-01. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-UCC-001.

## Rule UCC4A-SEC-02: At/above the configured dual-control threshold a second, distinct approver is required — one appr...
Severity: LOW
Category: MM
Scenario: security-procedures
Requirement: MUST
Invariant: At/above the configured dual-control threshold a second, distinct approver is required — one approver cannot satisfy both controls concurrently.

Source check `UCC4A-SEC-02` from `checks.json` (behavioural; deterministic: yes). Covers: Security procedures · missing procedure · UCC Article 4A. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-UCC-001.

## Rule UCC4A-SEC-52: Dual-control checks approver1 ≠ approver2 at or above the threshold read from config
Severity: LOW
Category: MM
Scenario: security-procedures
Requirement: MUST
Invariant: Dual-control checks approver1 ≠ approver2 at or above the threshold read from config.

Source check `UCC4A-SEC-52` from `checks.json` (static, static backstop; deterministic: yes). Covers: Security procedures · missing procedure · UCC Article 4A. Backstop for UCC4A-SEC-02. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-UCC-001.

## Rule UCC4A-SEC-03: Wire capability (incl
Severity: LOW
Category: MM
Scenario: security-procedures
Requirement: MUST
Invariant: Wire capability (incl. a new channel) is disabled in config until an agreed security procedure is recorded.

Source check `UCC4A-SEC-03` from `checks.json` (static; deterministic: yes). Covers: Security procedures, Error detection · missing procedure · UCC Article 4A. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-UCC-001.

## Rule UCC4A-WIRE-01: A wire is sent exactly once
Severity: LOW
Category: MM
Scenario: wire-transfers
Requirement: MUST
Invariant: A wire is sent exactly once: duplicate submissions and concurrent identical orders release one; network timeouts reconcile status before retry.

Source check `UCC4A-WIRE-01` from `checks.json` (behavioural; deterministic: yes). Covers: Wire transfers, Error detection · Unauthorized wire · UCC Article 4A. Review status in source: Drafted (AI) – needs compliance review.

## Rule UCC4A-WIRE-51: Wire submission requires an idempotency key
Severity: LOW
Category: MM
Scenario: wire-transfers
Requirement: MUST
Invariant: Wire submission requires an idempotency key; network-timeout handling queries status before any resend.

Source check `UCC4A-WIRE-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: Wire transfers, Error detection · Unauthorized wire · UCC Article 4A. Backstop for UCC4A-WIRE-01. Review status in source: Drafted (AI) – needs compliance review.

## Rule UCC4A-WIRE-02: An authorised wire executes with correct details and ledger debit
Severity: LOW
Category: MM
Scenario: wire-transfers
Requirement: MUST
Invariant: An authorised wire executes with correct details and ledger debit; wires to sanctioned beneficiaries are held, and failed callbacks hold and alert.

Source check `UCC4A-WIRE-02` from `checks.json` (behavioural; deterministic: yes). Covers: Wire transfers · Unauthorized wire · UCC Article 4A. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-OFAC-001.

## Rule UCC4A-WIRE-03: Execution date follows the configured cutoff time
Severity: LOW
Category: MM
Scenario: wire-transfers
Requirement: MUST
Invariant: Execution date follows the configured cutoff time.

Source check `UCC4A-WIRE-03` from `checks.json` (behavioural; deterministic: yes). Covers: Wire transfers · None · UCC Article 4A. Review status in source: Drafted (AI) – needs compliance review.

## Rule UCC4A-ERR-01: Amount/beneficiary name-account mismatches and duplicates within the configured window are flagge...
Severity: LOW
Category: MM
Scenario: error-detection
Requirement: MUST
Invariant: Amount/beneficiary name-account mismatches and duplicates within the configured window are flagged before release, with decisions logged.

Source check `UCC4A-ERR-01` from `checks.json` (behavioural; deterministic: yes). Covers: Error detection · Unauthorized wire · UCC Article 4A. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-UCC-003.

## Rule UCC4A-ERR-02: An erroneous wire's recall and refund (plus configured interest) post correctly and the ledger st...
Severity: LOW
Category: MM
Scenario: wire-transfers
Requirement: MUST
Invariant: An erroneous wire's recall and refund (plus configured interest) post correctly and the ledger stays balanced.

Source check `UCC4A-ERR-02` from `checks.json` (behavioural; deterministic: yes). Covers: Wire transfers, Error detection · Unauthorized wire · UCC Article 4A. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-UCC-007.
