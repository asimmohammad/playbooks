---
helixPlaybookFormat: helix-playbook/0.1-proposal
playbookId: vigil-card-fraud-stolen
title: "Stolen Card Fraud Controls Assurance"
declaredVersion: 0.1.0
intent: draft
applicability:
  languages: [javascript, typescript]
  scenarios: [card-testing-velocity-incl-bin-attacks, verification-signals-avs-cvv-device-ip-geo, account-takeover-card-add, decisioning-limits-decline-codes, false-positive-review-release, fraud-reporting-chargebacks, reversal-refund-abuse-ledger, lost-stolen-block-propagation]
---
# Helix portable playbook — DRAFT manifest · Stolen Card Fraud Controls Assurance

> **DRAFT — not LOCKED.** Proposed Card-network fraud, reporting & chargeback rules (as configured) (Card Fraud) playbook built from 52 **inline AI-drafted scenarios** (not in the source sheet; see *Inline scenarios*): one runner, two layers, **45 harness checks (16 static, incl. 15 static backstops, + 29 behavioural)**, plus 2 manual/evidence items listed separately because neither layer can verify them. Every invariant, layer and determinism call is **AI-drafted (Helix) and needs compliance review**; 5 check(s) are **⚑ SME-flagged** and cannot gate until an SME/counsel supplies their parameter matrix. No detector or rule code exists yet. Before this manifest can be LOCKED, each row needs its detector/rule, a review, and a commit that adds the check alongside its row.

## Layers

- **static**: a repo-agnostic source scanner parameterised by a `VIGIL_FRD` preset (no app specifics in the detector). It reads source / SQL / config / IaC / git-diff, **fails CLOSED** on a match, and runs with **no adapter**, so it is the CI gate. *Static backstops* (IDs `-5x`) prove a supporting source invariant for a named behavioural check, the way N-CAP-01 / N-STATE-01 back neobank behaviour. They fire even when the adapter never drives that path. Backstops of ⚑ SME checks stay out of the gate.
- **behavioural**: a rule written once against the canonical `MoneySystem` interface (or a DRAFT extension surface in `adapters/`) and driven through the app adapter. Surfaces needed: **FraudDecisionSystem** (`adapters/fraud-decision.ts`), **CardAuthorizationSystem** (`adapters/card-authorization.ts`). Every behavioural row reports NOT_EXERCISED until an adapter implements its surface. It returns **CHECKED only when it actually drove the guard's path**.
- **manual/evidence**: organisational process, live-infrastructure, statistical or retention evidence that no source scan or adapter-driven rule can prove. These are **outside the harness**, report `NOT_APPLICABLE` to it, and are tracked as evidence tasks, never as passes.

## Verdicts

`CHECKED` the path ran and the guard held · `FINDING` the guard was violated · `NOT_APPLICABLE` the invariant cannot apply here (incl. every manual/evidence item) · `NOT_EXERCISED` (glyph `????`) the adapter did not drive the path, so nothing is proven. NOT_EXERCISED is **surfaced distinctly and never counted as a pass** (no fake coverage). A ⚑ SME check with no approved parameter matrix reports `NOT_EXERCISED`, never `CHECKED`.

## How to run

- **Not runnable yet**: this draft defines invariants only (no detector/rule code). The intended shape mirrors the neobank playbook:
  - CI gate (adapter-free, blocks on any static FINDING): `run-static` with preset `VIGIL_FRD`.
  - Full combined table (static + behavioural via the adapter): `run-all`.
- Machine-readable rows: `checks.json` (same IDs; includes source-scenario traceability and neobank overlaps).

## The draft inventory: 16 static + 29 behavioural = 45 checks

| ID | Layer | Deterministic | Invariant (one line) | Covers (automation point · common failure · regulation) |
| --- | --- | --- | --- | --- |
| **FRD-VEL-01** | behavioural | yes | Velocity limits fire at configured thresholds per source; windows roll on the controllable clock; configured merchant profiles apply without lifting per-card limits. | Card testing & velocity (incl. BIN attacks) · Card-testing or velocity attack not throttled · Card-network fraud, reporting & chargeback rules (as configured) |
| **FRD-VEL-52** | static | yes | Velocity thresholds and windows load from a single configured source; no threshold literals in rule code. | backstop for FRD-VEL-01 · Card testing & velocity (incl. BIN attacks) · Card-testing or velocity attack not throttled · Card-network fraud, reporting & chargeback rules (as configured) |
| **FRD-VEL-02** | behavioural | yes | Velocity counters are atomic: concurrent attempts never exceed the configured limit. | Card testing & velocity (incl. BIN attacks) · Card-testing or velocity attack not throttled · Card-network fraud, reporting & chargeback rules (as configured) |
| **FRD-VEL-51** | static | yes | Velocity counters are incremented atomically (or under lock) inside the decision transaction; no read-then-write. | backstop for FRD-VEL-02 · Card testing & velocity (incl. BIN attacks) · Card-testing or velocity attack not throttled · Card-network fraud, reporting & chargeback rules (as configured) |
| **FRD-VEL-03** | behavioural | yes | Sequential PAN enumeration within a BIN range is detected and blocked per the configured rule. | Card testing & velocity (incl. BIN attacks) · Card-testing or velocity attack not throttled · Card-network fraud, reporting & chargeback rules (as configured) |
| **FRD-VEL-04** | behavioural | yes ⚑ SME | Every configured velocity dimension (card, device, IP, merchant, BIN) is enforced at its configured threshold. | Card testing & velocity (incl. BIN attacks) · Card-testing or velocity attack not throttled · Card-network fraud, reporting & chargeback rules (as configured) |
| **FRD-SIG-01** | behavioural | yes | AVS/CVV results map through the configured action matrix; a mismatch is never treated as a match; unknown codes fail closed. | Verification signals (AVS / CVV / device / IP / geo) · Mismatch signals ignored or sensitive verification data retained · Card-network fraud, reporting & chargeback rules (as configured) |
| **FRD-SIG-51** | static | yes | The AVS/CVV action mapping has an explicit default branch that declines or reviews; no default-approve. | backstop for FRD-SIG-01 · Verification signals (AVS / CVV / device / IP / geo) · Mismatch signals ignored or sensitive verification data retained · Card-network fraud, reporting & chargeback rules (as configured) |
| **FRD-SIG-02** | behavioural | yes | Device/IP/geo anomaly rules are deterministic, and a vendor outage applies the configured elevated-risk fallback, never "no risk". | Verification signals (AVS / CVV / device / IP / geo) · Mismatch signals ignored or sensitive verification data retained · Card-network fraud, reporting & chargeback rules (as configured) |
| **FRD-SIG-03** | static | yes | CVV never reaches persistent storage, logs or the fraud feature store. | Verification signals (AVS / CVV / device / IP / geo) · Mismatch signals ignored or sensitive verification data retained · Card-network fraud, reporting & chargeback rules (as configured) |
| **FRD-ATO-01** | behavioural | yes | A card add inside the configured cooling window after a credential/contact change needs step-up or is held, evaluated against post-change state even under concurrency. | Account takeover & card-add · Card added or used after account takeover · Card-network fraud, reporting & chargeback rules (as configured) |
| **FRD-ATO-51** | static | yes | The card-add handler reads the last credential/contact change from the locked account row before deciding. | backstop for FRD-ATO-01 · Account takeover & card-add · Card added or used after account takeover · Card-network fraud, reporting & chargeback rules (as configured) |
| **FRD-ATO-02** | behavioural | yes | The ATO chain (new device → credential reset → card add → high-value purchase) is flagged and the purchase declined or held. | Account takeover & card-add · Card added or used after account takeover · Card-network fraud, reporting & chargeback rules (as configured) |
| **FRD-ATO-03** | behavioural | yes | ATO-relevant events are audited with timestamps and no PAN/CVV. | Account takeover & card-add · general control (no source failure) · Card-network fraud, reporting & chargeback rules (as configured) |
| **FRD-DEC-01** | behavioural | yes | First transaction on a new card above the configured first-use limit is declined or stepped up. | Decisioning, limits & decline codes · Non-deterministic or unreproducible fraud decision · Card-network fraud, reporting & chargeback rules (as configured) |
| **FRD-DEC-02** | behavioural | yes ⚑ SME | High-risk MCC limits follow the configured MCC table. | Decisioning, limits & decline codes · Non-deterministic or unreproducible fraud decision · Card-network fraud, reporting & chargeback rules (as configured) |
| **FRD-DEC-03** | behavioural | yes | Fraud decisions are reproducible: replay with pinned rule/model versions and clock gives the same outcome/score/reasons; each record carries versions and snapshot hash; threshold comparison is deterministic. | Decisioning, limits & decline codes · Non-deterministic or unreproducible fraud decision · Card-network fraud, reporting & chargeback rules (as configured) |
| **FRD-DEC-51** | static | yes | Fraud decision code reads time only from the injected clock, has no unseeded randomness, and writes rule/model versions with every decision. | backstop for FRD-DEC-03 · Decisioning, limits & decline codes · Non-deterministic or unreproducible fraud decision · Card-network fraud, reporting & chargeback rules (as configured) |
| **FRD-DEC-04** | behavioural | yes | External decline responses use only the configured generic code table; internal fraud reasons never leak. | Decisioning, limits & decline codes · Decline response leaks fraud-signal detail · Card-network fraud, reporting & chargeback rules (as configured) |
| **FRD-DEC-52** | static | yes | External decline responses are built only from the configured generic code table; internal reason fields are not serialised into external responses. | backstop for FRD-DEC-04 · Decisioning, limits & decline codes · Decline response leaks fraud-signal detail · Card-network fraud, reporting & chargeback rules (as configured) |
| **FRD-DEC-05** | behavioural | yes | A model-service outage applies the configured rules-only fallback and flags the decision; never blanket approval. | Decisioning, limits & decline codes · Non-deterministic or unreproducible fraud decision · Card-network fraud, reporting & chargeback rules (as configured) |
| **FRD-DEC-53** | static | yes | The model-call catch/timeout branch routes to the rules-only fallback; no branch returns approve by default. | backstop for FRD-DEC-05 · Decisioning, limits & decline codes · Non-deterministic or unreproducible fraud decision · Card-network fraud, reporting & chargeback rules (as configured) |
| **FRD-DEC-06** | behavioural | yes | Decision logs are retained for the configured window then purged (controllable clock). | Decisioning, limits & decline codes · general control (no source failure) · Card-network fraud, reporting & chargeback rules (as configured) |
| **FRD-REL-01** | behavioural | yes | A hold is released only via an authenticated channel, and each release labels the decision false positive. | False-positive review & release · general control (no source failure) · Card-network fraud, reporting & chargeback rules (as configured) |
| **FRD-REL-02** | behavioural | yes | A hold reaches exactly one terminal state (release vs confirm-fraud race); after configured expiry a late release is rejected. | False-positive review & release · general control (no source failure) · Card-network fraud, reporting & chargeback rules (as configured) |
| **FRD-REL-51** | static | yes | Hold resolution is a locked compare-and-set from pending to a terminal state. | backstop for FRD-REL-02 · False-positive review & release · general control (no source failure) · Card-network fraud, reporting & chargeback rules (as configured) |
| **FRD-RPT-01** | behavioural | yes ⚑ SME | Each confirmed fraud yields one report record in the configured network schema (e.g. TC40/SAFE as configured) within the configured deadline. | Fraud reporting & chargebacks · Fraud not reported, reported twice, or miscoded · Card-network fraud, reporting & chargeback rules (as configured) |
| **FRD-RPT-02** | behavioural | yes | Fraud reports are submitted exactly once per transaction and type, with failures retried without loss or duplication. | Fraud reporting & chargebacks · Fraud not reported, reported twice, or miscoded · Card-network fraud, reporting & chargeback rules (as configured) |
| **FRD-RPT-51** | static | yes | The fraud report table has a unique key on (transaction id, report type) and submission is gated on it. | backstop for FRD-RPT-02 · Fraud reporting & chargebacks · Fraud not reported, reported twice, or miscoded · Card-network fraud, reporting & chargeback rules (as configured) |
| **FRD-RPT-03** | behavioural | yes | An unsubmitted report escalates at the configured deadline. | Fraud reporting & chargebacks · Fraud not reported, reported twice, or miscoded · Card-network fraud, reporting & chargeback rules (as configured) |
| **FRD-RPT-04** | behavioural | yes | Fraud case and chargeback evidence is retrievable for the configured retention window. | Fraud reporting & chargebacks · general control (no source failure) · Card-network fraud, reporting & chargeback rules (as configured) |
| **FRD-RPT-05** | behavioural | yes ⚑ SME | Fraud chargeback reason codes come from the configured network matrix. | Fraud reporting & chargebacks · Fraud not reported, reported twice, or miscoded · Card-network fraud, reporting & chargeback rules (as configured) |
| **FRD-REF-01** | behavioural | yes | Refunds go only to the original instrument (configured approved exception aside). | Reversal & refund abuse / ledger · Refund/reversal routed to a different card or over-credited · Card-network fraud, reporting & chargeback rules (as configured) |
| **FRD-REF-51** | static | yes | The refund destination is loaded from the original capture record; no request field selects the refund instrument. | backstop for FRD-REF-01 · Reversal & refund abuse / ledger · Refund/reversal routed to a different card or over-credited · Card-network fraud, reporting & chargeback rules (as configured) |
| **FRD-REF-02** | behavioural | yes | Cumulative refunds, reversals and chargebacks on one capture never exceed what was captured, including concurrently. | Reversal & refund abuse / ledger · Refund/reversal routed to a different card or over-credited · Card-network fraud, reporting & chargeback rules (as configured) |
| **FRD-REF-52** | static | yes | Cumulative recovered amount is read and checked against captured inside the refund/reversal transaction under a lock. | backstop for FRD-REF-02 · Reversal & refund abuse / ledger · Refund/reversal routed to a different card or over-credited · Card-network fraud, reporting & chargeback rules (as configured) |
| **FRD-LEDG-01** | behavioural | yes | Fraud reversals are atomic and keep trial balance 0 with every transaction balanced; the cardholder is credited once. | Reversal & refund abuse / ledger · Ledger imbalance after fraud reversal · Card-network fraud, reporting & chargeback rules (as configured) |
| **FRD-LEDG-51** | static | yes | Fraud reversals post only through the single balanced-posting path. | backstop for FRD-LEDG-01 · Reversal & refund abuse / ledger · Ledger imbalance after fraud reversal · Card-network fraud, reporting & chargeback rules (as configured) |
| **FRD-BLK-01** | behavioural | yes | A lost/stolen block suspends every linked token in one operation and every token's next authorization is declined; one audit record per token. | Lost / stolen block propagation · Lost/stolen block not propagated to every token · Card-network fraud, reporting & chargeback rules (as configured) |
| **FRD-BLK-51** | static | yes | A lost/stolen block updates every token linked to the PAN in the same transaction as the card status change. | backstop for FRD-BLK-01 · Lost / stolen block propagation · Lost/stolen block not propagated to every token · Card-network fraud, reporting & chargeback rules (as configured) |
| **FRD-BLK-02** | behavioural | yes | An authorization concurrent with a block is decided against the locked card state; no approval after the block commits. | Lost / stolen block propagation · Lost/stolen block not propagated to every token · Card-network fraud, reporting & chargeback rules (as configured) |
| **FRD-BLK-52** | static | yes | Authorization re-reads card/token status from the locked row and rejects blocked statuses. | backstop for FRD-BLK-02 · Lost / stolen block propagation · Lost/stolen block not propagated to every token · Card-network fraud, reporting & chargeback rules (as configured) |
| **FRD-BLK-03** | behavioural | yes | A TSP notification failure never weakens the local block; notification is retried and alerted. | Lost / stolen block propagation · Lost/stolen block not propagated to every token · Card-network fraud, reporting & chargeback rules (as configured) |
| **FRD-BLK-53** | static | yes | TSP notification is sent only after the block commits durably (outbox), never before. | backstop for FRD-BLK-03 · Lost / stolen block propagation · Lost/stolen block not propagated to every token · Card-network fraud, reporting & chargeback rules (as configured) |
| **FRD-BLK-04** | behavioural | yes | Reissue after lost/stolen keeps the old PAN's tokens blocked. | Lost / stolen block propagation · Lost/stolen block not propagated to every token · Card-network fraud, reporting & chargeback rules (as configured) |

## Outside the harness: manual/evidence (2)

These items are not harness checks. Each reports `NOT_APPLICABLE` to the runner and needs an owner and evidence on a schedule.

| ID | Layer | Deterministic | Invariant (one line) | Covers (automation point · common failure · regulation) |
| --- | --- | --- | --- | --- |
| **FRD-DEC-07** | manual/evidence | no (manual) | Model validation and drift monitoring are evidenced on the configured cadence. | Decisioning, limits & decline codes · Non-deterministic or unreproducible fraud decision · Card-network fraud, reporting & chargeback rules (as configured) |
| **FRD-RPT-06** | manual/evidence | no (manual) | Fraud losses are reconciled to submitted network reports each period with sign-off. | Fraud reporting & chargebacks · Fraud not reported, reported twice, or miscoded · Card-network fraud, reporting & chargeback rules (as configured) |

### Determinism

Every harness row (static and behavioural) is drafted as deterministic. Static detectors, including backstops, are pure functions of the committed source/config/diff. Behavioural rules each run against a **fresh `reset()` MoneySystem** (no state leaks between rules), driven by a **controllable clock**; deadlines, windows, expiries and cadences are asserted by advancing that clock, never by wall-clock reads, and no randomness affects a verdict. External dependencies (vendors, registries, feeds) are faked inside the adapter, which is how fault-injection rows stay deterministic. Manual/evidence rows are not deterministic and are not gate checks. ⚑ SME rows are deterministic once parameters exist, but are excluded from the gate until then.

### Coverage note

Built from 52 inline AI-drafted scenarios (`FRD-S-nnn`, listed below; not in the source sheet or the skills export); each inline scenario maps to exactly one non-backstop row (see the appendix). Static backstops add no scenarios and trace through the check they back. The scenarios were merged into crisp invariants by automation point and failure mode, across categories (positive, negative, boundary, failure/recovery, concurrency/idempotency, retention/audit, common failure, core). Automation points covered: Card testing & velocity (incl. BIN attacks), Verification signals (AVS / CVV / device / IP / geo), Account takeover & card-add, Decisioning, limits & decline codes, False-positive review & release, Fraud reporting & chargebacks, Reversal & refund abuse / ledger, Lost / stolen block propagation. Source common failures: Card-testing or velocity attack not throttled, Mismatch signals ignored or sensitive verification data retained, Card added or used after account takeover, Non-deterministic or unreproducible fraud decision, Decline response leaks fraud-signal detail, Fraud not reported, reported twice, or miscoded, Refund/reversal routed to a different card or over-credited, Lost/stolen block not propagated to every token, Ledger imbalance after fraud reversal. Thresholds, windows and deadlines are *configured* parameters, not asserted statutory values. No regulation or citation was added beyond the source sheet.

### Overlap with the locked neobank playbook (19 checks)

| This check | Neobank check | Strength | Why |
| --- | --- | --- | --- |
| FRD-VEL-02 | N-CAP-01 | related | velocity counter enforced atomically |
| FRD-VEL-02 | N-ATOMIC | related | concurrent attempts never exceed limit |
| FRD-VEL-51 | N-CAP-01 | related | counter enforced under lock in the txn |
| FRD-ATO-01 | N-STATE-01 | related | card add evaluated against current (post-change) subject state |
| FRD-ATO-51 | N-STATE-01 | same | re-read subject state from the LOCKED row |
| FRD-REL-02 | N-CAS-01 | related | one terminal hold decision |
| FRD-REL-51 | N-CAS-01 | same | locked compare-and-set on status |
| FRD-RPT-02 | N-IDEMP-01 | related | report submitted exactly once |
| FRD-RPT-51 | N-IDEMP-01 | related | unique-key dedupe on the write path |
| FRD-REF-02 | N-CHGBK-05 | same | cumulative recovery on one capture never exceeds captured |
| FRD-REF-52 | N-CAP-01 | related | cap read under lock |
| FRD-REF-52 | N-CHGBK-05 | related | static guard for cumulative recovery ≤ captured |
| FRD-LEDG-01 | LEDGER-CONSERVE | same | trial balance 0, every fraud reversal balanced |
| FRD-LEDG-01 | N-ATOMIC | related | no partial reversal posting |
| FRD-LEDG-51 | LEDGER-CONSERVE | related | single balanced-posting path |
| FRD-BLK-01 | N-STATE-01 | related | every token re-reads blocked status |
| FRD-BLK-02 | N-STATE-01 | related | auth re-reads state from locked row |
| FRD-BLK-02 | N-ATOMIC | related | block vs auth race |
| FRD-BLK-52 | N-STATE-01 | same | money op re-reads subject state from the LOCKED row and rejects blocked subjects |
| FRD-BLK-03 | N-ORDER-01 | related | durable block before external TSP call |
| FRD-BLK-53 | N-ORDER-01 | same | durable commit before irreversible external call |
| FRD-BLK-04 | N-SCHED-01 | related | card state survives reissue (block, here, rather than scheduled start) |

`same` means the neobank check already enforces this invariant, so reuse it instead of re-implementing. `related` means the same defect class, but this check needs its own rule or preset.

### Review flags

- ⚑ **FRD-VEL-04**: needs an SME/counsel parameter matrix (source scenarios carry review status "+ SME input").
- ⚑ **FRD-DEC-02**: needs an SME/counsel parameter matrix (source scenarios carry review status "+ SME input").
- ⚑ **FRD-DEC-07**: needs an SME/counsel parameter matrix (source scenarios carry review status "+ SME input").
- ⚑ **FRD-RPT-01**: needs an SME/counsel parameter matrix (source scenarios carry review status "+ SME input").
- ⚑ **FRD-RPT-05**: needs an SME/counsel parameter matrix (source scenarios carry review status "+ SME input").

## Inline scenarios (52, AI-drafted)

Generated for this playbook because the source sheet has no rows for it. Each scenario maps to exactly one check (see the appendix). ⚑ marks scenarios that need SME input on network rules or thresholds.

| Scenario | Category | Automation point | Title | Steps | Expected result | SME |
| --- | --- | --- | --- | --- | --- | --- |
| FRD-S-001 | Core | Card testing & velocity (incl. BIN attacks) | Card-testing from one source is throttled | Drive many low-value authorizations on distinct PANs from one device/IP/merchant inside the configured window. | At the configured threshold further attempts are declined or challenged; counters keyed by source; alert raised. |  |
| FRD-S-002 | Boundary/Edge | Card testing & velocity (incl. BIN attacks) | Velocity threshold boundary and window roll | Drive attempts exactly at the threshold, one over, then advance the clock past the window. | At-threshold behaviour per configuration; over-threshold blocked; the window roll resets deterministically. |  |
| FRD-S-003 | Concurrency/Idempotency | Card testing & velocity (incl. BIN attacks) | Concurrent attempts cannot exceed the velocity limit | Fire concurrent attempts at the limit. | Counters are atomic; no more than the configured number pass. |  |
| FRD-S-004 | Negative | Card testing & velocity (incl. BIN attacks) | BIN attack enumeration detected | Sequential PANs in one BIN range with varied expiry/CVV. | Pattern detected per configured rule; attempts blocked; BIN-level alert. |  |
| FRD-S-005 | Common Failure | Card testing & velocity (incl. BIN attacks) | Every configured velocity dimension enforced | Exercise card, device, IP, merchant and BIN dimensions. | All configured dimensions apply at their configured thresholds (threshold values need SME input). | ⚑ |
| FRD-S-006 | Positive | Card testing & velocity (incl. BIN attacks) | Configured high-frequency merchant profile not falsely throttled | Drive normal volume for a merchant with a configured profile. | Profile thresholds apply; no false block; per-card limits still apply. |  |
| FRD-S-007 | Core | Verification signals (AVS / CVV / device / IP / geo) | AVS/CVV results follow the configured action matrix | Drive each AVS and CVV result code. | Action (approve/decline/review) comes from the configured matrix; unknown codes decline or review. |  |
| FRD-S-008 | Negative | Verification signals (AVS / CVV / device / IP / geo) | CVV mismatch never treated as matched | Return a CVV mismatch. | Not treated as a match and not downgraded to "not checked". |  |
| FRD-S-009 | Boundary/Edge | Verification signals (AVS / CVV / device / IP / geo) | Partial AVS matches | Return postal-only and street-only matches. | Mapped deterministically per configuration. |  |
| FRD-S-010 | Core | Verification signals (AVS / CVV / device / IP / geo) | Device/IP/geo anomaly rules are deterministic | Fixed device, IP geolocated far from billing, and impossible travel (advance clock between authorizations). | Anomaly flags raised per configured rules; same inputs give the same decision. |  |
| FRD-S-011 | Failure/Recovery | Verification signals (AVS / CVV / device / IP / geo) | Device/geo vendor outage | Inject a vendor timeout. | Configured fallback (e.g. elevated risk) applies; never silently "no risk". |  |
| FRD-S-012 | Common Failure | Verification signals (AVS / CVV / device / IP / geo) | CVV not stored or logged after use | Authorize with CVV; scan stores, logs and the feature store. | CVV absent everywhere after authorization. |  |
| FRD-S-013 | Core | Account takeover & card-add | Card add after credential change is held | Change password/email/phone, then add a card inside the configured cooling window. | Card add requires step-up or is held for the configured window. |  |
| FRD-S-014 | Negative | Account takeover & card-add | ATO chain flagged | New device, credential reset, card add and high-value purchase in sequence. | ATO rule triggers; the purchase is declined or held; account locked per policy. |  |
| FRD-S-015 | Boundary/Edge | Account takeover & card-add | Cooling window boundary | Advance clock to exactly the window edge and one tick past. | Deterministic decision at the boundary. |  |
| FRD-S-016 | Concurrency/Idempotency | Account takeover & card-add | Card-add racing a credential change | Fire card add and credential change concurrently. | Card add is evaluated against the post-change state; no bypass. |  |
| FRD-S-017 | Positive | Account takeover & card-add | Card add with successful step-up | Pass step-up during the window. | Card added; event audited. |  |
| FRD-S-018 | Retention/Audit | Account takeover & card-add | ATO audit trail | Run the ATO chain. | Credential change, device, card add and decisions recorded with timestamps; no PAN/CVV. |  |
| FRD-S-019 | Core | Decisioning, limits & decline codes | First-use limit on a new card | First transaction on a newly issued/added card above and below the configured first-use limit. | Above the limit declined or stepped up; below it allowed. |  |
| FRD-S-020 | Boundary/Edge | Decisioning, limits & decline codes | High-risk MCC limits | Drive authorizations at the limit for MCCs in the configured table. | Limits per configured table (MCC list and limits need SME input). | ⚑ |
| FRD-S-021 | Core | Decisioning, limits & decline codes | Decisions reproducible with fixed clock and pinned versions | Replay the same inputs with the same rule-set/model version and clock. | Identical outcome, score and reason codes. |  |
| FRD-S-022 | Negative | Decisioning, limits & decline codes | Decline codes don't leak fraud signals | Trigger a fraud decline. | External response uses the configured generic code; internal reasons appear only internally. |  |
| FRD-S-023 | Failure/Recovery | Decisioning, limits & decline codes | Model service outage | Inject a model timeout. | Configured rules-only fallback; decision recorded with a fallback flag; never blanket approval. |  |
| FRD-S-024 | Common Failure | Decisioning, limits & decline codes | Decision record carries versions | Make a decision. | Record holds rule-set version, model version, feature snapshot hash and clock time. |  |
| FRD-S-025 | Retention/Audit | Decisioning, limits & decline codes | Decision log retention | Advance clock past the configured retention. | Retained within the window, purged after. |  |
| FRD-S-026 | Boundary/Edge | Decisioning, limits & decline codes | Score exactly at threshold | Produce a score equal to the configured threshold. | Deterministic per configured comparison. |  |
| FRD-S-027 | Core | False-positive review & release | False-positive release via authenticated channel | Cardholder confirms legitimacy in the authenticated app. | Hold released; card usable; audited. |  |
| FRD-S-028 | Negative | False-positive review & release | Release from an unauthenticated channel ignored | Spoofed SMS reply or unauthenticated API call. | No release. |  |
| FRD-S-029 | Concurrency/Idempotency | False-positive review & release | Release racing confirm-fraud | Fire release and confirm-fraud concurrently. | One terminal decision; no reopen. |  |
| FRD-S-030 | Failure/Recovery | False-positive review & release | Release after hold expiry | Advance clock past the configured hold expiry, then release. | Configured terminal action applied; late release rejected. |  |
| FRD-S-031 | Positive | False-positive review & release | Released decision labelled false positive | Release a hold. | False-positive label linked to the decision for rule/model feedback. |  |
| FRD-S-032 | Core | Fraud reporting & chargebacks | Confirmed fraud reported in the configured network schema | Confirm fraud on an authorization. | One report record per confirmed fraud with configured fields (e.g. TC40/SAFE as configured) within the configured deadline. | ⚑ |
| FRD-S-033 | Concurrency/Idempotency | Fraud reporting & chargebacks | Fraud report submitted exactly once | Confirm fraud twice and retry submission. | One submission per transaction and report type. |  |
| FRD-S-034 | Boundary/Edge | Fraud reporting & chargebacks | Reporting deadline boundary | Advance clock to the configured deadline without submission. | Escalation at the configured deadline. |  |
| FRD-S-035 | Failure/Recovery | Fraud reporting & chargebacks | Report submission failure retried | Inject submission failure. | Queued and retried; no loss; no duplicate. |  |
| FRD-S-036 | Retention/Audit | Fraud reporting & chargebacks | Fraud case and chargeback evidence retained | Advance clock across the configured retention. | Evidence retrievable within the window. |  |
| FRD-S-037 | Common Failure | Fraud reporting & chargebacks | Fraud chargeback reason code selection | Open a fraud chargeback. | Reason code from the configured network matrix. | ⚑ |
| FRD-S-038 | Core | Reversal & refund abuse / ledger | Refund only to the original instrument | Request a refund to a different card. | Rejected (or configured exception with approval); refund routes to the original card/token. |  |
| FRD-S-039 | Negative | Reversal & refund abuse / ledger | Refund above captured refused | Refund more than captured minus prior refunds. | Refused. |  |
| FRD-S-040 | Concurrency/Idempotency | Reversal & refund abuse / ledger | Concurrent refunds/reversals cannot exceed captured | Fire concurrent refunds and a reversal. | Total recovered ≤ captured. |  |
| FRD-S-041 | Core | Reversal & refund abuse / ledger | Ledger conservation on fraud reversal | Reverse a fraudulent captured transaction with chargeback and provisional credit. | Trial balance 0; every transaction balanced; cardholder credited once. |  |
| FRD-S-042 | Common Failure | Reversal & refund abuse / ledger | Merchant refund plus chargeback double credit | Refund and chargeback on the same capture. | Cardholder net credit ≤ captured; second credit blocked. |  |
| FRD-S-043 | Failure/Recovery | Reversal & refund abuse / ledger | Reversal fails mid-posting | Inject failure during reversal posting. | No partial posting; retry completes atomically. |  |
| FRD-S-044 | Core | Lost / stolen block propagation | Lost/stolen block reaches every token | Report a card lost with device and card-on-file tokens provisioned. | All linked tokens suspended in one operation; next authorization on any token declined. |  |
| FRD-S-045 | Negative | Lost / stolen block propagation | Network-token authorization after block declined | Authorize via a network token after the PAN block. | Declined. |  |
| FRD-S-046 | Concurrency/Idempotency | Lost / stolen block propagation | Authorization in flight during a block | Fire an authorization and the block concurrently. | After the block commits, no new approvals; the in-flight auth is decided against locked state. |  |
| FRD-S-047 | Failure/Recovery | Lost / stolen block propagation | Token service provider notification failure | Inject TSP failure during a block. | Local block still enforced; notification retried; alert raised. |  |
| FRD-S-048 | Boundary/Edge | Lost / stolen block propagation | Reissue after lost/stolen | Reissue the card. | Old PAN tokens stay blocked; token lifecycle per configuration. |  |
| FRD-S-049 | Retention/Audit | Lost / stolen block propagation | Block events audited per token | Block a card. | One audit record per affected token. |  |
| FRD-S-050 | Retention/Audit | Decisioning, limits & decline codes | Model governance evidence | Review model validation and drift monitoring evidence. | Validation and drift reviews completed on configured cadence with sign-off. | ⚑ |
| FRD-S-051 | Core | Fraud reporting & chargebacks | Fraud losses reconciled to network reports | Periodic reconciliation. | Fraud loss ledger reconciled to submitted network reports each period with sign-off. |  |
| FRD-S-052 | Positive | Verification signals (AVS / CVV / device / IP / geo) | Full AVS/CVV match on low-risk authorization approves | Full match, normal device, normal amount. | Approved per configuration with no friction. |  |

## Appendix: traceability to source scenarios

| Check ID | Source scenario IDs | Categories merged |
| --- | --- | --- |
| FRD-VEL-01 | FRD-S-001, FRD-S-002, FRD-S-006 | Boundary/Edge, Core, Positive |
| FRD-VEL-52 | — (static backstop; traced via FRD-VEL-01) | — |
| FRD-VEL-02 | FRD-S-003 | Concurrency/Idempotency |
| FRD-VEL-51 | — (static backstop; traced via FRD-VEL-02) | — |
| FRD-VEL-03 | FRD-S-004 | Negative |
| FRD-VEL-04 | FRD-S-005 | Common Failure |
| FRD-SIG-01 | FRD-S-007, FRD-S-008, FRD-S-009, FRD-S-052 | Boundary/Edge, Core, Negative, Positive |
| FRD-SIG-51 | — (static backstop; traced via FRD-SIG-01) | — |
| FRD-SIG-02 | FRD-S-010, FRD-S-011 | Core, Failure/Recovery |
| FRD-SIG-03 | FRD-S-012 | Common Failure |
| FRD-ATO-01 | FRD-S-013, FRD-S-015, FRD-S-016, FRD-S-017 | Boundary/Edge, Concurrency/Idempotency, Core, Positive |
| FRD-ATO-51 | — (static backstop; traced via FRD-ATO-01) | — |
| FRD-ATO-02 | FRD-S-014 | Negative |
| FRD-ATO-03 | FRD-S-018 | Retention/Audit |
| FRD-DEC-01 | FRD-S-019 | Core |
| FRD-DEC-02 | FRD-S-020 | Boundary/Edge |
| FRD-DEC-03 | FRD-S-021, FRD-S-024, FRD-S-026 | Boundary/Edge, Common Failure, Core |
| FRD-DEC-51 | — (static backstop; traced via FRD-DEC-03) | — |
| FRD-DEC-04 | FRD-S-022 | Negative |
| FRD-DEC-52 | — (static backstop; traced via FRD-DEC-04) | — |
| FRD-DEC-05 | FRD-S-023 | Failure/Recovery |
| FRD-DEC-53 | — (static backstop; traced via FRD-DEC-05) | — |
| FRD-DEC-06 | FRD-S-025 | Retention/Audit |
| FRD-DEC-07 | FRD-S-050 | Retention/Audit |
| FRD-REL-01 | FRD-S-027, FRD-S-028, FRD-S-031 | Core, Negative, Positive |
| FRD-REL-02 | FRD-S-029, FRD-S-030 | Concurrency/Idempotency, Failure/Recovery |
| FRD-REL-51 | — (static backstop; traced via FRD-REL-02) | — |
| FRD-RPT-01 | FRD-S-032 | Core |
| FRD-RPT-02 | FRD-S-033, FRD-S-035 | Concurrency/Idempotency, Failure/Recovery |
| FRD-RPT-51 | — (static backstop; traced via FRD-RPT-02) | — |
| FRD-RPT-03 | FRD-S-034 | Boundary/Edge |
| FRD-RPT-04 | FRD-S-036 | Retention/Audit |
| FRD-RPT-05 | FRD-S-037 | Common Failure |
| FRD-RPT-06 | FRD-S-051 | Core |
| FRD-REF-01 | FRD-S-038 | Core |
| FRD-REF-51 | — (static backstop; traced via FRD-REF-01) | — |
| FRD-REF-02 | FRD-S-039, FRD-S-040, FRD-S-042 | Common Failure, Concurrency/Idempotency, Negative |
| FRD-REF-52 | — (static backstop; traced via FRD-REF-02) | — |
| FRD-LEDG-01 | FRD-S-041, FRD-S-043 | Core, Failure/Recovery |
| FRD-LEDG-51 | — (static backstop; traced via FRD-LEDG-01) | — |
| FRD-BLK-01 | FRD-S-044, FRD-S-045, FRD-S-049 | Core, Negative, Retention/Audit |
| FRD-BLK-51 | — (static backstop; traced via FRD-BLK-01) | — |
| FRD-BLK-02 | FRD-S-046 | Concurrency/Idempotency |
| FRD-BLK-52 | — (static backstop; traced via FRD-BLK-02) | — |
| FRD-BLK-03 | FRD-S-047 | Failure/Recovery |
| FRD-BLK-53 | — (static backstop; traced via FRD-BLK-03) | — |
| FRD-BLK-04 | FRD-S-048 | Boundary/Edge |

# Helix review rules

Generated from `checks.json` (45 static and behavioural checks; manual/evidence items are not code-reviewable and are omitted). Severity is derived from the playbook priority (P0 -> HIGH); Category MM marks money-movement checks. Rule text is the source invariant, unchanged; it is AI-drafted and needs compliance review.

## Rule FRD-VEL-01: Velocity limits fire at configured thresholds per source
Severity: HIGH
Category: MM
Scenario: card-testing-velocity-incl-bin-attacks
Requirement: MUST
Invariant: Velocity limits fire at configured thresholds per source; windows roll on the controllable clock; configured merchant profiles apply without lifting per-card limits.

Source check `FRD-VEL-01` from `checks.json` (behavioural; deterministic: yes). Covers: Card testing & velocity (incl. BIN attacks) · Card-testing or velocity attack not throttled · Card-network fraud, reporting & chargeback rules (as configured). Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-CARD-015.

## Rule FRD-VEL-52: Velocity thresholds and windows load from a single configured source
Severity: HIGH
Category: MM
Scenario: card-testing-velocity-incl-bin-attacks
Requirement: MUST
Invariant: Velocity thresholds and windows load from a single configured source; no threshold literals in rule code.

Source check `FRD-VEL-52` from `checks.json` (static, static backstop; deterministic: yes). Covers: Card testing & velocity (incl. BIN attacks) · Card-testing or velocity attack not throttled · Card-network fraud, reporting & chargeback rules (as configured). Backstop for FRD-VEL-01. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-CARD-015.

## Rule FRD-VEL-02: Velocity counters are atomic
Severity: HIGH
Category: MM
Scenario: card-testing-velocity-incl-bin-attacks
Requirement: MUST
Invariant: Velocity counters are atomic: concurrent attempts never exceed the configured limit.

Source check `FRD-VEL-02` from `checks.json` (behavioural; deterministic: yes). Covers: Card testing & velocity (incl. BIN attacks) · Card-testing or velocity attack not throttled · Card-network fraud, reporting & chargeback rules (as configured). Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-CARD-015.

## Rule FRD-VEL-51: Velocity counters are incremented atomically (or under lock) inside the decision transaction
Severity: HIGH
Category: MM
Scenario: card-testing-velocity-incl-bin-attacks
Requirement: MUST
Invariant: Velocity counters are incremented atomically (or under lock) inside the decision transaction; no read-then-write.

Source check `FRD-VEL-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: Card testing & velocity (incl. BIN attacks) · Card-testing or velocity attack not throttled · Card-network fraud, reporting & chargeback rules (as configured). Backstop for FRD-VEL-02. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-CARD-015.

## Rule FRD-VEL-03: Sequential PAN enumeration within a BIN range is detected and blocked per the configured rule
Severity: HIGH
Category: MM
Scenario: card-testing-velocity-incl-bin-attacks
Requirement: MUST
Invariant: Sequential PAN enumeration within a BIN range is detected and blocked per the configured rule.

Source check `FRD-VEL-03` from `checks.json` (behavioural; deterministic: yes). Covers: Card testing & velocity (incl. BIN attacks) · Card-testing or velocity attack not throttled · Card-network fraud, reporting & chargeback rules (as configured). Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-CARD-015.

## Rule FRD-VEL-04: Every configured velocity dimension (card, device, IP, merchant, BIN) is enforced at its configur...
Severity: HIGH
Category: MM
Scenario: card-testing-velocity-incl-bin-attacks
Requirement: MUST
Invariant: Every configured velocity dimension (card, device, IP, merchant, BIN) is enforced at its configured threshold.

Source check `FRD-VEL-04` from `checks.json` (behavioural; deterministic: yes). Covers: Card testing & velocity (incl. BIN attacks) · Card-testing or velocity attack not throttled · Card-network fraud, reporting & chargeback rules (as configured). Flagged for SME input in the source; needs an approved parameter matrix. Review status in source: Drafted (AI) – needs compliance review + SME input.

Regulation references: RR-CARD-015.

## Rule FRD-SIG-01: AVS/CVV results map through the configured action matrix
Severity: HIGH
Category: MM
Scenario: verification-signals-avs-cvv-device-ip-geo
Requirement: MUST
Invariant: AVS/CVV results map through the configured action matrix; a mismatch is never treated as a match; unknown codes fail closed.

Source check `FRD-SIG-01` from `checks.json` (behavioural; deterministic: yes). Covers: Verification signals (AVS / CVV / device / IP / geo) · Mismatch signals ignored or sensitive verification data retained · Card-network fraud, reporting & chargeback rules (as configured). Review status in source: Drafted (AI) – needs compliance review.

## Rule FRD-SIG-51: The AVS/CVV action mapping has an explicit default branch that declines or reviews
Severity: HIGH
Category: MM
Scenario: verification-signals-avs-cvv-device-ip-geo
Requirement: MUST
Invariant: The AVS/CVV action mapping has an explicit default branch that declines or reviews; no default-approve.

Source check `FRD-SIG-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: Verification signals (AVS / CVV / device / IP / geo) · Mismatch signals ignored or sensitive verification data retained · Card-network fraud, reporting & chargeback rules (as configured). Backstop for FRD-SIG-01. Review status in source: Drafted (AI) – needs compliance review.

## Rule FRD-SIG-02: Device/IP/geo anomaly rules are deterministic, and a vendor outage applies the configured elevate...
Severity: HIGH
Category: MM
Scenario: verification-signals-avs-cvv-device-ip-geo
Requirement: MUST
Invariant: Device/IP/geo anomaly rules are deterministic, and a vendor outage applies the configured elevated-risk fallback, never "no risk".

Source check `FRD-SIG-02` from `checks.json` (behavioural; deterministic: yes). Covers: Verification signals (AVS / CVV / device / IP / geo) · Mismatch signals ignored or sensitive verification data retained · Card-network fraud, reporting & chargeback rules (as configured). Review status in source: Drafted (AI) – needs compliance review.

## Rule FRD-SIG-03: CVV never reaches persistent storage, logs or the fraud feature store
Severity: HIGH
Category: MM
Scenario: verification-signals-avs-cvv-device-ip-geo
Requirement: MUST
Invariant: CVV never reaches persistent storage, logs or the fraud feature store.

Source check `FRD-SIG-03` from `checks.json` (static; deterministic: yes). Covers: Verification signals (AVS / CVV / device / IP / geo) · Mismatch signals ignored or sensitive verification data retained · Card-network fraud, reporting & chargeback rules (as configured). Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-PCI-001.

## Rule FRD-ATO-01: A card add inside the configured cooling window after a credential/contact change needs step-up o...
Severity: HIGH
Category: MM
Scenario: account-takeover-card-add
Requirement: MUST
Invariant: A card add inside the configured cooling window after a credential/contact change needs step-up or is held, evaluated against post-change state even under concurrency.

Source check `FRD-ATO-01` from `checks.json` (behavioural; deterministic: yes). Covers: Account takeover & card-add · Card added or used after account takeover · Card-network fraud, reporting & chargeback rules (as configured). Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-FCRA-004, RR-FFIEC-002.

## Rule FRD-ATO-51: The card-add handler reads the last credential/contact change from the locked account row before...
Severity: HIGH
Category: MM
Scenario: account-takeover-card-add
Requirement: MUST
Invariant: The card-add handler reads the last credential/contact change from the locked account row before deciding.

Source check `FRD-ATO-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: Account takeover & card-add · Card added or used after account takeover · Card-network fraud, reporting & chargeback rules (as configured). Backstop for FRD-ATO-01. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-FCRA-004, RR-FFIEC-002.

## Rule FRD-ATO-02: The ATO chain (new device → credential reset → card add → high-value purchase) is flagged and the...
Severity: HIGH
Category: MM
Scenario: account-takeover-card-add
Requirement: MUST
Invariant: The ATO chain (new device → credential reset → card add → high-value purchase) is flagged and the purchase declined or held.

Source check `FRD-ATO-02` from `checks.json` (behavioural; deterministic: yes). Covers: Account takeover & card-add · Card added or used after account takeover · Card-network fraud, reporting & chargeback rules (as configured). Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-FCRA-004, RR-FFIEC-002.

## Rule FRD-ATO-03: ATO-relevant events are audited with timestamps and no PAN/CVV
Severity: HIGH
Category: MM
Scenario: account-takeover-card-add
Requirement: MUST
Invariant: ATO-relevant events are audited with timestamps and no PAN/CVV.

Source check `FRD-ATO-03` from `checks.json` (behavioural; deterministic: yes). Covers: Account takeover & card-add · None · Card-network fraud, reporting & chargeback rules (as configured). Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-PCI-001.

## Rule FRD-DEC-01: First transaction on a new card above the configured first-use limit is declined or stepped up
Severity: HIGH
Category: MM
Scenario: decisioning-limits-decline-codes
Requirement: MUST
Invariant: First transaction on a new card above the configured first-use limit is declined or stepped up.

Source check `FRD-DEC-01` from `checks.json` (behavioural; deterministic: yes). Covers: Decisioning, limits & decline codes · Non-deterministic or unreproducible fraud decision · Card-network fraud, reporting & chargeback rules (as configured). Review status in source: Drafted (AI) – needs compliance review.

## Rule FRD-DEC-02: High-risk MCC limits follow the configured MCC table
Severity: HIGH
Category: MM
Scenario: decisioning-limits-decline-codes
Requirement: MUST
Invariant: High-risk MCC limits follow the configured MCC table.

Source check `FRD-DEC-02` from `checks.json` (behavioural; deterministic: yes). Covers: Decisioning, limits & decline codes · Non-deterministic or unreproducible fraud decision · Card-network fraud, reporting & chargeback rules (as configured). Flagged for SME input in the source; needs an approved parameter matrix. Review status in source: Drafted (AI) – needs compliance review + SME input.

## Rule FRD-DEC-03: Fraud decisions are reproducible
Severity: HIGH
Category: MM
Scenario: decisioning-limits-decline-codes
Requirement: MUST
Invariant: Fraud decisions are reproducible: replay with pinned rule/model versions and clock gives the same outcome/score/reasons; each record carries versions and snapshot hash; threshold comparison is deterministic.

Source check `FRD-DEC-03` from `checks.json` (behavioural; deterministic: yes). Covers: Decisioning, limits & decline codes · Non-deterministic or unreproducible fraud decision · Card-network fraud, reporting & chargeback rules (as configured). Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-MRM-001.

## Rule FRD-DEC-51: Fraud decision code reads time only from the injected clock, has no unseeded randomness, and writ...
Severity: HIGH
Category: MM
Scenario: decisioning-limits-decline-codes
Requirement: MUST
Invariant: Fraud decision code reads time only from the injected clock, has no unseeded randomness, and writes rule/model versions with every decision.

Source check `FRD-DEC-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: Decisioning, limits & decline codes · Non-deterministic or unreproducible fraud decision · Card-network fraud, reporting & chargeback rules (as configured). Backstop for FRD-DEC-03. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-MRM-001.

## Rule FRD-DEC-04: External decline responses use only the configured generic code table
Severity: HIGH
Category: MM
Scenario: decisioning-limits-decline-codes
Requirement: MUST
Invariant: External decline responses use only the configured generic code table; internal fraud reasons never leak.

Source check `FRD-DEC-04` from `checks.json` (behavioural; deterministic: yes). Covers: Decisioning, limits & decline codes · Decline response leaks fraud-signal detail · Card-network fraud, reporting & chargeback rules (as configured). Review status in source: Drafted (AI) – needs compliance review.

## Rule FRD-DEC-52: External decline responses are built only from the configured generic code table
Severity: HIGH
Category: MM
Scenario: decisioning-limits-decline-codes
Requirement: MUST
Invariant: External decline responses are built only from the configured generic code table; internal reason fields are not serialised into external responses.

Source check `FRD-DEC-52` from `checks.json` (static, static backstop; deterministic: yes). Covers: Decisioning, limits & decline codes · Decline response leaks fraud-signal detail · Card-network fraud, reporting & chargeback rules (as configured). Backstop for FRD-DEC-04. Review status in source: Drafted (AI) – needs compliance review.

## Rule FRD-DEC-05: A model-service outage applies the configured rules-only fallback and flags the decision
Severity: HIGH
Category: MM
Scenario: decisioning-limits-decline-codes
Requirement: MUST
Invariant: A model-service outage applies the configured rules-only fallback and flags the decision; never blanket approval.

Source check `FRD-DEC-05` from `checks.json` (behavioural; deterministic: yes). Covers: Decisioning, limits & decline codes · Non-deterministic or unreproducible fraud decision · Card-network fraud, reporting & chargeback rules (as configured). Review status in source: Drafted (AI) – needs compliance review.

## Rule FRD-DEC-53: The model-call catch/timeout branch routes to the rules-only fallback
Severity: HIGH
Category: MM
Scenario: decisioning-limits-decline-codes
Requirement: MUST
Invariant: The model-call catch/timeout branch routes to the rules-only fallback; no branch returns approve by default.

Source check `FRD-DEC-53` from `checks.json` (static, static backstop; deterministic: yes). Covers: Decisioning, limits & decline codes · Non-deterministic or unreproducible fraud decision · Card-network fraud, reporting & chargeback rules (as configured). Backstop for FRD-DEC-05. Review status in source: Drafted (AI) – needs compliance review.

## Rule FRD-DEC-06: Decision logs are retained for the configured window then purged (controllable clock)
Severity: HIGH
Category: MM
Scenario: decisioning-limits-decline-codes
Requirement: MUST
Invariant: Decision logs are retained for the configured window then purged (controllable clock).

Source check `FRD-DEC-06` from `checks.json` (behavioural; deterministic: yes). Covers: Decisioning, limits & decline codes · None · Card-network fraud, reporting & chargeback rules (as configured). Review status in source: Drafted (AI) – needs compliance review.

## Rule FRD-REL-01: A hold is released only via an authenticated channel, and each release labels the decision false...
Severity: HIGH
Category: MM
Scenario: false-positive-review-release
Requirement: MUST
Invariant: A hold is released only via an authenticated channel, and each release labels the decision false positive.

Source check `FRD-REL-01` from `checks.json` (behavioural; deterministic: yes). Covers: False-positive review & release · None · Card-network fraud, reporting & chargeback rules (as configured). Review status in source: Drafted (AI) – needs compliance review.

## Rule FRD-REL-02: A hold reaches exactly one terminal state (release vs confirm-fraud race)
Severity: HIGH
Category: MM
Scenario: false-positive-review-release
Requirement: MUST
Invariant: A hold reaches exactly one terminal state (release vs confirm-fraud race); after configured expiry a late release is rejected.

Source check `FRD-REL-02` from `checks.json` (behavioural; deterministic: yes). Covers: False-positive review & release · None · Card-network fraud, reporting & chargeback rules (as configured). Review status in source: Drafted (AI) – needs compliance review.

## Rule FRD-REL-51: Hold resolution is a locked compare-and-set from pending to a terminal state
Severity: HIGH
Category: MM
Scenario: false-positive-review-release
Requirement: MUST
Invariant: Hold resolution is a locked compare-and-set from pending to a terminal state.

Source check `FRD-REL-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: False-positive review & release · None · Card-network fraud, reporting & chargeback rules (as configured). Backstop for FRD-REL-02. Review status in source: Drafted (AI) – needs compliance review.

## Rule FRD-RPT-01: Each confirmed fraud yields one report record in the configured network schema (e.g
Severity: HIGH
Category: MM
Scenario: fraud-reporting-chargebacks
Requirement: MUST
Invariant: Each confirmed fraud yields one report record in the configured network schema (e.g. TC40/SAFE as configured) within the configured deadline.

Source check `FRD-RPT-01` from `checks.json` (behavioural; deterministic: yes). Covers: Fraud reporting & chargebacks · Fraud not reported, reported twice, or miscoded · Card-network fraud, reporting & chargeback rules (as configured). Flagged for SME input in the source; needs an approved parameter matrix. Review status in source: Drafted (AI) – needs compliance review + SME input.

Regulation references: RR-CARD-015.

## Rule FRD-RPT-02: Fraud reports are submitted exactly once per transaction and type, with failures retried without...
Severity: HIGH
Category: MM
Scenario: fraud-reporting-chargebacks
Requirement: MUST
Invariant: Fraud reports are submitted exactly once per transaction and type, with failures retried without loss or duplication.

Source check `FRD-RPT-02` from `checks.json` (behavioural; deterministic: yes). Covers: Fraud reporting & chargebacks · Fraud not reported, reported twice, or miscoded · Card-network fraud, reporting & chargeback rules (as configured). Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-CARD-015.

## Rule FRD-RPT-51: The fraud report table has a unique key on (transaction id, report type) and submission is gated...
Severity: HIGH
Category: MM
Scenario: fraud-reporting-chargebacks
Requirement: MUST
Invariant: The fraud report table has a unique key on (transaction id, report type) and submission is gated on it.

Source check `FRD-RPT-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: Fraud reporting & chargebacks · Fraud not reported, reported twice, or miscoded · Card-network fraud, reporting & chargeback rules (as configured). Backstop for FRD-RPT-02. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-CARD-015.

## Rule FRD-RPT-03: An unsubmitted report escalates at the configured deadline
Severity: HIGH
Category: MM
Scenario: fraud-reporting-chargebacks
Requirement: MUST
Invariant: An unsubmitted report escalates at the configured deadline.

Source check `FRD-RPT-03` from `checks.json` (behavioural; deterministic: yes). Covers: Fraud reporting & chargebacks · Fraud not reported, reported twice, or miscoded · Card-network fraud, reporting & chargeback rules (as configured). Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-CARD-015.

## Rule FRD-RPT-04: Fraud case and chargeback evidence is retrievable for the configured retention window
Severity: HIGH
Category: MM
Scenario: fraud-reporting-chargebacks
Requirement: MUST
Invariant: Fraud case and chargeback evidence is retrievable for the configured retention window.

Source check `FRD-RPT-04` from `checks.json` (behavioural; deterministic: yes). Covers: Fraud reporting & chargebacks · None · Card-network fraud, reporting & chargeback rules (as configured). Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-CARD-004.

## Rule FRD-RPT-05: Fraud chargeback reason codes come from the configured network matrix
Severity: HIGH
Category: MM
Scenario: fraud-reporting-chargebacks
Requirement: MUST
Invariant: Fraud chargeback reason codes come from the configured network matrix.

Source check `FRD-RPT-05` from `checks.json` (behavioural; deterministic: yes). Covers: Fraud reporting & chargebacks · Fraud not reported, reported twice, or miscoded · Card-network fraud, reporting & chargeback rules (as configured). Flagged for SME input in the source; needs an approved parameter matrix. Review status in source: Drafted (AI) – needs compliance review + SME input.

Regulation references: RR-CARD-004.

## Rule FRD-REF-01: Refunds go only to the original instrument (configured approved exception aside)
Severity: HIGH
Category: MM
Scenario: reversal-refund-abuse-ledger
Requirement: MUST
Invariant: Refunds go only to the original instrument (configured approved exception aside).

Source check `FRD-REF-01` from `checks.json` (behavioural; deterministic: yes). Covers: Reversal & refund abuse / ledger · Refund/reversal routed to a different card or over-credited · Card-network fraud, reporting & chargeback rules (as configured). Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-CARD-001, RR-CARD-002.

## Rule FRD-REF-51: The refund destination is loaded from the original capture record
Severity: HIGH
Category: MM
Scenario: reversal-refund-abuse-ledger
Requirement: MUST
Invariant: The refund destination is loaded from the original capture record; no request field selects the refund instrument.

Source check `FRD-REF-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: Reversal & refund abuse / ledger · Refund/reversal routed to a different card or over-credited · Card-network fraud, reporting & chargeback rules (as configured). Backstop for FRD-REF-01. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-CARD-001, RR-CARD-002.

## Rule FRD-REF-02: Cumulative refunds, reversals and chargebacks on one capture never exceed what was captured, incl...
Severity: HIGH
Category: MM
Scenario: reversal-refund-abuse-ledger
Requirement: MUST
Invariant: Cumulative refunds, reversals and chargebacks on one capture never exceed what was captured, including concurrently.

Source check `FRD-REF-02` from `checks.json` (behavioural; deterministic: yes). Covers: Reversal & refund abuse / ledger · Refund/reversal routed to a different card or over-credited · Card-network fraud, reporting & chargeback rules (as configured). Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-CARD-001, RR-CARD-002.

## Rule FRD-REF-52: Cumulative recovered amount is read and checked against captured inside the refund/reversal trans...
Severity: HIGH
Category: MM
Scenario: reversal-refund-abuse-ledger
Requirement: MUST
Invariant: Cumulative recovered amount is read and checked against captured inside the refund/reversal transaction under a lock.

Source check `FRD-REF-52` from `checks.json` (static, static backstop; deterministic: yes). Covers: Reversal & refund abuse / ledger · Refund/reversal routed to a different card or over-credited · Card-network fraud, reporting & chargeback rules (as configured). Backstop for FRD-REF-02. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-CARD-001, RR-CARD-002.

## Rule FRD-LEDG-01: Fraud reversals are atomic and keep trial balance 0 with every transaction balanced
Severity: HIGH
Category: MM
Scenario: reversal-refund-abuse-ledger
Requirement: MUST
Invariant: Fraud reversals are atomic and keep trial balance 0 with every transaction balanced; the cardholder is credited once.

Source check `FRD-LEDG-01` from `checks.json` (behavioural; deterministic: yes). Covers: Reversal & refund abuse / ledger · Ledger imbalance after fraud reversal · Card-network fraud, reporting & chargeback rules (as configured). Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-ACCT-001.

## Rule FRD-LEDG-51: Fraud reversals post only through the single balanced-posting path
Severity: HIGH
Category: MM
Scenario: reversal-refund-abuse-ledger
Requirement: MUST
Invariant: Fraud reversals post only through the single balanced-posting path.

Source check `FRD-LEDG-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: Reversal & refund abuse / ledger · Ledger imbalance after fraud reversal · Card-network fraud, reporting & chargeback rules (as configured). Backstop for FRD-LEDG-01. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-ACCT-001.

## Rule FRD-BLK-01: A lost/stolen block suspends every linked token in one operation and every token's next authoriza...
Severity: HIGH
Category: MM
Scenario: lost-stolen-block-propagation
Requirement: MUST
Invariant: A lost/stolen block suspends every linked token in one operation and every token's next authorization is declined; one audit record per token.

Source check `FRD-BLK-01` from `checks.json` (behavioural; deterministic: yes). Covers: Lost / stolen block propagation · Lost/stolen block not propagated to every token · Card-network fraud, reporting & chargeback rules (as configured). Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-CARD-006, RR-EMV-002.

## Rule FRD-BLK-51: A lost/stolen block updates every token linked to the PAN in the same transaction as the card sta...
Severity: HIGH
Category: MM
Scenario: lost-stolen-block-propagation
Requirement: MUST
Invariant: A lost/stolen block updates every token linked to the PAN in the same transaction as the card status change.

Source check `FRD-BLK-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: Lost / stolen block propagation · Lost/stolen block not propagated to every token · Card-network fraud, reporting & chargeback rules (as configured). Backstop for FRD-BLK-01. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-CARD-006, RR-EMV-002.

## Rule FRD-BLK-02: An authorization concurrent with a block is decided against the locked card state
Severity: HIGH
Category: MM
Scenario: lost-stolen-block-propagation
Requirement: MUST
Invariant: An authorization concurrent with a block is decided against the locked card state; no approval after the block commits.

Source check `FRD-BLK-02` from `checks.json` (behavioural; deterministic: yes). Covers: Lost / stolen block propagation · Lost/stolen block not propagated to every token · Card-network fraud, reporting & chargeback rules (as configured). Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-CARD-006, RR-REGE-002, RR-REGZ-002.

## Rule FRD-BLK-52: Authorization re-reads card/token status from the locked row and rejects blocked statuses
Severity: HIGH
Category: MM
Scenario: lost-stolen-block-propagation
Requirement: MUST
Invariant: Authorization re-reads card/token status from the locked row and rejects blocked statuses.

Source check `FRD-BLK-52` from `checks.json` (static, static backstop; deterministic: yes). Covers: Lost / stolen block propagation · Lost/stolen block not propagated to every token · Card-network fraud, reporting & chargeback rules (as configured). Backstop for FRD-BLK-02. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-CARD-006, RR-REGE-002, RR-REGZ-002.

## Rule FRD-BLK-03: A TSP notification failure never weakens the local block
Severity: HIGH
Category: MM
Scenario: lost-stolen-block-propagation
Requirement: MUST
Invariant: A TSP notification failure never weakens the local block; notification is retried and alerted.

Source check `FRD-BLK-03` from `checks.json` (behavioural; deterministic: yes). Covers: Lost / stolen block propagation · Lost/stolen block not propagated to every token · Card-network fraud, reporting & chargeback rules (as configured). Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-CARD-006, RR-EMV-002.

## Rule FRD-BLK-53: TSP notification is sent only after the block commits durably (outbox), never before
Severity: HIGH
Category: MM
Scenario: lost-stolen-block-propagation
Requirement: MUST
Invariant: TSP notification is sent only after the block commits durably (outbox), never before.

Source check `FRD-BLK-53` from `checks.json` (static, static backstop; deterministic: yes). Covers: Lost / stolen block propagation · Lost/stolen block not propagated to every token · Card-network fraud, reporting & chargeback rules (as configured). Backstop for FRD-BLK-03. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-CARD-006, RR-EMV-002.

## Rule FRD-BLK-04: Reissue after lost/stolen keeps the old PAN's tokens blocked
Severity: HIGH
Category: MM
Scenario: lost-stolen-block-propagation
Requirement: MUST
Invariant: Reissue after lost/stolen keeps the old PAN's tokens blocked.

Source check `FRD-BLK-04` from `checks.json` (behavioural; deterministic: yes). Covers: Lost / stolen block propagation · Lost/stolen block not propagated to every token · Card-network fraud, reporting & chargeback rules (as configured). Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-CARD-006, RR-EMV-002.
