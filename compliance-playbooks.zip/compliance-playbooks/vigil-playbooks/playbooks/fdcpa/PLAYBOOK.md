---
helixPlaybookFormat: helix-playbook/0.1-proposal
playbookId: vigil-fdcpa
title: "FDCPA Collections Communication Controls"
declaredVersion: 0.1.0
intent: draft
applicability:
  languages: [javascript, typescript]
  scenarios: [validation-notice, dispute-handling, communication-rules]
---
# Helix portable playbook — DRAFT manifest · FDCPA Collections Communication Controls

> **DRAFT — not LOCKED.** Proposed FDCPA (Debt Collection) playbook converted from Vigil skill `SK-FDCPA-001`: one runner, two layers, **10 harness checks (4 static, incl. 4 static backstops, + 6 behavioural)**, plus 3 manual/evidence items listed separately because neither layer can verify them. Every invariant, layer and determinism call is **AI-drafted (Helix) and needs compliance review**. No detector or rule code exists yet. Before this manifest can be LOCKED, each row needs its detector/rule, a review, and a commit that adds the check alongside its row.

## Layers

- **static**: a repo-agnostic source scanner parameterised by a `VIGIL_FDCPA` preset (no app specifics in the detector). It reads source / SQL / config / IaC / git-diff, **fails CLOSED** on a match, and runs with **no adapter**, so it is the CI gate. *Static backstops* (IDs `-5x`) prove a supporting source invariant for a named behavioural check, the way N-CAP-01 / N-STATE-01 back neobank behaviour. They fire even when the adapter never drives that path. Backstops of ⚑ SME checks stay out of the gate.
- **behavioural**: a rule written once against the canonical `MoneySystem` interface (or a DRAFT extension surface in `adapters/`) and driven through the app adapter. Surfaces needed: **CollectionsSystem** (`adapters/collections.ts`). Every behavioural row reports NOT_EXERCISED until an adapter implements its surface. It returns **CHECKED only when it actually drove the guard's path**.
- **manual/evidence**: organisational process, live-infrastructure, statistical or retention evidence that no source scan or adapter-driven rule can prove. These are **outside the harness**, report `NOT_APPLICABLE` to it, and are tracked as evidence tasks, never as passes.

## Verdicts

`CHECKED` the path ran and the guard held · `FINDING` the guard was violated · `NOT_APPLICABLE` the invariant cannot apply here (incl. every manual/evidence item) · `NOT_EXERCISED` (glyph `????`) the adapter did not drive the path, so nothing is proven. NOT_EXERCISED is **surfaced distinctly and never counted as a pass** (no fake coverage). A ⚑ SME check with no approved parameter matrix reports `NOT_EXERCISED`, never `CHECKED`.

## How to run

- **Not runnable yet**: this draft defines invariants only (no detector/rule code). The intended shape mirrors the neobank playbook:
  - CI gate (adapter-free, blocks on any static FINDING): `run-static` with preset `VIGIL_FDCPA`.
  - Full combined table (static + behavioural via the adapter): `run-all`.
- Machine-readable rows: `checks.json` (same IDs; includes source-scenario traceability and neobank overlaps).

## The draft inventory: 4 static + 6 behavioural = 10 checks

| ID | Layer | Deterministic | Invariant (one line) | Covers (automation point · common failure · regulation) |
| --- | --- | --- | --- | --- |
| **FDCPA-VN-01** | behavioural | yes | A validation notice with all required fields, itemisation reconciling exactly to the ledger balance, is sent once within the configured window after initial communication. | Validation notice · Missing notice · FDCPA |
| **FDCPA-VN-02** | behavioural | yes | Collection activity halts until the validation notice is sent; undeliverable notices are recorded and re-sent per policy. | Validation notice · Missing notice · FDCPA |
| **FDCPA-VN-51** | static | yes | Collection outreach paths check the validation-notice-sent flag before contacting. | backstop for FDCPA-VN-02 · Validation notice · Missing notice · FDCPA |
| **FDCPA-DSP-01** | behavioural | yes | A timely dispute from any channel — incl. during a channel outage and at the validation-period boundary — opens one case and pauses collection until verification is sent. | Dispute handling · general control (no source failure) · FDCPA |
| **FDCPA-DSP-51** | static | yes | Every dispute intake channel writes through the single dispute-case creator that sets the collection-pause flag. | backstop for FDCPA-DSP-01 · Dispute handling · general control (no source failure) · FDCPA |
| **FDCPA-DSP-02** | behavioural | yes | A disputed account is furnished with the dispute indicator per the configured mapping. | Dispute handling · general control (no source failure) · FDCPA |
| **FDCPA-COM-01** | behavioural | yes | No contact after a cease request (except permitted notices), to attorney-represented consumers, or outside the configured window in the consumer's time zone. | Communication rules · improper contact · FDCPA |
| **FDCPA-COM-52** | static | yes | The send path checks cease/attorney-representation flags and the consumer-timezone window before every contact. | backstop for FDCPA-COM-01 · Communication rules · improper contact · FDCPA |
| **FDCPA-COM-02** | behavioural | yes | Combined contact attempts across all channels/dialers stay within the configured frequency cap, including after a scheduler outage (no burst on recovery). | Communication rules · improper contact · FDCPA |
| **FDCPA-COM-51** | static | yes | Contact-frequency counters are shared across all channels/dialers (single counter store) and checked in the send path. | backstop for FDCPA-COM-02 · Communication rules · improper contact · FDCPA |

## Outside the harness: manual/evidence (3)

These items are not harness checks. Each reports `NOT_APPLICABLE` to the runner and needs an owner and evidence on a schedule.

| ID | Layer | Deterministic | Invariant (one line) | Covers (automation point · common failure · regulation) |
| --- | --- | --- | --- | --- |
| **FDCPA-VN-03** | manual/evidence | no (manual) | Validation notices and delivery proof are retained. | Validation notice · general control (no source failure) · FDCPA |
| **FDCPA-DSP-03** | manual/evidence | no (manual) | Dispute and verification records are retained. | Dispute handling · general control (no source failure) · FDCPA |
| **FDCPA-COM-03** | manual/evidence | no (manual) | All communications are retained with time, channel and content/recording. | Communication rules · general control (no source failure) · FDCPA |

### Determinism

Every harness row (static and behavioural) is drafted as deterministic. Static detectors, including backstops, are pure functions of the committed source/config/diff. Behavioural rules each run against a **fresh `reset()` MoneySystem** (no state leaks between rules), driven by a **controllable clock**; deadlines, windows, expiries and cadences are asserted by advancing that clock, never by wall-clock reads, and no randomness affects a verdict. External dependencies (vendors, registries, feeds) are faked inside the adapter, which is how fault-injection rows stay deterministic. Manual/evidence rows are not deterministic and are not gate checks.

### Coverage note

Converted from 24 AI-drafted source scenarios of `SK-FDCPA-001`; each source scenario maps to exactly one non-backstop row (see the appendix). Static backstops add no scenarios and trace through the check they back. The scenarios were merged into crisp invariants by automation point and failure mode, across categories (positive, negative, boundary, failure/recovery, concurrency/idempotency, retention/audit, common failure, core). Automation points covered: Validation notice, Dispute handling, Communication rules. Source common failures: Missing notice, improper contact. Thresholds, windows and deadlines are *configured* parameters, not asserted statutory values. No regulation or citation was added beyond the source sheet.

### Overlap with the locked neobank playbook (19 checks)

None. This playbook's invariants are not covered by the neobank set.

### Review flags

- No SME-flagged rows. All rows still need compliance review.

## Appendix: traceability to source scenarios

| Check ID | Source scenario IDs | Categories merged |
| --- | --- | --- |
| FDCPA-VN-01 | SC-FDCPA-001-01, SC-FDCPA-001-04, SC-FDCPA-001-05, SC-FDCPA-001-16, SC-FDCPA-001-14 | Boundary/Edge, Common Failure, Concurrency/Idempotency, Core, Positive |
| FDCPA-VN-02 | SC-FDCPA-001-13, SC-FDCPA-001-06 | Failure/Recovery, Negative |
| FDCPA-VN-51 | — (static backstop; traced via FDCPA-VN-02) | — |
| FDCPA-VN-03 | SC-FDCPA-001-15 | Retention/Audit |
| FDCPA-DSP-01 | SC-FDCPA-001-02, SC-FDCPA-001-07, SC-FDCPA-001-08, SC-FDCPA-001-17, SC-FDCPA-001-18, SC-FDCPA-001-19 | Boundary/Edge, Concurrency/Idempotency, Core, Failure/Recovery, Negative, Positive |
| FDCPA-DSP-51 | — (static backstop; traced via FDCPA-DSP-01) | — |
| FDCPA-DSP-02 | SC-FDCPA-001-21 | Common Failure |
| FDCPA-DSP-03 | SC-FDCPA-001-20 | Retention/Audit |
| FDCPA-COM-01 | SC-FDCPA-001-03, SC-FDCPA-001-11, SC-FDCPA-001-09, SC-FDCPA-001-22 | Boundary/Edge, Core, Negative, Positive |
| FDCPA-COM-52 | — (static backstop; traced via FDCPA-COM-01) | — |
| FDCPA-COM-02 | SC-FDCPA-001-10, SC-FDCPA-001-24, SC-FDCPA-001-23 | Common Failure, Concurrency/Idempotency, Failure/Recovery |
| FDCPA-COM-51 | — (static backstop; traced via FDCPA-COM-02) | — |
| FDCPA-COM-03 | SC-FDCPA-001-12 | Retention/Audit |

# Helix review rules

Generated from `checks.json` (10 static and behavioural checks; manual/evidence items are not code-reviewable and are omitted). Severity is derived from the playbook priority (P2 -> LOW); Category MM marks money-movement checks. Rule text is the source invariant, unchanged; it is AI-drafted and needs compliance review.

## Rule FDCPA-VN-01: A validation notice with all required fields, itemisation reconciling exactly to the ledger balan...
Severity: LOW
Category: NON_MM
Scenario: validation-notice
Requirement: MUST
Invariant: A validation notice with all required fields, itemisation reconciling exactly to the ledger balance, is sent once within the configured window after initial communication.

Source check `FDCPA-VN-01` from `checks.json` (behavioural; deterministic: yes). Covers: Validation notice · Missing notice · FDCPA. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-REGF-003.

## Rule FDCPA-VN-02: Collection activity halts until the validation notice is sent
Severity: LOW
Category: NON_MM
Scenario: validation-notice
Requirement: MUST
Invariant: Collection activity halts until the validation notice is sent; undeliverable notices are recorded and re-sent per policy.

Source check `FDCPA-VN-02` from `checks.json` (behavioural; deterministic: yes). Covers: Validation notice · Missing notice · FDCPA. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-REGF-003.

## Rule FDCPA-VN-51: Collection outreach paths check the validation-notice-sent flag before contacting
Severity: LOW
Category: NON_MM
Scenario: validation-notice
Requirement: MUST
Invariant: Collection outreach paths check the validation-notice-sent flag before contacting.

Source check `FDCPA-VN-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: Validation notice · Missing notice · FDCPA. Backstop for FDCPA-VN-02. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-REGF-003.

## Rule FDCPA-DSP-01: A timely dispute from any channel — incl
Severity: LOW
Category: NON_MM
Scenario: dispute-handling
Requirement: MUST
Invariant: A timely dispute from any channel — incl. during a channel outage and at the validation-period boundary — opens one case and pauses collection until verification is sent.

Source check `FDCPA-DSP-01` from `checks.json` (behavioural; deterministic: yes). Covers: Dispute handling · None · FDCPA. Review status in source: Drafted (AI) – needs compliance review.

## Rule FDCPA-DSP-51: Every dispute intake channel writes through the single dispute-case creator that sets the collect...
Severity: LOW
Category: NON_MM
Scenario: dispute-handling
Requirement: MUST
Invariant: Every dispute intake channel writes through the single dispute-case creator that sets the collection-pause flag.

Source check `FDCPA-DSP-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: Dispute handling · None · FDCPA. Backstop for FDCPA-DSP-01. Review status in source: Drafted (AI) – needs compliance review.

## Rule FDCPA-DSP-02: A disputed account is furnished with the dispute indicator per the configured mapping
Severity: LOW
Category: NON_MM
Scenario: dispute-handling
Requirement: MUST
Invariant: A disputed account is furnished with the dispute indicator per the configured mapping.

Source check `FDCPA-DSP-02` from `checks.json` (behavioural; deterministic: yes). Covers: Dispute handling · None · FDCPA. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-FCRA-003, RR-CDIA-001.

## Rule FDCPA-COM-01: No contact after a cease request (except permitted notices), to attorney-represented consumers, o...
Severity: LOW
Category: NON_MM
Scenario: communication-rules
Requirement: MUST
Invariant: No contact after a cease request (except permitted notices), to attorney-represented consumers, or outside the configured window in the consumer's time zone.

Source check `FDCPA-COM-01` from `checks.json` (behavioural; deterministic: yes). Covers: Communication rules · improper contact · FDCPA. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-REGF-002.

## Rule FDCPA-COM-52: The send path checks cease/attorney-representation flags and the consumer-timezone window before...
Severity: LOW
Category: NON_MM
Scenario: communication-rules
Requirement: MUST
Invariant: The send path checks cease/attorney-representation flags and the consumer-timezone window before every contact.

Source check `FDCPA-COM-52` from `checks.json` (static, static backstop; deterministic: yes). Covers: Communication rules · improper contact · FDCPA. Backstop for FDCPA-COM-01. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-REGF-002.

## Rule FDCPA-COM-02: Combined contact attempts across all channels/dialers stay within the configured frequency cap, i...
Severity: LOW
Category: NON_MM
Scenario: communication-rules
Requirement: MUST
Invariant: Combined contact attempts across all channels/dialers stay within the configured frequency cap, including after a scheduler outage (no burst on recovery).

Source check `FDCPA-COM-02` from `checks.json` (behavioural; deterministic: yes). Covers: Communication rules · improper contact · FDCPA. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-REGF-001.

## Rule FDCPA-COM-51: Contact-frequency counters are shared across all channels/dialers (single counter store) and chec...
Severity: LOW
Category: NON_MM
Scenario: communication-rules
Requirement: MUST
Invariant: Contact-frequency counters are shared across all channels/dialers (single counter store) and checked in the send path.

Source check `FDCPA-COM-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: Communication rules · improper contact · FDCPA. Backstop for FDCPA-COM-02. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-REGF-001.
