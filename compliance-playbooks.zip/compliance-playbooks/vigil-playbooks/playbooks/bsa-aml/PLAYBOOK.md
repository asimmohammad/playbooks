---
helixPlaybookFormat: helix-playbook/0.1-proposal
playbookId: vigil-bsa-aml
title: "BSA/AML KYC, Monitoring & SAR Assurance"
declaredVersion: 0.1.0
intent: draft
applicability:
  languages: [javascript, typescript]
  scenarios: [kyc, transaction-monitoring, sar-filing, ofac-screening]
---
# Helix portable playbook — DRAFT manifest · BSA/AML KYC, Monitoring & SAR Assurance

> **DRAFT — not LOCKED.** Proposed BSA/AML (Anti-Money Laundering) playbook converted from Vigil skill `SK-BSA-001`: one runner, two layers, **27 harness checks (8 static, incl. 7 static backstops, + 19 behavioural)**, plus 4 manual/evidence items listed separately because neither layer can verify them. Every invariant, layer and determinism call is **AI-drafted (Helix) and needs compliance review**. No detector or rule code exists yet. Before this manifest can be LOCKED, each row needs its detector/rule, a review, and a commit that adds the check alongside its row.

## Layers

- **static**: a repo-agnostic source scanner parameterised by a `VIGIL_BSA` preset (no app specifics in the detector). It reads source / SQL / config / IaC / git-diff, **fails CLOSED** on a match, and runs with **no adapter**, so it is the CI gate. *Static backstops* (IDs `-5x`) prove a supporting source invariant for a named behavioural check, the way N-CAP-01 / N-STATE-01 back neobank behaviour. They fire even when the adapter never drives that path. Backstops of ⚑ SME checks stay out of the gate.
- **behavioural**: a rule written once against the canonical `MoneySystem` interface (or a DRAFT extension surface in `adapters/`) and driven through the app adapter. Surfaces needed: **OnboardingSystem** (`adapters/onboarding.ts`), **ComplianceCaseSystem** (`adapters/compliance-cases.ts`), **ScreeningSystem** (`adapters/screening.ts`). Every behavioural row reports NOT_EXERCISED until an adapter implements its surface. It returns **CHECKED only when it actually drove the guard's path**.
- **manual/evidence**: organisational process, live-infrastructure, statistical or retention evidence that no source scan or adapter-driven rule can prove. These are **outside the harness**, report `NOT_APPLICABLE` to it, and are tracked as evidence tasks, never as passes.

## Verdicts

`CHECKED` the path ran and the guard held · `FINDING` the guard was violated · `NOT_APPLICABLE` the invariant cannot apply here (incl. every manual/evidence item) · `NOT_EXERCISED` (glyph `????`) the adapter did not drive the path, so nothing is proven. NOT_EXERCISED is **surfaced distinctly and never counted as a pass** (no fake coverage). A ⚑ SME check with no approved parameter matrix reports `NOT_EXERCISED`, never `CHECKED`.

## How to run

- **Not runnable yet**: this draft defines invariants only (no detector/rule code). The intended shape mirrors the neobank playbook:
  - CI gate (adapter-free, blocks on any static FINDING): `run-static` with preset `VIGIL_BSA`.
  - Full combined table (static + behavioural via the adapter): `run-all`.
- Machine-readable rows: `checks.json` (same IDs; includes source-scenario traceability and neobank overlaps).

## The draft inventory: 8 static + 19 behavioural = 27 checks

| ID | Layer | Deterministic | Invariant (one line) | Covers (automation point · common failure · regulation) |
| --- | --- | --- | --- | --- |
| **BSA-KYC-01** | static | yes | Every money-in/money-out rail and activation path gates on the actual party's KYC status — no rail bypasses the KYC gate. | KYC · incomplete KYC · BSA/AML |
| **BSA-KYC-02** | behavioural | yes | No account moves money before KYC approval; failed/mismatched identities route to review; a clean identity is approved, risk-rated and enabled. | KYC · incomplete KYC · BSA/AML |
| **BSA-KYC-03** | behavioural | yes | KYC vendor outage holds applications pending — never auto-approves — and retries on recovery. | KYC · incomplete KYC · BSA/AML |
| **BSA-KYC-51** | static | yes | KYC vendor error/timeout handling sets status 'pending' — no path sets 'approved' outside the decision handler. | backstop for BSA-KYC-03 · KYC · incomplete KYC · BSA/AML |
| **BSA-KYC-04** | behavioural | yes | Document-verification retries stop at the configured maximum and route to manual review/decline. | KYC · incomplete KYC · BSA/AML |
| **BSA-KYC-05** | behavioural | yes | Concurrent applications with one identity let at most one account proceed per configured policy. | KYC · incomplete KYC · BSA/AML |
| **BSA-KYC-06** | behavioural | yes | Configured high-risk profile changes trigger re-verification/hold before high-risk activity. | KYC · incomplete KYC · BSA/AML |
| **BSA-TM-01** | behavioural | yes | Monitoring completeness: count and value of ledger transactions equal those ingested by monitoring, for every money-movement type, including backlog replay after an outage. | Transaction monitoring · Missed SAR · BSA/AML |
| **BSA-TM-51** | static | yes | Every money-movement event type in the ledger enum is published to the monitoring stream (event-type registry ↔ producer coverage). | backstop for BSA-TM-01 · Transaction monitoring · Missed SAR · BSA/AML |
| **BSA-TM-02** | behavioural | yes | Each positive typology (structuring, pass-through, P2P funnel, velocity) yields exactly one alert with rule ID at the configured inclusive/exclusive boundary; benign controls do not alert. | Transaction monitoring · Missed SAR · BSA/AML |
| **BSA-TM-03** | behavioural | yes | Duplicate events never double-alert or inflate aggregated counts/amounts. | Transaction monitoring · Missed SAR · BSA/AML |
| **BSA-TM-04** | behavioural | yes | High-risk alerts are never auto-closed; closure needs rationale, reviewer and timestamp; aged alerts escalate. | Transaction monitoring · Missed SAR · BSA/AML |
| **BSA-TM-52** | static | yes | Alert auto-close/suppression rules exclude the high-risk rule set, and the close path requires non-null rationale and reviewer. | backstop for BSA-TM-04 · Transaction monitoring · Missed SAR · BSA/AML |
| **BSA-TM-05** | behavioural | yes | Aggregated cash activity above the configured threshold creates a currency-transaction reporting task. | Transaction monitoring · general control (no source failure) · BSA/AML |
| **BSA-SAR-01** | behavioural | yes | Every case reaches a filed/no-file decision with rationale before the configured deadline from immutable detection date; overdue escalates; continuing-activity review is scheduled. | SAR filing · Missed SAR · BSA/AML |
| **BSA-SAR-02** | behavioural | yes | A SAR cannot be submitted until required fields are complete; a case is not 'filed' until acknowledgement, and retry never duplicates a filing. | SAR filing · Missed SAR · BSA/AML |
| **BSA-SAR-03** | behavioural | yes | Two investigators cannot file duplicate SARs for one case. | SAR filing · Missed SAR · BSA/AML |
| **BSA-SAR-52** | static | yes | SAR filing state transition is a locked compare-and-set on the case row (unique filing per case). | backstop for BSA-SAR-03 · SAR filing · Missed SAR · BSA/AML |
| **BSA-SAR-04** | behavioural | yes | SAR existence is never revealed to the subject or to unauthorised staff roles. | SAR filing · Missed SAR · BSA/AML |
| **BSA-SAR-51** | static | yes | No customer-facing serializer, template or support-tool query exposes SAR/case tables or fields. | backstop for BSA-SAR-04 · SAR filing · Missed SAR · BSA/AML |
| **BSA-OFAC-01** | behavioural | yes | No account is activated or funded, and no new payee receives a first payment, until sanctions screening clears; true matches route to review. | OFAC screening · general control (no source failure) · BSA/AML |
| **BSA-OFAC-02** | behavioural | yes | Name/address changes and list updates trigger re-screening of existing customers within the configured window; new matches alert. | OFAC screening · general control (no source failure) · BSA/AML |
| **BSA-OFAC-52** | static | yes | Customer name/address update paths and list-ingest jobs enqueue a re-screen. | backstop for BSA-OFAC-02 · OFAC screening · general control (no source failure) · BSA/AML |
| **BSA-OFAC-03** | behavioural | yes | Fuzzy-match alerts fire exactly at the configured score threshold with score and algorithm version logged; false-positive suppressions expire and re-alert. | OFAC screening · general control (no source failure) · BSA/AML |
| **BSA-OFAC-04** | behavioural | yes | Screening service outage holds payments by default and screens them on recovery. | OFAC screening · general control (no source failure) · BSA/AML |
| **BSA-OFAC-51** | static | yes | Screening-service error/timeout handling sets payments to 'held' — no default-release branch. | backstop for BSA-OFAC-04 · OFAC screening · general control (no source failure) · BSA/AML |
| **BSA-OFAC-05** | behavioural | yes | Concurrent payouts are each screened exactly once before release. | OFAC screening · general control (no source failure) · BSA/AML |

## Outside the harness: manual/evidence (4)

These items are not harness checks. Each reports `NOT_APPLICABLE` to the runner and needs an owner and evidence on a schedule.

| ID | Layer | Deterministic | Invariant (one line) | Covers (automation point · common failure · regulation) |
| --- | --- | --- | --- | --- |
| **BSA-KYC-07** | manual/evidence | no (manual) | KYC evidence and funds-transfer records (originator, beneficiary, amount, date) are retained and retrievable for the configured period after closure. | KYC · general control (no source failure) · BSA/AML |
| **BSA-TM-06** | manual/evidence | no (manual) | Monitoring rule/threshold changes are backtested and cannot ship if they drop previously confirmed suspicious cases; rule versions and dispositions retained. | Transaction monitoring · Missed SAR · BSA/AML |
| **BSA-SAR-05** | manual/evidence | no (manual) | SAR copies and supporting documentation are retained with restricted access. | SAR filing · general control (no source failure) · BSA/AML |
| **BSA-OFAC-06** | manual/evidence | no (manual) | Screening results, dispositions and the list version used are retained and reproducible. | OFAC screening · general control (no source failure) · BSA/AML |

### Determinism

Every harness row (static and behavioural) is drafted as deterministic. Static detectors, including backstops, are pure functions of the committed source/config/diff. Behavioural rules each run against a **fresh `reset()` MoneySystem** (no state leaks between rules), driven by a **controllable clock**; deadlines, windows, expiries and cadences are asserted by advancing that clock, never by wall-clock reads, and no randomness affects a verdict. External dependencies (vendors, registries, feeds) are faked inside the adapter, which is how fault-injection rows stay deterministic. Manual/evidence rows are not deterministic and are not gate checks.

### Coverage note

Converted from 43 AI-drafted source scenarios of `SK-BSA-001`; each source scenario maps to exactly one non-backstop row (see the appendix). Static backstops add no scenarios and trace through the check they back. The scenarios were merged into crisp invariants by automation point and failure mode, across categories (positive, negative, boundary, failure/recovery, concurrency/idempotency, retention/audit, common failure, core). Automation points covered: KYC, Transaction monitoring, SAR filing, OFAC screening. Source common failures: Missed SAR, incomplete KYC. Thresholds, windows and deadlines are *configured* parameters, not asserted statutory values. No regulation or citation was added beyond the source sheet.

### Overlap with the locked neobank playbook (19 checks)

| This check | Neobank check | Strength | Why |
| --- | --- | --- | --- |
| BSA-KYC-01 | N-SCREEN-02 | same | every rail/activation gates on the actual party's KYC |
| BSA-KYC-02 | PARTY-SCREEN | same | un-KYC'd party never gets an active, money-moving account |
| BSA-KYC-05 | N-ATOMIC | related | concurrent applications, one proceeds |
| BSA-TM-01 | LEDGER-CONSERVE | related | monitoring population = ledger population |
| BSA-TM-03 | N-IDEMP-01 | related | duplicates never double-alert |
| BSA-SAR-03 | N-CAS-01 | related | single filing under race |
| BSA-SAR-52 | N-CAS-01 | same | locked compare-and-set on status |
| BSA-OFAC-01 | PARTY-SCREEN | same | sanctioned party never activated/funded |
| BSA-OFAC-02 | N-SCREEN-02 | related | re-screen on party change / list update |
| BSA-OFAC-52 | N-SCREEN-02 | related | re-screen on party change |
| BSA-OFAC-05 | N-IDEMP-01 | related | screened exactly once |

`same` means the neobank check already enforces this invariant, so reuse it instead of re-implementing. `related` means the same defect class, but this check needs its own rule or preset.

### Review flags

- No SME-flagged rows. All rows still need compliance review.

## Appendix: traceability to source scenarios

| Check ID | Source scenario IDs | Categories merged |
| --- | --- | --- |
| BSA-KYC-01 | SC-BSA-001-04 | Common Failure |
| BSA-KYC-02 | SC-BSA-001-01, SC-BSA-001-26 | Core, Positive |
| BSA-KYC-03 | SC-BSA-001-05 | Failure/Recovery |
| BSA-KYC-51 | — (static backstop; traced via BSA-KYC-03) | — |
| BSA-KYC-04 | SC-BSA-001-06 | Boundary/Edge |
| BSA-KYC-05 | SC-BSA-001-07 | Concurrency/Idempotency |
| BSA-KYC-06 | SC-BSA-001-08 | Negative |
| BSA-KYC-07 | SC-BSA-001-09, DR-BSA-001-10 | Core, Retention/Audit |
| BSA-TM-01 | DR-BSA-001-03, SC-BSA-001-12 | Core, Failure/Recovery |
| BSA-TM-51 | — (static backstop; traced via BSA-TM-01) | — |
| BSA-TM-02 | SC-BSA-001-02, DR-BSA-001-04, SC-BSA-001-10, SC-BSA-001-11, SC-BSA-001-14, SC-BSA-001-27 | Boundary/Edge, Core, Negative, Positive |
| BSA-TM-03 | SC-BSA-001-13 | Concurrency/Idempotency |
| BSA-TM-04 | SC-BSA-001-15, DR-BSA-001-05 | Common Failure, Core |
| BSA-TM-52 | — (static backstop; traced via BSA-TM-04) | — |
| BSA-TM-05 | DR-BSA-001-09 | Core |
| BSA-TM-06 | DR-BSA-001-08, SC-BSA-001-28 | Core, Retention/Audit |
| BSA-SAR-01 | SC-BSA-001-03, SC-BSA-001-17, DR-BSA-001-07 | Boundary/Edge, Core |
| BSA-SAR-02 | SC-BSA-001-16, SC-BSA-001-29, SC-BSA-001-19 | Failure/Recovery, Negative, Positive |
| BSA-SAR-03 | SC-BSA-001-30 | Concurrency/Idempotency |
| BSA-SAR-52 | — (static backstop; traced via BSA-SAR-03) | — |
| BSA-SAR-04 | DR-BSA-001-06, SC-BSA-001-31 | Common Failure, Core |
| BSA-SAR-51 | — (static backstop; traced via BSA-SAR-04) | — |
| BSA-SAR-05 | SC-BSA-001-18 | Retention/Audit |
| BSA-OFAC-01 | DR-BSA-001-01, SC-BSA-001-20 | Core, Positive |
| BSA-OFAC-02 | SC-BSA-001-21, DR-BSA-001-02, SC-BSA-001-33 | Common Failure, Core, Negative |
| BSA-OFAC-52 | — (static backstop; traced via BSA-OFAC-02) | — |
| BSA-OFAC-03 | SC-BSA-001-22, SC-BSA-001-24 | Boundary/Edge, Negative |
| BSA-OFAC-04 | SC-BSA-001-23 | Failure/Recovery |
| BSA-OFAC-51 | — (static backstop; traced via BSA-OFAC-04) | — |
| BSA-OFAC-05 | SC-BSA-001-32 | Concurrency/Idempotency |
| BSA-OFAC-06 | SC-BSA-001-25 | Retention/Audit |

# Helix review rules

Generated from `checks.json` (27 static and behavioural checks; manual/evidence items are not code-reviewable and are omitted). Severity is derived from the playbook priority (P0 -> HIGH); Category MM marks money-movement checks. Rule text is the source invariant, unchanged; it is AI-drafted and needs compliance review.

## Rule BSA-KYC-01: Every money-in/money-out rail and activation path gates on the actual party's KYC status — no rai...
Severity: HIGH
Category: MM
Scenario: kyc
Requirement: MUST
Invariant: Every money-in/money-out rail and activation path gates on the actual party's KYC status — no rail bypasses the KYC gate.

Source check `BSA-KYC-01` from `checks.json` (static; deterministic: yes). Covers: KYC · incomplete KYC · BSA/AML. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-AML-007, RR-AML-001.

## Rule BSA-KYC-02: No account moves money before KYC approval
Severity: HIGH
Category: MM
Scenario: kyc
Requirement: MUST
Invariant: No account moves money before KYC approval; failed/mismatched identities route to review; a clean identity is approved, risk-rated and enabled.

Source check `BSA-KYC-02` from `checks.json` (behavioural; deterministic: yes). Covers: KYC · incomplete KYC · BSA/AML. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-AML-007, RR-AML-001.

## Rule BSA-KYC-03: KYC vendor outage holds applications pending — never auto-approves — and retries on recovery
Severity: HIGH
Category: MM
Scenario: kyc
Requirement: MUST
Invariant: KYC vendor outage holds applications pending — never auto-approves — and retries on recovery.

Source check `BSA-KYC-03` from `checks.json` (behavioural; deterministic: yes). Covers: KYC · incomplete KYC · BSA/AML. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-AML-007.

## Rule BSA-KYC-51: KYC vendor error/timeout handling sets status 'pending' — no path sets 'approved' outside the dec...
Severity: HIGH
Category: MM
Scenario: kyc
Requirement: MUST
Invariant: KYC vendor error/timeout handling sets status 'pending' — no path sets 'approved' outside the decision handler.

Source check `BSA-KYC-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: KYC · incomplete KYC · BSA/AML. Backstop for BSA-KYC-03. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-AML-007.

## Rule BSA-KYC-04: Document-verification retries stop at the configured maximum and route to manual review/decline
Severity: HIGH
Category: MM
Scenario: kyc
Requirement: MUST
Invariant: Document-verification retries stop at the configured maximum and route to manual review/decline.

Source check `BSA-KYC-04` from `checks.json` (behavioural; deterministic: yes). Covers: KYC · incomplete KYC · BSA/AML. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-AML-007.

## Rule BSA-KYC-05: Concurrent applications with one identity let at most one account proceed per configured policy
Severity: HIGH
Category: MM
Scenario: kyc
Requirement: MUST
Invariant: Concurrent applications with one identity let at most one account proceed per configured policy.

Source check `BSA-KYC-05` from `checks.json` (behavioural; deterministic: yes). Covers: KYC · incomplete KYC · BSA/AML. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-AML-007.

## Rule BSA-KYC-06: Configured high-risk profile changes trigger re-verification/hold before high-risk activity
Severity: HIGH
Category: MM
Scenario: kyc
Requirement: MUST
Invariant: Configured high-risk profile changes trigger re-verification/hold before high-risk activity.

Source check `BSA-KYC-06` from `checks.json` (behavioural; deterministic: yes). Covers: KYC · incomplete KYC · BSA/AML. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-AML-001.

## Rule BSA-TM-01: Monitoring completeness
Severity: HIGH
Category: MM
Scenario: transaction-monitoring
Requirement: MUST
Invariant: Monitoring completeness: count and value of ledger transactions equal those ingested by monitoring, for every money-movement type, including backlog replay after an outage.

Source check `BSA-TM-01` from `checks.json` (behavioural; deterministic: yes). Covers: Transaction monitoring · Missed SAR · BSA/AML. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-AML-001, RR-AML-003.

## Rule BSA-TM-51: Every money-movement event type in the ledger enum is published to the monitoring stream (event-t...
Severity: HIGH
Category: MM
Scenario: transaction-monitoring
Requirement: MUST
Invariant: Every money-movement event type in the ledger enum is published to the monitoring stream (event-type registry ↔ producer coverage).

Source check `BSA-TM-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: Transaction monitoring · Missed SAR · BSA/AML. Backstop for BSA-TM-01. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-AML-001, RR-AML-003.

## Rule BSA-TM-02: Each positive typology (structuring, pass-through, P2P funnel, velocity) yields exactly one alert...
Severity: HIGH
Category: MM
Scenario: transaction-monitoring
Requirement: MUST
Invariant: Each positive typology (structuring, pass-through, P2P funnel, velocity) yields exactly one alert with rule ID at the configured inclusive/exclusive boundary; benign controls do not alert.

Source check `BSA-TM-02` from `checks.json` (behavioural; deterministic: yes). Covers: Transaction monitoring · Missed SAR · BSA/AML. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-AML-012, RR-AML-023, RR-AML-003.

## Rule BSA-TM-03: Duplicate events never double-alert or inflate aggregated counts/amounts
Severity: HIGH
Category: MM
Scenario: transaction-monitoring
Requirement: MUST
Invariant: Duplicate events never double-alert or inflate aggregated counts/amounts.

Source check `BSA-TM-03` from `checks.json` (behavioural; deterministic: yes). Covers: Transaction monitoring · Missed SAR · BSA/AML. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-AML-001, RR-AML-003.

## Rule BSA-TM-04: High-risk alerts are never auto-closed
Severity: HIGH
Category: MM
Scenario: transaction-monitoring
Requirement: MUST
Invariant: High-risk alerts are never auto-closed; closure needs rationale, reviewer and timestamp; aged alerts escalate.

Source check `BSA-TM-04` from `checks.json` (behavioural; deterministic: yes). Covers: Transaction monitoring · Missed SAR · BSA/AML. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-AML-001, RR-AML-003.

## Rule BSA-TM-52: Alert auto-close/suppression rules exclude the high-risk rule set, and the close path requires no...
Severity: HIGH
Category: MM
Scenario: transaction-monitoring
Requirement: MUST
Invariant: Alert auto-close/suppression rules exclude the high-risk rule set, and the close path requires non-null rationale and reviewer.

Source check `BSA-TM-52` from `checks.json` (static, static backstop; deterministic: yes). Covers: Transaction monitoring · Missed SAR · BSA/AML. Backstop for BSA-TM-04. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-AML-001, RR-AML-003.

## Rule BSA-TM-05: Aggregated cash activity above the configured threshold creates a currency-transaction reporting...
Severity: HIGH
Category: MM
Scenario: transaction-monitoring
Requirement: MUST
Invariant: Aggregated cash activity above the configured threshold creates a currency-transaction reporting task.

Source check `BSA-TM-05` from `checks.json` (behavioural; deterministic: yes). Covers: Transaction monitoring · None · BSA/AML. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-AML-002, RR-AML-022.

## Rule BSA-SAR-01: Every case reaches a filed/no-file decision with rationale before the configured deadline from im...
Severity: HIGH
Category: MM
Scenario: sar-filing
Requirement: MUST
Invariant: Every case reaches a filed/no-file decision with rationale before the configured deadline from immutable detection date; overdue escalates; continuing-activity review is scheduled.

Source check `BSA-SAR-01` from `checks.json` (behavioural; deterministic: yes). Covers: SAR filing · Missed SAR · BSA/AML. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-AML-003, RR-AML-004.

## Rule BSA-SAR-02: A SAR cannot be submitted until required fields are complete
Severity: HIGH
Category: MM
Scenario: sar-filing
Requirement: MUST
Invariant: A SAR cannot be submitted until required fields are complete; a case is not 'filed' until acknowledgement, and retry never duplicates a filing.

Source check `BSA-SAR-02` from `checks.json` (behavioural; deterministic: yes). Covers: SAR filing · Missed SAR · BSA/AML. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-AML-003, RR-AML-004.

## Rule BSA-SAR-03: Two investigators cannot file duplicate SARs for one case
Severity: HIGH
Category: MM
Scenario: sar-filing
Requirement: MUST
Invariant: Two investigators cannot file duplicate SARs for one case.

Source check `BSA-SAR-03` from `checks.json` (behavioural; deterministic: yes). Covers: SAR filing · Missed SAR · BSA/AML. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-AML-003, RR-AML-004.

## Rule BSA-SAR-52: SAR filing state transition is a locked compare-and-set on the case row (unique filing per case)
Severity: HIGH
Category: MM
Scenario: sar-filing
Requirement: MUST
Invariant: SAR filing state transition is a locked compare-and-set on the case row (unique filing per case).

Source check `BSA-SAR-52` from `checks.json` (static, static backstop; deterministic: yes). Covers: SAR filing · Missed SAR · BSA/AML. Backstop for BSA-SAR-03. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-AML-003, RR-AML-004.

## Rule BSA-SAR-04: SAR existence is never revealed to the subject or to unauthorised staff roles
Severity: HIGH
Category: MM
Scenario: sar-filing
Requirement: MUST
Invariant: SAR existence is never revealed to the subject or to unauthorised staff roles.

Source check `BSA-SAR-04` from `checks.json` (behavioural; deterministic: yes). Covers: SAR filing · Missed SAR · BSA/AML. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-AML-003.

## Rule BSA-SAR-51: No customer-facing serializer, template or support-tool query exposes SAR/case tables or fields
Severity: HIGH
Category: MM
Scenario: sar-filing
Requirement: MUST
Invariant: No customer-facing serializer, template or support-tool query exposes SAR/case tables or fields.

Source check `BSA-SAR-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: SAR filing · Missed SAR · BSA/AML. Backstop for BSA-SAR-04. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-AML-003.

## Rule BSA-OFAC-01: No account is activated or funded, and no new payee receives a first payment, until sanctions scr...
Severity: HIGH
Category: MM
Scenario: ofac-screening
Requirement: MUST
Invariant: No account is activated or funded, and no new payee receives a first payment, until sanctions screening clears; true matches route to review.

Source check `BSA-OFAC-01` from `checks.json` (behavioural; deterministic: yes). Covers: OFAC screening · None · BSA/AML. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-OFAC-001.

## Rule BSA-OFAC-02: Name/address changes and list updates trigger re-screening of existing customers within the confi...
Severity: HIGH
Category: MM
Scenario: ofac-screening
Requirement: MUST
Invariant: Name/address changes and list updates trigger re-screening of existing customers within the configured window; new matches alert.

Source check `BSA-OFAC-02` from `checks.json` (behavioural; deterministic: yes). Covers: OFAC screening · None · BSA/AML. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-OFAC-001.

## Rule BSA-OFAC-52: Customer name/address update paths and list-ingest jobs enqueue a re-screen
Severity: HIGH
Category: MM
Scenario: ofac-screening
Requirement: MUST
Invariant: Customer name/address update paths and list-ingest jobs enqueue a re-screen.

Source check `BSA-OFAC-52` from `checks.json` (static, static backstop; deterministic: yes). Covers: OFAC screening · None · BSA/AML. Backstop for BSA-OFAC-02. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-OFAC-001.

## Rule BSA-OFAC-03: Fuzzy-match alerts fire exactly at the configured score threshold with score and algorithm versio...
Severity: HIGH
Category: MM
Scenario: ofac-screening
Requirement: MUST
Invariant: Fuzzy-match alerts fire exactly at the configured score threshold with score and algorithm version logged; false-positive suppressions expire and re-alert.

Source check `BSA-OFAC-03` from `checks.json` (behavioural; deterministic: yes). Covers: OFAC screening · None · BSA/AML. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-OFAC-001.

## Rule BSA-OFAC-04: Screening service outage holds payments by default and screens them on recovery
Severity: HIGH
Category: MM
Scenario: ofac-screening
Requirement: MUST
Invariant: Screening service outage holds payments by default and screens them on recovery.

Source check `BSA-OFAC-04` from `checks.json` (behavioural; deterministic: yes). Covers: OFAC screening · None · BSA/AML. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-OFAC-001.

## Rule BSA-OFAC-51: Screening-service error/timeout handling sets payments to 'held' — no default-release branch
Severity: HIGH
Category: MM
Scenario: ofac-screening
Requirement: MUST
Invariant: Screening-service error/timeout handling sets payments to 'held' — no default-release branch.

Source check `BSA-OFAC-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: OFAC screening · None · BSA/AML. Backstop for BSA-OFAC-04. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-OFAC-001.

## Rule BSA-OFAC-05: Concurrent payouts are each screened exactly once before release
Severity: HIGH
Category: MM
Scenario: ofac-screening
Requirement: MUST
Invariant: Concurrent payouts are each screened exactly once before release.

Source check `BSA-OFAC-05` from `checks.json` (behavioural; deterministic: yes). Covers: OFAC screening · None · BSA/AML. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-OFAC-001.
