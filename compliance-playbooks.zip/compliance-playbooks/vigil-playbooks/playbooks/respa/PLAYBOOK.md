---
helixPlaybookFormat: helix-playbook/0.1-proposal
playbookId: vigil-respa
title: "RESPA Settlement Disclosures & Escrow"
declaredVersion: 0.1.0
intent: draft
applicability:
  languages: [javascript, typescript]
  scenarios: [disclosure, kickbacks, escrow]
---
# Helix portable playbook — DRAFT manifest · RESPA Settlement Disclosures & Escrow

> **DRAFT — not LOCKED.** Proposed RESPA (Mortgage) playbook converted from Vigil skill `SK-RESPA-001`: one runner, two layers, **8 harness checks (3 static, incl. 2 static backstops, + 5 behavioural)**, plus 3 manual/evidence items listed separately because neither layer can verify them. Every invariant, layer and determinism call is **AI-drafted (Helix) and needs compliance review**; 4 check(s) are **⚑ SME-flagged** and cannot gate until an SME/counsel supplies their parameter matrix. No detector or rule code exists yet. Before this manifest can be LOCKED, each row needs its detector/rule, a review, and a commit that adds the check alongside its row.

## Layers

- **static**: a repo-agnostic source scanner parameterised by a `VIGIL_RESPA` preset (no app specifics in the detector). It reads source / SQL / config / IaC / git-diff, **fails CLOSED** on a match, and runs with **no adapter**, so it is the CI gate. *Static backstops* (IDs `-5x`) prove a supporting source invariant for a named behavioural check, the way N-CAP-01 / N-STATE-01 back neobank behaviour. They fire even when the adapter never drives that path. Backstops of ⚑ SME checks stay out of the gate.
- **behavioural**: a rule written once against the canonical `MoneySystem` interface (or a DRAFT extension surface in `adapters/`) and driven through the app adapter. Surfaces needed: **MortgageSystem** (`adapters/mortgage.ts`). Every behavioural row reports NOT_EXERCISED until an adapter implements its surface. It returns **CHECKED only when it actually drove the guard's path**.
- **manual/evidence**: organisational process, live-infrastructure, statistical or retention evidence that no source scan or adapter-driven rule can prove. These are **outside the harness**, report `NOT_APPLICABLE` to it, and are tracked as evidence tasks, never as passes.

## Verdicts

`CHECKED` the path ran and the guard held · `FINDING` the guard was violated · `NOT_APPLICABLE` the invariant cannot apply here (incl. every manual/evidence item) · `NOT_EXERCISED` (glyph `????`) the adapter did not drive the path, so nothing is proven. NOT_EXERCISED is **surfaced distinctly and never counted as a pass** (no fake coverage). A ⚑ SME check with no approved parameter matrix reports `NOT_EXERCISED`, never `CHECKED`.

## How to run

- **Not runnable yet**: this draft defines invariants only (no detector/rule code). The intended shape mirrors the neobank playbook:
  - CI gate (adapter-free, blocks on any static FINDING): `run-static` with preset `VIGIL_RESPA`.
  - Full combined table (static + behavioural via the adapter): `run-all`.
- Machine-readable rows: `checks.json` (same IDs; includes source-scenario traceability and neobank overlaps).

## The draft inventory: 3 static + 5 behavioural = 8 checks

| ID | Layer | Deterministic | Invariant (one line) | Covers (automation point · common failure · regulation) |
| --- | --- | --- | --- | --- |
| **RESPA-DIS-01** | static | yes ⚑ SME | The disclosure regime per loan type comes from the configured (counsel-maintained) mapping; an unmapped loan type blocks; out-of-scope types take the alternative path. | Disclosure · Missing disclosure · RESPA |
| **RESPA-DIS-02** | behavioural | yes | Settlement disclosures are generated within the configured window with fees matching the fee schedule; every settlement-statement fee appears on the disclosure; one current version under concurrent edits. | Disclosure · Missing disclosure · RESPA |
| **RESPA-DIS-03** | behavioural | yes | Disclosure generation failure blocks loan progression; servicing-transfer notices are delivered within configured windows without mishandling transition-period payments. | Disclosure · Missing disclosure · RESPA |
| **RESPA-KB-01** | behavioural | yes ⚑ SME | A referral to an affiliate is blocked until the affiliated business disclosure is delivered and logged. | Kickbacks · improper kickback · RESPA |
| **RESPA-KB-51** | static | yes ⚑ SME | The referral path checks that an affiliated-business-disclosure delivery record exists before referring. | backstop for RESPA-KB-01 · Kickbacks · improper kickback · RESPA |
| **RESPA-ESC-01** | behavioural | yes | Escrow analysis projected balances, cushion (within configured cap) and shortage/surplus handling match the reference calculation; the annual statement is generated after each analysis. | Escrow · general control (no source failure) · RESPA |
| **RESPA-ESC-02** | behavioural | yes | Each tax/insurance disbursement is paid exactly once on schedule (advanced per policy when the balance is short), with failures retried and alerted, and the ledger updated. | Escrow · general control (no source failure) · RESPA |
| **RESPA-ESC-51** | static | yes | Escrow disbursements are keyed by a unique (escrow item, due date) key. | backstop for RESPA-ESC-02 · Escrow · general control (no source failure) · RESPA |

## Outside the harness: manual/evidence (3)

These items are not harness checks. Each reports `NOT_APPLICABLE` to the runner and needs an owner and evidence on a schedule.

| ID | Layer | Deterministic | Invariant (one line) | Covers (automation point · common failure · regulation) |
| --- | --- | --- | --- | --- |
| **RESPA-DIS-04** | manual/evidence | no (manual) | Disclosures are retained. | Disclosure · general control (no source failure) · RESPA |
| **RESPA-KB-02** | manual/evidence | no (manual) | Payments to referral sources/affiliates reconcile to documented services and are reviewed at the SME-configured threshold; payment totals are deduplicated; feed gaps flag monitoring incomplete; reviews retained. | Kickbacks · improper kickback · RESPA |
| **RESPA-ESC-03** | manual/evidence | no (manual) | Annual escrow statements are retained. | Escrow · general control (no source failure) · RESPA |

### Determinism

Every harness row (static and behavioural) is drafted as deterministic. Static detectors, including backstops, are pure functions of the committed source/config/diff. Behavioural rules each run against a **fresh `reset()` MoneySystem** (no state leaks between rules), driven by a **controllable clock**; deadlines, windows, expiries and cadences are asserted by advancing that clock, never by wall-clock reads, and no randomness affects a verdict. External dependencies (vendors, registries, feeds) are faked inside the adapter, which is how fault-injection rows stay deterministic. Manual/evidence rows are not deterministic and are not gate checks. ⚑ SME rows are deterministic once parameters exist, but are excluded from the gate until then.

### Coverage note

Converted from 24 AI-drafted source scenarios of `SK-RESPA-001`; each source scenario maps to exactly one non-backstop row (see the appendix). Static backstops add no scenarios and trace through the check they back. The scenarios were merged into crisp invariants by automation point and failure mode, across categories (positive, negative, boundary, failure/recovery, concurrency/idempotency, retention/audit, common failure, core). Automation points covered: Disclosure, Kickbacks, Escrow. Source common failures: Missing disclosure, improper kickback. Thresholds, windows and deadlines are *configured* parameters, not asserted statutory values. No regulation or citation was added beyond the source sheet.

### Overlap with the locked neobank playbook (19 checks)

| This check | Neobank check | Strength | Why |
| --- | --- | --- | --- |
| RESPA-ESC-02 | N-IDEMP-01 | related | disbursement paid once |
| RESPA-ESC-51 | N-IDEMP-01 | related | unique-key dedupe on the write path |

`same` means the neobank check already enforces this invariant, so reuse it instead of re-implementing. `related` means the same defect class, but this check needs its own rule or preset.

### Review flags

- ⚑ **RESPA-DIS-01**: needs an SME/counsel parameter matrix (source scenarios carry review status "+ SME input").
- ⚑ **RESPA-KB-01**: needs an SME/counsel parameter matrix (source scenarios carry review status "+ SME input").
- ⚑ **RESPA-KB-51**: needs an SME/counsel parameter matrix (source scenarios carry review status "+ SME input").
- ⚑ **RESPA-KB-02**: needs an SME/counsel parameter matrix (source scenarios carry review status "+ SME input").

## Appendix: traceability to source scenarios

| Check ID | Source scenario IDs | Categories merged |
| --- | --- | --- |
| RESPA-DIS-01 | SC-RESPA-001-04, SC-RESPA-001-11 | Negative, Positive |
| RESPA-DIS-02 | SC-RESPA-001-01, SC-RESPA-001-15, SC-RESPA-001-13 | Common Failure, Concurrency/Idempotency, Core |
| RESPA-DIS-03 | SC-RESPA-001-12, SC-RESPA-001-05 | Boundary/Edge, Failure/Recovery |
| RESPA-DIS-04 | SC-RESPA-001-14 | Retention/Audit |
| RESPA-KB-01 | SC-RESPA-001-07, SC-RESPA-001-16 | Negative, Positive |
| RESPA-KB-51 | — (static backstop; traced via RESPA-KB-01) | — |
| RESPA-KB-02 | SC-RESPA-001-02, SC-RESPA-001-06, SC-RESPA-001-17, SC-RESPA-001-19, SC-RESPA-001-18, SC-RESPA-001-20 | Boundary/Edge, Common Failure, Concurrency/Idempotency, Core, Failure/Recovery, Retention/Audit |
| RESPA-ESC-01 | SC-RESPA-001-03, SC-RESPA-001-08, SC-RESPA-001-24 | Boundary/Edge, Common Failure, Core |
| RESPA-ESC-02 | SC-RESPA-001-09, SC-RESPA-001-21, SC-RESPA-001-22, SC-RESPA-001-23 | Concurrency/Idempotency, Failure/Recovery, Negative, Positive |
| RESPA-ESC-51 | — (static backstop; traced via RESPA-ESC-02) | — |
| RESPA-ESC-03 | SC-RESPA-001-10 | Retention/Audit |

# Helix review rules

Generated from `checks.json` (8 static and behavioural checks; manual/evidence items are not code-reviewable and are omitted). Severity is derived from the playbook priority (P2 -> LOW); Category MM marks money-movement checks. Rule text is the source invariant, unchanged; it is AI-drafted and needs compliance review.

## Rule RESPA-DIS-01: The disclosure regime per loan type comes from the configured (counsel-maintained) mapping
Severity: LOW
Category: NON_MM
Scenario: disclosure
Requirement: MUST
Invariant: The disclosure regime per loan type comes from the configured (counsel-maintained) mapping; an unmapped loan type blocks; out-of-scope types take the alternative path.

Source check `RESPA-DIS-01` from `checks.json` (static; deterministic: yes). Covers: Disclosure · Missing disclosure · RESPA. Flagged for SME input in the source; needs an approved parameter matrix. Review status in source: Drafted (AI) – needs compliance review + SME input.

## Rule RESPA-DIS-02: Settlement disclosures are generated within the configured window with fees matching the fee sche...
Severity: LOW
Category: NON_MM
Scenario: disclosure
Requirement: MUST
Invariant: Settlement disclosures are generated within the configured window with fees matching the fee schedule; every settlement-statement fee appears on the disclosure; one current version under concurrent edits.

Source check `RESPA-DIS-02` from `checks.json` (behavioural; deterministic: yes). Covers: Disclosure · Missing disclosure · RESPA. Review status in source: Drafted (AI) – needs compliance review.

## Rule RESPA-DIS-03: Disclosure generation failure blocks loan progression
Severity: LOW
Category: NON_MM
Scenario: disclosure
Requirement: MUST
Invariant: Disclosure generation failure blocks loan progression; servicing-transfer notices are delivered within configured windows without mishandling transition-period payments.

Source check `RESPA-DIS-03` from `checks.json` (behavioural; deterministic: yes). Covers: Disclosure · Missing disclosure · RESPA. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-REGX-005.

## Rule RESPA-KB-01: A referral to an affiliate is blocked until the affiliated business disclosure is delivered and l...
Severity: LOW
Category: NON_MM
Scenario: kickbacks
Requirement: MUST
Invariant: A referral to an affiliate is blocked until the affiliated business disclosure is delivered and logged.

Source check `RESPA-KB-01` from `checks.json` (behavioural; deterministic: yes). Covers: Kickbacks · improper kickback · RESPA. Flagged for SME input in the source; needs an approved parameter matrix. Review status in source: Drafted (AI) – needs compliance review + SME input.

## Rule RESPA-KB-51: The referral path checks that an affiliated-business-disclosure delivery record exists before ref...
Severity: LOW
Category: NON_MM
Scenario: kickbacks
Requirement: MUST
Invariant: The referral path checks that an affiliated-business-disclosure delivery record exists before referring.

Source check `RESPA-KB-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: Kickbacks · improper kickback · RESPA. Backstop for RESPA-KB-01. Flagged for SME input in the source; needs an approved parameter matrix. Review status in source: Drafted (AI) – needs compliance review + SME input.

## Rule RESPA-ESC-01: Escrow analysis projected balances, cushion (within configured cap) and shortage/surplus handling...
Severity: LOW
Category: NON_MM
Scenario: escrow
Requirement: MUST
Invariant: Escrow analysis projected balances, cushion (within configured cap) and shortage/surplus handling match the reference calculation; the annual statement is generated after each analysis.

Source check `RESPA-ESC-01` from `checks.json` (behavioural; deterministic: yes). Covers: Escrow · None · RESPA. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-REGX-002, RR-REGX-003.

## Rule RESPA-ESC-02: Each tax/insurance disbursement is paid exactly once on schedule (advanced per policy when the ba...
Severity: LOW
Category: NON_MM
Scenario: escrow
Requirement: MUST
Invariant: Each tax/insurance disbursement is paid exactly once on schedule (advanced per policy when the balance is short), with failures retried and alerted, and the ledger updated.

Source check `RESPA-ESC-02` from `checks.json` (behavioural; deterministic: yes). Covers: Escrow · None · RESPA. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-REGX-002.

## Rule RESPA-ESC-51: Escrow disbursements are keyed by a unique (escrow item, due date) key
Severity: LOW
Category: NON_MM
Scenario: escrow
Requirement: MUST
Invariant: Escrow disbursements are keyed by a unique (escrow item, due date) key.

Source check `RESPA-ESC-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: Escrow · None · RESPA. Backstop for RESPA-ESC-02. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-REGX-002.
