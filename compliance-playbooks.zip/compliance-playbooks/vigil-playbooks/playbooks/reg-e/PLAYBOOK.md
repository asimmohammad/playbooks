---
helixPlaybookFormat: helix-playbook/0.1-proposal
playbookId: vigil-reg-e
title: "Reg E Error Resolution & Consumer Liability"
declaredVersion: 0.1.0
intent: draft
applicability:
  languages: [javascript, typescript]
  scenarios: [error-resolution, liability-limits, disclosure]
---
# Helix portable playbook — DRAFT manifest · Reg E Error Resolution & Consumer Liability

> **DRAFT — not LOCKED.** Proposed EFTA / Reg E (Consumer Protection) playbook converted from Vigil skill `SK-REGE-001`: one runner, two layers, **15 harness checks (4 static, incl. 4 static backstops, + 11 behavioural)**, plus 2 manual/evidence items listed separately because neither layer can verify them. Every invariant, layer and determinism call is **AI-drafted (Helix) and needs compliance review**. No detector or rule code exists yet. Before this manifest can be LOCKED, each row needs its detector/rule, a review, and a commit that adds the check alongside its row.

## Layers

- **static**: a repo-agnostic source scanner parameterised by a `VIGIL_REGE` preset (no app specifics in the detector). It reads source / SQL / config / IaC / git-diff, **fails CLOSED** on a match, and runs with **no adapter**, so it is the CI gate. *Static backstops* (IDs `-5x`) prove a supporting source invariant for a named behavioural check, the way N-CAP-01 / N-STATE-01 back neobank behaviour. They fire even when the adapter never drives that path. Backstops of ⚑ SME checks stay out of the gate.
- **behavioural**: a rule written once against the canonical `MoneySystem` interface (or a DRAFT extension surface in `adapters/`) and driven through the app adapter. Surfaces needed: **DisputesSystem** (`adapters/disputes.ts`). Every behavioural row reports NOT_EXERCISED until an adapter implements its surface. It returns **CHECKED only when it actually drove the guard's path**.
- **manual/evidence**: organisational process, live-infrastructure, statistical or retention evidence that no source scan or adapter-driven rule can prove. These are **outside the harness**, report `NOT_APPLICABLE` to it, and are tracked as evidence tasks, never as passes.

## Verdicts

`CHECKED` the path ran and the guard held · `FINDING` the guard was violated · `NOT_APPLICABLE` the invariant cannot apply here (incl. every manual/evidence item) · `NOT_EXERCISED` (glyph `????`) the adapter did not drive the path, so nothing is proven. NOT_EXERCISED is **surfaced distinctly and never counted as a pass** (no fake coverage). A ⚑ SME check with no approved parameter matrix reports `NOT_EXERCISED`, never `CHECKED`.

## How to run

- **Not runnable yet**: this draft defines invariants only (no detector/rule code). The intended shape mirrors the neobank playbook:
  - CI gate (adapter-free, blocks on any static FINDING): `run-static` with preset `VIGIL_REGE`.
  - Full combined table (static + behavioural via the adapter): `run-all`.
- Machine-readable rows: `checks.json` (same IDs; includes source-scenario traceability and neobank overlaps).

## The draft inventory: 4 static + 11 behavioural = 15 checks

| ID | Layer | Deterministic | Invariant (one line) | Covers (automation point · common failure · regulation) |
| --- | --- | --- | --- | --- |
| **REGE-ERR-01** | behavioural | yes | A dispute from any configured channel opens one case with notice date = first notice and starts timers; requesting documents never pauses them. | Error resolution · wrong liability · EFTA / Reg E |
| **REGE-ERR-52** | static | yes | Document-request handlers do not modify investigation timer fields. | backstop for REGE-ERR-01 · Error resolution · wrong liability · EFTA / Reg E |
| **REGE-ERR-02** | behavioural | yes | Provisional credit posts exactly when the investigation exceeds the configured window (controllable clock); missing it fails. | Error resolution · wrong liability · EFTA / Reg E |
| **REGE-ERR-03** | behavioural | yes | Duplicate disputes on one transaction create a single case and at most one provisional credit. | Error resolution · wrong liability · EFTA / Reg E |
| **REGE-ERR-51** | static | yes | Disputes have a unique constraint per (transaction, open status); provisional credit posting is idempotent per dispute ID. | backstop for REGE-ERR-03 · Error resolution · wrong liability · EFTA / Reg E |
| **REGE-ERR-04** | behavioural | yes | Provisional credit is reversed only after a no-error finding and the configured notice period, with the ledger balanced. | Error resolution · wrong liability · EFTA / Reg E |
| **REGE-ERR-05** | behavioural | yes | Late notices beyond the configured window follow configured policy with a recorded reason (no automatic denial). | Error resolution · wrong liability · EFTA / Reg E |
| **REGE-LIA-01** | behavioural | yes | Consumer liability never exceeds the configured tier cap for the notification timing — across concurrent disputes for one loss event — and is zero when not liable. | Liability limits · wrong liability · EFTA / Reg E |
| **REGE-LIA-51** | static | yes | Liability tier caps come from the configured cap table inside the decision transaction, aggregated per loss event — never from request input. | backstop for REGE-LIA-01 · Liability limits · wrong liability · EFTA / Reg E |
| **REGE-LIA-02** | behavioural | yes | Final credited amount = disputed amount − computed consumer liability, with no rounding drift; a late-reported recalculation adjusts the ledger once. | Liability limits · wrong liability · EFTA / Reg E |
| **REGE-LIA-03** | behavioural | yes | Transaction classification (authorized user, consumer-initiated) and extenuating-circumstance extensions drive liability per configured rules with rationale. | Liability limits · wrong liability · EFTA / Reg E |
| **REGE-DIS-01** | behavioural | yes | Every EFT appears on exactly one periodic statement with all required fields per the configured template, including EFTs near cycle cutoff. | Disclosure · Missing disclosure · EFTA / Reg E |
| **REGE-DIS-51** | static | yes | The statement template references every field the configured required-field list names, for every EFT type. | backstop for REGE-DIS-01 · Disclosure · Missing disclosure · EFTA / Reg E |
| **REGE-DIS-02** | behavioural | yes | Required disclosures are delivered before the first EFT; electronic delivery only with valid e-consent; change-in-terms notices meet the configured lead time. | Disclosure · Missing disclosure · EFTA / Reg E |
| **REGE-DIS-03** | behavioural | yes | Statement generation failures retry within the cycle deadline or alert; the error-resolution notice is delivered on the configured cadence. | Disclosure · Missing disclosure · EFTA / Reg E |

## Outside the harness: manual/evidence (2)

These items are not harness checks. Each reports `NOT_APPLICABLE` to the runner and needs an owner and evidence on a schedule.

| ID | Layer | Deterministic | Invariant (one line) | Covers (automation point · common failure · regulation) |
| --- | --- | --- | --- | --- |
| **REGE-ERR-06** | manual/evidence | no (manual) | Dispute case files (notice, investigation, documents, notices sent) are retained. | Error resolution · general control (no source failure) · EFTA / Reg E |
| **REGE-LIA-04** | manual/evidence | no (manual) | Liability determination rationale is retained. | Liability limits · general control (no source failure) · EFTA / Reg E |

### Determinism

Every harness row (static and behavioural) is drafted as deterministic. Static detectors, including backstops, are pure functions of the committed source/config/diff. Behavioural rules each run against a **fresh `reset()` MoneySystem** (no state leaks between rules), driven by a **controllable clock**; deadlines, windows, expiries and cadences are asserted by advancing that clock, never by wall-clock reads, and no randomness affects a verdict. External dependencies (vendors, registries, feeds) are faked inside the adapter, which is how fault-injection rows stay deterministic. Manual/evidence rows are not deterministic and are not gate checks.

### Coverage note

Converted from 25 AI-drafted source scenarios of `SK-REGE-001`; each source scenario maps to exactly one non-backstop row (see the appendix). Static backstops add no scenarios and trace through the check they back. The scenarios were merged into crisp invariants by automation point and failure mode, across categories (positive, negative, boundary, failure/recovery, concurrency/idempotency, retention/audit, common failure, core). Automation points covered: Error resolution, Liability limits, Disclosure. Source common failures: Missing disclosure, wrong liability. Thresholds, windows and deadlines are *configured* parameters, not asserted statutory values. No regulation or citation was added beyond the source sheet.

### Overlap with the locked neobank playbook (19 checks)

| This check | Neobank check | Strength | Why |
| --- | --- | --- | --- |
| REGE-ERR-03 | N-IDEMP-01 | related | one provisional credit per dispute |
| REGE-ERR-51 | N-IDEMP-01 | related | unique-key dedupe on the write path |
| REGE-LIA-01 | N-CAP-01 | related | liability cap across concurrent disputes |
| REGE-LIA-51 | N-CAP-01 | related | cap table read in decision txn |
| REGE-LIA-02 | LEDGER-CONSERVE | related | credit = disputed − liability, no drift |

`same` means the neobank check already enforces this invariant, so reuse it instead of re-implementing. `related` means the same defect class, but this check needs its own rule or preset.

### Review flags

- **REGE-LIA-03**: expert input noted in source feasibility: needs SME policy.

## Appendix: traceability to source scenarios

| Check ID | Source scenario IDs | Categories merged |
| --- | --- | --- |
| REGE-ERR-01 | SC-REGE-001-01, SC-REGE-001-04, SC-REGE-001-06 | Core, Negative, Positive |
| REGE-ERR-52 | — (static backstop; traced via REGE-ERR-01) | — |
| REGE-ERR-02 | SC-REGE-001-05, SC-REGE-001-17 | Boundary/Edge, Common Failure |
| REGE-ERR-03 | SC-REGE-001-07 | Concurrency/Idempotency |
| REGE-ERR-51 | — (static backstop; traced via REGE-ERR-03) | — |
| REGE-ERR-04 | SC-REGE-001-09 | Failure/Recovery |
| REGE-ERR-05 | SC-REGE-001-08 | Boundary/Edge |
| REGE-ERR-06 | SC-REGE-001-10 | Retention/Audit |
| REGE-LIA-01 | SC-REGE-001-02, SC-REGE-001-19, SC-REGE-001-21 | Common Failure, Concurrency/Idempotency, Core |
| REGE-LIA-51 | — (static backstop; traced via REGE-LIA-01) | — |
| REGE-LIA-02 | SC-REGE-001-13, SC-REGE-001-18 | Failure/Recovery, Positive |
| REGE-LIA-03 | SC-REGE-001-11, SC-REGE-001-12 | Boundary/Edge, Negative |
| REGE-LIA-04 | SC-REGE-001-20 | Retention/Audit |
| REGE-DIS-01 | SC-REGE-001-14, SC-REGE-001-24, SC-REGE-001-25 | Common Failure, Concurrency/Idempotency, Positive |
| REGE-DIS-51 | — (static backstop; traced via REGE-DIS-01) | — |
| REGE-DIS-02 | SC-REGE-001-03, SC-REGE-001-16, SC-REGE-001-22 | Boundary/Edge, Core, Negative |
| REGE-DIS-03 | SC-REGE-001-23, SC-REGE-001-15 | Failure/Recovery, Retention/Audit |

# Helix review rules

Generated from `checks.json` (15 static and behavioural checks; manual/evidence items are not code-reviewable and are omitted). Severity is derived from the playbook priority (P1 -> MEDIUM); Category MM marks money-movement checks. Rule text is the source invariant, unchanged; it is AI-drafted and needs compliance review.

## Rule REGE-ERR-01: A dispute from any configured channel opens one case with notice date = first notice and starts t...
Severity: MEDIUM
Category: MM
Scenario: error-resolution
Requirement: MUST
Invariant: A dispute from any configured channel opens one case with notice date = first notice and starts timers; requesting documents never pauses them.

Source check `REGE-ERR-01` from `checks.json` (behavioural; deterministic: yes). Covers: Error resolution · wrong liability · EFTA / Reg E. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-REGE-001.

## Rule REGE-ERR-52: Document-request handlers do not modify investigation timer fields
Severity: MEDIUM
Category: MM
Scenario: error-resolution
Requirement: MUST
Invariant: Document-request handlers do not modify investigation timer fields.

Source check `REGE-ERR-52` from `checks.json` (static, static backstop; deterministic: yes). Covers: Error resolution · wrong liability · EFTA / Reg E. Backstop for REGE-ERR-01. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-REGE-001.

## Rule REGE-ERR-02: Provisional credit posts exactly when the investigation exceeds the configured window (controllab...
Severity: MEDIUM
Category: MM
Scenario: error-resolution
Requirement: MUST
Invariant: Provisional credit posts exactly when the investigation exceeds the configured window (controllable clock); missing it fails.

Source check `REGE-ERR-02` from `checks.json` (behavioural; deterministic: yes). Covers: Error resolution · wrong liability · EFTA / Reg E. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-REGE-001.

## Rule REGE-ERR-03: Duplicate disputes on one transaction create a single case and at most one provisional credit
Severity: MEDIUM
Category: MM
Scenario: error-resolution
Requirement: MUST
Invariant: Duplicate disputes on one transaction create a single case and at most one provisional credit.

Source check `REGE-ERR-03` from `checks.json` (behavioural; deterministic: yes). Covers: Error resolution · wrong liability · EFTA / Reg E. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-REGE-001.

## Rule REGE-ERR-51: Disputes have a unique constraint per (transaction, open status)
Severity: MEDIUM
Category: MM
Scenario: error-resolution
Requirement: MUST
Invariant: Disputes have a unique constraint per (transaction, open status); provisional credit posting is idempotent per dispute ID.

Source check `REGE-ERR-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: Error resolution · wrong liability · EFTA / Reg E. Backstop for REGE-ERR-03. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-REGE-001.

## Rule REGE-ERR-04: Provisional credit is reversed only after a no-error finding and the configured notice period, wi...
Severity: MEDIUM
Category: MM
Scenario: error-resolution
Requirement: MUST
Invariant: Provisional credit is reversed only after a no-error finding and the configured notice period, with the ledger balanced.

Source check `REGE-ERR-04` from `checks.json` (behavioural; deterministic: yes). Covers: Error resolution · wrong liability · EFTA / Reg E. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-REGE-001.

## Rule REGE-ERR-05: Late notices beyond the configured window follow configured policy with a recorded reason (no aut...
Severity: MEDIUM
Category: MM
Scenario: error-resolution
Requirement: MUST
Invariant: Late notices beyond the configured window follow configured policy with a recorded reason (no automatic denial).

Source check `REGE-ERR-05` from `checks.json` (behavioural; deterministic: yes). Covers: Error resolution · wrong liability · EFTA / Reg E. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-REGE-001.

## Rule REGE-LIA-01: Consumer liability never exceeds the configured tier cap for the notification timing — across con...
Severity: MEDIUM
Category: MM
Scenario: liability-limits
Requirement: MUST
Invariant: Consumer liability never exceeds the configured tier cap for the notification timing — across concurrent disputes for one loss event — and is zero when not liable.

Source check `REGE-LIA-01` from `checks.json` (behavioural; deterministic: yes). Covers: Liability limits · wrong liability · EFTA / Reg E. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-REGE-002.

## Rule REGE-LIA-51: Liability tier caps come from the configured cap table inside the decision transaction, aggregate...
Severity: MEDIUM
Category: MM
Scenario: liability-limits
Requirement: MUST
Invariant: Liability tier caps come from the configured cap table inside the decision transaction, aggregated per loss event — never from request input.

Source check `REGE-LIA-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: Liability limits · wrong liability · EFTA / Reg E. Backstop for REGE-LIA-01. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-REGE-002.

## Rule REGE-LIA-02: Final credited amount = disputed amount − computed consumer liability, with no rounding drift
Severity: MEDIUM
Category: MM
Scenario: liability-limits
Requirement: MUST
Invariant: Final credited amount = disputed amount − computed consumer liability, with no rounding drift; a late-reported recalculation adjusts the ledger once.

Source check `REGE-LIA-02` from `checks.json` (behavioural; deterministic: yes). Covers: Liability limits · wrong liability · EFTA / Reg E. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-REGE-002.

## Rule REGE-LIA-03: Transaction classification (authorized user, consumer-initiated) and extenuating-circumstance ext...
Severity: MEDIUM
Category: MM
Scenario: liability-limits
Requirement: MUST
Invariant: Transaction classification (authorized user, consumer-initiated) and extenuating-circumstance extensions drive liability per configured rules with rationale.

Source check `REGE-LIA-03` from `checks.json` (behavioural; deterministic: yes). Covers: Liability limits · wrong liability · EFTA / Reg E. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-REGE-002.

## Rule REGE-DIS-01: Every EFT appears on exactly one periodic statement with all required fields per the configured t...
Severity: MEDIUM
Category: MM
Scenario: disclosure
Requirement: MUST
Invariant: Every EFT appears on exactly one periodic statement with all required fields per the configured template, including EFTs near cycle cutoff.

Source check `REGE-DIS-01` from `checks.json` (behavioural; deterministic: yes). Covers: Disclosure · Missing disclosure · EFTA / Reg E. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-REGE-004.

## Rule REGE-DIS-51: The statement template references every field the configured required-field list names, for every...
Severity: MEDIUM
Category: MM
Scenario: disclosure
Requirement: MUST
Invariant: The statement template references every field the configured required-field list names, for every EFT type.

Source check `REGE-DIS-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: Disclosure · Missing disclosure · EFTA / Reg E. Backstop for REGE-DIS-01. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-REGE-004.

## Rule REGE-DIS-02: Required disclosures are delivered before the first EFT
Severity: MEDIUM
Category: MM
Scenario: disclosure
Requirement: MUST
Invariant: Required disclosures are delivered before the first EFT; electronic delivery only with valid e-consent; change-in-terms notices meet the configured lead time.

Source check `REGE-DIS-02` from `checks.json` (behavioural; deterministic: yes). Covers: Disclosure · Missing disclosure · EFTA / Reg E. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-REGE-003, RR-ESIGN-001.

## Rule REGE-DIS-03: Statement generation failures retry within the cycle deadline or alert
Severity: MEDIUM
Category: MM
Scenario: disclosure
Requirement: MUST
Invariant: Statement generation failures retry within the cycle deadline or alert; the error-resolution notice is delivered on the configured cadence.

Source check `REGE-DIS-03` from `checks.json` (behavioural; deterministic: yes). Covers: Disclosure · Missing disclosure · EFTA / Reg E. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-REGE-004, RR-REGE-003.
