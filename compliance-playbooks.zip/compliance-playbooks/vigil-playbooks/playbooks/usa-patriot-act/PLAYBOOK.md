---
helixPlaybookFormat: helix-playbook/0.1-proposal
playbookId: vigil-usa-patriot-act
title: "USA PATRIOT Act CIP / CDD / EDD"
declaredVersion: 0.1.0
intent: draft
applicability:
  languages: [javascript, typescript]
  scenarios: [cip, cdd, edd, beneficial-ownership]
---
# Helix portable playbook — DRAFT manifest · USA PATRIOT Act CIP / CDD / EDD

> **DRAFT — not LOCKED.** Proposed USA PATRIOT Act (Anti-Money Laundering) playbook converted from Vigil skill `SK-PATRIOT-001`: one runner, two layers, **23 harness checks (6 static, incl. 6 static backstops, + 17 behavioural)**, plus 4 manual/evidence items listed separately because neither layer can verify them. Every invariant, layer and determinism call is **AI-drafted (Helix) and needs compliance review**. No detector or rule code exists yet. Before this manifest can be LOCKED, each row needs its detector/rule, a review, and a commit that adds the check alongside its row.

## Layers

- **static**: a repo-agnostic source scanner parameterised by a `VIGIL_PATRIOT` preset (no app specifics in the detector). It reads source / SQL / config / IaC / git-diff, **fails CLOSED** on a match, and runs with **no adapter**, so it is the CI gate. *Static backstops* (IDs `-5x`) prove a supporting source invariant for a named behavioural check, the way N-CAP-01 / N-STATE-01 back neobank behaviour. They fire even when the adapter never drives that path. Backstops of ⚑ SME checks stay out of the gate.
- **behavioural**: a rule written once against the canonical `MoneySystem` interface (or a DRAFT extension surface in `adapters/`) and driven through the app adapter. Surfaces needed: **OnboardingSystem** (`adapters/onboarding.ts`). Every behavioural row reports NOT_EXERCISED until an adapter implements its surface. It returns **CHECKED only when it actually drove the guard's path**.
- **manual/evidence**: organisational process, live-infrastructure, statistical or retention evidence that no source scan or adapter-driven rule can prove. These are **outside the harness**, report `NOT_APPLICABLE` to it, and are tracked as evidence tasks, never as passes.

## Verdicts

`CHECKED` the path ran and the guard held · `FINDING` the guard was violated · `NOT_APPLICABLE` the invariant cannot apply here (incl. every manual/evidence item) · `NOT_EXERCISED` (glyph `????`) the adapter did not drive the path, so nothing is proven. NOT_EXERCISED is **surfaced distinctly and never counted as a pass** (no fake coverage). A ⚑ SME check with no approved parameter matrix reports `NOT_EXERCISED`, never `CHECKED`.

## How to run

- **Not runnable yet**: this draft defines invariants only (no detector/rule code). The intended shape mirrors the neobank playbook:
  - CI gate (adapter-free, blocks on any static FINDING): `run-static` with preset `VIGIL_PATRIOT`.
  - Full combined table (static + behavioural via the adapter): `run-all`.
- Machine-readable rows: `checks.json` (same IDs; includes source-scenario traceability and neobank overlaps).

## The draft inventory: 6 static + 17 behavioural = 23 checks

| ID | Layer | Deterministic | Invariant (one line) | Covers (automation point · common failure · regulation) |
| --- | --- | --- | --- | --- |
| **PAT-CIP-01** | behavioural | yes | No account opens without all CIP elements and a recorded verification result, for every person defined as a customer (incl. joint holders). | CIP · Missing CIP · USA PATRIOT Act |
| **PAT-CIP-51** | static | yes | Account-activation code paths check the CIP-complete flag for every customer person on the account; no activation path omits it. | backstop for PAT-CIP-01 · CIP · Missing CIP · USA PATRIOT Act |
| **PAT-CIP-02** | behavioural | yes | Address-type and ID-number rules accept/reject/escalate exactly per configuration; malformed IDs are rejected and non-US persons follow the alternative-ID path. | CIP · Missing CIP · USA PATRIOT Act |
| **PAT-CIP-03** | behavioural | yes | Unverified accounts are restricted and then closed/escalated at the configured window end (controllable clock); fallback verification outcomes are recorded. | CIP · Missing CIP · USA PATRIOT Act |
| **PAT-CIP-04** | behavioural | yes | A verification result applies only to the data verified; editing identity data during pending verification re-triggers verification. | CIP · Missing CIP · USA PATRIOT Act |
| **PAT-CIP-53** | static | yes | Identity-field update paths reset the verification status to pending. | backstop for PAT-CIP-04 · CIP · Missing CIP · USA PATRIOT Act |
| **PAT-CIP-05** | behavioural | yes | ID-verification vendor outage holds account opening — no unverified opening. | CIP · Missing CIP · USA PATRIOT Act |
| **PAT-CIP-52** | static | yes | ID-verification vendor error handling never marks an identity verified. | backstop for PAT-CIP-05 · CIP · Missing CIP · USA PATRIOT Act |
| **PAT-CIP-06** | behavioural | yes | Applicants matching government lists during CIP are routed to compliance before opening. | CIP · Missing CIP · USA PATRIOT Act |
| **PAT-CDD-01** | behavioural | yes | Every customer past its risk-tier refresh interval is queued exactly at the configured interval — including reviews that came due during a scheduler outage. | CDD · stale CDD · USA PATRIOT Act |
| **PAT-CDD-51** | static | yes | The CDD refresh scheduler selects by due date ≤ now (catch-up), not by date = today. | backstop for PAT-CDD-01 · CDD · stale CDD · USA PATRIOT Act |
| **PAT-CDD-02** | behavioural | yes | Trigger events recompute the versioned risk rating and the monitoring tier uses the stricter thresholds immediately. | CDD · stale CDD · USA PATRIOT Act |
| **PAT-CDD-03** | behavioural | yes | Activity deviating beyond the configured multiple of the expected profile raises a CDD review; stale CDD restricts high-risk activity. | CDD · stale CDD · USA PATRIOT Act |
| **PAT-CDD-04** | behavioural | yes | A refresh racing a profile update uses the latest data or restarts. | CDD · stale CDD · USA PATRIOT Act |
| **PAT-CDD-05** | behavioural | yes | FinCEN 314(a) matches create response tasks before the configured deadline. | CDD · general control (no source failure) · USA PATRIOT Act |
| **PAT-EDD-01** | behavioural | yes | Each EDD trigger (incl. a PEP hit) opens exactly one case, raises the risk rating and holds restricted activity until approval. | EDD · general control (no source failure) · USA PATRIOT Act |
| **PAT-EDD-02** | behavioural | yes | Only a qualified approver who is not the case owner can approve EDD. | EDD · general control (no source failure) · USA PATRIOT Act |
| **PAT-EDD-51** | static | yes | The EDD approval handler rejects approver = case owner and checks the qualified-approver role. | backstop for PAT-EDD-02 · EDD · general control (no source failure) · USA PATRIOT Act |
| **PAT-EDD-03** | behavioural | yes | High-risk periodic reviews queue on the due date; stalled cases escalate and held activity stays held — no auto-approval on timeout. | EDD · general control (no source failure) · USA PATRIOT Act |
| **PAT-BO-01** | behavioural | yes | Legal-entity onboarding completes only after all owners at/above the configured threshold plus a control person are captured, identity-verified and screened; failure holds the account. | Beneficial ownership · general control (no source failure) · USA PATRIOT Act |
| **PAT-BO-51** | static | yes | Entity activation checks that owner records meet the configured threshold rule plus ≥1 control person, each verified and screened. | backstop for PAT-BO-01 · Beneficial ownership · general control (no source failure) · USA PATRIOT Act |
| **PAT-BO-02** | behavioural | yes | Trusts/complex structures capture the configured required parties or route to review; re-certification falls due on cadence and overdue entities are restricted. | Beneficial ownership · general control (no source failure) · USA PATRIOT Act |
| **PAT-BO-03** | behavioural | yes | Simultaneous owner edits are versioned, none lost. | Beneficial ownership · general control (no source failure) · USA PATRIOT Act |

## Outside the harness: manual/evidence (4)

These items are not harness checks. Each reports `NOT_APPLICABLE` to the runner and needs an owner and evidence on a schedule.

| ID | Layer | Deterministic | Invariant (one line) | Covers (automation point · common failure · regulation) |
| --- | --- | --- | --- | --- |
| **PAT-CIP-07** | manual/evidence | no (manual) | The CIP notice is shown and acknowledged before account opening; CIP records are retained for the configured period after closure. | CIP · Missing CIP · USA PATRIOT Act |
| **PAT-CDD-06** | manual/evidence | no (manual) | CDD profile versions are retained with timestamp, reviewer and rationale. | CDD · stale CDD · USA PATRIOT Act |
| **PAT-EDD-04** | manual/evidence | no (manual) | EDD files are retained for the configured period. | EDD · general control (no source failure) · USA PATRIOT Act |
| **PAT-BO-04** | manual/evidence | no (manual) | Beneficial-ownership records are retained after closure until the configured period ends. | Beneficial ownership · general control (no source failure) · USA PATRIOT Act |

### Determinism

Every harness row (static and behavioural) is drafted as deterministic. Static detectors, including backstops, are pure functions of the committed source/config/diff. Behavioural rules each run against a **fresh `reset()` MoneySystem** (no state leaks between rules), driven by a **controllable clock**; deadlines, windows, expiries and cadences are asserted by advancing that clock, never by wall-clock reads, and no randomness affects a verdict. External dependencies (vendors, registries, feeds) are faked inside the adapter, which is how fault-injection rows stay deterministic. Manual/evidence rows are not deterministic and are not gate checks.

### Coverage note

Converted from 40 AI-drafted source scenarios of `SK-PATRIOT-001`; each source scenario maps to exactly one non-backstop row (see the appendix). Static backstops add no scenarios and trace through the check they back. The scenarios were merged into crisp invariants by automation point and failure mode, across categories (positive, negative, boundary, failure/recovery, concurrency/idempotency, retention/audit, common failure, core). Automation points covered: CIP, CDD, EDD, Beneficial ownership. Source common failures: Missing CIP, stale CDD. Thresholds, windows and deadlines are *configured* parameters, not asserted statutory values. No regulation or citation was added beyond the source sheet.

### Overlap with the locked neobank playbook (19 checks)

| This check | Neobank check | Strength | Why |
| --- | --- | --- | --- |
| PAT-CIP-01 | PARTY-SCREEN | same | no account without completed CIP for every customer person |
| PAT-CIP-51 | N-SCREEN-02 | same | activation checks every customer person, not just the owner |
| PAT-CIP-04 | N-STATE-01 | related | verification tied to current data |
| PAT-CIP-06 | PARTY-SCREEN | same | list-matched applicant never opened |
| PAT-CDD-04 | N-CAS-01 | related | refresh vs update race |
| PAT-BO-01 | PARTY-SCREEN | related | entity owners verified & screened before activation |

`same` means the neobank check already enforces this invariant, so reuse it instead of re-implementing. `related` means the same defect class, but this check needs its own rule or preset.

### Review flags

- No SME-flagged rows. All rows still need compliance review.

## Appendix: traceability to source scenarios

| Check ID | Source scenario IDs | Categories merged |
| --- | --- | --- |
| PAT-CIP-01 | SC-PATRIOT-001-01, SC-PATRIOT-001-06 | Core, Positive |
| PAT-CIP-51 | — (static backstop; traced via PAT-CIP-01) | — |
| PAT-CIP-02 | SC-PATRIOT-001-04, SC-PATRIOT-001-05 | Boundary/Edge, Negative |
| PAT-CIP-03 | DR-PATRIOT-001-03, DR-PATRIOT-001-04 | Core |
| PAT-CIP-04 | SC-PATRIOT-001-07 | Concurrency/Idempotency |
| PAT-CIP-53 | — (static backstop; traced via PAT-CIP-04) | — |
| PAT-CIP-05 | SC-PATRIOT-001-20 | Failure/Recovery |
| PAT-CIP-52 | — (static backstop; traced via PAT-CIP-05) | — |
| PAT-CIP-06 | DR-PATRIOT-001-07 | Core |
| PAT-CIP-07 | DR-PATRIOT-001-05, SC-PATRIOT-001-22, DR-PATRIOT-001-06, SC-PATRIOT-001-21 | Common Failure, Core, Retention/Audit |
| PAT-CDD-01 | SC-PATRIOT-001-02, SC-PATRIOT-001-23, SC-PATRIOT-001-10 | Boundary/Edge, Core, Failure/Recovery |
| PAT-CDD-51 | — (static backstop; traced via PAT-CDD-01) | — |
| PAT-CDD-02 | SC-PATRIOT-001-08, DR-PATRIOT-001-09 | Core, Positive |
| PAT-CDD-03 | SC-PATRIOT-001-09, SC-PATRIOT-001-25 | Common Failure, Negative |
| PAT-CDD-04 | SC-PATRIOT-001-24 | Concurrency/Idempotency |
| PAT-CDD-05 | DR-PATRIOT-001-08 | Core |
| PAT-CDD-06 | SC-PATRIOT-001-11 | Retention/Audit |
| PAT-EDD-01 | SC-PATRIOT-001-03, SC-PATRIOT-001-13, SC-PATRIOT-001-26 | Concurrency/Idempotency, Core, Positive |
| PAT-EDD-02 | SC-PATRIOT-001-12, SC-PATRIOT-001-28 | Common Failure, Negative |
| PAT-EDD-51 | — (static backstop; traced via PAT-EDD-02) | — |
| PAT-EDD-03 | SC-PATRIOT-001-14, SC-PATRIOT-001-15 | Boundary/Edge, Failure/Recovery |
| PAT-EDD-04 | SC-PATRIOT-001-27 | Retention/Audit |
| PAT-BO-01 | DR-PATRIOT-001-01, DR-PATRIOT-001-02, SC-PATRIOT-001-29, SC-PATRIOT-001-16, SC-PATRIOT-001-30 | Common Failure, Core, Failure/Recovery, Positive |
| PAT-BO-51 | — (static backstop; traced via PAT-BO-01) | — |
| PAT-BO-02 | SC-PATRIOT-001-18, SC-PATRIOT-001-17 | Boundary/Edge, Negative |
| PAT-BO-03 | SC-PATRIOT-001-31 | Concurrency/Idempotency |
| PAT-BO-04 | SC-PATRIOT-001-19 | Retention/Audit |

# Helix review rules

Generated from `checks.json` (23 static and behavioural checks; manual/evidence items are not code-reviewable and are omitted). Severity is derived from the playbook priority (P0 -> HIGH); Category MM marks money-movement checks. Rule text is the source invariant, unchanged; it is AI-drafted and needs compliance review.

## Rule PAT-CIP-01: No account opens without all CIP elements and a recorded verification result, for every person de...
Severity: HIGH
Category: MM
Scenario: cip
Requirement: MUST
Invariant: No account opens without all CIP elements and a recorded verification result, for every person defined as a customer (incl. joint holders).

Source check `PAT-CIP-01` from `checks.json` (behavioural; deterministic: yes). Covers: CIP · Missing CIP · USA PATRIOT Act. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-AML-007.

## Rule PAT-CIP-51: Account-activation code paths check the CIP-complete flag for every customer person on the account
Severity: HIGH
Category: MM
Scenario: cip
Requirement: MUST
Invariant: Account-activation code paths check the CIP-complete flag for every customer person on the account; no activation path omits it.

Source check `PAT-CIP-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: CIP · Missing CIP · USA PATRIOT Act. Backstop for PAT-CIP-01. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-AML-007.

## Rule PAT-CIP-02: Address-type and ID-number rules accept/reject/escalate exactly per configuration
Severity: HIGH
Category: MM
Scenario: cip
Requirement: MUST
Invariant: Address-type and ID-number rules accept/reject/escalate exactly per configuration; malformed IDs are rejected and non-US persons follow the alternative-ID path.

Source check `PAT-CIP-02` from `checks.json` (behavioural; deterministic: yes). Covers: CIP · Missing CIP · USA PATRIOT Act. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-AML-007.

## Rule PAT-CIP-03: Unverified accounts are restricted and then closed/escalated at the configured window end (contro...
Severity: HIGH
Category: MM
Scenario: cip
Requirement: MUST
Invariant: Unverified accounts are restricted and then closed/escalated at the configured window end (controllable clock); fallback verification outcomes are recorded.

Source check `PAT-CIP-03` from `checks.json` (behavioural; deterministic: yes). Covers: CIP · Missing CIP · USA PATRIOT Act. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-AML-007.

## Rule PAT-CIP-04: A verification result applies only to the data verified
Severity: HIGH
Category: MM
Scenario: cip
Requirement: MUST
Invariant: A verification result applies only to the data verified; editing identity data during pending verification re-triggers verification.

Source check `PAT-CIP-04` from `checks.json` (behavioural; deterministic: yes). Covers: CIP · Missing CIP · USA PATRIOT Act. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-AML-007.

## Rule PAT-CIP-53: Identity-field update paths reset the verification status to pending
Severity: HIGH
Category: MM
Scenario: cip
Requirement: MUST
Invariant: Identity-field update paths reset the verification status to pending.

Source check `PAT-CIP-53` from `checks.json` (static, static backstop; deterministic: yes). Covers: CIP · Missing CIP · USA PATRIOT Act. Backstop for PAT-CIP-04. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-AML-007.

## Rule PAT-CIP-05: ID-verification vendor outage holds account opening — no unverified opening
Severity: HIGH
Category: MM
Scenario: cip
Requirement: MUST
Invariant: ID-verification vendor outage holds account opening — no unverified opening.

Source check `PAT-CIP-05` from `checks.json` (behavioural; deterministic: yes). Covers: CIP · Missing CIP · USA PATRIOT Act. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-AML-007.

## Rule PAT-CIP-52: ID-verification vendor error handling never marks an identity verified
Severity: HIGH
Category: MM
Scenario: cip
Requirement: MUST
Invariant: ID-verification vendor error handling never marks an identity verified.

Source check `PAT-CIP-52` from `checks.json` (static, static backstop; deterministic: yes). Covers: CIP · Missing CIP · USA PATRIOT Act. Backstop for PAT-CIP-05. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-AML-007.

## Rule PAT-CIP-06: Applicants matching government lists during CIP are routed to compliance before opening
Severity: HIGH
Category: MM
Scenario: cip
Requirement: MUST
Invariant: Applicants matching government lists during CIP are routed to compliance before opening.

Source check `PAT-CIP-06` from `checks.json` (behavioural; deterministic: yes). Covers: CIP · Missing CIP · USA PATRIOT Act. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-AML-007, RR-OFAC-001.

## Rule PAT-CDD-01: Every customer past its risk-tier refresh interval is queued exactly at the configured interval —...
Severity: HIGH
Category: MM
Scenario: cdd
Requirement: MUST
Invariant: Every customer past its risk-tier refresh interval is queued exactly at the configured interval — including reviews that came due during a scheduler outage.

Source check `PAT-CDD-01` from `checks.json` (behavioural; deterministic: yes). Covers: CDD · stale CDD · USA PATRIOT Act. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-AML-001.

## Rule PAT-CDD-51: The CDD refresh scheduler selects by due date ≤ now (catch-up), not by date = today
Severity: HIGH
Category: MM
Scenario: cdd
Requirement: MUST
Invariant: The CDD refresh scheduler selects by due date ≤ now (catch-up), not by date = today.

Source check `PAT-CDD-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: CDD · stale CDD · USA PATRIOT Act. Backstop for PAT-CDD-01. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-AML-001.

## Rule PAT-CDD-02: Trigger events recompute the versioned risk rating and the monitoring tier uses the stricter thre...
Severity: HIGH
Category: MM
Scenario: cdd
Requirement: MUST
Invariant: Trigger events recompute the versioned risk rating and the monitoring tier uses the stricter thresholds immediately.

Source check `PAT-CDD-02` from `checks.json` (behavioural; deterministic: yes). Covers: CDD · stale CDD · USA PATRIOT Act. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-AML-001.

## Rule PAT-CDD-03: Activity deviating beyond the configured multiple of the expected profile raises a CDD review
Severity: HIGH
Category: MM
Scenario: cdd
Requirement: MUST
Invariant: Activity deviating beyond the configured multiple of the expected profile raises a CDD review; stale CDD restricts high-risk activity.

Source check `PAT-CDD-03` from `checks.json` (behavioural; deterministic: yes). Covers: CDD · stale CDD · USA PATRIOT Act. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-AML-001.

## Rule PAT-CDD-04: A refresh racing a profile update uses the latest data or restarts
Severity: HIGH
Category: MM
Scenario: cdd
Requirement: MUST
Invariant: A refresh racing a profile update uses the latest data or restarts.

Source check `PAT-CDD-04` from `checks.json` (behavioural; deterministic: yes). Covers: CDD · stale CDD · USA PATRIOT Act. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-AML-001.

## Rule PAT-CDD-05: FinCEN 314(a) matches create response tasks before the configured deadline
Severity: HIGH
Category: MM
Scenario: cdd
Requirement: MUST
Invariant: FinCEN 314(a) matches create response tasks before the configured deadline.

Source check `PAT-CDD-05` from `checks.json` (behavioural; deterministic: yes). Covers: CDD · None · USA PATRIOT Act. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-AML-013.

## Rule PAT-EDD-01: Each EDD trigger (incl
Severity: HIGH
Category: MM
Scenario: edd
Requirement: MUST
Invariant: Each EDD trigger (incl. a PEP hit) opens exactly one case, raises the risk rating and holds restricted activity until approval.

Source check `PAT-EDD-01` from `checks.json` (behavioural; deterministic: yes). Covers: EDD · None · USA PATRIOT Act. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-AML-001.

## Rule PAT-EDD-02: Only a qualified approver who is not the case owner can approve EDD
Severity: HIGH
Category: MM
Scenario: edd
Requirement: MUST
Invariant: Only a qualified approver who is not the case owner can approve EDD.

Source check `PAT-EDD-02` from `checks.json` (behavioural; deterministic: yes). Covers: EDD · None · USA PATRIOT Act. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-AML-001.

## Rule PAT-EDD-51: The EDD approval handler rejects approver = case owner and checks the qualified-approver role
Severity: HIGH
Category: MM
Scenario: edd
Requirement: MUST
Invariant: The EDD approval handler rejects approver = case owner and checks the qualified-approver role.

Source check `PAT-EDD-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: EDD · None · USA PATRIOT Act. Backstop for PAT-EDD-02. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-AML-001.

## Rule PAT-EDD-03: High-risk periodic reviews queue on the due date
Severity: HIGH
Category: MM
Scenario: edd
Requirement: MUST
Invariant: High-risk periodic reviews queue on the due date; stalled cases escalate and held activity stays held — no auto-approval on timeout.

Source check `PAT-EDD-03` from `checks.json` (behavioural; deterministic: yes). Covers: EDD · None · USA PATRIOT Act. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-AML-001.

## Rule PAT-BO-01: Legal-entity onboarding completes only after all owners at/above the configured threshold plus a...
Severity: HIGH
Category: MM
Scenario: beneficial-ownership
Requirement: MUST
Invariant: Legal-entity onboarding completes only after all owners at/above the configured threshold plus a control person are captured, identity-verified and screened; failure holds the account.

Source check `PAT-BO-01` from `checks.json` (behavioural; deterministic: yes). Covers: Beneficial ownership · None · USA PATRIOT Act. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-AML-008.

## Rule PAT-BO-51: Entity activation checks that owner records meet the configured threshold rule plus ≥1 control pe...
Severity: HIGH
Category: MM
Scenario: beneficial-ownership
Requirement: MUST
Invariant: Entity activation checks that owner records meet the configured threshold rule plus ≥1 control person, each verified and screened.

Source check `PAT-BO-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: Beneficial ownership · None · USA PATRIOT Act. Backstop for PAT-BO-01. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-AML-008.

## Rule PAT-BO-02: Trusts/complex structures capture the configured required parties or route to review
Severity: HIGH
Category: MM
Scenario: beneficial-ownership
Requirement: MUST
Invariant: Trusts/complex structures capture the configured required parties or route to review; re-certification falls due on cadence and overdue entities are restricted.

Source check `PAT-BO-02` from `checks.json` (behavioural; deterministic: yes). Covers: Beneficial ownership · None · USA PATRIOT Act. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-AML-008.

## Rule PAT-BO-03: Simultaneous owner edits are versioned, none lost
Severity: HIGH
Category: MM
Scenario: beneficial-ownership
Requirement: MUST
Invariant: Simultaneous owner edits are versioned, none lost.

Source check `PAT-BO-03` from `checks.json` (behavioural; deterministic: yes). Covers: Beneficial ownership · None · USA PATRIOT Act. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-AML-008.
