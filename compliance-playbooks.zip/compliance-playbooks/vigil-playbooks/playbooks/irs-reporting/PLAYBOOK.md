---
helixPlaybookFormat: helix-playbook/0.1-proposal
playbookId: vigil-irs-reporting
title: "IRS Information Reporting & Backup Withholding"
declaredVersion: 0.1.0
intent: draft
applicability:
  languages: [javascript, typescript]
  scenarios: [s-1099, s-1098, s-1099-k, backup-withholding]
---
# Helix portable playbook — DRAFT manifest · IRS Information Reporting & Backup Withholding

> **DRAFT — not LOCKED.** Proposed IRS Reporting (Tax) playbook converted from Vigil skill `SK-IRS-001`: one runner, two layers, **10 harness checks (2 static, incl. 2 static backstops, + 8 behavioural)**, plus 4 manual/evidence items listed separately because neither layer can verify them. Every invariant, layer and determinism call is **AI-drafted (Helix) and needs compliance review**. No detector or rule code exists yet. Before this manifest can be LOCKED, each row needs its detector/rule, a review, and a commit that adds the check alongside its row.

## Layers

- **static**: a repo-agnostic source scanner parameterised by a `VIGIL_IRS` preset (no app specifics in the detector). It reads source / SQL / config / IaC / git-diff, **fails CLOSED** on a match, and runs with **no adapter**, so it is the CI gate. *Static backstops* (IDs `-5x`) prove a supporting source invariant for a named behavioural check, the way N-CAP-01 / N-STATE-01 back neobank behaviour. They fire even when the adapter never drives that path. Backstops of ⚑ SME checks stay out of the gate.
- **behavioural**: a rule written once against the canonical `MoneySystem` interface (or a DRAFT extension surface in `adapters/`) and driven through the app adapter. Surfaces needed: **TaxReportingSystem** (`adapters/tax-reporting.ts`). Every behavioural row reports NOT_EXERCISED until an adapter implements its surface. It returns **CHECKED only when it actually drove the guard's path**.
- **manual/evidence**: organisational process, live-infrastructure, statistical or retention evidence that no source scan or adapter-driven rule can prove. These are **outside the harness**, report `NOT_APPLICABLE` to it, and are tracked as evidence tasks, never as passes.

## Verdicts

`CHECKED` the path ran and the guard held · `FINDING` the guard was violated · `NOT_APPLICABLE` the invariant cannot apply here (incl. every manual/evidence item) · `NOT_EXERCISED` (glyph `????`) the adapter did not drive the path, so nothing is proven. NOT_EXERCISED is **surfaced distinctly and never counted as a pass** (no fake coverage). A ⚑ SME check with no approved parameter matrix reports `NOT_EXERCISED`, never `CHECKED`.

## How to run

- **Not runnable yet**: this draft defines invariants only (no detector/rule code). The intended shape mirrors the neobank playbook:
  - CI gate (adapter-free, blocks on any static FINDING): `run-static` with preset `VIGIL_IRS`.
  - Full combined table (static + behavioural via the adapter): `run-all`.
- Machine-readable rows: `checks.json` (same IDs; includes source-scenario traceability and neobank overlaps).

## The draft inventory: 2 static + 8 behavioural = 10 checks

| ID | Layer | Deterministic | Invariant (one line) | Covers (automation point · common failure · regulation) |
| --- | --- | --- | --- | --- |
| **IRS-1099-01** | behavioural | yes | A 1099-INT/DIV is issued for every account at/above the configured threshold (none below) with box amounts equal to ledger amounts per payee; mismatches block filing. | 1099 · Missing 1099 · IRS Reporting |
| **IRS-1099-51** | static | yes | Form box amounts are computed from ledger queries (single source), not separate accumulators. | backstop for IRS-1099-01 · 1099 · Missing 1099 · IRS Reporting |
| **IRS-1099-02** | behavioural | yes | Transactions are attributed to the tax year per the configured paid/credited rule; year-end reruns are idempotent; post-filing adjustments issue a corrected form and retain the original. | 1099 · wrong amount · IRS Reporting |
| **IRS-1098-01** | behavioural | yes | A 1098 is generated for every eligible loan at the configured threshold with mortgage interest equal to interest received (concurrent postings counted once); missing TIN starts solicitation. | 1098 · wrong amount · IRS Reporting |
| **IRS-1098-02** | behavioural | yes | A payment reversal produces a corrected 1098 with the original retained and borrower statement updated. | 1098 · wrong amount · IRS Reporting |
| **IRS-1099K-01** | behavioural | yes | 1099-K reportability follows the versioned configured threshold aggregated per payee TIN; gross includes refunds/chargebacks per rule (no netting) and monthly boxes sum exactly to annual gross. | 1099-K · wrong amount · IRS Reporting |
| **IRS-1099K-02** | behavioural | yes | A processor data-feed gap is flagged and no partial form is produced. | 1099-K · wrong amount · IRS Reporting |
| **IRS-BW-01** | behavioural | yes | Backup withholding applies at the configured rate only to flagged accounts, exactly once per payment under concurrency, and the withheld box equals the ledger. | Backup withholding · wrong amount · IRS Reporting |
| **IRS-BW-51** | static | yes | Backup withholding is computed once per payment ID (unique constraint) at the configured rate. | backstop for IRS-BW-01 · Backup withholding · wrong amount · IRS Reporting |
| **IRS-BW-02** | behavioural | yes | A mismatch notice starts solicitation and withholding per the configured timeline; a valid certified TIN stops it at the configured boundary with no over-withholding. | Backup withholding · wrong amount · IRS Reporting |

## Outside the harness: manual/evidence (4)

These items are not harness checks. Each reports `NOT_APPLICABLE` to the runner and needs an owner and evidence on a schedule.

| ID | Layer | Deterministic | Invariant (one line) | Covers (automation point · common failure · regulation) |
| --- | --- | --- | --- | --- |
| **IRS-1099-03** | manual/evidence | no (manual) | Forms and filings are retained. | 1099 · general control (no source failure) · IRS Reporting |
| **IRS-1098-03** | manual/evidence | no (manual) | 1098 records are retained. | 1098 · general control (no source failure) · IRS Reporting |
| **IRS-1099K-03** | manual/evidence | no (manual) | 1099-K records are retained. | 1099-K · general control (no source failure) · IRS Reporting |
| **IRS-BW-03** | manual/evidence | no (manual) | TIN certifications and filed forms are retained and linked to the account. | Backup withholding · general control (no source failure) · IRS Reporting |

### Determinism

Every harness row (static and behavioural) is drafted as deterministic. Static detectors, including backstops, are pure functions of the committed source/config/diff. Behavioural rules each run against a **fresh `reset()` MoneySystem** (no state leaks between rules), driven by a **controllable clock**; deadlines, windows, expiries and cadences are asserted by advancing that clock, never by wall-clock reads, and no randomness affects a verdict. External dependencies (vendors, registries, feeds) are faked inside the adapter, which is how fault-injection rows stay deterministic. Manual/evidence rows are not deterministic and are not gate checks.

### Coverage note

Converted from 34 AI-drafted source scenarios of `SK-IRS-001`; each source scenario maps to exactly one non-backstop row (see the appendix). Static backstops add no scenarios and trace through the check they back. The scenarios were merged into crisp invariants by automation point and failure mode, across categories (positive, negative, boundary, failure/recovery, concurrency/idempotency, retention/audit, common failure, core). Automation points covered: 1099, 1098, 1099-K, Backup withholding. Source common failures: Missing 1099, wrong amount. Thresholds, windows and deadlines are *configured* parameters, not asserted statutory values. No regulation or citation was added beyond the source sheet.

### Overlap with the locked neobank playbook (19 checks)

| This check | Neobank check | Strength | Why |
| --- | --- | --- | --- |
| IRS-1099-01 | LEDGER-CONSERVE | related | form amounts = ledger |
| IRS-1098-01 | LEDGER-CONSERVE | related | 1098 = interest received |
| IRS-BW-01 | N-IDEMP-01 | related | withholding once per payment |
| IRS-BW-51 | N-IDEMP-01 | related | unique-key dedupe on the write path |

`same` means the neobank check already enforces this invariant, so reuse it instead of re-implementing. `related` means the same defect class, but this check needs its own rule or preset.

### Review flags

- No SME-flagged rows. All rows still need compliance review.

## Appendix: traceability to source scenarios

| Check ID | Source scenario IDs | Categories merged |
| --- | --- | --- |
| IRS-1099-01 | SC-IRS-001-01, SC-IRS-001-02, SC-IRS-001-04, SC-IRS-001-05, SC-IRS-001-19, SC-IRS-001-20 | Boundary/Edge, Common Failure, Core, Negative, Positive |
| IRS-1099-51 | — (static backstop; traced via IRS-1099-01) | — |
| IRS-1099-02 | SC-IRS-001-07, SC-IRS-001-21, SC-IRS-001-06 | Boundary/Edge, Concurrency/Idempotency, Failure/Recovery |
| IRS-1099-03 | SC-IRS-001-22 | Retention/Audit |
| IRS-1098-01 | SC-IRS-001-08, SC-IRS-001-27, SC-IRS-001-26, SC-IRS-001-23, SC-IRS-001-24, SC-IRS-001-09 | Boundary/Edge, Common Failure, Concurrency/Idempotency, Core, Negative, Positive |
| IRS-1098-02 | SC-IRS-001-16 | Failure/Recovery |
| IRS-1098-03 | SC-IRS-001-25 | Retention/Audit |
| IRS-1099K-01 | SC-IRS-001-10, SC-IRS-001-31, SC-IRS-001-17, SC-IRS-001-11, SC-IRS-001-29, SC-IRS-001-18 | Boundary/Edge, Common Failure, Concurrency/Idempotency, Core, Negative, Positive |
| IRS-1099K-02 | SC-IRS-001-28 | Failure/Recovery |
| IRS-1099K-03 | SC-IRS-001-30 | Retention/Audit |
| IRS-BW-01 | SC-IRS-001-03, SC-IRS-001-14, SC-IRS-001-34 | Common Failure, Concurrency/Idempotency, Core |
| IRS-BW-51 | — (static backstop; traced via IRS-BW-01) | — |
| IRS-BW-02 | SC-IRS-001-13, SC-IRS-001-12, SC-IRS-001-32, SC-IRS-001-33 | Boundary/Edge, Failure/Recovery, Negative, Positive |
| IRS-BW-03 | SC-IRS-001-15 | Retention/Audit |

# Helix review rules

Generated from `checks.json` (10 static and behavioural checks; manual/evidence items are not code-reviewable and are omitted). Severity is derived from the playbook priority (P1 -> MEDIUM); Category MM marks money-movement checks. Rule text is the source invariant, unchanged; it is AI-drafted and needs compliance review.

## Rule IRS-1099-01: A 1099-INT/DIV is issued for every account at/above the configured threshold (none below) with bo...
Severity: MEDIUM
Category: NON_MM
Scenario: s-1099
Requirement: MUST
Invariant: A 1099-INT/DIV is issued for every account at/above the configured threshold (none below) with box amounts equal to ledger amounts per payee; mismatches block filing.

Source check `IRS-1099-01` from `checks.json` (behavioural; deterministic: yes). Covers: 1099 · Missing 1099 · IRS Reporting. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-IRS-001, RR-IRS-007.

## Rule IRS-1099-51: Form box amounts are computed from ledger queries (single source), not separate accumulators
Severity: MEDIUM
Category: NON_MM
Scenario: s-1099
Requirement: MUST
Invariant: Form box amounts are computed from ledger queries (single source), not separate accumulators.

Source check `IRS-1099-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: 1099 · Missing 1099 · IRS Reporting. Backstop for IRS-1099-01. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-IRS-001, RR-IRS-007.

## Rule IRS-1099-02: Transactions are attributed to the tax year per the configured paid/credited rule
Severity: MEDIUM
Category: NON_MM
Scenario: s-1099
Requirement: MUST
Invariant: Transactions are attributed to the tax year per the configured paid/credited rule; year-end reruns are idempotent; post-filing adjustments issue a corrected form and retain the original.

Source check `IRS-1099-02` from `checks.json` (behavioural; deterministic: yes). Covers: 1099 · wrong amount · IRS Reporting. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-IRS-001.

## Rule IRS-1098-01: A 1098 is generated for every eligible loan at the configured threshold with mortgage interest eq...
Severity: MEDIUM
Category: NON_MM
Scenario: s-1098
Requirement: MUST
Invariant: A 1098 is generated for every eligible loan at the configured threshold with mortgage interest equal to interest received (concurrent postings counted once); missing TIN starts solicitation.

Source check `IRS-1098-01` from `checks.json` (behavioural; deterministic: yes). Covers: 1098 · wrong amount · IRS Reporting. Review status in source: Drafted (AI) – needs compliance review.

## Rule IRS-1098-02: A payment reversal produces a corrected 1098 with the original retained and borrower statement up...
Severity: MEDIUM
Category: NON_MM
Scenario: s-1098
Requirement: MUST
Invariant: A payment reversal produces a corrected 1098 with the original retained and borrower statement updated.

Source check `IRS-1098-02` from `checks.json` (behavioural; deterministic: yes). Covers: 1098 · wrong amount · IRS Reporting. Review status in source: Drafted (AI) – needs compliance review.

## Rule IRS-1099K-01: 1099-K reportability follows the versioned configured threshold aggregated per payee TIN
Severity: MEDIUM
Category: NON_MM
Scenario: s-1099-k
Requirement: MUST
Invariant: 1099-K reportability follows the versioned configured threshold aggregated per payee TIN; gross includes refunds/chargebacks per rule (no netting) and monthly boxes sum exactly to annual gross.

Source check `IRS-1099K-01` from `checks.json` (behavioural; deterministic: yes). Covers: 1099-K · wrong amount · IRS Reporting. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-IRS-004.

## Rule IRS-1099K-02: A processor data-feed gap is flagged and no partial form is produced
Severity: MEDIUM
Category: NON_MM
Scenario: s-1099-k
Requirement: MUST
Invariant: A processor data-feed gap is flagged and no partial form is produced.

Source check `IRS-1099K-02` from `checks.json` (behavioural; deterministic: yes). Covers: 1099-K · wrong amount · IRS Reporting. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-IRS-004.

## Rule IRS-BW-01: Backup withholding applies at the configured rate only to flagged accounts, exactly once per paym...
Severity: MEDIUM
Category: NON_MM
Scenario: backup-withholding
Requirement: MUST
Invariant: Backup withholding applies at the configured rate only to flagged accounts, exactly once per payment under concurrency, and the withheld box equals the ledger.

Source check `IRS-BW-01` from `checks.json` (behavioural; deterministic: yes). Covers: Backup withholding · wrong amount · IRS Reporting. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-IRS-006.

## Rule IRS-BW-51: Backup withholding is computed once per payment ID (unique constraint) at the configured rate
Severity: MEDIUM
Category: NON_MM
Scenario: backup-withholding
Requirement: MUST
Invariant: Backup withholding is computed once per payment ID (unique constraint) at the configured rate.

Source check `IRS-BW-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: Backup withholding · wrong amount · IRS Reporting. Backstop for IRS-BW-01. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-IRS-006.

## Rule IRS-BW-02: A mismatch notice starts solicitation and withholding per the configured timeline
Severity: MEDIUM
Category: NON_MM
Scenario: backup-withholding
Requirement: MUST
Invariant: A mismatch notice starts solicitation and withholding per the configured timeline; a valid certified TIN stops it at the configured boundary with no over-withholding.

Source check `IRS-BW-02` from `checks.json` (behavioural; deterministic: yes). Covers: Backup withholding · wrong amount · IRS Reporting. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-IRS-006.
