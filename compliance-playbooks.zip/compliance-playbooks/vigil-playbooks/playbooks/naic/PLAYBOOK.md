---
helixPlaybookFormat: helix-playbook/0.1-proposal
playbookId: vigil-naic
title: "NAIC RBC, Statutory Reporting & Exam Readiness"
declaredVersion: 0.1.0
intent: draft
applicability:
  languages: [javascript, typescript]
  scenarios: [financial-reporting, risk-based-capital]
---
# Helix portable playbook — DRAFT manifest · NAIC RBC, Statutory Reporting & Exam Readiness

> **DRAFT — not LOCKED.** Proposed NAIC (Insurance) playbook converted from Vigil skill `SK-NAIC-001`: one runner, two layers, **5 harness checks (1 static, incl. 1 static backstops, + 4 behavioural)**, plus 4 manual/evidence items listed separately because neither layer can verify them. Every invariant, layer and determinism call is **AI-drafted (Helix) and needs compliance review**; 3 check(s) are **⚑ SME-flagged** and cannot gate until an SME/counsel supplies their parameter matrix. No detector or rule code exists yet. Before this manifest can be LOCKED, each row needs its detector/rule, a review, and a commit that adds the check alongside its row.

## Layers

- **static**: a repo-agnostic source scanner parameterised by a `VIGIL_NAIC` preset (no app specifics in the detector). It reads source / SQL / config / IaC / git-diff, **fails CLOSED** on a match, and runs with **no adapter**, so it is the CI gate. *Static backstops* (IDs `-5x`) prove a supporting source invariant for a named behavioural check, the way N-CAP-01 / N-STATE-01 back neobank behaviour. They fire even when the adapter never drives that path. Backstops of ⚑ SME checks stay out of the gate.
- **behavioural**: a rule written once against the canonical `MoneySystem` interface (or a DRAFT extension surface in `adapters/`) and driven through the app adapter. Surfaces needed: **InsuranceSystem** (`adapters/insurance.ts`), **CapitalEngine** (`adapters/capital-engine.ts`). Every behavioural row reports NOT_EXERCISED until an adapter implements its surface. It returns **CHECKED only when it actually drove the guard's path**.
- **manual/evidence**: organisational process, live-infrastructure, statistical or retention evidence that no source scan or adapter-driven rule can prove. These are **outside the harness**, report `NOT_APPLICABLE` to it, and are tracked as evidence tasks, never as passes.

## Verdicts

`CHECKED` the path ran and the guard held · `FINDING` the guard was violated · `NOT_APPLICABLE` the invariant cannot apply here (incl. every manual/evidence item) · `NOT_EXERCISED` (glyph `????`) the adapter did not drive the path, so nothing is proven. NOT_EXERCISED is **surfaced distinctly and never counted as a pass** (no fake coverage). A ⚑ SME check with no approved parameter matrix reports `NOT_EXERCISED`, never `CHECKED`.

## How to run

- **Not runnable yet**: this draft defines invariants only (no detector/rule code). The intended shape mirrors the neobank playbook:
  - CI gate (adapter-free, blocks on any static FINDING): `run-static` with preset `VIGIL_NAIC`.
  - Full combined table (static + behavioural via the adapter): `run-all`.
- Machine-readable rows: `checks.json` (same IDs; includes source-scenario traceability and neobank overlaps).

## The draft inventory: 1 static + 4 behavioural = 5 checks

| ID | Layer | Deterministic | Invariant (one line) | Covers (automation point · common failure · regulation) |
| --- | --- | --- | --- | --- |
| **NAIC-FIN-01** | behavioural | yes | Statutory statement lines reconcile to the GL within tolerance and cross-foot, built from a consistent snapshot; a late GL close keeps the statement draft. | Financial reporting · late filing · NAIC |
| **NAIC-FIN-02** | behavioural | yes | Filing format errors are caught pre-submission; deadlines escalate and late filings are flagged (controllable clock). | Financial reporting / Examination · late filing · NAIC |
| **NAIC-RBC-01** | behavioural | yes ⚑ SME | The RBC ratio computed via the SME parameter matrix matches the reference workbook, is idempotent, and assigns the correct action level with alerts and escalation at configured levels. | Risk-based capital · RBC shortfall · NAIC |
| **NAIC-RBC-02** | behavioural | yes ⚑ SME | Missing RBC factors or input data fail the run or flag conservatively — never a silent zero. | Risk-based capital · RBC shortfall · NAIC |
| **NAIC-RBC-51** | static | yes ⚑ SME | Every RBC asset class has a factor entry; a missing factor raises rather than defaulting to zero. | backstop for NAIC-RBC-02 · Risk-based capital · RBC shortfall · NAIC |

## Outside the harness: manual/evidence (4)

These items are not harness checks. Each reports `NOT_APPLICABLE` to the runner and needs an owner and evidence on a schedule.

| ID | Layer | Deterministic | Invariant (one line) | Covers (automation point · common failure · regulation) |
| --- | --- | --- | --- | --- |
| **NAIC-FIN-03** | manual/evidence | no (manual) | Statement filings and workpapers are retained. | Financial reporting · general control (no source failure) · NAIC |
| **NAIC-RBC-03** | manual/evidence | no (manual) | RBC parameter versions are retained and linked to each run. | Risk-based capital · general control (no source failure) · NAIC |
| **NAIC-EXM-01** | manual/evidence | no (manual) | Exam request items are produced from the evidence store within the configured time with owner and timestamp; missing items flag as gaps; concurrent pulls return identical versioned evidence; overdue items escalate. | Examination · late filing · NAIC |
| **NAIC-EXM-02** | manual/evidence | no (manual) | Prior exam findings remain open until remediation evidence is attached. | Examination · general control (no source failure) · NAIC |

### Determinism

Every harness row (static and behavioural) is drafted as deterministic. Static detectors, including backstops, are pure functions of the committed source/config/diff. Behavioural rules each run against a **fresh `reset()` MoneySystem** (no state leaks between rules), driven by a **controllable clock**; deadlines, windows, expiries and cadences are asserted by advancing that clock, never by wall-clock reads, and no randomness affects a verdict. External dependencies (vendors, registries, feeds) are faked inside the adapter, which is how fault-injection rows stay deterministic. Manual/evidence rows are not deterministic and are not gate checks. ⚑ SME rows are deterministic once parameters exist, but are excluded from the gate until then.

### Coverage note

Converted from 24 AI-drafted source scenarios of `SK-NAIC-001`; each source scenario maps to exactly one non-backstop row (see the appendix). Static backstops add no scenarios and trace through the check they back. The scenarios were merged into crisp invariants by automation point and failure mode, across categories (positive, negative, boundary, failure/recovery, concurrency/idempotency, retention/audit, common failure, core). Automation points covered: Financial reporting, Risk-based capital, Examination. Source common failures: RBC shortfall, late filing. Thresholds, windows and deadlines are *configured* parameters, not asserted statutory values. No regulation or citation was added beyond the source sheet.

### Overlap with the locked neobank playbook (19 checks)

| This check | Neobank check | Strength | Why |
| --- | --- | --- | --- |
| NAIC-FIN-01 | LEDGER-CONSERVE | related | statement ties to GL |

`same` means the neobank check already enforces this invariant, so reuse it instead of re-implementing. `related` means the same defect class, but this check needs its own rule or preset.

### Review flags

- ⚑ **NAIC-RBC-01**: needs an SME/counsel parameter matrix (source scenarios carry review status "+ SME input").
- ⚑ **NAIC-RBC-02**: needs an SME/counsel parameter matrix (source scenarios carry review status "+ SME input").
- ⚑ **NAIC-RBC-51**: needs an SME/counsel parameter matrix (source scenarios carry review status "+ SME input").

## Appendix: traceability to source scenarios

| Check ID | Source scenario IDs | Categories merged |
| --- | --- | --- |
| NAIC-FIN-01 | SC-NAIC-001-02, SC-NAIC-001-04, SC-NAIC-001-11, SC-NAIC-001-13, SC-NAIC-001-12 | Boundary/Edge, Concurrency/Idempotency, Core, Failure/Recovery, Positive |
| NAIC-FIN-02 | SC-NAIC-001-06, SC-NAIC-001-05, SC-NAIC-001-24 | Common Failure, Negative |
| NAIC-FIN-03 | SC-NAIC-001-14 | Retention/Audit |
| NAIC-RBC-01 | SC-NAIC-001-01, SC-NAIC-001-15, SC-NAIC-001-17, SC-NAIC-001-07, SC-NAIC-001-19 | Boundary/Edge, Common Failure, Concurrency/Idempotency, Core, Positive |
| NAIC-RBC-02 | SC-NAIC-001-08, SC-NAIC-001-16 | Failure/Recovery, Negative |
| NAIC-RBC-51 | — (static backstop; traced via NAIC-RBC-02) | — |
| NAIC-RBC-03 | SC-NAIC-001-18 | Retention/Audit |
| NAIC-EXM-01 | SC-NAIC-001-03, SC-NAIC-001-09, SC-NAIC-001-20, SC-NAIC-001-22, SC-NAIC-001-23, SC-NAIC-001-21 | Boundary/Edge, Concurrency/Idempotency, Core, Failure/Recovery, Positive, Retention/Audit |
| NAIC-EXM-02 | SC-NAIC-001-10 | Negative |

# Helix review rules

Generated from `checks.json` (5 static and behavioural checks; manual/evidence items are not code-reviewable and are omitted). Severity is derived from the playbook priority (P2 -> LOW); Category MM marks money-movement checks. Rule text is the source invariant, unchanged; it is AI-drafted and needs compliance review.

## Rule NAIC-FIN-01: Statutory statement lines reconcile to the GL within tolerance and cross-foot, built from a consi...
Severity: LOW
Category: NON_MM
Scenario: financial-reporting
Requirement: MUST
Invariant: Statutory statement lines reconcile to the GL within tolerance and cross-foot, built from a consistent snapshot; a late GL close keeps the statement draft.

Source check `NAIC-FIN-01` from `checks.json` (behavioural; deterministic: yes). Covers: Financial reporting · late filing · NAIC. Review status in source: Drafted (AI) – needs compliance review.

## Rule NAIC-FIN-02: Filing format errors are caught pre-submission
Severity: LOW
Category: NON_MM
Scenario: financial-reporting
Requirement: MUST
Invariant: Filing format errors are caught pre-submission; deadlines escalate and late filings are flagged (controllable clock).

Source check `NAIC-FIN-02` from `checks.json` (behavioural; deterministic: yes). Covers: Financial reporting, Examination · late filing · NAIC. Review status in source: Drafted (AI) – needs compliance review.

## Rule NAIC-RBC-01: The RBC ratio computed via the SME parameter matrix matches the reference workbook, is idempotent...
Severity: LOW
Category: NON_MM
Scenario: risk-based-capital
Requirement: MUST
Invariant: The RBC ratio computed via the SME parameter matrix matches the reference workbook, is idempotent, and assigns the correct action level with alerts and escalation at configured levels.

Source check `NAIC-RBC-01` from `checks.json` (behavioural; deterministic: yes). Covers: Risk-based capital · RBC shortfall · NAIC. Flagged for SME input in the source; needs an approved parameter matrix. Review status in source: Drafted (AI) – needs compliance review + SME input.

## Rule NAIC-RBC-02: Missing RBC factors or input data fail the run or flag conservatively — never a silent zero
Severity: LOW
Category: NON_MM
Scenario: risk-based-capital
Requirement: MUST
Invariant: Missing RBC factors or input data fail the run or flag conservatively — never a silent zero.

Source check `NAIC-RBC-02` from `checks.json` (behavioural; deterministic: yes). Covers: Risk-based capital · RBC shortfall · NAIC. Flagged for SME input in the source; needs an approved parameter matrix. Review status in source: Drafted (AI) – needs compliance review + SME input.

## Rule NAIC-RBC-51: Every RBC asset class has a factor entry
Severity: LOW
Category: NON_MM
Scenario: risk-based-capital
Requirement: MUST
Invariant: Every RBC asset class has a factor entry; a missing factor raises rather than defaulting to zero.

Source check `NAIC-RBC-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: Risk-based capital · RBC shortfall · NAIC. Backstop for NAIC-RBC-02. Flagged for SME input in the source; needs an approved parameter matrix. Review status in source: Drafted (AI) – needs compliance review + SME input.
