---
helixPlaybookFormat: helix-playbook/0.1-proposal
playbookId: vigil-ucc-article-4
title: "UCC Art. 4 Check Encoding, Returns & Notice"
declaredVersion: 0.1.0
intent: draft
applicability:
  languages: [javascript, typescript]
  scenarios: [check-processing, returned-items, notice]
---
# Helix portable playbook — DRAFT manifest · UCC Art. 4 Check Encoding, Returns & Notice

> **DRAFT — not LOCKED.** Proposed UCC Article 4 (Payments) playbook converted from Vigil skill `SK-UCC4-001`: one runner, two layers, **8 harness checks (2 static, incl. 2 static backstops, + 6 behavioural)**, plus 3 manual/evidence items listed separately because neither layer can verify them. Every invariant, layer and determinism call is **AI-drafted (Helix) and needs compliance review**. No detector or rule code exists yet. Before this manifest can be LOCKED, each row needs its detector/rule, a review, and a commit that adds the check alongside its row.

## Layers

- **static**: a repo-agnostic source scanner parameterised by a `VIGIL_UCC4` preset (no app specifics in the detector). It reads source / SQL / config / IaC / git-diff, **fails CLOSED** on a match, and runs with **no adapter**, so it is the CI gate. *Static backstops* (IDs `-5x`) prove a supporting source invariant for a named behavioural check, the way N-CAP-01 / N-STATE-01 back neobank behaviour. They fire even when the adapter never drives that path. Backstops of ⚑ SME checks stay out of the gate.
- **behavioural**: a rule written once against the canonical `MoneySystem` interface (or a DRAFT extension surface in `adapters/`) and driven through the app adapter. Surfaces needed: **CheckSystem** (`adapters/checks.ts`). Every behavioural row reports NOT_EXERCISED until an adapter implements its surface. It returns **CHECKED only when it actually drove the guard's path**.
- **manual/evidence**: organisational process, live-infrastructure, statistical or retention evidence that no source scan or adapter-driven rule can prove. These are **outside the harness**, report `NOT_APPLICABLE` to it, and are tracked as evidence tasks, never as passes.

## Verdicts

`CHECKED` the path ran and the guard held · `FINDING` the guard was violated · `NOT_APPLICABLE` the invariant cannot apply here (incl. every manual/evidence item) · `NOT_EXERCISED` (glyph `????`) the adapter did not drive the path, so nothing is proven. NOT_EXERCISED is **surfaced distinctly and never counted as a pass** (no fake coverage). A ⚑ SME check with no approved parameter matrix reports `NOT_EXERCISED`, never `CHECKED`.

## How to run

- **Not runnable yet**: this draft defines invariants only (no detector/rule code). The intended shape mirrors the neobank playbook:
  - CI gate (adapter-free, blocks on any static FINDING): `run-static` with preset `VIGIL_UCC4`.
  - Full combined table (static + behavioural via the adapter): `run-all`.
- Machine-readable rows: `checks.json` (same IDs; includes source-scenario traceability and neobank overlaps).

## The draft inventory: 2 static + 6 behavioural = 8 checks

| ID | Layer | Deterministic | Invariant (one line) | Covers (automation point · common failure · regulation) |
| --- | --- | --- | --- | --- |
| **UCC4-CHK-01** | behavioural | yes | Encoded amount and routing/account match the check image/MICR; mismatches and low-confidence amount reads route to exception/manual review before posting. | Check processing · Encoding error · UCC Article 4 |
| **UCC4-CHK-02** | behavioural | yes | A duplicate presentment is blocked/flagged with no double credit. | Check processing · Encoding error · UCC Article 4 |
| **UCC4-CHK-51** | static | yes | Deposits dedupe on an item fingerprint (routing, account, serial, amount) with a unique constraint. | backstop for UCC4-CHK-02 · Check processing · Encoding error · UCC Article 4 |
| **UCC4-CHK-03** | behavioural | yes | A valid deposit posts with the configured hold; image-service outage queues the deposit and nothing posts without an image. | Check processing · Encoding error · UCC Article 4 |
| **UCC4-RET-01** | behavioural | yes | Each returned item reverses its provisional credit and fees exactly once (duplicate return files processed once); returns for unknown items go to an exception queue, never a random reversal. | Returned items · late return · UCC Article 4 |
| **UCC4-RET-51** | static | yes | Returned-item reversal is keyed by a unique item ID; unknown items go to an exception queue. | backstop for UCC4-RET-01 · Returned items · late return · UCC Article 4 |
| **UCC4-RET-02** | behavioural | yes | Returns are initiated before the configured banking-day deadline; late returns are flagged. | Returned items · late return · UCC Article 4 |
| **UCC4-NOT-01** | behavioural | yes | A returned item produces one customer notice (per configured grouping) with reason and amount within the configured window, retried/alternate channel on failure; non-returned items produce none. | Notice · late return · UCC Article 4 |

## Outside the harness: manual/evidence (3)

These items are not harness checks. Each reports `NOT_APPLICABLE` to the runner and needs an owner and evidence on a schedule.

| ID | Layer | Deterministic | Invariant (one line) | Covers (automation point · common failure · regulation) |
| --- | --- | --- | --- | --- |
| **UCC4-CHK-04** | manual/evidence | no (manual) | Check images are retained. | Check processing · general control (no source failure) · UCC Article 4 |
| **UCC4-RET-03** | manual/evidence | no (manual) | Return records are retained. | Returned items · general control (no source failure) · UCC Article 4 |
| **UCC4-NOT-02** | manual/evidence | no (manual) | Statements and item images are retained. | Notice · general control (no source failure) · UCC Article 4 |

### Determinism

Every harness row (static and behavioural) is drafted as deterministic. Static detectors, including backstops, are pure functions of the committed source/config/diff. Behavioural rules each run against a **fresh `reset()` MoneySystem** (no state leaks between rules), driven by a **controllable clock**; deadlines, windows, expiries and cadences are asserted by advancing that clock, never by wall-clock reads, and no randomness affects a verdict. External dependencies (vendors, registries, feeds) are faked inside the adapter, which is how fault-injection rows stay deterministic. Manual/evidence rows are not deterministic and are not gate checks.

### Coverage note

Converted from 24 AI-drafted source scenarios of `SK-UCC4-001`; each source scenario maps to exactly one non-backstop row (see the appendix). Static backstops add no scenarios and trace through the check they back. The scenarios were merged into crisp invariants by automation point and failure mode, across categories (positive, negative, boundary, failure/recovery, concurrency/idempotency, retention/audit, common failure, core). Automation points covered: Check processing, Returned items, Notice. Source common failures: Encoding error, late return. Thresholds, windows and deadlines are *configured* parameters, not asserted statutory values. No regulation or citation was added beyond the source sheet.

### Overlap with the locked neobank playbook (19 checks)

| This check | Neobank check | Strength | Why |
| --- | --- | --- | --- |
| UCC4-CHK-02 | N-IDEMP-01 | related | no double credit on re-presentment |
| UCC4-CHK-51 | N-IDEMP-01 | related | unique-key dedupe on the write path |
| UCC4-RET-01 | N-CHGBK-05 | related | return reverses credit once |
| UCC4-RET-51 | N-IDEMP-01 | related | unique-key dedupe on the write path |

`same` means the neobank check already enforces this invariant, so reuse it instead of re-implementing. `related` means the same defect class, but this check needs its own rule or preset.

### Review flags

- No SME-flagged rows. All rows still need compliance review.

## Appendix: traceability to source scenarios

| Check ID | Source scenario IDs | Categories merged |
| --- | --- | --- |
| UCC4-CHK-01 | SC-UCC4-001-01, SC-UCC4-001-04, SC-UCC4-001-12 | Boundary/Edge, Common Failure, Core |
| UCC4-CHK-02 | SC-UCC4-001-05, SC-UCC4-001-11 | Concurrency/Idempotency, Negative |
| UCC4-CHK-51 | — (static backstop; traced via UCC4-CHK-02) | — |
| UCC4-CHK-03 | SC-UCC4-001-10, SC-UCC4-001-13 | Failure/Recovery, Positive |
| UCC4-CHK-04 | SC-UCC4-001-14 | Retention/Audit |
| UCC4-RET-01 | SC-UCC4-001-02, SC-UCC4-001-07, SC-UCC4-001-15, SC-UCC4-001-17, SC-UCC4-001-16 | Concurrency/Idempotency, Core, Failure/Recovery, Negative, Positive |
| UCC4-RET-51 | — (static backstop; traced via UCC4-RET-01) | — |
| UCC4-RET-02 | SC-UCC4-001-06, SC-UCC4-001-19 | Boundary/Edge, Common Failure |
| UCC4-RET-03 | SC-UCC4-001-18 | Retention/Audit |
| UCC4-NOT-01 | SC-UCC4-001-03, SC-UCC4-001-08, SC-UCC4-001-21, SC-UCC4-001-22, SC-UCC4-001-23, SC-UCC4-001-24, SC-UCC4-001-20 | Boundary/Edge, Common Failure, Concurrency/Idempotency, Core, Failure/Recovery, Negative, Positive |
| UCC4-NOT-02 | SC-UCC4-001-09 | Retention/Audit |

# Helix review rules

Generated from `checks.json` (8 static and behavioural checks; manual/evidence items are not code-reviewable and are omitted). Severity is derived from the playbook priority (P2 -> LOW); Category MM marks money-movement checks. Rule text is the source invariant, unchanged; it is AI-drafted and needs compliance review.

## Rule UCC4-CHK-01: Encoded amount and routing/account match the check image/MICR
Severity: LOW
Category: MM
Scenario: check-processing
Requirement: MUST
Invariant: Encoded amount and routing/account match the check image/MICR; mismatches and low-confidence amount reads route to exception/manual review before posting.

Source check `UCC4-CHK-01` from `checks.json` (behavioural; deterministic: yes). Covers: Check processing · Encoding error · UCC Article 4. Review status in source: Drafted (AI) – needs compliance review.

## Rule UCC4-CHK-02: A duplicate presentment is blocked/flagged with no double credit
Severity: LOW
Category: MM
Scenario: check-processing
Requirement: MUST
Invariant: A duplicate presentment is blocked/flagged with no double credit.

Source check `UCC4-CHK-02` from `checks.json` (behavioural; deterministic: yes). Covers: Check processing · Encoding error · UCC Article 4. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-REGCC-006, RR-FFIEC-005.

## Rule UCC4-CHK-51: Deposits dedupe on an item fingerprint (routing, account, serial, amount) with a unique constraint
Severity: LOW
Category: MM
Scenario: check-processing
Requirement: MUST
Invariant: Deposits dedupe on an item fingerprint (routing, account, serial, amount) with a unique constraint.

Source check `UCC4-CHK-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: Check processing · Encoding error · UCC Article 4. Backstop for UCC4-CHK-02. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-REGCC-006, RR-FFIEC-005.

## Rule UCC4-CHK-03: A valid deposit posts with the configured hold
Severity: LOW
Category: MM
Scenario: check-processing
Requirement: MUST
Invariant: A valid deposit posts with the configured hold; image-service outage queues the deposit and nothing posts without an image.

Source check `UCC4-CHK-03` from `checks.json` (behavioural; deterministic: yes). Covers: Check processing · Encoding error · UCC Article 4. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-REGCC-003.

## Rule UCC4-RET-01: Each returned item reverses its provisional credit and fees exactly once (duplicate return files...
Severity: LOW
Category: MM
Scenario: returned-items
Requirement: MUST
Invariant: Each returned item reverses its provisional credit and fees exactly once (duplicate return files processed once); returns for unknown items go to an exception queue, never a random reversal.

Source check `UCC4-RET-01` from `checks.json` (behavioural; deterministic: yes). Covers: Returned items · late return · UCC Article 4. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-REGCC-005.

## Rule UCC4-RET-51: Returned-item reversal is keyed by a unique item ID
Severity: LOW
Category: MM
Scenario: returned-items
Requirement: MUST
Invariant: Returned-item reversal is keyed by a unique item ID; unknown items go to an exception queue.

Source check `UCC4-RET-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: Returned items · late return · UCC Article 4. Backstop for UCC4-RET-01. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-REGCC-005.

## Rule UCC4-RET-02: Returns are initiated before the configured banking-day deadline
Severity: LOW
Category: MM
Scenario: returned-items
Requirement: MUST
Invariant: Returns are initiated before the configured banking-day deadline; late returns are flagged.

Source check `UCC4-RET-02` from `checks.json` (behavioural; deterministic: yes). Covers: Returned items · late return · UCC Article 4. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-UCC-005, RR-REGCC-007.

## Rule UCC4-NOT-01: A returned item produces one customer notice (per configured grouping) with reason and amount wit...
Severity: LOW
Category: MM
Scenario: notice
Requirement: MUST
Invariant: A returned item produces one customer notice (per configured grouping) with reason and amount within the configured window, retried/alternate channel on failure; non-returned items produce none.

Source check `UCC4-NOT-01` from `checks.json` (behavioural; deterministic: yes). Covers: Notice · late return · UCC Article 4. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-REGCC-005.
