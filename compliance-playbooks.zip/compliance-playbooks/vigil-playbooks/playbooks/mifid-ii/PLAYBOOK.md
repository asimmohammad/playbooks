---
helixPlaybookFormat: helix-playbook/0.1-proposal
playbookId: vigil-mifid-ii
title: "MiFID II Best Execution, Reporting & Unbundling"
declaredVersion: 0.1.0
intent: draft
applicability:
  languages: [javascript, typescript]
  scenarios: [best-execution, transaction-reporting, unbundling]
---
# Helix portable playbook — DRAFT manifest · MiFID II Best Execution, Reporting & Unbundling

> **DRAFT — not LOCKED.** Proposed MiFID II (EU Regulation) playbook converted from Vigil skill `SK-MIFID-001`: one runner, two layers, **10 harness checks (3 static, incl. 2 static backstops, + 7 behavioural)**, plus 3 manual/evidence items listed separately because neither layer can verify them. Every invariant, layer and determinism call is **AI-drafted (Helix) and needs compliance review**. No detector or rule code exists yet. Before this manifest can be LOCKED, each row needs its detector/rule, a review, and a commit that adds the check alongside its row.

## Layers

- **static**: a repo-agnostic source scanner parameterised by a `VIGIL_MIFID` preset (no app specifics in the detector). It reads source / SQL / config / IaC / git-diff, **fails CLOSED** on a match, and runs with **no adapter**, so it is the CI gate. *Static backstops* (IDs `-5x`) prove a supporting source invariant for a named behavioural check, the way N-CAP-01 / N-STATE-01 back neobank behaviour. They fire even when the adapter never drives that path. Backstops of ⚑ SME checks stay out of the gate.
- **behavioural**: a rule written once against the canonical `MoneySystem` interface (or a DRAFT extension surface in `adapters/`) and driven through the app adapter. Surfaces needed: **SecuritiesSystem** (`adapters/securities.ts`). Every behavioural row reports NOT_EXERCISED until an adapter implements its surface. It returns **CHECKED only when it actually drove the guard's path**.
- **manual/evidence**: organisational process, live-infrastructure, statistical or retention evidence that no source scan or adapter-driven rule can prove. These are **outside the harness**, report `NOT_APPLICABLE` to it, and are tracked as evidence tasks, never as passes.

## Verdicts

`CHECKED` the path ran and the guard held · `FINDING` the guard was violated · `NOT_APPLICABLE` the invariant cannot apply here (incl. every manual/evidence item) · `NOT_EXERCISED` (glyph `????`) the adapter did not drive the path, so nothing is proven. NOT_EXERCISED is **surfaced distinctly and never counted as a pass** (no fake coverage). A ⚑ SME check with no approved parameter matrix reports `NOT_EXERCISED`, never `CHECKED`.

## How to run

- **Not runnable yet**: this draft defines invariants only (no detector/rule code). The intended shape mirrors the neobank playbook:
  - CI gate (adapter-free, blocks on any static FINDING): `run-static` with preset `VIGIL_MIFID`.
  - Full combined table (static + behavioural via the adapter): `run-all`.
- Machine-readable rows: `checks.json` (same IDs; includes source-scenario traceability and neobank overlaps).

## The draft inventory: 3 static + 7 behavioural = 10 checks

| ID | Layer | Deterministic | Invariant (one line) | Covers (automation point · common failure · regulation) |
| --- | --- | --- | --- | --- |
| **MIFID-BX-01** | behavioural | yes | Order routing follows the configured best-execution policy factors, never worse than the configured best price at tick boundaries, and ignores stale venue data; deviations recorded with reason. | Best execution · best execution fail · MiFID II |
| **MIFID-BX-02** | behavioural | yes | Aggregated client orders are allocated per the configured policy with no systematic client disadvantage. | Best execution · best execution fail · MiFID II |
| **MIFID-BX-03** | behavioural | yes | Trading is blocked until execution-policy disclosure is acknowledged. | Best execution · general control (no source failure) · MiFID II |
| **MIFID-TR-01** | behavioural | yes | Every reportable transaction has exactly one accepted report with valid mandatory identifiers within the configured deadline; invalid reports blocked pre-submission; duplicates suppressed; late flagged. | Transaction reporting · Missing report · MiFID II |
| **MIFID-TR-51** | static | yes | Transaction reports validate mandatory identifiers pre-submission and are keyed by a unique transaction ID. | backstop for MIFID-TR-01 · Transaction reporting · Missing report · MiFID II |
| **MIFID-TR-02** | behavioural | yes | Books-vs-reports reconciliation shows no over/under-reporting and every rejection is tracked to accepted resubmission. | Transaction reporting · Missing report · MiFID II |
| **MIFID-UB-01** | static | yes | No research cost is embedded in the commission rate configuration. | Unbundling · general control (no source failure) · MiFID II |
| **MIFID-UB-02** | behavioural | yes | Research charges stop or require approval at the budget cap, including under concurrent consumption; a budget-feed failure queues charges and never bills them as execution. | Unbundling · general control (no source failure) · MiFID II |
| **MIFID-UB-51** | static | yes | Research charges check and decrement the budget inside a locked transaction; failures queue without an execution-billing fallback. | backstop for MIFID-UB-02 · Unbundling · general control (no source failure) · MiFID II |
| **MIFID-UB-03** | behavioural | yes | Disclosed client cost aggregates equal charged costs within tolerance; unpaid research consumption is flagged. | Unbundling · general control (no source failure) · MiFID II |

## Outside the harness: manual/evidence (3)

These items are not harness checks. Each reports `NOT_APPLICABLE` to the runner and needs an owner and evidence on a schedule.

| ID | Layer | Deterministic | Invariant (one line) | Covers (automation point · common failure · regulation) |
| --- | --- | --- | --- | --- |
| **MIFID-BX-04** | manual/evidence | no (manual) | Execution-quality monitoring reports are produced on schedule and evidence suffices to reconstruct each decision. | Best execution · best execution fail · MiFID II |
| **MIFID-TR-03** | manual/evidence | no (manual) | Reports and rejections are retained. | Transaction reporting · general control (no source failure) · MiFID II |
| **MIFID-UB-04** | manual/evidence | no (manual) | Research payment records are retained. | Unbundling · general control (no source failure) · MiFID II |

### Determinism

Every harness row (static and behavioural) is drafted as deterministic. Static detectors, including backstops, are pure functions of the committed source/config/diff. Behavioural rules each run against a **fresh `reset()` MoneySystem** (no state leaks between rules), driven by a **controllable clock**; deadlines, windows, expiries and cadences are asserted by advancing that clock, never by wall-clock reads, and no randomness affects a verdict. External dependencies (vendors, registries, feeds) are faked inside the adapter, which is how fault-injection rows stay deterministic. Manual/evidence rows are not deterministic and are not gate checks.

### Coverage note

Converted from 24 AI-drafted source scenarios of `SK-MIFID-001`; each source scenario maps to exactly one non-backstop row (see the appendix). Static backstops add no scenarios and trace through the check they back. The scenarios were merged into crisp invariants by automation point and failure mode, across categories (positive, negative, boundary, failure/recovery, concurrency/idempotency, retention/audit, common failure, core). Automation points covered: Best execution, Transaction reporting, Unbundling. Source common failures: Missing report, best execution fail. Thresholds, windows and deadlines are *configured* parameters, not asserted statutory values. No regulation or citation was added beyond the source sheet.

### Overlap with the locked neobank playbook (19 checks)

| This check | Neobank check | Strength | Why |
| --- | --- | --- | --- |
| MIFID-TR-51 | N-IDEMP-01 | related | unique-key dedupe on the write path |
| MIFID-UB-02 | N-CAP-01 | related | research budget cap under concurrency |
| MIFID-UB-51 | N-CAP-01 | related | budget decremented under lock |

`same` means the neobank check already enforces this invariant, so reuse it instead of re-implementing. `related` means the same defect class, but this check needs its own rule or preset.

### Review flags

- No SME-flagged rows. All rows still need compliance review.

## Appendix: traceability to source scenarios

| Check ID | Source scenario IDs | Categories merged |
| --- | --- | --- |
| MIFID-BX-01 | SC-MIFID-001-01, SC-MIFID-001-14, SC-MIFID-001-15, SC-MIFID-001-04 | Boundary/Edge, Core, Failure/Recovery, Positive |
| MIFID-BX-02 | SC-MIFID-001-05 | Concurrency/Idempotency |
| MIFID-BX-03 | SC-MIFID-001-06 | Negative |
| MIFID-BX-04 | SC-MIFID-001-16, SC-MIFID-001-07 | Common Failure, Retention/Audit |
| MIFID-TR-01 | SC-MIFID-001-02, SC-MIFID-001-08, SC-MIFID-001-17, SC-MIFID-001-18, SC-MIFID-001-19 | Boundary/Edge, Concurrency/Idempotency, Core, Negative, Positive |
| MIFID-TR-51 | — (static backstop; traced via MIFID-TR-01) | — |
| MIFID-TR-02 | SC-MIFID-001-10, SC-MIFID-001-09 | Common Failure, Failure/Recovery |
| MIFID-TR-03 | SC-MIFID-001-20 | Retention/Audit |
| MIFID-UB-01 | SC-MIFID-001-24 | Common Failure |
| MIFID-UB-02 | SC-MIFID-001-11, SC-MIFID-001-22, SC-MIFID-001-21, SC-MIFID-001-03 | Boundary/Edge, Concurrency/Idempotency, Core, Failure/Recovery |
| MIFID-UB-51 | — (static backstop; traced via MIFID-UB-02) | — |
| MIFID-UB-03 | SC-MIFID-001-13, SC-MIFID-001-12 | Negative, Positive |
| MIFID-UB-04 | SC-MIFID-001-23 | Retention/Audit |

# Helix review rules

Generated from `checks.json` (10 static and behavioural checks; manual/evidence items are not code-reviewable and are omitted). Severity is derived from the playbook priority (P1 -> MEDIUM); Category MM marks money-movement checks. Rule text is the source invariant, unchanged; it is AI-drafted and needs compliance review.

## Rule MIFID-BX-01: Order routing follows the configured best-execution policy factors, never worse than the configur...
Severity: MEDIUM
Category: NON_MM
Scenario: best-execution
Requirement: MUST
Invariant: Order routing follows the configured best-execution policy factors, never worse than the configured best price at tick boundaries, and ignores stale venue data; deviations recorded with reason.

Source check `MIFID-BX-01` from `checks.json` (behavioural; deterministic: yes). Covers: Best execution · best execution fail · MiFID II. Review status in source: Drafted (AI) – needs compliance review.

## Rule MIFID-BX-02: Aggregated client orders are allocated per the configured policy with no systematic client disadv...
Severity: MEDIUM
Category: NON_MM
Scenario: best-execution
Requirement: MUST
Invariant: Aggregated client orders are allocated per the configured policy with no systematic client disadvantage.

Source check `MIFID-BX-02` from `checks.json` (behavioural; deterministic: yes). Covers: Best execution · best execution fail · MiFID II. Review status in source: Drafted (AI) – needs compliance review.

## Rule MIFID-BX-03: Trading is blocked until execution-policy disclosure is acknowledged
Severity: MEDIUM
Category: NON_MM
Scenario: best-execution
Requirement: MUST
Invariant: Trading is blocked until execution-policy disclosure is acknowledged.

Source check `MIFID-BX-03` from `checks.json` (behavioural; deterministic: yes). Covers: Best execution · None · MiFID II. Review status in source: Drafted (AI) – needs compliance review.

## Rule MIFID-TR-01: Every reportable transaction has exactly one accepted report with valid mandatory identifiers wit...
Severity: MEDIUM
Category: NON_MM
Scenario: transaction-reporting
Requirement: MUST
Invariant: Every reportable transaction has exactly one accepted report with valid mandatory identifiers within the configured deadline; invalid reports blocked pre-submission; duplicates suppressed; late flagged.

Source check `MIFID-TR-01` from `checks.json` (behavioural; deterministic: yes). Covers: Transaction reporting · Missing report · MiFID II. Review status in source: Drafted (AI) – needs compliance review.

## Rule MIFID-TR-51: Transaction reports validate mandatory identifiers pre-submission and are keyed by a unique trans...
Severity: MEDIUM
Category: NON_MM
Scenario: transaction-reporting
Requirement: MUST
Invariant: Transaction reports validate mandatory identifiers pre-submission and are keyed by a unique transaction ID.

Source check `MIFID-TR-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: Transaction reporting · Missing report · MiFID II. Backstop for MIFID-TR-01. Review status in source: Drafted (AI) – needs compliance review.

## Rule MIFID-TR-02: Books-vs-reports reconciliation shows no over/under-reporting and every rejection is tracked to a...
Severity: MEDIUM
Category: NON_MM
Scenario: transaction-reporting
Requirement: MUST
Invariant: Books-vs-reports reconciliation shows no over/under-reporting and every rejection is tracked to accepted resubmission.

Source check `MIFID-TR-02` from `checks.json` (behavioural; deterministic: yes). Covers: Transaction reporting · Missing report · MiFID II. Review status in source: Drafted (AI) – needs compliance review.

## Rule MIFID-UB-01: No research cost is embedded in the commission rate configuration
Severity: MEDIUM
Category: NON_MM
Scenario: unbundling
Requirement: MUST
Invariant: No research cost is embedded in the commission rate configuration.

Source check `MIFID-UB-01` from `checks.json` (static; deterministic: yes). Covers: Unbundling · None · MiFID II. Review status in source: Drafted (AI) – needs compliance review.

## Rule MIFID-UB-02: Research charges stop or require approval at the budget cap, including under concurrent consumption
Severity: MEDIUM
Category: NON_MM
Scenario: unbundling
Requirement: MUST
Invariant: Research charges stop or require approval at the budget cap, including under concurrent consumption; a budget-feed failure queues charges and never bills them as execution.

Source check `MIFID-UB-02` from `checks.json` (behavioural; deterministic: yes). Covers: Unbundling · None · MiFID II. Review status in source: Drafted (AI) – needs compliance review.

## Rule MIFID-UB-51: Research charges check and decrement the budget inside a locked transaction
Severity: MEDIUM
Category: NON_MM
Scenario: unbundling
Requirement: MUST
Invariant: Research charges check and decrement the budget inside a locked transaction; failures queue without an execution-billing fallback.

Source check `MIFID-UB-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: Unbundling · None · MiFID II. Backstop for MIFID-UB-02. Review status in source: Drafted (AI) – needs compliance review.

## Rule MIFID-UB-03: Disclosed client cost aggregates equal charged costs within tolerance
Severity: MEDIUM
Category: NON_MM
Scenario: unbundling
Requirement: MUST
Invariant: Disclosed client cost aggregates equal charged costs within tolerance; unpaid research consumption is flagged.

Source check `MIFID-UB-03` from `checks.json` (behavioural; deterministic: yes). Covers: Unbundling · None · MiFID II. Review status in source: Drafted (AI) – needs compliance review.
