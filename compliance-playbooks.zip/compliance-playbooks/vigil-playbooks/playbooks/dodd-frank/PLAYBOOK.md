---
helixPlaybookFormat: helix-playbook/0.1-proposal
playbookId: vigil-dodd-frank
title: "Dodd-Frank Stress Test, Resolution Plan & Swap Reporting"
declaredVersion: 0.1.0
intent: draft
applicability:
  languages: [javascript, typescript]
  scenarios: [stress-testing, swap-reporting]
---
# Helix portable playbook — DRAFT manifest · Dodd-Frank Stress Test, Resolution Plan & Swap Reporting

> **DRAFT — not LOCKED.** Proposed Dodd-Frank Act (Dodd-Frank) playbook converted from Vigil skill `SK-DFA-001`: one runner, two layers, **7 harness checks (2 static, incl. 2 static backstops, + 5 behavioural)**, plus 4 manual/evidence items listed separately because neither layer can verify them. Every invariant, layer and determinism call is **AI-drafted (Helix) and needs compliance review**; 1 check(s) are **⚑ SME-flagged** and cannot gate until an SME/counsel supplies their parameter matrix. No detector or rule code exists yet. Before this manifest can be LOCKED, each row needs its detector/rule, a review, and a commit that adds the check alongside its row.

## Layers

- **static**: a repo-agnostic source scanner parameterised by a `VIGIL_DFA` preset (no app specifics in the detector). It reads source / SQL / config / IaC / git-diff, **fails CLOSED** on a match, and runs with **no adapter**, so it is the CI gate. *Static backstops* (IDs `-5x`) prove a supporting source invariant for a named behavioural check, the way N-CAP-01 / N-STATE-01 back neobank behaviour. They fire even when the adapter never drives that path. Backstops of ⚑ SME checks stay out of the gate.
- **behavioural**: a rule written once against the canonical `MoneySystem` interface (or a DRAFT extension surface in `adapters/`) and driven through the app adapter. Surfaces needed: **CapitalEngine** (`adapters/capital-engine.ts`), **SecuritiesSystem** (`adapters/securities.ts`). Every behavioural row reports NOT_EXERCISED until an adapter implements its surface. It returns **CHECKED only when it actually drove the guard's path**.
- **manual/evidence**: organisational process, live-infrastructure, statistical or retention evidence that no source scan or adapter-driven rule can prove. These are **outside the harness**, report `NOT_APPLICABLE` to it, and are tracked as evidence tasks, never as passes.

## Verdicts

`CHECKED` the path ran and the guard held · `FINDING` the guard was violated · `NOT_APPLICABLE` the invariant cannot apply here (incl. every manual/evidence item) · `NOT_EXERCISED` (glyph `????`) the adapter did not drive the path, so nothing is proven. NOT_EXERCISED is **surfaced distinctly and never counted as a pass** (no fake coverage). A ⚑ SME check with no approved parameter matrix reports `NOT_EXERCISED`, never `CHECKED`.

## How to run

- **Not runnable yet**: this draft defines invariants only (no detector/rule code). The intended shape mirrors the neobank playbook:
  - CI gate (adapter-free, blocks on any static FINDING): `run-static` with preset `VIGIL_DFA`.
  - Full combined table (static + behavioural via the adapter): `run-all`.
- Machine-readable rows: `checks.json` (same IDs; includes source-scenario traceability and neobank overlaps).

## The draft inventory: 2 static + 5 behavioural = 7 checks

| ID | Layer | Deterministic | Invariant (one line) | Covers (automation point · common failure · regulation) |
| --- | --- | --- | --- | --- |
| **DFA-ST-01** | behavioural | yes | Stress-test results are reproducible for identical version-locked inputs, and runs with unapproved scenario/model versions are blocked or non-official. | Stress testing · Missing test · Dodd-Frank Act |
| **DFA-ST-51** | static | yes | Official stress runs pin scenario and model version IDs from the approved registry; unapproved IDs are rejected in code. | backstop for DFA-ST-01 · Stress testing · Missing test · Dodd-Frank Act |
| **DFA-ST-02** | behavioural | yes | Missing lineage or stale feeds block or mark the run incomplete; extreme values never produce overflow/NaN. | Stress testing · Missing test · Dodd-Frank Act |
| **DFA-ST-03** | behavioural | yes | Parallel scenario runs are isolated (no cross-contamination); a missed scheduled run alerts. | Stress testing · general control (no source failure) · Dodd-Frank Act |
| **DFA-SW-01** | behavioural | yes | Each swap lifecycle event produces exactly one report with required identifiers within the configured deadline; repository state matches books. | Swap reporting · late report · Dodd-Frank Act |
| **DFA-SW-51** | static | yes | Swap reports are keyed by a unique lifecycle-event ID. | backstop for DFA-SW-01 · Swap reporting · late report · Dodd-Frank Act |
| **DFA-SW-02** | behavioural | yes | Repository rejections go to an exception queue through correction to acceptance, with ageing alerts and the original retained; late reports escalate. | Swap reporting · late report · Dodd-Frank Act |

## Outside the harness: manual/evidence (4)

These items are not harness checks. Each reports `NOT_APPLICABLE` to the runner and needs an owner and evidence on a schedule.

| ID | Layer | Deterministic | Invariant (one line) | Covers (automation point · common failure · regulation) |
| --- | --- | --- | --- | --- |
| **DFA-ST-04** | manual/evidence | no (manual) | Stress-test submissions and full lineage are retained. | Stress testing · general control (no source failure) · Dodd-Frank Act |
| **DFA-LW-01** | manual/evidence | no (manual) | The resolution plan reflects current critical services, operations and vendors against the configured template (SME-defined); unmapped changes are flagged. | Living wills · general control (no source failure) · Dodd-Frank Act |
| **DFA-LW-02** | manual/evidence | no (manual) | Resolution data packs are producible within the configured time; pipeline failure publishes no partial plan; concurrent edits versioned; plan versions retained. | Living wills · general control (no source failure) · Dodd-Frank Act |
| **DFA-SW-03** | manual/evidence | no (manual) | Swap records are retained. | Swap reporting · general control (no source failure) · Dodd-Frank Act |

### Determinism

Every harness row (static and behavioural) is drafted as deterministic. Static detectors, including backstops, are pure functions of the committed source/config/diff. Behavioural rules each run against a **fresh `reset()` MoneySystem** (no state leaks between rules), driven by a **controllable clock**; deadlines, windows, expiries and cadences are asserted by advancing that clock, never by wall-clock reads, and no randomness affects a verdict. External dependencies (vendors, registries, feeds) are faked inside the adapter, which is how fault-injection rows stay deterministic. Manual/evidence rows are not deterministic and are not gate checks. ⚑ SME rows are deterministic once parameters exist, but are excluded from the gate until then.

### Coverage note

Converted from 24 AI-drafted source scenarios of `SK-DFA-001`; each source scenario maps to exactly one non-backstop row (see the appendix). Static backstops add no scenarios and trace through the check they back. The scenarios were merged into crisp invariants by automation point and failure mode, across categories (positive, negative, boundary, failure/recovery, concurrency/idempotency, retention/audit, common failure, core). Automation points covered: Stress testing, Living wills, Swap reporting. Source common failures: Missing test, late report. Thresholds, windows and deadlines are *configured* parameters, not asserted statutory values. No regulation or citation was added beyond the source sheet.

### Overlap with the locked neobank playbook (19 checks)

| This check | Neobank check | Strength | Why |
| --- | --- | --- | --- |
| DFA-SW-51 | N-IDEMP-01 | related | unique-key dedupe on the write path |

`same` means the neobank check already enforces this invariant, so reuse it instead of re-implementing. `related` means the same defect class, but this check needs its own rule or preset.

### Review flags

- ⚑ **DFA-LW-01**: needs an SME/counsel parameter matrix (source scenarios carry review status "+ SME input").

## Appendix: traceability to source scenarios

| Check ID | Source scenario IDs | Categories merged |
| --- | --- | --- |
| DFA-ST-01 | SC-DFA-001-01, SC-DFA-001-04, SC-DFA-001-12 | Core, Negative, Positive |
| DFA-ST-51 | — (static backstop; traced via DFA-ST-01) | — |
| DFA-ST-02 | SC-DFA-001-05, SC-DFA-001-13 | Boundary/Edge, Failure/Recovery |
| DFA-ST-03 | SC-DFA-001-14, SC-DFA-001-16 | Common Failure, Concurrency/Idempotency |
| DFA-ST-04 | SC-DFA-001-15 | Retention/Audit |
| DFA-LW-01 | SC-DFA-001-02, SC-DFA-001-06, SC-DFA-001-17, SC-DFA-001-18 | Common Failure, Core, Negative, Positive |
| DFA-LW-02 | SC-DFA-001-07, SC-DFA-001-19, SC-DFA-001-20, SC-DFA-001-21 | Boundary/Edge, Concurrency/Idempotency, Failure/Recovery, Retention/Audit |
| DFA-SW-01 | SC-DFA-001-03, SC-DFA-001-22, SC-DFA-001-08, SC-DFA-001-09 | Boundary/Edge, Concurrency/Idempotency, Core, Positive |
| DFA-SW-51 | — (static backstop; traced via DFA-SW-01) | — |
| DFA-SW-02 | SC-DFA-001-10, SC-DFA-001-23, SC-DFA-001-24 | Common Failure, Failure/Recovery, Negative |
| DFA-SW-03 | SC-DFA-001-11 | Retention/Audit |

# Helix review rules

Generated from `checks.json` (7 static and behavioural checks; manual/evidence items are not code-reviewable and are omitted). Severity is derived from the playbook priority (P2 -> LOW); Category MM marks money-movement checks. Rule text is the source invariant, unchanged; it is AI-drafted and needs compliance review.

## Rule DFA-ST-01: Stress-test results are reproducible for identical version-locked inputs, and runs with unapprove...
Severity: LOW
Category: NON_MM
Scenario: stress-testing
Requirement: MUST
Invariant: Stress-test results are reproducible for identical version-locked inputs, and runs with unapproved scenario/model versions are blocked or non-official.

Source check `DFA-ST-01` from `checks.json` (behavioural; deterministic: yes). Covers: Stress testing · Missing test · Dodd-Frank Act. Review status in source: Drafted (AI) – needs compliance review.

## Rule DFA-ST-51: Official stress runs pin scenario and model version IDs from the approved registry
Severity: LOW
Category: NON_MM
Scenario: stress-testing
Requirement: MUST
Invariant: Official stress runs pin scenario and model version IDs from the approved registry; unapproved IDs are rejected in code.

Source check `DFA-ST-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: Stress testing · Missing test · Dodd-Frank Act. Backstop for DFA-ST-01. Review status in source: Drafted (AI) – needs compliance review.

## Rule DFA-ST-02: Missing lineage or stale feeds block or mark the run incomplete
Severity: LOW
Category: NON_MM
Scenario: stress-testing
Requirement: MUST
Invariant: Missing lineage or stale feeds block or mark the run incomplete; extreme values never produce overflow/NaN.

Source check `DFA-ST-02` from `checks.json` (behavioural; deterministic: yes). Covers: Stress testing · Missing test · Dodd-Frank Act. Review status in source: Drafted (AI) – needs compliance review.

## Rule DFA-ST-03: Parallel scenario runs are isolated (no cross-contamination)
Severity: LOW
Category: NON_MM
Scenario: stress-testing
Requirement: MUST
Invariant: Parallel scenario runs are isolated (no cross-contamination); a missed scheduled run alerts.

Source check `DFA-ST-03` from `checks.json` (behavioural; deterministic: yes). Covers: Stress testing · None · Dodd-Frank Act. Review status in source: Drafted (AI) – needs compliance review.

## Rule DFA-SW-01: Each swap lifecycle event produces exactly one report with required identifiers within the config...
Severity: LOW
Category: NON_MM
Scenario: swap-reporting
Requirement: MUST
Invariant: Each swap lifecycle event produces exactly one report with required identifiers within the configured deadline; repository state matches books.

Source check `DFA-SW-01` from `checks.json` (behavioural; deterministic: yes). Covers: Swap reporting · late report · Dodd-Frank Act. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-FX-003.

## Rule DFA-SW-51: Swap reports are keyed by a unique lifecycle-event ID
Severity: LOW
Category: NON_MM
Scenario: swap-reporting
Requirement: MUST
Invariant: Swap reports are keyed by a unique lifecycle-event ID.

Source check `DFA-SW-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: Swap reporting · late report · Dodd-Frank Act. Backstop for DFA-SW-01. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-FX-003.

## Rule DFA-SW-02: Repository rejections go to an exception queue through correction to acceptance, with ageing aler...
Severity: LOW
Category: NON_MM
Scenario: swap-reporting
Requirement: MUST
Invariant: Repository rejections go to an exception queue through correction to acceptance, with ageing alerts and the original retained; late reports escalate.

Source check `DFA-SW-02` from `checks.json` (behavioural; deterministic: yes). Covers: Swap reporting · late report · Dodd-Frank Act. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-FX-003.
