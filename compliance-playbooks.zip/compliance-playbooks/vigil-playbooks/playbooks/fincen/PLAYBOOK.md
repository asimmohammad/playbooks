---
helixPlaybookFormat: helix-playbook/0.1-proposal
playbookId: vigil-fincen
title: "FinCEN Crypto MSB, Travel Rule & SAR"
declaredVersion: 0.1.0
intent: draft
applicability:
  languages: [javascript, typescript]
  scenarios: [msb-registration, travel-rule, sar-filing]
---
# Helix portable playbook — DRAFT manifest · FinCEN Crypto MSB, Travel Rule & SAR

> **DRAFT — not LOCKED.** Proposed FinCEN (Crypto Regulation) playbook converted from Vigil skill `SK-FINCEN-001`: one runner, two layers, **10 harness checks (3 static, incl. 2 static backstops, + 7 behavioural)**, plus 3 manual/evidence items listed separately because neither layer can verify them. Every invariant, layer and determinism call is **AI-drafted (Helix) and needs compliance review**. No detector or rule code exists yet. Before this manifest can be LOCKED, each row needs its detector/rule, a review, and a commit that adds the check alongside its row.

## Layers

- **static**: a repo-agnostic source scanner parameterised by a `VIGIL_FINCEN` preset (no app specifics in the detector). It reads source / SQL / config / IaC / git-diff, **fails CLOSED** on a match, and runs with **no adapter**, so it is the CI gate. *Static backstops* (IDs `-5x`) prove a supporting source invariant for a named behavioural check, the way N-CAP-01 / N-STATE-01 back neobank behaviour. They fire even when the adapter never drives that path. Backstops of ⚑ SME checks stay out of the gate.
- **behavioural**: a rule written once against the canonical `MoneySystem` interface (or a DRAFT extension surface in `adapters/`) and driven through the app adapter. Surfaces needed: **CryptoSystem** (`adapters/crypto.ts`), **ComplianceCaseSystem** (`adapters/compliance-cases.ts`). Every behavioural row reports NOT_EXERCISED until an adapter implements its surface. It returns **CHECKED only when it actually drove the guard's path**.
- **manual/evidence**: organisational process, live-infrastructure, statistical or retention evidence that no source scan or adapter-driven rule can prove. These are **outside the harness**, report `NOT_APPLICABLE` to it, and are tracked as evidence tasks, never as passes.

## Verdicts

`CHECKED` the path ran and the guard held · `FINDING` the guard was violated · `NOT_APPLICABLE` the invariant cannot apply here (incl. every manual/evidence item) · `NOT_EXERCISED` (glyph `????`) the adapter did not drive the path, so nothing is proven. NOT_EXERCISED is **surfaced distinctly and never counted as a pass** (no fake coverage). A ⚑ SME check with no approved parameter matrix reports `NOT_EXERCISED`, never `CHECKED`.

## How to run

- **Not runnable yet**: this draft defines invariants only (no detector/rule code). The intended shape mirrors the neobank playbook:
  - CI gate (adapter-free, blocks on any static FINDING): `run-static` with preset `VIGIL_FINCEN`.
  - Full combined table (static + behavioural via the adapter): `run-all`.
- Machine-readable rows: `checks.json` (same IDs; includes source-scenario traceability and neobank overlaps).

## The draft inventory: 3 static + 7 behavioural = 10 checks

| ID | Layer | Deterministic | Invariant (one line) | Covers (automation point · common failure · regulation) |
| --- | --- | --- | --- | --- |
| **FIN-MSB-01** | static | yes | A money-service feature cannot be enabled for a jurisdiction without a recorded active registration/licence (feature-flag config gated by the register). | MSB registration · Missing registration · FinCEN |
| **FIN-MSB-02** | behavioural | yes | An expired registration or a register-service outage blocks the feature (fail closed); a renewal racing expiry leaves no gap in active status. | MSB registration · Missing registration · FinCEN |
| **FIN-TR-01** | behavioural | yes | Transfers at/above the configured threshold (after FX conversion) carry and transmit the required originator and beneficiary data. | Travel rule · travel rule fail · FinCEN |
| **FIN-TR-51** | static | yes | Travel-rule threshold comparison uses the converted amount in the configured currency and attaches the required data fields. | backstop for FIN-TR-01 · Travel rule · travel rule fail · FinCEN |
| **FIN-TR-02** | behavioural | yes | An unreachable counterparty VASP holds the transfer per policy with logged retry/escalation — never silently released. | Travel rule · travel rule fail · FinCEN |
| **FIN-TR-03** | behavioural | yes | Retries send exactly one travel-rule message per transfer ID. | Travel rule · travel rule fail · FinCEN |
| **FIN-TR-52** | static | yes | Travel-rule messages are keyed by transfer ID with a unique constraint. | backstop for FIN-TR-03 · Travel rule · travel rule fail · FinCEN |
| **FIN-TR-04** | behavioural | yes | Inbound transfers missing originator data are flagged and handled per policy; structuring just below the threshold alerts. | Travel rule · travel rule fail · FinCEN |
| **FIN-SAR-01** | behavioural | yes | Crypto typology alerts route to one merged SAR case whose decision is recorded before the configured deadline, preserved across case-tool outages and escalated if missed. | SAR filing · general control (no source failure) · FinCEN |
| **FIN-SAR-02** | behavioural | yes | SAR existence is never revealed to the customer or unauthorised roles; access attempts are logged. | SAR filing · general control (no source failure) · FinCEN |

## Outside the harness: manual/evidence (3)

These items are not harness checks. Each reports `NOT_APPLICABLE` to the runner and needs an owner and evidence on a schedule.

| ID | Layer | Deterministic | Invariant (one line) | Covers (automation point · common failure · regulation) |
| --- | --- | --- | --- | --- |
| **FIN-MSB-03** | manual/evidence | no (manual) | Renewal deadlines are tracked with escalation; the agent list is current with history; material changes trigger a re-registration review. | MSB registration · Missing registration · FinCEN |
| **FIN-TR-05** | manual/evidence | no (manual) | Travel-rule records are retained. | Travel rule · general control (no source failure) · FinCEN |
| **FIN-SAR-03** | manual/evidence | no (manual) | SAR decisions are retained. | SAR filing · general control (no source failure) · FinCEN |

### Determinism

Every harness row (static and behavioural) is drafted as deterministic. Static detectors, including backstops, are pure functions of the committed source/config/diff. Behavioural rules each run against a **fresh `reset()` MoneySystem** (no state leaks between rules), driven by a **controllable clock**; deadlines, windows, expiries and cadences are asserted by advancing that clock, never by wall-clock reads, and no randomness affects a verdict. External dependencies (vendors, registries, feeds) are faked inside the adapter, which is how fault-injection rows stay deterministic. Manual/evidence rows are not deterministic and are not gate checks.

### Coverage note

Converted from 25 AI-drafted source scenarios of `SK-FINCEN-001`; each source scenario maps to exactly one non-backstop row (see the appendix). Static backstops add no scenarios and trace through the check they back. The scenarios were merged into crisp invariants by automation point and failure mode, across categories (positive, negative, boundary, failure/recovery, concurrency/idempotency, retention/audit, common failure, core). Automation points covered: MSB registration, Travel rule, SAR filing. Source common failures: Missing registration, travel rule fail. Thresholds, windows and deadlines are *configured* parameters, not asserted statutory values. No regulation or citation was added beyond the source sheet.

### Overlap with the locked neobank playbook (19 checks)

| This check | Neobank check | Strength | Why |
| --- | --- | --- | --- |
| FIN-MSB-02 | N-STATE-01 | related | expired registration blocks feature |
| FIN-TR-03 | N-IDEMP-01 | related | one travel-rule message per transfer |
| FIN-TR-52 | N-IDEMP-01 | related | unique-key dedupe on the write path |

`same` means the neobank check already enforces this invariant, so reuse it instead of re-implementing. `related` means the same defect class, but this check needs its own rule or preset.

### Review flags

- No SME-flagged rows. All rows still need compliance review.

## Appendix: traceability to source scenarios

| Check ID | Source scenario IDs | Categories merged |
| --- | --- | --- |
| FIN-MSB-01 | SC-FINCEN-001-01, SC-FINCEN-001-15 | Core, Positive |
| FIN-MSB-02 | SC-FINCEN-001-16, SC-FINCEN-001-17, SC-FINCEN-001-18 | Concurrency/Idempotency, Failure/Recovery, Negative |
| FIN-MSB-03 | SC-FINCEN-001-04, SC-FINCEN-001-05, SC-FINCEN-001-06 | Boundary/Edge, Common Failure, Retention/Audit |
| FIN-TR-01 | SC-FINCEN-001-02, SC-FINCEN-001-07, SC-FINCEN-001-19 | Boundary/Edge, Core, Positive |
| FIN-TR-51 | — (static backstop; traced via FIN-TR-01) | — |
| FIN-TR-02 | SC-FINCEN-001-09, SC-FINCEN-001-21 | Common Failure, Failure/Recovery |
| FIN-TR-03 | SC-FINCEN-001-20 | Concurrency/Idempotency |
| FIN-TR-52 | — (static backstop; traced via FIN-TR-03) | — |
| FIN-TR-04 | SC-FINCEN-001-10, SC-FINCEN-001-08 | Negative |
| FIN-TR-05 | SC-FINCEN-001-11 | Retention/Audit |
| FIN-SAR-01 | SC-FINCEN-001-03, SC-FINCEN-001-12, SC-FINCEN-001-13, SC-FINCEN-001-22, SC-FINCEN-001-23, SC-FINCEN-001-25 | Boundary/Edge, Common Failure, Concurrency/Idempotency, Core, Failure/Recovery, Positive |
| FIN-SAR-02 | SC-FINCEN-001-14 | Negative |
| FIN-SAR-03 | SC-FINCEN-001-24 | Retention/Audit |

# Helix review rules

Generated from `checks.json` (10 static and behavioural checks; manual/evidence items are not code-reviewable and are omitted). Severity is derived from the playbook priority (P1 -> MEDIUM); Category MM marks money-movement checks. Rule text is the source invariant, unchanged; it is AI-drafted and needs compliance review.

## Rule FIN-MSB-01: A money-service feature cannot be enabled for a jurisdiction without a recorded active registrati...
Severity: MEDIUM
Category: NON_MM
Scenario: msb-registration
Requirement: MUST
Invariant: A money-service feature cannot be enabled for a jurisdiction without a recorded active registration/licence (feature-flag config gated by the register).

Source check `FIN-MSB-01` from `checks.json` (static; deterministic: yes). Covers: MSB registration · Missing registration · FinCEN. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-AML-009, RR-STATE-001.

## Rule FIN-MSB-02: An expired registration or a register-service outage blocks the feature (fail closed)
Severity: MEDIUM
Category: NON_MM
Scenario: msb-registration
Requirement: MUST
Invariant: An expired registration or a register-service outage blocks the feature (fail closed); a renewal racing expiry leaves no gap in active status.

Source check `FIN-MSB-02` from `checks.json` (behavioural; deterministic: yes). Covers: MSB registration · Missing registration · FinCEN. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-AML-009, RR-STATE-001.

## Rule FIN-TR-01: Transfers at/above the configured threshold (after FX conversion) carry and transmit the required...
Severity: MEDIUM
Category: NON_MM
Scenario: travel-rule
Requirement: MUST
Invariant: Transfers at/above the configured threshold (after FX conversion) carry and transmit the required originator and beneficiary data.

Source check `FIN-TR-01` from `checks.json` (behavioural; deterministic: yes). Covers: Travel rule · travel rule fail · FinCEN. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-AML-005, RR-CRYPTO-005.

## Rule FIN-TR-51: Travel-rule threshold comparison uses the converted amount in the configured currency and attache...
Severity: MEDIUM
Category: NON_MM
Scenario: travel-rule
Requirement: MUST
Invariant: Travel-rule threshold comparison uses the converted amount in the configured currency and attaches the required data fields.

Source check `FIN-TR-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: Travel rule · travel rule fail · FinCEN. Backstop for FIN-TR-01. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-AML-005, RR-CRYPTO-005.

## Rule FIN-TR-02: An unreachable counterparty VASP holds the transfer per policy with logged retry/escalation — nev...
Severity: MEDIUM
Category: NON_MM
Scenario: travel-rule
Requirement: MUST
Invariant: An unreachable counterparty VASP holds the transfer per policy with logged retry/escalation — never silently released.

Source check `FIN-TR-02` from `checks.json` (behavioural; deterministic: yes). Covers: Travel rule · travel rule fail · FinCEN. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-AML-005, RR-CRYPTO-005.

## Rule FIN-TR-03: Retries send exactly one travel-rule message per transfer ID
Severity: MEDIUM
Category: NON_MM
Scenario: travel-rule
Requirement: MUST
Invariant: Retries send exactly one travel-rule message per transfer ID.

Source check `FIN-TR-03` from `checks.json` (behavioural; deterministic: yes). Covers: Travel rule · travel rule fail · FinCEN. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-AML-005, RR-CRYPTO-005.

## Rule FIN-TR-52: Travel-rule messages are keyed by transfer ID with a unique constraint
Severity: MEDIUM
Category: NON_MM
Scenario: travel-rule
Requirement: MUST
Invariant: Travel-rule messages are keyed by transfer ID with a unique constraint.

Source check `FIN-TR-52` from `checks.json` (static, static backstop; deterministic: yes). Covers: Travel rule · travel rule fail · FinCEN. Backstop for FIN-TR-03. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-AML-005, RR-CRYPTO-005.

## Rule FIN-TR-04: Inbound transfers missing originator data are flagged and handled per policy
Severity: MEDIUM
Category: NON_MM
Scenario: travel-rule
Requirement: MUST
Invariant: Inbound transfers missing originator data are flagged and handled per policy; structuring just below the threshold alerts.

Source check `FIN-TR-04` from `checks.json` (behavioural; deterministic: yes). Covers: Travel rule · travel rule fail · FinCEN. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-AML-005, RR-CRYPTO-005, RR-AML-012.

## Rule FIN-SAR-01: Crypto typology alerts route to one merged SAR case whose decision is recorded before the configu...
Severity: MEDIUM
Category: NON_MM
Scenario: sar-filing
Requirement: MUST
Invariant: Crypto typology alerts route to one merged SAR case whose decision is recorded before the configured deadline, preserved across case-tool outages and escalated if missed.

Source check `FIN-SAR-01` from `checks.json` (behavioural; deterministic: yes). Covers: SAR filing · None · FinCEN. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-AML-004, RR-AML-023.

## Rule FIN-SAR-02: SAR existence is never revealed to the customer or unauthorised roles
Severity: MEDIUM
Category: NON_MM
Scenario: sar-filing
Requirement: MUST
Invariant: SAR existence is never revealed to the customer or unauthorised roles; access attempts are logged.

Source check `FIN-SAR-02` from `checks.json` (behavioural; deterministic: yes). Covers: SAR filing · None · FinCEN. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-AML-004.
