---
helixPlaybookFormat: helix-playbook/0.1-proposal
playbookId: vigil-pci-dss
title: "PCI-DSS Cardholder Data Protection Assurance"
declaredVersion: 0.1.0
intent: draft
applicability:
  languages: [javascript, typescript]
  scenarios: [encryption, access-control, network-segmentation, logging]
---
# Helix portable playbook — DRAFT manifest · PCI-DSS Cardholder Data Protection Assurance

> **DRAFT — not LOCKED.** Proposed PCI-DSS 4.0 (Payment Security) playbook converted from Vigil skill `SK-PCI-001`: one runner, two layers, **23 harness checks (11 static, incl. 7 static backstops, + 12 behavioural)**, plus 7 manual/evidence items listed separately because neither layer can verify them. Every invariant, layer and determinism call is **AI-drafted (Helix) and needs compliance review**. No detector or rule code exists yet. Before this manifest can be LOCKED, each row needs its detector/rule, a review, and a commit that adds the check alongside its row.

## Layers

- **static**: a repo-agnostic source scanner parameterised by a `VIGIL_PCI` preset (no app specifics in the detector). It reads source / SQL / config / IaC / git-diff, **fails CLOSED** on a match, and runs with **no adapter**, so it is the CI gate. *Static backstops* (IDs `-5x`) prove a supporting source invariant for a named behavioural check, the way N-CAP-01 / N-STATE-01 back neobank behaviour. They fire even when the adapter never drives that path. Backstops of ⚑ SME checks stay out of the gate.
- **behavioural**: a rule written once against the canonical `MoneySystem` interface (or a DRAFT extension surface in `adapters/`) and driven through the app adapter. Surfaces needed: **CardVaultSystem** (`adapters/card-vault.ts`), **IdentityAccessSystem** (`adapters/card-vault.ts`). Every behavioural row reports NOT_EXERCISED until an adapter implements its surface. It returns **CHECKED only when it actually drove the guard's path**.
- **manual/evidence**: organisational process, live-infrastructure, statistical or retention evidence that no source scan or adapter-driven rule can prove. These are **outside the harness**, report `NOT_APPLICABLE` to it, and are tracked as evidence tasks, never as passes.

## Verdicts

`CHECKED` the path ran and the guard held · `FINDING` the guard was violated · `NOT_APPLICABLE` the invariant cannot apply here (incl. every manual/evidence item) · `NOT_EXERCISED` (glyph `????`) the adapter did not drive the path, so nothing is proven. NOT_EXERCISED is **surfaced distinctly and never counted as a pass** (no fake coverage). A ⚑ SME check with no approved parameter matrix reports `NOT_EXERCISED`, never `CHECKED`.

## How to run

- **Not runnable yet**: this draft defines invariants only (no detector/rule code). The intended shape mirrors the neobank playbook:
  - CI gate (adapter-free, blocks on any static FINDING): `run-static` with preset `VIGIL_PCI`.
  - Full combined table (static + behavioural via the adapter): `run-all`.
- Machine-readable rows: `checks.json` (same IDs; includes source-scenario traceability and neobank overlaps).

## The draft inventory: 11 static + 12 behavioural = 23 checks

| ID | Layer | Deterministic | Invariant (one line) | Covers (automation point · common failure · regulation) |
| --- | --- | --- | --- | --- |
| **PCI-ENC-01** | static | yes | PAN never reaches storage, logs, URLs, error bodies, traces or third-party payloads in clear — only token, truncated or encrypted forms. | Encryption · Unencrypted PAN · PCI-DSS 4.0 |
| **PCI-ENC-02** | behavioural | yes | PAN-like input in free-text fields is redacted or rejected before persistence; non-PAN numbers are not false-redacted. | Encryption · Unencrypted PAN · PCI-DSS 4.0 |
| **PCI-ENC-03** | behavioural | yes | Sensitive authentication data (CVV, PIN block, track) does not persist anywhere after authorization. | Encryption · Unencrypted PAN · PCI-DSS 4.0 |
| **PCI-ENC-51** | static | yes | No column, log statement, cache or serializer persists CVV/CVC, PIN block or track data fields after the authorization call site (schema + source scan). | backstop for PCI-ENC-03 · Encryption · Unencrypted PAN · PCI-DSS 4.0 |
| **PCI-ENC-04** | behavioural | yes | Detokenization returns the original PAN only to authorised services; unauthorised callers get an authz error, no PAN, and a logged denial. | Encryption · general control (no source failure) · PCI-DSS 4.0 |
| **PCI-ENC-53** | static | yes | The detokenize entry point is reachable only through an authz-checked route/service allowlist; no other module imports the vault's raw detokenize. | backstop for PCI-ENC-04 · Encryption · general control (no source failure) · PCI-DSS 4.0 |
| **PCI-ENC-05** | static | yes | Every CDE volume, bucket, table and backup target is declared encrypted at rest under the configured key policy (IaC = deployed, no drift). | Encryption · Unencrypted PAN · PCI-DSS 4.0 |
| **PCI-ENC-06** | behavioural | yes | Truncated and hashed PAN forms cannot be correlated back to a PAN (keyed hash, protected key). | Encryption · general control (no source failure) · PCI-DSS 4.0 |
| **PCI-ENC-07** | behavioural | yes | Tokenisation and re-encryption are idempotent: concurrent tokenise of one PAN yields one vault record; an interrupted re-key job leaves every record encrypted exactly once. | Encryption · Unencrypted PAN · PCI-DSS 4.0 |
| **PCI-ENC-54** | static | yes | Tokenisation writes use a unique constraint on the PAN fingerprint (or upsert), and the re-key job persists a per-record key-version marker before advancing. | backstop for PCI-ENC-07 · Encryption · Unencrypted PAN · PCI-DSS 4.0 |
| **PCI-ENC-08** | behavioural | yes | Key revoked/unavailable fails closed — no fallback to plaintext storage or processing. | Encryption · Unencrypted PAN · PCI-DSS 4.0 |
| **PCI-ENC-52** | static | yes | Every encrypt/decrypt call path handles key-unavailable by throwing/aborting — no catch branch writes or returns the plaintext value. | backstop for PCI-ENC-08 · Encryption · Unencrypted PAN · PCI-DSS 4.0 |
| **PCI-ACC-01** | behavioural | yes | CDE permissions equal the approved policy matrix: least privilege, no wildcard/implicit grants, unique IDs, MFA on interactive access, masked PAN for non-authorised roles. | Access control · missing access review · PCI-DSS 4.0 |
| **PCI-ACC-51** | static | yes | IAM/RBAC policy files contain no wildcard actions/resources on CDE resources, and every interactive CDE role requires MFA in config. | backstop for PCI-ACC-01 · Access control · missing access review · PCI-DSS 4.0 |
| **PCI-ACC-02** | behavioural | yes | A role downgrade or termination takes effect on the next request — no stale-token or stale-session privilege beyond the configured TTL. | Access control · missing access review · PCI-DSS 4.0 |
| **PCI-ACC-52** | static | yes | Authorization middleware re-reads role/status from the store on each CDE request (or token TTL ≤ configured max) — no role taken from an unverified token claim alone. | backstop for PCI-ACC-02 · Access control · missing access review · PCI-DSS 4.0 |
| **PCI-ACC-03** | behavioural | yes | Session idle timeout and break-glass windows are enforced at the configured boundary using the controllable clock; break-glass requires approval and auto-expires. | Access control · general control (no source failure) · PCI-DSS 4.0 |
| **PCI-ACC-04** | behavioural | yes | IdP outage fails closed: normal CDE access denied; only approved, fully-logged break-glass works. | Access control · general control (no source failure) · PCI-DSS 4.0 |
| **PCI-ACC-05** | static | yes | No vendor default credentials or default accounts are present in CDE component config/IaC. | Access control · general control (no source failure) · PCI-DSS 4.0 |
| **PCI-SEG-01** | static | yes | A network-policy/IaC diff that opens a path into the CDE or deploys an unscoped service into it is blocked without approval. | Network segmentation · general control (no source failure) · PCI-DSS 4.0 |
| **PCI-LOG-01** | behavioural | yes | Every CHD access and every failed/invalid access attempt emits exactly one audit event (user, time, resource, reason, outcome) containing no PAN. | Logging · missing access review · PCI-DSS 4.0 |
| **PCI-LOG-51** | static | yes | Every CHD-access and auth-failure handler calls the audit emitter, and audit event schemas exclude PAN-typed fields. | backstop for PCI-LOG-01 · Logging · missing access review · PCI-DSS 4.0 |
| **PCI-LOG-02** | behavioural | yes | Under concurrent load the audit event count equals the action count and the log pipeline never silently drops events (buffered or alerted on outage). | Logging · general control (no source failure) · PCI-DSS 4.0 |

## Outside the harness: manual/evidence (7)

These items are not harness checks. Each reports `NOT_APPLICABLE` to the runner and needs an owner and evidence on a schedule.

| ID | Layer | Deterministic | Invariant (one line) | Covers (automation point · common failure · regulation) |
| --- | --- | --- | --- | --- |
| **PCI-ENC-09** | manual/evidence | no (manual) | Strong-crypto-only transport (configured protocol/cipher set) on every CHD channel; key rotation within crypto-period and restricted key use; key lifecycle records retained. | Encryption · general control (no source failure) · PCI-DSS 4.0 |
| **PCI-ENC-10** | manual/evidence | no (manual) | No cardholder data is retained beyond the configured retention period without documented justification. | Encryption · Unencrypted PAN · PCI-DSS 4.0 |
| **PCI-ACC-06** | manual/evidence | no (manual) | Periodic access reviews cover every in-scope system on cadence; every CDE grant maps to an approved role and active owner; overdue reviews alert. | Access control · missing access review · PCI-DSS 4.0 |
| **PCI-SEG-02** | manual/evidence | no (manual) | Live segmentation matrix holds: non-CDE→CDE refused, egress only to approved destinations, exact allowed ports only, vendor access only via jump host — including after failover/redeploy. | Network segmentation · general control (no source failure) · PCI-DSS 4.0 |
| **PCI-SEG-03** | manual/evidence | no (manual) | Asset discovery flags unregistered assets in the CDE segment; segmentation test evidence exists for every period. | Network segmentation · general control (no source failure) · PCI-DSS 4.0 |
| **PCI-LOG-03** | manual/evidence | no (manual) | Audit logs are tamper-evident, retained for the configured window, time-synchronised within tolerance, and security alerts are reviewed within SLA. | Logging · general control (no source failure) · PCI-DSS 4.0 |
| **PCI-LOG-04** | manual/evidence | no (manual) | Payment-page scripts are inventoried and unauthorised/modified scripts are detected and alerted. | Logging · general control (no source failure) · PCI-DSS 4.0 |

### Determinism

Every harness row (static and behavioural) is drafted as deterministic. Static detectors, including backstops, are pure functions of the committed source/config/diff. Behavioural rules each run against a **fresh `reset()` MoneySystem** (no state leaks between rules), driven by a **controllable clock**; deadlines, windows, expiries and cadences are asserted by advancing that clock, never by wall-clock reads, and no randomness affects a verdict. External dependencies (vendors, registries, feeds) are faked inside the adapter, which is how fault-injection rows stay deterministic. Manual/evidence rows are not deterministic and are not gate checks.

### Coverage note

Converted from 49 AI-drafted source scenarios of `SK-PCI-001`; each source scenario maps to exactly one non-backstop row (see the appendix). Static backstops add no scenarios and trace through the check they back. The scenarios were merged into crisp invariants by automation point and failure mode, across categories (positive, negative, boundary, failure/recovery, concurrency/idempotency, retention/audit, common failure, core). Automation points covered: Encryption, Access control, Network segmentation, Logging. Source common failures: Unencrypted PAN, missing access review. Thresholds, windows and deadlines are *configured* parameters, not asserted statutory values. No regulation or citation was added beyond the source sheet.

### Overlap with the locked neobank playbook (19 checks)

| This check | Neobank check | Strength | Why |
| --- | --- | --- | --- |
| PCI-ENC-07 | N-IDEMP-01 | related | tokenise/re-key idempotent |
| PCI-ACC-02 | N-STATE-01 | related | revoked subject rejected on next request |
| PCI-ACC-52 | N-STATE-01 | related | re-read subject state per request |

`same` means the neobank check already enforces this invariant, so reuse it instead of re-implementing. `related` means the same defect class, but this check needs its own rule or preset.

### Review flags

- No SME-flagged rows. All rows still need compliance review.

## Appendix: traceability to source scenarios

| Check ID | Source scenario IDs | Categories merged |
| --- | --- | --- |
| PCI-ENC-01 | SC-PCI-001-01, SC-PCI-001-06, SC-PCI-001-08 | Common Failure, Core |
| PCI-ENC-02 | SC-PCI-001-09 | Negative |
| PCI-ENC-03 | DR-PCI-001-03 | Core |
| PCI-ENC-51 | — (static backstop; traced via PCI-ENC-03) | — |
| PCI-ENC-04 | SC-PCI-001-04, SC-PCI-001-05 | Negative, Positive |
| PCI-ENC-53 | — (static backstop; traced via PCI-ENC-04) | — |
| PCI-ENC-05 | SC-PCI-001-14, SC-PCI-001-13 | Common Failure, Positive |
| PCI-ENC-06 | SC-PCI-001-07 | Boundary/Edge |
| PCI-ENC-07 | SC-PCI-001-10, SC-PCI-001-12 | Concurrency/Idempotency |
| PCI-ENC-54 | — (static backstop; traced via PCI-ENC-07) | — |
| PCI-ENC-08 | SC-PCI-001-11 | Failure/Recovery |
| PCI-ENC-52 | — (static backstop; traced via PCI-ENC-08) | — |
| PCI-ENC-09 | DR-PCI-001-05, DR-PCI-001-06, SC-PCI-001-33 | Core, Retention/Audit |
| PCI-ENC-10 | DR-PCI-001-09 | Core |
| PCI-ACC-01 | SC-PCI-001-15, DR-PCI-001-04, DR-PCI-001-07, DR-PCI-001-08 | Core, Positive |
| PCI-ACC-51 | — (static backstop; traced via PCI-ACC-01) | — |
| PCI-ACC-02 | SC-PCI-001-21, SC-PCI-001-17 | Common Failure, Concurrency/Idempotency |
| PCI-ACC-52 | — (static backstop; traced via PCI-ACC-02) | — |
| PCI-ACC-03 | SC-PCI-001-20, SC-PCI-001-16 | Boundary/Edge |
| PCI-ACC-04 | SC-PCI-001-34 | Failure/Recovery |
| PCI-ACC-05 | SC-PCI-001-19 | Negative |
| PCI-ACC-06 | SC-PCI-001-02, SC-PCI-001-18 | Core, Retention/Audit |
| PCI-SEG-01 | SC-PCI-001-23, SC-PCI-001-37, SC-PCI-001-36 | Common Failure, Concurrency/Idempotency, Negative |
| PCI-SEG-02 | DR-PCI-001-01, DR-PCI-001-02, SC-PCI-001-24, SC-PCI-001-25, SC-PCI-001-35 | Boundary/Edge, Core, Failure/Recovery, Negative |
| PCI-SEG-03 | SC-PCI-001-22, SC-PCI-001-26 | Positive, Retention/Audit |
| PCI-LOG-01 | SC-PCI-001-03, SC-PCI-001-27, SC-PCI-001-38 | Core, Negative, Positive |
| PCI-LOG-51 | — (static backstop; traced via PCI-LOG-01) | — |
| PCI-LOG-02 | SC-PCI-001-39, SC-PCI-001-28 | Concurrency/Idempotency, Failure/Recovery |
| PCI-LOG-03 | SC-PCI-001-29, SC-PCI-001-30, SC-PCI-001-31, SC-PCI-001-32 | Boundary/Edge, Common Failure, Retention/Audit |
| PCI-LOG-04 | DR-PCI-001-10 | Core |

# Helix review rules

Generated from `checks.json` (23 static and behavioural checks; manual/evidence items are not code-reviewable and are omitted). Severity is derived from the playbook priority (P0 -> HIGH); Category MM marks money-movement checks. Rule text is the source invariant, unchanged; it is AI-drafted and needs compliance review.

## Rule PCI-ENC-01: PAN never reaches storage, logs, URLs, error bodies, traces or third-party payloads in clear — on...
Severity: HIGH
Category: NON_MM
Scenario: encryption
Requirement: MUST
Invariant: PAN never reaches storage, logs, URLs, error bodies, traces or third-party payloads in clear — only token, truncated or encrypted forms.

Source check `PCI-ENC-01` from `checks.json` (static; deterministic: yes). Covers: Encryption · Unencrypted PAN · PCI-DSS 4.0. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-PCI-001.

## Rule PCI-ENC-02: PAN-like input in free-text fields is redacted or rejected before persistence
Severity: HIGH
Category: NON_MM
Scenario: encryption
Requirement: MUST
Invariant: PAN-like input in free-text fields is redacted or rejected before persistence; non-PAN numbers are not false-redacted.

Source check `PCI-ENC-02` from `checks.json` (behavioural; deterministic: yes). Covers: Encryption · Unencrypted PAN · PCI-DSS 4.0. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-PCI-001.

## Rule PCI-ENC-03: Sensitive authentication data (CVV, PIN block, track) does not persist anywhere after authorization
Severity: HIGH
Category: NON_MM
Scenario: encryption
Requirement: MUST
Invariant: Sensitive authentication data (CVV, PIN block, track) does not persist anywhere after authorization.

Source check `PCI-ENC-03` from `checks.json` (behavioural; deterministic: yes). Covers: Encryption · Unencrypted PAN · PCI-DSS 4.0. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-PCI-001.

## Rule PCI-ENC-51: No column, log statement, cache or serializer persists CVV/CVC, PIN block or track data fields af...
Severity: HIGH
Category: NON_MM
Scenario: encryption
Requirement: MUST
Invariant: No column, log statement, cache or serializer persists CVV/CVC, PIN block or track data fields after the authorization call site (schema + source scan).

Source check `PCI-ENC-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: Encryption · Unencrypted PAN · PCI-DSS 4.0. Backstop for PCI-ENC-03. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-PCI-001.

## Rule PCI-ENC-04: Detokenization returns the original PAN only to authorised services
Severity: HIGH
Category: NON_MM
Scenario: encryption
Requirement: MUST
Invariant: Detokenization returns the original PAN only to authorised services; unauthorised callers get an authz error, no PAN, and a logged denial.

Source check `PCI-ENC-04` from `checks.json` (behavioural; deterministic: yes). Covers: Encryption · None · PCI-DSS 4.0. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-PCI-001.

## Rule PCI-ENC-53: The detokenize entry point is reachable only through an authz-checked route/service allowlist
Severity: HIGH
Category: NON_MM
Scenario: encryption
Requirement: MUST
Invariant: The detokenize entry point is reachable only through an authz-checked route/service allowlist; no other module imports the vault's raw detokenize.

Source check `PCI-ENC-53` from `checks.json` (static, static backstop; deterministic: yes). Covers: Encryption · None · PCI-DSS 4.0. Backstop for PCI-ENC-04. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-PCI-001.

## Rule PCI-ENC-05: Every CDE volume, bucket, table and backup target is declared encrypted at rest under the configu...
Severity: HIGH
Category: NON_MM
Scenario: encryption
Requirement: MUST
Invariant: Every CDE volume, bucket, table and backup target is declared encrypted at rest under the configured key policy (IaC = deployed, no drift).

Source check `PCI-ENC-05` from `checks.json` (static; deterministic: yes). Covers: Encryption · Unencrypted PAN · PCI-DSS 4.0. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-PCI-001.

## Rule PCI-ENC-06: Truncated and hashed PAN forms cannot be correlated back to a PAN (keyed hash, protected key)
Severity: HIGH
Category: NON_MM
Scenario: encryption
Requirement: MUST
Invariant: Truncated and hashed PAN forms cannot be correlated back to a PAN (keyed hash, protected key).

Source check `PCI-ENC-06` from `checks.json` (behavioural; deterministic: yes). Covers: Encryption · None · PCI-DSS 4.0. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-PCI-001.

## Rule PCI-ENC-07: Tokenisation and re-encryption are idempotent
Severity: HIGH
Category: NON_MM
Scenario: encryption
Requirement: MUST
Invariant: Tokenisation and re-encryption are idempotent: concurrent tokenise of one PAN yields one vault record; an interrupted re-key job leaves every record encrypted exactly once.

Source check `PCI-ENC-07` from `checks.json` (behavioural; deterministic: yes). Covers: Encryption · Unencrypted PAN · PCI-DSS 4.0. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-PCI-001, RR-PCI-011.

## Rule PCI-ENC-54: Tokenisation writes use a unique constraint on the PAN fingerprint (or upsert), and the re-key jo...
Severity: HIGH
Category: NON_MM
Scenario: encryption
Requirement: MUST
Invariant: Tokenisation writes use a unique constraint on the PAN fingerprint (or upsert), and the re-key job persists a per-record key-version marker before advancing.

Source check `PCI-ENC-54` from `checks.json` (static, static backstop; deterministic: yes). Covers: Encryption · Unencrypted PAN · PCI-DSS 4.0. Backstop for PCI-ENC-07. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-PCI-001, RR-PCI-011.

## Rule PCI-ENC-08: Key revoked/unavailable fails closed — no fallback to plaintext storage or processing
Severity: HIGH
Category: NON_MM
Scenario: encryption
Requirement: MUST
Invariant: Key revoked/unavailable fails closed — no fallback to plaintext storage or processing.

Source check `PCI-ENC-08` from `checks.json` (behavioural; deterministic: yes). Covers: Encryption · Unencrypted PAN · PCI-DSS 4.0. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-PCI-001, RR-PCI-011.

## Rule PCI-ENC-52: Every encrypt/decrypt call path handles key-unavailable by throwing/aborting — no catch branch wr...
Severity: HIGH
Category: NON_MM
Scenario: encryption
Requirement: MUST
Invariant: Every encrypt/decrypt call path handles key-unavailable by throwing/aborting — no catch branch writes or returns the plaintext value.

Source check `PCI-ENC-52` from `checks.json` (static, static backstop; deterministic: yes). Covers: Encryption · Unencrypted PAN · PCI-DSS 4.0. Backstop for PCI-ENC-08. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-PCI-001, RR-PCI-011.

## Rule PCI-ACC-01: CDE permissions equal the approved policy matrix
Severity: HIGH
Category: NON_MM
Scenario: access-control
Requirement: MUST
Invariant: CDE permissions equal the approved policy matrix: least privilege, no wildcard/implicit grants, unique IDs, MFA on interactive access, masked PAN for non-authorised roles.

Source check `PCI-ACC-01` from `checks.json` (behavioural; deterministic: yes). Covers: Access control · missing access review · PCI-DSS 4.0. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-PCI-003, RR-NIST-001.

## Rule PCI-ACC-51: IAM/RBAC policy files contain no wildcard actions/resources on CDE resources, and every interacti...
Severity: HIGH
Category: NON_MM
Scenario: access-control
Requirement: MUST
Invariant: IAM/RBAC policy files contain no wildcard actions/resources on CDE resources, and every interactive CDE role requires MFA in config.

Source check `PCI-ACC-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: Access control · missing access review · PCI-DSS 4.0. Backstop for PCI-ACC-01. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-PCI-003, RR-NIST-001.

## Rule PCI-ACC-02: A role downgrade or termination takes effect on the next request — no stale-token or stale-sessio...
Severity: HIGH
Category: NON_MM
Scenario: access-control
Requirement: MUST
Invariant: A role downgrade or termination takes effect on the next request — no stale-token or stale-session privilege beyond the configured TTL.

Source check `PCI-ACC-02` from `checks.json` (behavioural; deterministic: yes). Covers: Access control · missing access review · PCI-DSS 4.0. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-PCI-003, RR-NIST-001.

## Rule PCI-ACC-52: Authorization middleware re-reads role/status from the store on each CDE request (or token TTL ≤...
Severity: HIGH
Category: NON_MM
Scenario: access-control
Requirement: MUST
Invariant: Authorization middleware re-reads role/status from the store on each CDE request (or token TTL ≤ configured max) — no role taken from an unverified token claim alone.

Source check `PCI-ACC-52` from `checks.json` (static, static backstop; deterministic: yes). Covers: Access control · missing access review · PCI-DSS 4.0. Backstop for PCI-ACC-02. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-PCI-003, RR-NIST-001.

## Rule PCI-ACC-03: Session idle timeout and break-glass windows are enforced at the configured boundary using the co...
Severity: HIGH
Category: NON_MM
Scenario: access-control
Requirement: MUST
Invariant: Session idle timeout and break-glass windows are enforced at the configured boundary using the controllable clock; break-glass requires approval and auto-expires.

Source check `PCI-ACC-03` from `checks.json` (behavioural; deterministic: yes). Covers: Access control · None · PCI-DSS 4.0. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-PCI-003.

## Rule PCI-ACC-04: IdP outage fails closed
Severity: HIGH
Category: NON_MM
Scenario: access-control
Requirement: MUST
Invariant: IdP outage fails closed: normal CDE access denied; only approved, fully-logged break-glass works.

Source check `PCI-ACC-04` from `checks.json` (behavioural; deterministic: yes). Covers: Access control · None · PCI-DSS 4.0. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-PCI-003.

## Rule PCI-ACC-05: No vendor default credentials or default accounts are present in CDE component config/IaC
Severity: HIGH
Category: NON_MM
Scenario: access-control
Requirement: MUST
Invariant: No vendor default credentials or default accounts are present in CDE component config/IaC.

Source check `PCI-ACC-05` from `checks.json` (static; deterministic: yes). Covers: Access control · None · PCI-DSS 4.0. Review status in source: Drafted (AI) – needs compliance review.

## Rule PCI-SEG-01: A network-policy/IaC diff that opens a path into the CDE or deploys an unscoped service into it i...
Severity: HIGH
Category: NON_MM
Scenario: network-segmentation
Requirement: MUST
Invariant: A network-policy/IaC diff that opens a path into the CDE or deploys an unscoped service into it is blocked without approval.

Source check `PCI-SEG-01` from `checks.json` (static; deterministic: yes). Covers: Network segmentation · None · PCI-DSS 4.0. Review status in source: Drafted (AI) – needs compliance review.

## Rule PCI-LOG-01: Every CHD access and every failed/invalid access attempt emits exactly one audit event (user, tim...
Severity: HIGH
Category: NON_MM
Scenario: logging
Requirement: MUST
Invariant: Every CHD access and every failed/invalid access attempt emits exactly one audit event (user, time, resource, reason, outcome) containing no PAN.

Source check `PCI-LOG-01` from `checks.json` (behavioural; deterministic: yes). Covers: Logging · missing access review · PCI-DSS 4.0. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-PCI-004.

## Rule PCI-LOG-51: Every CHD-access and auth-failure handler calls the audit emitter, and audit event schemas exclud...
Severity: HIGH
Category: NON_MM
Scenario: logging
Requirement: MUST
Invariant: Every CHD-access and auth-failure handler calls the audit emitter, and audit event schemas exclude PAN-typed fields.

Source check `PCI-LOG-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: Logging · missing access review · PCI-DSS 4.0. Backstop for PCI-LOG-01. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-PCI-004.

## Rule PCI-LOG-02: Under concurrent load the audit event count equals the action count and the log pipeline never si...
Severity: HIGH
Category: NON_MM
Scenario: logging
Requirement: MUST
Invariant: Under concurrent load the audit event count equals the action count and the log pipeline never silently drops events (buffered or alerted on outage).

Source check `PCI-LOG-02` from `checks.json` (behavioural; deterministic: yes). Covers: Logging · None · PCI-DSS 4.0. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-PCI-004.
