---
helixPlaybookFormat: helix-playbook/0.1-proposal
playbookId: vigil-ccpa-cpra
title: "CCPA/CPRA Consumer Privacy Rights"
declaredVersion: 0.1.0
intent: draft
applicability:
  languages: [javascript, typescript]
  scenarios: [opt-out, data-access-request, sale-of-data]
---
# Helix portable playbook — DRAFT manifest · CCPA/CPRA Consumer Privacy Rights

> **DRAFT — not LOCKED.** Proposed CCPA/CPRA (Data Privacy) playbook converted from Vigil skill `SK-CCPA-001`: one runner, two layers, **16 harness checks (4 static, incl. 3 static backstops, + 12 behavioural)**, plus 2 manual/evidence items listed separately because neither layer can verify them. Every invariant, layer and determinism call is **AI-drafted (Helix) and needs compliance review**. No detector or rule code exists yet. Before this manifest can be LOCKED, each row needs its detector/rule, a review, and a commit that adds the check alongside its row.

## Layers

- **static**: a repo-agnostic source scanner parameterised by a `VIGIL_CCPA` preset (no app specifics in the detector). It reads source / SQL / config / IaC / git-diff, **fails CLOSED** on a match, and runs with **no adapter**, so it is the CI gate. *Static backstops* (IDs `-5x`) prove a supporting source invariant for a named behavioural check, the way N-CAP-01 / N-STATE-01 back neobank behaviour. They fire even when the adapter never drives that path. Backstops of ⚑ SME checks stay out of the gate.
- **behavioural**: a rule written once against the canonical `MoneySystem` interface (or a DRAFT extension surface in `adapters/`) and driven through the app adapter. Surfaces needed: **PrivacySystem** (`adapters/privacy.ts`). Every behavioural row reports NOT_EXERCISED until an adapter implements its surface. It returns **CHECKED only when it actually drove the guard's path**.
- **manual/evidence**: organisational process, live-infrastructure, statistical or retention evidence that no source scan or adapter-driven rule can prove. These are **outside the harness**, report `NOT_APPLICABLE` to it, and are tracked as evidence tasks, never as passes.

## Verdicts

`CHECKED` the path ran and the guard held · `FINDING` the guard was violated · `NOT_APPLICABLE` the invariant cannot apply here (incl. every manual/evidence item) · `NOT_EXERCISED` (glyph `????`) the adapter did not drive the path, so nothing is proven. NOT_EXERCISED is **surfaced distinctly and never counted as a pass** (no fake coverage). A ⚑ SME check with no approved parameter matrix reports `NOT_EXERCISED`, never `CHECKED`.

## How to run

- **Not runnable yet**: this draft defines invariants only (no detector/rule code). The intended shape mirrors the neobank playbook:
  - CI gate (adapter-free, blocks on any static FINDING): `run-static` with preset `VIGIL_CCPA`.
  - Full combined table (static + behavioural via the adapter): `run-all`.
- Machine-readable rows: `checks.json` (same IDs; includes source-scenario traceability and neobank overlaps).

## The draft inventory: 4 static + 12 behavioural = 16 checks

| ID | Layer | Deterministic | Invariant (one line) | Covers (automation point · common failure · regulation) |
| --- | --- | --- | --- | --- |
| **CCPA-OPT-01** | behavioural | yes | An opt-out (link, preference signal such as GPC, logged-out choice) persists across sessions/devices and suppresses every sale/share flow, including server-side forwarding and new partner feeds. | Opt-out / Sale of data · Missing opt-out · CCPA/CPRA |
| **CCPA-OPT-51** | static | yes | Every outbound sale/share integration (pixel, server-side forwarder, partner feed) reads the opt-out suppression list before sending. | backstop for CCPA-OPT-01 · Opt-out / Sale of data · Missing opt-out · CCPA/CPRA |
| **CCPA-OPT-02** | behavioural | yes | Opt-out is honoured without verification beyond the configured minimum. | Opt-out · Missing opt-out · CCPA/CPRA |
| **CCPA-OPT-03** | behavioural | yes | No third-party ad/sharing tag fires before the opt-out state is evaluated. | Opt-out · Missing opt-out · CCPA/CPRA |
| **CCPA-OPT-04** | behavioural | yes | Opt-out service outage defaults to no sale/share and alerts. | Opt-out · Missing opt-out · CCPA/CPRA |
| **CCPA-OPT-52** | static | yes | Opt-out state lookup failure defaults to suppress (no default-share branch). | backstop for CCPA-OPT-04 · Opt-out · Missing opt-out · CCPA/CPRA |
| **CCPA-OPT-05** | behavioural | yes | No price or service difference is attributable to exercising privacy rights (outside configured exceptions). | Opt-out · general control (no source failure) · CCPA/CPRA |
| **CCPA-ACC-01** | behavioural | yes | A verified access response lists all categories and specific pieces held (incl. data at service providers) over the configured lookback, withholding configured prohibited fields. | Data access request · incomplete access · CCPA/CPRA |
| **CCPA-ACC-02** | behavioural | yes | Requests are acknowledged and completed within configured windows or extended with notice before the deadline; an outage preserves the deadline clock (controllable clock). | Data access request · incomplete access · CCPA/CPRA |
| **CCPA-ACC-03** | behavioural | yes | Duplicate access requests within the window are handled per configured limits. | Data access request · incomplete access · CCPA/CPRA |
| **CCPA-ACC-04** | behavioural | yes | Corrections propagate to every mapped system within the configured window. | Data access request · incomplete access · CCPA/CPRA |
| **CCPA-SAL-01** | behavioural | yes | After opt-out, no export or partner feed classified as sale/share includes the consumer, including retries and runs in progress past the configured cutoff. | Sale of data · Missing opt-out · CCPA/CPRA |
| **CCPA-SAL-51** | static | yes | Partner export jobs and their retries re-query the current suppression list at send time rather than reusing a cached population. | backstop for CCPA-SAL-01 · Sale of data · Missing opt-out · CCPA/CPRA |
| **CCPA-SAL-02** | static | yes | A new data-sharing destination without a sale/share classification flag is blocked in CI. | Sale of data · Missing opt-out · CCPA/CPRA |
| **CCPA-SAL-03** | behavioural | yes | Minors' data is never sold/shared without affirmative opt-in; sensitive PI is used only for permitted purposes after a limit request; sharing resumes only after explicit opt-in. | Sale of data · Missing opt-out · CCPA/CPRA |
| **CCPA-SAL-04** | behavioural | yes | Deletion and opt-out notices propagate to service providers/third parties per configuration, and the consumer is not re-prompted before the configured interval. | Sale of data · general control (no source failure) · CCPA/CPRA |

## Outside the harness: manual/evidence (2)

These items are not harness checks. Each reports `NOT_APPLICABLE` to the runner and needs an owner and evidence on a schedule.

| ID | Layer | Deterministic | Invariant (one line) | Covers (automation point · common failure · regulation) |
| --- | --- | --- | --- | --- |
| **CCPA-OPT-06** | manual/evidence | no (manual) | 'Do Not Sell or Share' link and notice at collection are present on every applicable surface. | Opt-out · general control (no source failure) · CCPA/CPRA |
| **CCPA-ACC-05** | manual/evidence | no (manual) | GLBA-covered data scoping in responses follows the documented legal scoping decision; consumer-request records retained for the configured period. | Data access request / Opt-out · incomplete access · CCPA/CPRA |

### Determinism

Every harness row (static and behavioural) is drafted as deterministic. Static detectors, including backstops, are pure functions of the committed source/config/diff. Behavioural rules each run against a **fresh `reset()` MoneySystem** (no state leaks between rules), driven by a **controllable clock**; deadlines, windows, expiries and cadences are asserted by advancing that clock, never by wall-clock reads, and no randomness affects a verdict. External dependencies (vendors, registries, feeds) are faked inside the adapter, which is how fault-injection rows stay deterministic. Manual/evidence rows are not deterministic and are not gate checks.

### Coverage note

Converted from 34 AI-drafted source scenarios of `SK-CCPA-001`; each source scenario maps to exactly one non-backstop row (see the appendix). Static backstops add no scenarios and trace through the check they back. The scenarios were merged into crisp invariants by automation point and failure mode, across categories (positive, negative, boundary, failure/recovery, concurrency/idempotency, retention/audit, common failure, core). Automation points covered: Opt-out, Data access request, Sale of data. Source common failures: Missing opt-out, incomplete access. Thresholds, windows and deadlines are *configured* parameters, not asserted statutory values. No regulation or citation was added beyond the source sheet.

### Overlap with the locked neobank playbook (19 checks)

| This check | Neobank check | Strength | Why |
| --- | --- | --- | --- |
| CCPA-ACC-03 | N-IDEMP-01 | related | duplicate requests |

`same` means the neobank check already enforces this invariant, so reuse it instead of re-implementing. `related` means the same defect class, but this check needs its own rule or preset.

### Review flags

- **CCPA-ACC-05**: expert input noted in source feasibility: needs legal scoping.

## Appendix: traceability to source scenarios

| Check ID | Source scenario IDs | Categories merged |
| --- | --- | --- |
| CCPA-OPT-01 | SC-CCPA-001-01, SC-CCPA-001-04, SC-CCPA-001-18, SC-CCPA-001-19, SC-CCPA-001-15, DR-CCPA-001-01 | Boundary/Edge, Common Failure, Core, Positive |
| CCPA-OPT-51 | — (static backstop; traced via CCPA-OPT-01) | — |
| CCPA-OPT-02 | SC-CCPA-001-05 | Negative |
| CCPA-OPT-03 | SC-CCPA-001-06 | Concurrency/Idempotency |
| CCPA-OPT-04 | SC-CCPA-001-07 | Failure/Recovery |
| CCPA-OPT-52 | — (static backstop; traced via CCPA-OPT-04) | — |
| CCPA-OPT-05 | DR-CCPA-001-07 | Core |
| CCPA-OPT-06 | DR-CCPA-001-02 | Core |
| CCPA-ACC-01 | SC-CCPA-001-02, SC-CCPA-001-09, SC-CCPA-001-10, SC-CCPA-001-11, SC-CCPA-001-20 | Boundary/Edge, Common Failure, Core, Negative, Positive |
| CCPA-ACC-02 | SC-CCPA-001-12, SC-CCPA-001-21, DR-CCPA-001-06 | Boundary/Edge, Core, Failure/Recovery |
| CCPA-ACC-03 | SC-CCPA-001-13 | Concurrency/Idempotency |
| CCPA-ACC-04 | DR-CCPA-001-05 | Core |
| CCPA-ACC-05 | DR-CCPA-001-09, SC-CCPA-001-08, SC-CCPA-001-22 | Core, Retention/Audit |
| CCPA-SAL-01 | SC-CCPA-001-23, SC-CCPA-001-24, SC-CCPA-001-25 | Concurrency/Idempotency, Failure/Recovery, Negative |
| CCPA-SAL-51 | — (static backstop; traced via CCPA-SAL-01) | — |
| CCPA-SAL-02 | SC-CCPA-001-14 | Common Failure |
| CCPA-SAL-03 | DR-CCPA-001-03, DR-CCPA-001-04, SC-CCPA-001-16 | Boundary/Edge, Core |
| CCPA-SAL-04 | SC-CCPA-001-03, SC-CCPA-001-17, DR-CCPA-001-08 | Core, Retention/Audit |

# Helix review rules

Generated from `checks.json` (16 static and behavioural checks; manual/evidence items are not code-reviewable and are omitted). Severity is derived from the playbook priority (P0 -> HIGH); Category MM marks money-movement checks. Rule text is the source invariant, unchanged; it is AI-drafted and needs compliance review.

## Rule CCPA-OPT-01: An opt-out (link, preference signal such as GPC, logged-out choice) persists across sessions/devi...
Severity: HIGH
Category: NON_MM
Scenario: opt-out
Requirement: MUST
Invariant: An opt-out (link, preference signal such as GPC, logged-out choice) persists across sessions/devices and suppresses every sale/share flow, including server-side forwarding and new partner feeds.

Source check `CCPA-OPT-01` from `checks.json` (behavioural; deterministic: yes). Covers: Opt-out, Sale of data · Missing opt-out · CCPA/CPRA. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-DATA-003.

## Rule CCPA-OPT-51: Every outbound sale/share integration (pixel, server-side forwarder, partner feed) reads the opt-...
Severity: HIGH
Category: NON_MM
Scenario: opt-out
Requirement: MUST
Invariant: Every outbound sale/share integration (pixel, server-side forwarder, partner feed) reads the opt-out suppression list before sending.

Source check `CCPA-OPT-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: Opt-out, Sale of data · Missing opt-out · CCPA/CPRA. Backstop for CCPA-OPT-01. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-DATA-003.

## Rule CCPA-OPT-02: Opt-out is honoured without verification beyond the configured minimum
Severity: HIGH
Category: NON_MM
Scenario: opt-out
Requirement: MUST
Invariant: Opt-out is honoured without verification beyond the configured minimum.

Source check `CCPA-OPT-02` from `checks.json` (behavioural; deterministic: yes). Covers: Opt-out · Missing opt-out · CCPA/CPRA. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-DATA-003.

## Rule CCPA-OPT-03: No third-party ad/sharing tag fires before the opt-out state is evaluated
Severity: HIGH
Category: NON_MM
Scenario: opt-out
Requirement: MUST
Invariant: No third-party ad/sharing tag fires before the opt-out state is evaluated.

Source check `CCPA-OPT-03` from `checks.json` (behavioural; deterministic: yes). Covers: Opt-out · Missing opt-out · CCPA/CPRA. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-DATA-003.

## Rule CCPA-OPT-04: Opt-out service outage defaults to no sale/share and alerts
Severity: HIGH
Category: NON_MM
Scenario: opt-out
Requirement: MUST
Invariant: Opt-out service outage defaults to no sale/share and alerts.

Source check `CCPA-OPT-04` from `checks.json` (behavioural; deterministic: yes). Covers: Opt-out · Missing opt-out · CCPA/CPRA. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-DATA-003.

## Rule CCPA-OPT-52: Opt-out state lookup failure defaults to suppress (no default-share branch)
Severity: HIGH
Category: NON_MM
Scenario: opt-out
Requirement: MUST
Invariant: Opt-out state lookup failure defaults to suppress (no default-share branch).

Source check `CCPA-OPT-52` from `checks.json` (static, static backstop; deterministic: yes). Covers: Opt-out · Missing opt-out · CCPA/CPRA. Backstop for CCPA-OPT-04. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-DATA-003.

## Rule CCPA-OPT-05: No price or service difference is attributable to exercising privacy rights (outside configured e...
Severity: HIGH
Category: NON_MM
Scenario: opt-out
Requirement: MUST
Invariant: No price or service difference is attributable to exercising privacy rights (outside configured exceptions).

Source check `CCPA-OPT-05` from `checks.json` (behavioural; deterministic: yes). Covers: Opt-out · None · CCPA/CPRA. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-DATA-003.

## Rule CCPA-ACC-01: A verified access response lists all categories and specific pieces held (incl
Severity: HIGH
Category: NON_MM
Scenario: data-access-request
Requirement: MUST
Invariant: A verified access response lists all categories and specific pieces held (incl. data at service providers) over the configured lookback, withholding configured prohibited fields.

Source check `CCPA-ACC-01` from `checks.json` (behavioural; deterministic: yes). Covers: Data access request · incomplete access · CCPA/CPRA. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-DATA-003.

## Rule CCPA-ACC-02: Requests are acknowledged and completed within configured windows or extended with notice before...
Severity: HIGH
Category: NON_MM
Scenario: data-access-request
Requirement: MUST
Invariant: Requests are acknowledged and completed within configured windows or extended with notice before the deadline; an outage preserves the deadline clock (controllable clock).

Source check `CCPA-ACC-02` from `checks.json` (behavioural; deterministic: yes). Covers: Data access request · incomplete access · CCPA/CPRA. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-DATA-003.

## Rule CCPA-ACC-03: Duplicate access requests within the window are handled per configured limits
Severity: HIGH
Category: NON_MM
Scenario: data-access-request
Requirement: MUST
Invariant: Duplicate access requests within the window are handled per configured limits.

Source check `CCPA-ACC-03` from `checks.json` (behavioural; deterministic: yes). Covers: Data access request · incomplete access · CCPA/CPRA. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-DATA-003.

## Rule CCPA-ACC-04: Corrections propagate to every mapped system within the configured window
Severity: HIGH
Category: NON_MM
Scenario: data-access-request
Requirement: MUST
Invariant: Corrections propagate to every mapped system within the configured window.

Source check `CCPA-ACC-04` from `checks.json` (behavioural; deterministic: yes). Covers: Data access request · incomplete access · CCPA/CPRA. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-DATA-003.

## Rule CCPA-SAL-01: After opt-out, no export or partner feed classified as sale/share includes the consumer, includin...
Severity: HIGH
Category: NON_MM
Scenario: sale-of-data
Requirement: MUST
Invariant: After opt-out, no export or partner feed classified as sale/share includes the consumer, including retries and runs in progress past the configured cutoff.

Source check `CCPA-SAL-01` from `checks.json` (behavioural; deterministic: yes). Covers: Sale of data · Missing opt-out · CCPA/CPRA. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-DATA-003.

## Rule CCPA-SAL-51: Partner export jobs and their retries re-query the current suppression list at send time rather t...
Severity: HIGH
Category: NON_MM
Scenario: sale-of-data
Requirement: MUST
Invariant: Partner export jobs and their retries re-query the current suppression list at send time rather than reusing a cached population.

Source check `CCPA-SAL-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: Sale of data · Missing opt-out · CCPA/CPRA. Backstop for CCPA-SAL-01. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-DATA-003.

## Rule CCPA-SAL-02: A new data-sharing destination without a sale/share classification flag is blocked in CI
Severity: HIGH
Category: NON_MM
Scenario: sale-of-data
Requirement: MUST
Invariant: A new data-sharing destination without a sale/share classification flag is blocked in CI.

Source check `CCPA-SAL-02` from `checks.json` (static; deterministic: yes). Covers: Sale of data · Missing opt-out · CCPA/CPRA. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-DATA-003.

## Rule CCPA-SAL-03: Minors' data is never sold/shared without affirmative opt-in
Severity: HIGH
Category: NON_MM
Scenario: sale-of-data
Requirement: MUST
Invariant: Minors' data is never sold/shared without affirmative opt-in; sensitive PI is used only for permitted purposes after a limit request; sharing resumes only after explicit opt-in.

Source check `CCPA-SAL-03` from `checks.json` (behavioural; deterministic: yes). Covers: Sale of data · Missing opt-out · CCPA/CPRA. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-DATA-003.

## Rule CCPA-SAL-04: Deletion and opt-out notices propagate to service providers/third parties per configuration, and...
Severity: HIGH
Category: NON_MM
Scenario: sale-of-data
Requirement: MUST
Invariant: Deletion and opt-out notices propagate to service providers/third parties per configuration, and the consumer is not re-prompted before the configured interval.

Source check `CCPA-SAL-04` from `checks.json` (behavioural; deterministic: yes). Covers: Sale of data · None · CCPA/CPRA. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-DATA-003.
