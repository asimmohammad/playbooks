---
helixPlaybookFormat: helix-playbook/0.1-proposal
playbookId: vigil-3ds
title: "EMV 3-D Secure 2.x Authentication Assurance"
declaredVersion: 0.1.0
intent: draft
applicability:
  languages: [javascript, typescript]
  scenarios: [flow-challenge-frictionless-vs-challenge, authentication-value-authorization-binding-eci-c, liability-shift, exemptions-sca-interplay, errors-timeouts-fallback, data-handling-protocol-version]
---
# Helix portable playbook — DRAFT manifest · EMV 3-D Secure 2.x Authentication Assurance

> **DRAFT — not LOCKED.** Proposed EMV 3-D Secure 2.x + card-network rules (as configured); PSD2 SCA interplay (Card Authentication) playbook built from 48 **inline AI-drafted scenarios** (not in the source sheet; see *Inline scenarios*): one runner, two layers, **37 harness checks (13 static, incl. 11 static backstops, + 24 behavioural)**, plus 1 manual/evidence items listed separately because neither layer can verify them. Every invariant, layer and determinism call is **AI-drafted (Helix) and needs compliance review**; 6 check(s) are **⚑ SME-flagged** and cannot gate until an SME/counsel supplies their parameter matrix. No detector or rule code exists yet. Before this manifest can be LOCKED, each row needs its detector/rule, a review, and a commit that adds the check alongside its row.

## Layers

- **static**: a repo-agnostic source scanner parameterised by a `VIGIL_3DS` preset (no app specifics in the detector). It reads source / SQL / config / IaC / git-diff, **fails CLOSED** on a match, and runs with **no adapter**, so it is the CI gate. *Static backstops* (IDs `-5x`) prove a supporting source invariant for a named behavioural check, the way N-CAP-01 / N-STATE-01 back neobank behaviour. They fire even when the adapter never drives that path. Backstops of ⚑ SME checks stay out of the gate.
- **behavioural**: a rule written once against the canonical `MoneySystem` interface (or a DRAFT extension surface in `adapters/`) and driven through the app adapter. Surfaces needed: **ThreeDSecureSystem** (`adapters/three-d-secure.ts`). Every behavioural row reports NOT_EXERCISED until an adapter implements its surface. It returns **CHECKED only when it actually drove the guard's path**.
- **manual/evidence**: organisational process, live-infrastructure, statistical or retention evidence that no source scan or adapter-driven rule can prove. These are **outside the harness**, report `NOT_APPLICABLE` to it, and are tracked as evidence tasks, never as passes.

## Verdicts

`CHECKED` the path ran and the guard held · `FINDING` the guard was violated · `NOT_APPLICABLE` the invariant cannot apply here (incl. every manual/evidence item) · `NOT_EXERCISED` (glyph `????`) the adapter did not drive the path, so nothing is proven. NOT_EXERCISED is **surfaced distinctly and never counted as a pass** (no fake coverage). A ⚑ SME check with no approved parameter matrix reports `NOT_EXERCISED`, never `CHECKED`.

## How to run

- **Not runnable yet**: this draft defines invariants only (no detector/rule code). The intended shape mirrors the neobank playbook:
  - CI gate (adapter-free, blocks on any static FINDING): `run-static` with preset `VIGIL_3DS`.
  - Full combined table (static + behavioural via the adapter): `run-all`.
- Machine-readable rows: `checks.json` (same IDs; includes source-scenario traceability and neobank overlaps).

## The draft inventory: 13 static + 24 behavioural = 37 checks

| ID | Layer | Deterministic | Invariant (one line) | Covers (automation point · common failure · regulation) |
| --- | --- | --- | --- | --- |
| **3DS-FLOW-01** | behavioural | yes | Final authentication status comes only from the authenticated results channel for that transaction; redirect/client values never set status. | Flow & challenge (frictionless vs challenge) · Authorization proceeds without a valid authentication result · EMV 3-D Secure 2.x + card-network rules (as configured); PSD2 SCA interplay |
| **3DS-FLOW-51** | static | yes | Authentication status is written only by the results-message handler; browser-return handlers have no write path to authentication status. | backstop for 3DS-FLOW-01 · Flow & challenge (frictionless vs challenge) · Authorization proceeds without a valid authentication result · EMV 3-D Secure 2.x + card-network rules (as configured); PSD2 SCA interplay |
| **3DS-FLOW-02** | behavioural | yes | N and R never authorize as authenticated; U only per the configured fallback policy. | Flow & challenge (frictionless vs challenge) · Authorization proceeds without a valid authentication result · EMV 3-D Secure 2.x + card-network rules (as configured); PSD2 SCA interplay |
| **3DS-FLOW-03** | behavioural | yes | The challenge window is enforced at the configured timeout (controllable clock); abandoned or late challenges end not-authenticated and release any reservation. | Flow & challenge (frictionless vs challenge) · general control (no source failure) · EMV 3-D Secure 2.x + card-network rules (as configured); PSD2 SCA interplay |
| **3DS-FLOW-04** | behavioural | yes | Results messages are applied once per transaction id under duplicates and concurrency. | Flow & challenge (frictionless vs challenge) · general control (no source failure) · EMV 3-D Secure 2.x + card-network rules (as configured); PSD2 SCA interplay |
| **3DS-FLOW-53** | static | yes | The authentication results table has a unique key on the 3DS server transaction id and status updates are conditional, reporting success only when a row changed. | backstop for 3DS-FLOW-04 · Flow & challenge (frictionless vs challenge) · general control (no source failure) · EMV 3-D Secure 2.x + card-network rules (as configured); PSD2 SCA interplay |
| **3DS-FLOW-05** | behavioural | yes | A results message is authenticated (signature, known transaction) before any state change or authorization. | Flow & challenge (frictionless vs challenge) · Authorization proceeds without a valid authentication result · EMV 3-D Secure 2.x + card-network rules (as configured); PSD2 SCA interplay |
| **3DS-FLOW-52** | static | yes | The results-message handler verifies message authenticity before any DB write or authorization call, with a default-deny error branch. | backstop for 3DS-FLOW-05 · Flow & challenge (frictionless vs challenge) · Authorization proceeds without a valid authentication result · EMV 3-D Secure 2.x + card-network rules (as configured); PSD2 SCA interplay |
| **3DS-FLOW-06** | behavioural | yes | Every authentication emits exactly one audit record (ids, version, flow, status, ECI, times) with no authentication value or PAN. | Flow & challenge (frictionless vs challenge) · general control (no source failure) · EMV 3-D Secure 2.x + card-network rules (as configured); PSD2 SCA interplay |
| **3DS-AV-01** | behavioural | yes | Authorization ECI / authentication value / DS id equal those stored for this transaction; another transaction's result is never used; captures link to the original. | Authentication value & authorization binding (ECI / CAVV) · Authentication value reused or not bound to the transaction · EMV 3-D Secure 2.x + card-network rules (as configured); PSD2 SCA interplay |
| **3DS-AV-51** | static | yes | The authorization builder reads ECI/authentication value from the stored authentication record keyed by transaction id, never from request parameters. | backstop for 3DS-AV-01 · Authentication value & authorization binding (ECI / CAVV) · Authentication value reused or not bound to the transaction · EMV 3-D Secure 2.x + card-network rules (as configured); PSD2 SCA interplay |
| **3DS-AV-02** | behavioural | yes | An amount, currency or merchant change beyond the configured tolerance forces re-authentication. | Authentication value & authorization binding (ECI / CAVV) · Authentication value reused or not bound to the transaction · EMV 3-D Secure 2.x + card-network rules (as configured); PSD2 SCA interplay |
| **3DS-AV-03** | behavioural | yes | An authentication value is consumed at most once (incl. concurrently) and is never sent as authenticated after its configured validity. | Authentication value & authorization binding (ECI / CAVV) · Authentication value reused or not bound to the transaction · EMV 3-D Secure 2.x + card-network rules (as configured); PSD2 SCA interplay |
| **3DS-AV-52** | static | yes | Authentication-value consumption is a single-use conditional update (consumed IS NULL) inside the authorization transaction. | backstop for 3DS-AV-03 · Authentication value & authorization binding (ECI / CAVV) · Authentication value reused or not bound to the transaction · EMV 3-D Secure 2.x + card-network rules (as configured); PSD2 SCA interplay |
| **3DS-AV-04** | behavioural | yes | An authorization retry after timeout is idempotent: same authorization, no second use of the value. | Authentication value & authorization binding (ECI / CAVV) · general control (no source failure) · EMV 3-D Secure 2.x + card-network rules (as configured); PSD2 SCA interplay |
| **3DS-AV-05** | static | yes | ECI is selected from a configured per-network status→ECI table with a non-authenticated default; no ECI literals in the authorization path. | Authentication value & authorization binding (ECI / CAVV) · Authentication value reused or not bound to the transaction · EMV 3-D Secure 2.x + card-network rules (as configured); PSD2 SCA interplay |
| **3DS-LIAB-01** | behavioural | yes ⚑ SME | The liability-shift flag is set only per the configured network matrix from (status, ECI, value present, exemption); attempts are never upgraded; exempted or value-less authorizations are not shifted. | Liability shift · Liability shift claimed incorrectly · EMV 3-D Secure 2.x + card-network rules (as configured); PSD2 SCA interplay |
| **3DS-LIAB-51** | static | yes ⚑ SME | The liability-shift flag has one writer that reads the configured matrix; no other code path sets it. | backstop for 3DS-LIAB-01 · Liability shift · Liability shift claimed incorrectly · EMV 3-D Secure 2.x + card-network rules (as configured); PSD2 SCA interplay |
| **3DS-LIAB-02** | behavioural | yes | Liability evidence is retrievable for the configured window, then minimised; no authentication value in clear. | Liability shift · Authentication data elements logged or over-retained · EMV 3-D Secure 2.x + card-network rules (as configured); PSD2 SCA interplay |
| **3DS-EXM-01** | behavioural | yes ⚑ SME | TRA is granted only inside the configured fraud-rate/amount band; above it SCA is required. | Exemptions & SCA interplay · Exemption applied outside its configured conditions · EMV 3-D Secure 2.x + card-network rules (as configured); PSD2 SCA interplay |
| **3DS-EXM-51** | static | yes ⚑ SME | TRA band and fraud-rate thresholds load from a single configured source; no threshold literals in exemption code. | backstop for 3DS-EXM-01 · Exemptions & SCA interplay · Exemption applied outside its configured conditions · EMV 3-D Secure 2.x + card-network rules (as configured); PSD2 SCA interplay |
| **3DS-EXM-02** | behavioural | yes | Low-value exemption count/amount limits are kept server-side and enforced atomically under concurrency. | Exemptions & SCA interplay · Exemption applied outside its configured conditions · EMV 3-D Secure 2.x + card-network rules (as configured); PSD2 SCA interplay |
| **3DS-EXM-52** | static | yes | Low-value counters are read and incremented inside the payment transaction under a lock, never from client-supplied values. | backstop for 3DS-EXM-02 · Exemptions & SCA interplay · Exemption applied outside its configured conditions · EMV 3-D Secure 2.x + card-network rules (as configured); PSD2 SCA interplay |
| **3DS-EXM-03** | behavioural | yes | MIT requires a valid initial authenticated CIT reference; otherwise authentication is required. | Exemptions & SCA interplay · Exemption applied outside its configured conditions · EMV 3-D Secure 2.x + card-network rules (as configured); PSD2 SCA interplay |
| **3DS-EXM-04** | behavioural | yes | Trusted-beneficiary exemption requires ACS confirmation and exemption flags are never taken from the client. | Exemptions & SCA interplay · Exemption applied outside its configured conditions · EMV 3-D Secure 2.x + card-network rules (as configured); PSD2 SCA interplay |
| **3DS-EXM-53** | static | yes | No request DTO field maps to the exemption indicator; it is set only by the server-side exemption engine. | backstop for 3DS-EXM-04 · Exemptions & SCA interplay · Exemption applied outside its configured conditions · EMV 3-D Secure 2.x + card-network rules (as configured); PSD2 SCA interplay |
| **3DS-EXM-05** | behavioural | yes ⚑ SME | Scope classification (regional SCA scope, one-leg-out, MOTO) follows the configured matrix; in-scope transactions get SCA or a configured exemption; unknown defaults to SCA. | Exemptions & SCA interplay · Exemption applied outside its configured conditions · EMV 3-D Secure 2.x + card-network rules (as configured); PSD2 SCA interplay |
| **3DS-EXM-06** | behavioural | yes | An issuer SCA-required soft decline steps up to a challenge exactly once. | Exemptions & SCA interplay · general control (no source failure) · EMV 3-D Secure 2.x + card-network rules (as configured); PSD2 SCA interplay |
| **3DS-EXM-07** | behavioural | yes | Every exemption decision is audited with type, inputs, counters, decision and configuration version. | Exemptions & SCA interplay · general control (no source failure) · EMV 3-D Secure 2.x + card-network rules (as configured); PSD2 SCA interplay |
| **3DS-ERR-01** | behavioural | yes | DS/ACS timeouts, error messages, malformed responses and client exceptions fail closed: never authenticated, never frictionless-by-default. | Errors, timeouts & fallback · DS/ACS error or timeout fails open · EMV 3-D Secure 2.x + card-network rules (as configured); PSD2 SCA interplay |
| **3DS-ERR-51** | static | yes | Every 3DS client call's catch/timeout branch returns a not-authenticated result; no default or fall-through to Y/frictionless. | backstop for 3DS-ERR-01 · Errors, timeouts & fallback · DS/ACS error or timeout fails open · EMV 3-D Secure 2.x + card-network rules (as configured); PSD2 SCA interplay |
| **3DS-ERR-02** | behavioural | yes | ACS-unavailable fallback follows configured policy, never yields fully-authenticated ECI, and is deterministic at the timeout boundary. | Errors, timeouts & fallback · DS/ACS error or timeout fails open · EMV 3-D Secure 2.x + card-network rules (as configured); PSD2 SCA interplay |
| **3DS-ERR-03** | behavioural | yes | An AReq retry after timeout results in one applied authentication per purchase. | Errors, timeouts & fallback · general control (no source failure) · EMV 3-D Secure 2.x + card-network rules (as configured); PSD2 SCA interplay |
| **3DS-DATA-01** | static | yes | Authentication values, PAN and device-data payloads never reach log, trace or error sinks. | Data handling & protocol version · Authentication data elements logged or over-retained · EMV 3-D Secure 2.x + card-network rules (as configured); PSD2 SCA interplay |
| **3DS-DATA-02** | behavioural | yes | Versions below the configured minimum are refused; negotiation picks the highest supported ≥ minimum; stale or corrupt card-range data never causes a downgrade. | Data handling & protocol version · Protocol version downgrade accepted · EMV 3-D Secure 2.x + card-network rules (as configured); PSD2 SCA interplay |
| **3DS-DATA-51** | static | yes | The configured minimum protocol version is enforced at a single negotiation point; no code path builds messages below it. | backstop for 3DS-DATA-02 · Data handling & protocol version · Protocol version downgrade accepted · EMV 3-D Secure 2.x + card-network rules (as configured); PSD2 SCA interplay |
| **3DS-DATA-03** | behavioural | yes | 3DS messages and authentication values are purged/minimised per configured retention (controllable clock). | Data handling & protocol version · Authentication data elements logged or over-retained · EMV 3-D Secure 2.x + card-network rules (as configured); PSD2 SCA interplay |

## Outside the harness: manual/evidence (1)

These items are not harness checks. Each reports `NOT_APPLICABLE` to the runner and needs an owner and evidence on a schedule.

| ID | Layer | Deterministic | Invariant (one line) | Covers (automation point · common failure · regulation) |
| --- | --- | --- | --- | --- |
| **3DS-LIAB-03** | manual/evidence | no (manual) | ECI/liability matrix is SME-reviewed every network rule cycle and 3DS component approvals are current. | Data handling & protocol version / Liability shift · Liability shift claimed incorrectly · EMV 3-D Secure 2.x + card-network rules (as configured); PSD2 SCA interplay |

### Determinism

Every harness row (static and behavioural) is drafted as deterministic. Static detectors, including backstops, are pure functions of the committed source/config/diff. Behavioural rules each run against a **fresh `reset()` MoneySystem** (no state leaks between rules), driven by a **controllable clock**; deadlines, windows, expiries and cadences are asserted by advancing that clock, never by wall-clock reads, and no randomness affects a verdict. External dependencies (vendors, registries, feeds) are faked inside the adapter, which is how fault-injection rows stay deterministic. Manual/evidence rows are not deterministic and are not gate checks. ⚑ SME rows are deterministic once parameters exist, but are excluded from the gate until then.

### Coverage note

Built from 48 inline AI-drafted scenarios (`3DS-S-nnn`, listed below; not in the source sheet or the skills export); each inline scenario maps to exactly one non-backstop row (see the appendix). Static backstops add no scenarios and trace through the check they back. The scenarios were merged into crisp invariants by automation point and failure mode, across categories (positive, negative, boundary, failure/recovery, concurrency/idempotency, retention/audit, common failure, core). Automation points covered: Flow & challenge (frictionless vs challenge), Authentication value & authorization binding (ECI / CAVV), Liability shift, Exemptions & SCA interplay, Errors, timeouts & fallback, Data handling & protocol version. Source common failures: Authorization proceeds without a valid authentication result, Authentication value reused or not bound to the transaction, Liability shift claimed incorrectly, Exemption applied outside its configured conditions, DS/ACS error or timeout fails open, Authentication data elements logged or over-retained, Protocol version downgrade accepted. Thresholds, windows and deadlines are *configured* parameters, not asserted statutory values. No regulation or citation was added beyond the source sheet.

### Overlap with the locked neobank playbook (19 checks)

| This check | Neobank check | Strength | Why |
| --- | --- | --- | --- |
| 3DS-FLOW-04 | N-IDEMP-01 | related | results message applied once |
| 3DS-FLOW-53 | N-IDEMP-01 | same | conditional update reports success only when a row changed |
| 3DS-FLOW-05 | N-AUTHN | same | untrusted results message authenticated before any effect |
| 3DS-FLOW-52 | N-AUTHN | related | authenticity verified before effect, statically |
| 3DS-AV-03 | N-IDEMP-01 | related | authentication value single-use |
| 3DS-AV-03 | N-ATOMIC | related | two competing authorizations never both commit |
| 3DS-AV-52 | N-IDEMP-01 | same | single-use conditional update; success only when a row changed |
| 3DS-AV-04 | N-IDEMP-01 | related | authorization retry idempotent |
| 3DS-EXM-02 | N-CAP-01 | related | cumulative exemption limits enforced server-side, atomically |
| 3DS-EXM-52 | N-CAP-01 | same | limits read under lock in the txn, never from payload |
| 3DS-ERR-03 | N-IDEMP-01 | related | one authentication per purchase on retry |

`same` means the neobank check already enforces this invariant, so reuse it instead of re-implementing. `related` means the same defect class, but this check needs its own rule or preset.

### Review flags

- ⚑ **3DS-LIAB-01**: needs an SME/counsel parameter matrix (source scenarios carry review status "+ SME input").
- ⚑ **3DS-LIAB-51**: needs an SME/counsel parameter matrix (source scenarios carry review status "+ SME input").
- ⚑ **3DS-LIAB-03**: needs an SME/counsel parameter matrix (source scenarios carry review status "+ SME input").
- ⚑ **3DS-EXM-01**: needs an SME/counsel parameter matrix (source scenarios carry review status "+ SME input").
- ⚑ **3DS-EXM-51**: needs an SME/counsel parameter matrix (source scenarios carry review status "+ SME input").
- ⚑ **3DS-EXM-05**: needs an SME/counsel parameter matrix (source scenarios carry review status "+ SME input").

## Inline scenarios (48, AI-drafted)

Generated for this playbook because the source sheet has no rows for it. Each scenario maps to exactly one check (see the appendix). ⚑ marks scenarios that need SME input on network rules or thresholds.

| Scenario | Category | Automation point | Title | Steps | Expected result | SME |
| --- | --- | --- | --- | --- | --- | --- |
| 3DS-S-001 | Core | Flow & challenge (frictionless vs challenge) | Frictionless authenticated result proceeds to authorization | Script ACS ARes transStatus=Y (frictionless); authenticate; authorize. | Authorization carries the authentication result of this exact transaction; no challenge is shown; order marked authenticated. |  |
| 3DS-S-002 | Positive | Flow & challenge (frictionless vs challenge) | Challenge flow result taken from the results message | Script ARes C then RReq Y with valid signature; complete challenge; authorize. | Final status is taken from the authenticated results message, not browser redirect parameters; authorization proceeds with it. |  |
| 3DS-S-003 | Negative | Flow & challenge (frictionless vs challenge) | Client-supplied challenge outcome is ignored | After a challenge with RReq N, the browser return posts transStatus=Y. | Server status stays N; authorization is not sent as authenticated; the client value is ignored and logged. |  |
| 3DS-S-004 | Negative | Flow & challenge (frictionless vs challenge) | N / R / U statuses never authorize as authenticated | Script ARes N, R and U in turn; attempt authorization. | N and R stop the payment (or follow configured policy) and never carry authenticated ECI; U follows only the configured fallback policy. |  |
| 3DS-S-005 | Boundary/Edge | Flow & challenge (frictionless vs challenge) | Challenge window at the configured timeout | Start challenge; advance clock to exactly the configured timeout, then one tick past; deliver RReq. | Inside the window the RReq is accepted; past it the session is expired, the late RReq is rejected and the payment is not authenticated. |  |
| 3DS-S-006 | Concurrency/Idempotency | Flow & challenge (frictionless vs challenge) | Duplicate / concurrent results messages applied once | Deliver the same RReq twice sequentially and twice concurrently. | Exactly one state transition; repeats are acknowledged idempotently; no second authorization. |  |
| 3DS-S-007 | Failure/Recovery | Flow & challenge (frictionless vs challenge) | Abandoned challenge ends not-authenticated | Start challenge, never deliver RReq; advance clock past timeout. | Transaction reaches the configured not-authenticated terminal state; no authorization; any reservation is released. |  |
| 3DS-S-008 | Retention/Audit | Flow & challenge (frictionless vs challenge) | One audit record per authentication | Run frictionless and challenge flows. | One audit record each with transaction id, protocol version, flow, status, ECI and timestamps; no authentication value or PAN in clear. |  |
| 3DS-S-009 | Common Failure | Flow & challenge (frictionless vs challenge) | Unauthenticated results message rejected | Post an RReq with an invalid signature or an unknown transaction id. | Rejected before any state change; no authorization triggered; event logged. |  |
| 3DS-S-010 | Core | Authentication value & authorization binding (ECI / CAVV) | Authorization carries this authentication's ECI and value | Authenticate (Y) then authorize. | Authorization ECI, authentication-value reference and DS transaction id equal those stored for this transaction id. |  |
| 3DS-S-011 | Negative | Authentication value & authorization binding (ECI / CAVV) | Authentication value from another transaction refused | Attach transaction A's authentication result to transaction B's authorization. | Refused or sent unauthenticated per policy; never sent with A's value. |  |
| 3DS-S-012 | Boundary/Edge | Authentication value & authorization binding (ECI / CAVV) | Amount / currency / merchant changed after authentication | Authenticate 100.00; authorize 100.01, a different currency and a different merchant. | Binding mismatch beyond the configured tolerance forces re-authentication; the stored value is never reused for the changed transaction. |  |
| 3DS-S-013 | Concurrency/Idempotency | Authentication value & authorization binding (ECI / CAVV) | One authentication value, two concurrent authorizations | Fire two authorizations referencing the same authentication result concurrently. | At most one commits with the authenticated value; the other is refused. |  |
| 3DS-S-014 | Negative | Authentication value & authorization binding (ECI / CAVV) | Expired authentication result | Authenticate; advance clock past the configured validity window; authorize. | Result treated as expired; authorization not sent as authenticated. |  |
| 3DS-S-015 | Common Failure | Authentication value & authorization binding (ECI / CAVV) | ECI taken from configured per-network mapping | Drive every status for each configured network. | ECI chosen from the configured status→ECI table; unknown combinations fall to non-authenticated. |  |
| 3DS-S-016 | Failure/Recovery | Authentication value & authorization binding (ECI / CAVV) | Authorization retry after timeout reuses the same authorization | Inject network timeout on authorization; retry with the same idempotency key. | The retry resolves to the same authorization; no second authorization consumes the value. |  |
| 3DS-S-017 | Positive | Authentication value & authorization binding (ECI / CAVV) | Split captures reference the original authenticated authorization | Authorize once; capture in two parts as configured. | Both captures link to the original authenticated authorization; no authentication value is fabricated. |  |
| 3DS-S-018 | Core | Liability shift | Liability shift derived only from the configured network matrix | Drive Y, A, N, U across configured networks; authorize. | Liability-shift flag set only where the SME-supplied matrix says so for (network, status, ECI, value present). | ⚑ |
| 3DS-S-019 | Negative | Liability shift | Attempts (A) never upgraded to full authentication | Script ARes A; authorize. | Recorded as attempts per matrix; never stored or sent as Y. | ⚑ |
| 3DS-S-020 | Common Failure | Liability shift | Exempted transactions are not flagged liability-shifted | Apply a TRA exemption; authorize. | Liability-shift flag false. |  |
| 3DS-S-021 | Retention/Audit | Liability shift | Liability evidence retained for representment | Authenticate; advance clock across the configured retention window. | Evidence (transaction ids, ECI, version, timestamps) retrievable within the window, then minimised per policy; no authentication value in clear. |  |
| 3DS-S-022 | Boundary/Edge | Liability shift | Authenticated but value missing from the authorization | Authenticate Y; drop the value from the outgoing authorization. | Liability-shift flag false and an alert is raised. |  |
| 3DS-S-023 | Positive | Liability shift | Frictionless Y on a matrix-eligible network records liability shift | Frictionless Y on a network configured as eligible. | Authorization record carries liability shift true with the matrix version used. |  |
| 3DS-S-024 | Core | Exemptions & SCA interplay | TRA exemption only inside the configured fraud-rate / amount band | Configure the band; request TRA at the band edge and above it. | Inside the band the exemption may apply; above it SCA is required; band values come from configuration. | ⚑ |
| 3DS-S-025 | Boundary/Edge | Exemptions & SCA interplay | Low-value exemption cumulative count / amount limit | Run consecutive low-value payments up to the configured count and amount. | At the configured limit the next payment requires SCA; counters are kept server-side. |  |
| 3DS-S-026 | Concurrency/Idempotency | Exemptions & SCA interplay | Concurrent low-value payments cannot exceed the counter | Fire N concurrent low-value payments at the limit. | Counter enforced atomically; no more than the configured number are exempted. |  |
| 3DS-S-027 | Positive | Exemptions & SCA interplay | MIT references the initial authenticated CIT | Initial CIT with SCA; later merchant-initiated payment. | MIT flagged with the initial transaction reference; no challenge. |  |
| 3DS-S-028 | Negative | Exemptions & SCA interplay | MIT without a valid initial reference | Submit an MIT flag with a missing or unknown initial reference. | Not sent as MIT; authentication required. |  |
| 3DS-S-029 | Negative | Exemptions & SCA interplay | Trusted-beneficiary exemption needs ACS confirmation | Merchant claims whitelisting without ACS confirmation. | Exemption not applied. |  |
| 3DS-S-030 | Common Failure | Exemptions & SCA interplay | Exemption flag never accepted from client payload | Client posts exemption=TRA. | Exemption decided server-side only; client value ignored. |  |
| 3DS-S-031 | Boundary/Edge | Exemptions & SCA interplay | Scope classification (one-leg-out, MOTO, regional SCA scope) | Drive issuer outside region, MOTO and in-scope regional transactions. | Classified per the SME-supplied scope matrix; unknown classification defaults to SCA. | ⚑ |
| 3DS-S-032 | Failure/Recovery | Exemptions & SCA interplay | Issuer soft-decline for SCA triggers one step-up | Issuer returns SCA-required to an exempted authorization. | Payment steps up to a 3DS challenge once; never retried with the exemption again. |  |
| 3DS-S-033 | Retention/Audit | Exemptions & SCA interplay | Exemption decisions audited | Apply each exemption type. | Audit record with exemption type, inputs, counter values, decision and configuration version. |  |
| 3DS-S-034 | Core | Exemptions & SCA interplay | PSD2 SCA interplay for in-scope transactions | In-scope regional issuer and acquirer. | Either SCA via 3DS (frictionless or challenge) or a configured exemption; never neither. | ⚑ |
| 3DS-S-035 | Core | Errors, timeouts & fallback | DS / ACS timeout fails closed | Inject DS timeout and ACS timeout. | No authenticated authorization; outcome follows configured policy (decline, or proceed unauthenticated and flagged), never authenticated. |  |
| 3DS-S-036 | Failure/Recovery | Errors, timeouts & fallback | DS error message or malformed ARes handled | Script an error response and a malformed ARes. | Parsed as an error; no authentication result fabricated; logged. |  |
| 3DS-S-037 | Negative | Errors, timeouts & fallback | ACS unavailable follows configured fallback | Make the ACS unavailable. | Fallback to attempts or decline as configured; never fully-authenticated ECI. |  |
| 3DS-S-038 | Boundary/Edge | Errors, timeouts & fallback | Latency exactly at the configured timeout | Use controllable latency at, just under and just over the threshold. | Deterministic outcome at each boundary per configuration. |  |
| 3DS-S-039 | Common Failure | Errors, timeouts & fallback | Exception in the 3DS client never defaults to success | Throw inside response parsing. | Fails closed; no frictionless-success default. |  |
| 3DS-S-040 | Concurrency/Idempotency | Errors, timeouts & fallback | AReq retry after timeout creates one authentication | Time out an AReq; retry. | One authentication result applied per purchase; the earlier attempt is cancelled or reused. |  |
| 3DS-S-041 | Core | Data handling & protocol version | Authentication data not logged | Run every flow with debug logging. | Authentication values, full PAN and device-data payloads are absent from logs, traces and error bodies. |  |
| 3DS-S-042 | Negative | Data handling & protocol version | Version downgrade refused | Peer offers a version below the configured minimum. | Rejected; no fallback to a deprecated version. |  |
| 3DS-S-043 | Boundary/Edge | Data handling & protocol version | Version negotiation picks highest supported ≥ minimum | Card ranges advertising various versions. | Highest mutually supported version ≥ configured minimum; otherwise configured non-3DS policy. |  |
| 3DS-S-044 | Retention/Audit | Data handling & protocol version | Authentication data minimised after use | Advance clock past configured retention. | 3DS messages purged or minimised per configuration; authentication value not stored after authorization beyond configuration. |  |
| 3DS-S-045 | Positive | Data handling & protocol version | Card-range cache refreshed on schedule | Advance clock to the configured refresh interval. | Cache refreshed; a stale cache never causes a downgrade. |  |
| 3DS-S-046 | Failure/Recovery | Data handling & protocol version | Corrupt card-range data | Script corrupt card-range data on refresh. | Previous valid cache retained; no downgrade; alert raised. |  |
| 3DS-S-047 | Retention/Audit | Data handling & protocol version | 3DS component approvals current | Review evidence for 3DS server / SDK approvals. | Current approval evidence is on file for every deployed component. |  |
| 3DS-S-048 | Core | Liability shift | ECI / liability matrix reviewed each network rule cycle | Review network bulletins against the configured matrix. | SME sign-off recorded for each cycle; matrix version updated. | ⚑ |

## Appendix: traceability to source scenarios

| Check ID | Source scenario IDs | Categories merged |
| --- | --- | --- |
| 3DS-FLOW-01 | 3DS-S-001, 3DS-S-002, 3DS-S-003 | Core, Negative, Positive |
| 3DS-FLOW-51 | — (static backstop; traced via 3DS-FLOW-01) | — |
| 3DS-FLOW-02 | 3DS-S-004 | Negative |
| 3DS-FLOW-03 | 3DS-S-005, 3DS-S-007 | Boundary/Edge, Failure/Recovery |
| 3DS-FLOW-04 | 3DS-S-006 | Concurrency/Idempotency |
| 3DS-FLOW-53 | — (static backstop; traced via 3DS-FLOW-04) | — |
| 3DS-FLOW-05 | 3DS-S-009 | Common Failure |
| 3DS-FLOW-52 | — (static backstop; traced via 3DS-FLOW-05) | — |
| 3DS-FLOW-06 | 3DS-S-008 | Retention/Audit |
| 3DS-AV-01 | 3DS-S-010, 3DS-S-011, 3DS-S-017 | Core, Negative, Positive |
| 3DS-AV-51 | — (static backstop; traced via 3DS-AV-01) | — |
| 3DS-AV-02 | 3DS-S-012 | Boundary/Edge |
| 3DS-AV-03 | 3DS-S-013, 3DS-S-014 | Concurrency/Idempotency, Negative |
| 3DS-AV-52 | — (static backstop; traced via 3DS-AV-03) | — |
| 3DS-AV-04 | 3DS-S-016 | Failure/Recovery |
| 3DS-AV-05 | 3DS-S-015 | Common Failure |
| 3DS-LIAB-01 | 3DS-S-018, 3DS-S-019, 3DS-S-020, 3DS-S-022, 3DS-S-023 | Boundary/Edge, Common Failure, Core, Negative, Positive |
| 3DS-LIAB-51 | — (static backstop; traced via 3DS-LIAB-01) | — |
| 3DS-LIAB-02 | 3DS-S-021 | Retention/Audit |
| 3DS-LIAB-03 | 3DS-S-047, 3DS-S-048 | Core, Retention/Audit |
| 3DS-EXM-01 | 3DS-S-024 | Core |
| 3DS-EXM-51 | — (static backstop; traced via 3DS-EXM-01) | — |
| 3DS-EXM-02 | 3DS-S-025, 3DS-S-026 | Boundary/Edge, Concurrency/Idempotency |
| 3DS-EXM-52 | — (static backstop; traced via 3DS-EXM-02) | — |
| 3DS-EXM-03 | 3DS-S-027, 3DS-S-028 | Negative, Positive |
| 3DS-EXM-04 | 3DS-S-029, 3DS-S-030 | Common Failure, Negative |
| 3DS-EXM-53 | — (static backstop; traced via 3DS-EXM-04) | — |
| 3DS-EXM-05 | 3DS-S-031, 3DS-S-034 | Boundary/Edge, Core |
| 3DS-EXM-06 | 3DS-S-032 | Failure/Recovery |
| 3DS-EXM-07 | 3DS-S-033 | Retention/Audit |
| 3DS-ERR-01 | 3DS-S-035, 3DS-S-036, 3DS-S-039 | Common Failure, Core, Failure/Recovery |
| 3DS-ERR-51 | — (static backstop; traced via 3DS-ERR-01) | — |
| 3DS-ERR-02 | 3DS-S-037, 3DS-S-038 | Boundary/Edge, Negative |
| 3DS-ERR-03 | 3DS-S-040 | Concurrency/Idempotency |
| 3DS-DATA-01 | 3DS-S-041 | Core |
| 3DS-DATA-02 | 3DS-S-042, 3DS-S-043, 3DS-S-045, 3DS-S-046 | Boundary/Edge, Failure/Recovery, Negative, Positive |
| 3DS-DATA-51 | — (static backstop; traced via 3DS-DATA-02) | — |
| 3DS-DATA-03 | 3DS-S-044 | Retention/Audit |

# Helix review rules

Generated from `checks.json` (37 static and behavioural checks; manual/evidence items are not code-reviewable and are omitted). Severity is derived from the playbook priority (P0 -> HIGH); Category MM marks money-movement checks. Rule text is the source invariant, unchanged; it is AI-drafted and needs compliance review.

## Rule TDS-FLOW-01: Final authentication status comes only from the authenticated results channel for that transaction
Severity: HIGH
Category: MM
Scenario: flow-challenge-frictionless-vs-challenge
Requirement: MUST
Invariant: Final authentication status comes only from the authenticated results channel for that transaction; redirect/client values never set status.

Source check `3DS-FLOW-01` from `checks.json` (behavioural; deterministic: yes). Covers: Flow & challenge (frictionless vs challenge) · Authorization proceeds without a valid authentication result · EMV 3-D Secure 2.x + card-network rules (as configured); PSD2 SCA interplay. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-EMV-001, RR-CARD-005.

## Rule TDS-FLOW-51: Authentication status is written only by the results-message handler
Severity: HIGH
Category: MM
Scenario: flow-challenge-frictionless-vs-challenge
Requirement: MUST
Invariant: Authentication status is written only by the results-message handler; browser-return handlers have no write path to authentication status.

Source check `3DS-FLOW-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: Flow & challenge (frictionless vs challenge) · Authorization proceeds without a valid authentication result · EMV 3-D Secure 2.x + card-network rules (as configured); PSD2 SCA interplay. Backstop for TDS-FLOW-01. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-EMV-001, RR-CARD-005.

## Rule TDS-FLOW-02: N and R never authorize as authenticated
Severity: HIGH
Category: MM
Scenario: flow-challenge-frictionless-vs-challenge
Requirement: MUST
Invariant: N and R never authorize as authenticated; U only per the configured fallback policy.

Source check `3DS-FLOW-02` from `checks.json` (behavioural; deterministic: yes). Covers: Flow & challenge (frictionless vs challenge) · Authorization proceeds without a valid authentication result · EMV 3-D Secure 2.x + card-network rules (as configured); PSD2 SCA interplay. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-EMV-001, RR-CARD-005.

## Rule TDS-FLOW-03: The challenge window is enforced at the configured timeout (controllable clock)
Severity: HIGH
Category: MM
Scenario: flow-challenge-frictionless-vs-challenge
Requirement: MUST
Invariant: The challenge window is enforced at the configured timeout (controllable clock); abandoned or late challenges end not-authenticated and release any reservation.

Source check `3DS-FLOW-03` from `checks.json` (behavioural; deterministic: yes). Covers: Flow & challenge (frictionless vs challenge) · None · EMV 3-D Secure 2.x + card-network rules (as configured); PSD2 SCA interplay. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-EMV-001.

## Rule TDS-FLOW-04: Results messages are applied once per transaction id under duplicates and concurrency
Severity: HIGH
Category: MM
Scenario: flow-challenge-frictionless-vs-challenge
Requirement: MUST
Invariant: Results messages are applied once per transaction id under duplicates and concurrency.

Source check `3DS-FLOW-04` from `checks.json` (behavioural; deterministic: yes). Covers: Flow & challenge (frictionless vs challenge) · None · EMV 3-D Secure 2.x + card-network rules (as configured); PSD2 SCA interplay. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-EMV-001.

## Rule TDS-FLOW-53: The authentication results table has a unique key on the 3DS server transaction id and status upd...
Severity: HIGH
Category: MM
Scenario: flow-challenge-frictionless-vs-challenge
Requirement: MUST
Invariant: The authentication results table has a unique key on the 3DS server transaction id and status updates are conditional, reporting success only when a row changed.

Source check `3DS-FLOW-53` from `checks.json` (static, static backstop; deterministic: yes). Covers: Flow & challenge (frictionless vs challenge) · None · EMV 3-D Secure 2.x + card-network rules (as configured); PSD2 SCA interplay. Backstop for TDS-FLOW-04. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-EMV-001.

## Rule TDS-FLOW-05: A results message is authenticated (signature, known transaction) before any state change or auth...
Severity: HIGH
Category: MM
Scenario: flow-challenge-frictionless-vs-challenge
Requirement: MUST
Invariant: A results message is authenticated (signature, known transaction) before any state change or authorization.

Source check `3DS-FLOW-05` from `checks.json` (behavioural; deterministic: yes). Covers: Flow & challenge (frictionless vs challenge) · Authorization proceeds without a valid authentication result · EMV 3-D Secure 2.x + card-network rules (as configured); PSD2 SCA interplay. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-EMV-001, RR-CARD-005.

## Rule TDS-FLOW-52: The results-message handler verifies message authenticity before any DB write or authorization ca...
Severity: HIGH
Category: MM
Scenario: flow-challenge-frictionless-vs-challenge
Requirement: MUST
Invariant: The results-message handler verifies message authenticity before any DB write or authorization call, with a default-deny error branch.

Source check `3DS-FLOW-52` from `checks.json` (static, static backstop; deterministic: yes). Covers: Flow & challenge (frictionless vs challenge) · Authorization proceeds without a valid authentication result · EMV 3-D Secure 2.x + card-network rules (as configured); PSD2 SCA interplay. Backstop for TDS-FLOW-05. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-EMV-001, RR-CARD-005.

## Rule TDS-FLOW-06: Every authentication emits exactly one audit record (ids, version, flow, status, ECI, times) with...
Severity: HIGH
Category: MM
Scenario: flow-challenge-frictionless-vs-challenge
Requirement: MUST
Invariant: Every authentication emits exactly one audit record (ids, version, flow, status, ECI, times) with no authentication value or PAN.

Source check `3DS-FLOW-06` from `checks.json` (behavioural; deterministic: yes). Covers: Flow & challenge (frictionless vs challenge) · None · EMV 3-D Secure 2.x + card-network rules (as configured); PSD2 SCA interplay. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-EMV-001, RR-PCI-001.

## Rule TDS-AV-01: Authorization ECI / authentication value / DS id equal those stored for this transaction
Severity: HIGH
Category: MM
Scenario: authentication-value-authorization-binding-eci-c
Requirement: MUST
Invariant: Authorization ECI / authentication value / DS id equal those stored for this transaction; another transaction's result is never used; captures link to the original.

Source check `3DS-AV-01` from `checks.json` (behavioural; deterministic: yes). Covers: Authentication value & authorization binding (ECI / CAVV) · Authentication value reused or not bound to the transaction · EMV 3-D Secure 2.x + card-network rules (as configured); PSD2 SCA interplay. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-EMV-001, RR-CARD-005.

## Rule TDS-AV-51: The authorization builder reads ECI/authentication value from the stored authentication record ke...
Severity: HIGH
Category: MM
Scenario: authentication-value-authorization-binding-eci-c
Requirement: MUST
Invariant: The authorization builder reads ECI/authentication value from the stored authentication record keyed by transaction id, never from request parameters.

Source check `3DS-AV-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: Authentication value & authorization binding (ECI / CAVV) · Authentication value reused or not bound to the transaction · EMV 3-D Secure 2.x + card-network rules (as configured); PSD2 SCA interplay. Backstop for TDS-AV-01. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-EMV-001, RR-CARD-005.

## Rule TDS-AV-02: An amount, currency or merchant change beyond the configured tolerance forces re-authentication
Severity: HIGH
Category: MM
Scenario: authentication-value-authorization-binding-eci-c
Requirement: MUST
Invariant: An amount, currency or merchant change beyond the configured tolerance forces re-authentication.

Source check `3DS-AV-02` from `checks.json` (behavioural; deterministic: yes). Covers: Authentication value & authorization binding (ECI / CAVV) · Authentication value reused or not bound to the transaction · EMV 3-D Secure 2.x + card-network rules (as configured); PSD2 SCA interplay. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-EMV-001, RR-CARD-005.

## Rule TDS-AV-03: An authentication value is consumed at most once (incl
Severity: HIGH
Category: MM
Scenario: authentication-value-authorization-binding-eci-c
Requirement: MUST
Invariant: An authentication value is consumed at most once (incl. concurrently) and is never sent as authenticated after its configured validity.

Source check `3DS-AV-03` from `checks.json` (behavioural; deterministic: yes). Covers: Authentication value & authorization binding (ECI / CAVV) · Authentication value reused or not bound to the transaction · EMV 3-D Secure 2.x + card-network rules (as configured); PSD2 SCA interplay. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-EMV-001, RR-CARD-005.

## Rule TDS-AV-52: Authentication-value consumption is a single-use conditional update (consumed IS NULL) inside the...
Severity: HIGH
Category: MM
Scenario: authentication-value-authorization-binding-eci-c
Requirement: MUST
Invariant: Authentication-value consumption is a single-use conditional update (consumed IS NULL) inside the authorization transaction.

Source check `3DS-AV-52` from `checks.json` (static, static backstop; deterministic: yes). Covers: Authentication value & authorization binding (ECI / CAVV) · Authentication value reused or not bound to the transaction · EMV 3-D Secure 2.x + card-network rules (as configured); PSD2 SCA interplay. Backstop for TDS-AV-03. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-EMV-001, RR-CARD-005.

## Rule TDS-AV-04: An authorization retry after timeout is idempotent
Severity: HIGH
Category: MM
Scenario: authentication-value-authorization-binding-eci-c
Requirement: MUST
Invariant: An authorization retry after timeout is idempotent: same authorization, no second use of the value.

Source check `3DS-AV-04` from `checks.json` (behavioural; deterministic: yes). Covers: Authentication value & authorization binding (ECI / CAVV) · None · EMV 3-D Secure 2.x + card-network rules (as configured); PSD2 SCA interplay. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-EMV-001, RR-CARD-005.

## Rule TDS-AV-05: ECI is selected from a configured per-network status→ECI table with a non-authenticated default
Severity: HIGH
Category: MM
Scenario: authentication-value-authorization-binding-eci-c
Requirement: MUST
Invariant: ECI is selected from a configured per-network status→ECI table with a non-authenticated default; no ECI literals in the authorization path.

Source check `3DS-AV-05` from `checks.json` (static; deterministic: yes). Covers: Authentication value & authorization binding (ECI / CAVV) · Authentication value reused or not bound to the transaction · EMV 3-D Secure 2.x + card-network rules (as configured); PSD2 SCA interplay. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-EMV-001, RR-CARD-005.

## Rule TDS-LIAB-01: The liability-shift flag is set only per the configured network matrix from (status, ECI, value p...
Severity: HIGH
Category: MM
Scenario: liability-shift
Requirement: MUST
Invariant: The liability-shift flag is set only per the configured network matrix from (status, ECI, value present, exemption); attempts are never upgraded; exempted or value-less authorizations are not shifted.

Source check `3DS-LIAB-01` from `checks.json` (behavioural; deterministic: yes). Covers: Liability shift · Liability shift claimed incorrectly · EMV 3-D Secure 2.x + card-network rules (as configured); PSD2 SCA interplay. Flagged for SME input in the source; needs an approved parameter matrix. Review status in source: Drafted (AI) – needs compliance review + SME input.

Regulation references: RR-CARD-005.

## Rule TDS-LIAB-51: The liability-shift flag has one writer that reads the configured matrix
Severity: HIGH
Category: MM
Scenario: liability-shift
Requirement: MUST
Invariant: The liability-shift flag has one writer that reads the configured matrix; no other code path sets it.

Source check `3DS-LIAB-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: Liability shift · Liability shift claimed incorrectly · EMV 3-D Secure 2.x + card-network rules (as configured); PSD2 SCA interplay. Backstop for TDS-LIAB-01. Flagged for SME input in the source; needs an approved parameter matrix. Review status in source: Drafted (AI) – needs compliance review + SME input.

Regulation references: RR-CARD-005.

## Rule TDS-LIAB-02: Liability evidence is retrievable for the configured window, then minimised
Severity: HIGH
Category: MM
Scenario: liability-shift
Requirement: MUST
Invariant: Liability evidence is retrievable for the configured window, then minimised; no authentication value in clear.

Source check `3DS-LIAB-02` from `checks.json` (behavioural; deterministic: yes). Covers: Liability shift · Authentication data elements logged or over-retained · EMV 3-D Secure 2.x + card-network rules (as configured); PSD2 SCA interplay. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-CARD-005, RR-PCI-010.

## Rule TDS-EXM-01: TRA is granted only inside the configured fraud-rate/amount band
Severity: HIGH
Category: MM
Scenario: exemptions-sca-interplay
Requirement: MUST
Invariant: TRA is granted only inside the configured fraud-rate/amount band; above it SCA is required.

Source check `3DS-EXM-01` from `checks.json` (behavioural; deterministic: yes). Covers: Exemptions & SCA interplay · Exemption applied outside its configured conditions · EMV 3-D Secure 2.x + card-network rules (as configured); PSD2 SCA interplay. Flagged for SME input in the source; needs an approved parameter matrix. Review status in source: Drafted (AI) – needs compliance review + SME input.

Regulation references: RR-PSD2-003.

## Rule TDS-EXM-51: TRA band and fraud-rate thresholds load from a single configured source
Severity: HIGH
Category: MM
Scenario: exemptions-sca-interplay
Requirement: MUST
Invariant: TRA band and fraud-rate thresholds load from a single configured source; no threshold literals in exemption code.

Source check `3DS-EXM-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: Exemptions & SCA interplay · Exemption applied outside its configured conditions · EMV 3-D Secure 2.x + card-network rules (as configured); PSD2 SCA interplay. Backstop for TDS-EXM-01. Flagged for SME input in the source; needs an approved parameter matrix. Review status in source: Drafted (AI) – needs compliance review + SME input.

Regulation references: RR-PSD2-003.

## Rule TDS-EXM-02: Low-value exemption count/amount limits are kept server-side and enforced atomically under concur...
Severity: HIGH
Category: MM
Scenario: exemptions-sca-interplay
Requirement: MUST
Invariant: Low-value exemption count/amount limits are kept server-side and enforced atomically under concurrency.

Source check `3DS-EXM-02` from `checks.json` (behavioural; deterministic: yes). Covers: Exemptions & SCA interplay · Exemption applied outside its configured conditions · EMV 3-D Secure 2.x + card-network rules (as configured); PSD2 SCA interplay. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-PSD2-002.

## Rule TDS-EXM-52: Low-value counters are read and incremented inside the payment transaction under a lock, never fr...
Severity: HIGH
Category: MM
Scenario: exemptions-sca-interplay
Requirement: MUST
Invariant: Low-value counters are read and incremented inside the payment transaction under a lock, never from client-supplied values.

Source check `3DS-EXM-52` from `checks.json` (static, static backstop; deterministic: yes). Covers: Exemptions & SCA interplay · Exemption applied outside its configured conditions · EMV 3-D Secure 2.x + card-network rules (as configured); PSD2 SCA interplay. Backstop for TDS-EXM-02. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-PSD2-002.

## Rule TDS-EXM-03: MIT requires a valid initial authenticated CIT reference
Severity: HIGH
Category: MM
Scenario: exemptions-sca-interplay
Requirement: MUST
Invariant: MIT requires a valid initial authenticated CIT reference; otherwise authentication is required.

Source check `3DS-EXM-03` from `checks.json` (behavioural; deterministic: yes). Covers: Exemptions & SCA interplay · Exemption applied outside its configured conditions · EMV 3-D Secure 2.x + card-network rules (as configured); PSD2 SCA interplay. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-CARD-010.

## Rule TDS-EXM-04: Trusted-beneficiary exemption requires ACS confirmation and exemption flags are never taken from...
Severity: HIGH
Category: MM
Scenario: exemptions-sca-interplay
Requirement: MUST
Invariant: Trusted-beneficiary exemption requires ACS confirmation and exemption flags are never taken from the client.

Source check `3DS-EXM-04` from `checks.json` (behavioural; deterministic: yes). Covers: Exemptions & SCA interplay · Exemption applied outside its configured conditions · EMV 3-D Secure 2.x + card-network rules (as configured); PSD2 SCA interplay. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-PSD2-006.

## Rule TDS-EXM-53: No request DTO field maps to the exemption indicator
Severity: HIGH
Category: MM
Scenario: exemptions-sca-interplay
Requirement: MUST
Invariant: No request DTO field maps to the exemption indicator; it is set only by the server-side exemption engine.

Source check `3DS-EXM-53` from `checks.json` (static, static backstop; deterministic: yes). Covers: Exemptions & SCA interplay · Exemption applied outside its configured conditions · EMV 3-D Secure 2.x + card-network rules (as configured); PSD2 SCA interplay. Backstop for TDS-EXM-04. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-PSD2-006.

## Rule TDS-EXM-05: Scope classification (regional SCA scope, one-leg-out, MOTO) follows the configured matrix
Severity: HIGH
Category: MM
Scenario: exemptions-sca-interplay
Requirement: MUST
Invariant: Scope classification (regional SCA scope, one-leg-out, MOTO) follows the configured matrix; in-scope transactions get SCA or a configured exemption; unknown defaults to SCA.

Source check `3DS-EXM-05` from `checks.json` (behavioural; deterministic: yes). Covers: Exemptions & SCA interplay · Exemption applied outside its configured conditions · EMV 3-D Secure 2.x + card-network rules (as configured); PSD2 SCA interplay. Flagged for SME input in the source; needs an approved parameter matrix. Review status in source: Drafted (AI) – needs compliance review + SME input.

Regulation references: RR-PSD2-001.

## Rule TDS-EXM-06: An issuer SCA-required soft decline steps up to a challenge exactly once
Severity: HIGH
Category: MM
Scenario: exemptions-sca-interplay
Requirement: MUST
Invariant: An issuer SCA-required soft decline steps up to a challenge exactly once.

Source check `3DS-EXM-06` from `checks.json` (behavioural; deterministic: yes). Covers: Exemptions & SCA interplay · None · EMV 3-D Secure 2.x + card-network rules (as configured); PSD2 SCA interplay. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-PSD2-001, RR-EMV-001.

## Rule TDS-EXM-07: Every exemption decision is audited with type, inputs, counters, decision and configuration version
Severity: HIGH
Category: MM
Scenario: exemptions-sca-interplay
Requirement: MUST
Invariant: Every exemption decision is audited with type, inputs, counters, decision and configuration version.

Source check `3DS-EXM-07` from `checks.json` (behavioural; deterministic: yes). Covers: Exemptions & SCA interplay · None · EMV 3-D Secure 2.x + card-network rules (as configured); PSD2 SCA interplay. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-PSD2-002, RR-PSD2-003, RR-PSD2-006.

## Rule TDS-ERR-01: DS/ACS timeouts, error messages, malformed responses and client exceptions fail closed
Severity: HIGH
Category: MM
Scenario: errors-timeouts-fallback
Requirement: MUST
Invariant: DS/ACS timeouts, error messages, malformed responses and client exceptions fail closed: never authenticated, never frictionless-by-default.

Source check `3DS-ERR-01` from `checks.json` (behavioural; deterministic: yes). Covers: Errors, timeouts & fallback · DS/ACS error or timeout fails open · EMV 3-D Secure 2.x + card-network rules (as configured); PSD2 SCA interplay. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-EMV-001, RR-CARD-005.

## Rule TDS-ERR-51: Every 3DS client call's catch/timeout branch returns a not-authenticated result
Severity: HIGH
Category: MM
Scenario: errors-timeouts-fallback
Requirement: MUST
Invariant: Every 3DS client call's catch/timeout branch returns a not-authenticated result; no default or fall-through to Y/frictionless.

Source check `3DS-ERR-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: Errors, timeouts & fallback · DS/ACS error or timeout fails open · EMV 3-D Secure 2.x + card-network rules (as configured); PSD2 SCA interplay. Backstop for TDS-ERR-01. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-EMV-001, RR-CARD-005.

## Rule TDS-ERR-02: ACS-unavailable fallback follows configured policy, never yields fully-authenticated ECI, and is...
Severity: HIGH
Category: MM
Scenario: errors-timeouts-fallback
Requirement: MUST
Invariant: ACS-unavailable fallback follows configured policy, never yields fully-authenticated ECI, and is deterministic at the timeout boundary.

Source check `3DS-ERR-02` from `checks.json` (behavioural; deterministic: yes). Covers: Errors, timeouts & fallback · DS/ACS error or timeout fails open · EMV 3-D Secure 2.x + card-network rules (as configured); PSD2 SCA interplay. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-EMV-001, RR-CARD-005.

## Rule TDS-ERR-03: An AReq retry after timeout results in one applied authentication per purchase
Severity: HIGH
Category: MM
Scenario: errors-timeouts-fallback
Requirement: MUST
Invariant: An AReq retry after timeout results in one applied authentication per purchase.

Source check `3DS-ERR-03` from `checks.json` (behavioural; deterministic: yes). Covers: Errors, timeouts & fallback · None · EMV 3-D Secure 2.x + card-network rules (as configured); PSD2 SCA interplay. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-EMV-001.

## Rule TDS-DATA-01: Authentication values, PAN and device-data payloads never reach log, trace or error sinks
Severity: HIGH
Category: MM
Scenario: data-handling-protocol-version
Requirement: MUST
Invariant: Authentication values, PAN and device-data payloads never reach log, trace or error sinks.

Source check `3DS-DATA-01` from `checks.json` (static; deterministic: yes). Covers: Data handling & protocol version · Authentication data elements logged or over-retained · EMV 3-D Secure 2.x + card-network rules (as configured); PSD2 SCA interplay. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-PCI-001, RR-PCI-010.

## Rule TDS-DATA-02: Versions below the configured minimum are refused
Severity: HIGH
Category: MM
Scenario: data-handling-protocol-version
Requirement: MUST
Invariant: Versions below the configured minimum are refused; negotiation picks the highest supported ≥ minimum; stale or corrupt card-range data never causes a downgrade.

Source check `3DS-DATA-02` from `checks.json` (behavioural; deterministic: yes). Covers: Data handling & protocol version · Protocol version downgrade accepted · EMV 3-D Secure 2.x + card-network rules (as configured); PSD2 SCA interplay. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-EMV-001.

## Rule TDS-DATA-51: The configured minimum protocol version is enforced at a single negotiation point
Severity: HIGH
Category: MM
Scenario: data-handling-protocol-version
Requirement: MUST
Invariant: The configured minimum protocol version is enforced at a single negotiation point; no code path builds messages below it.

Source check `3DS-DATA-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: Data handling & protocol version · Protocol version downgrade accepted · EMV 3-D Secure 2.x + card-network rules (as configured); PSD2 SCA interplay. Backstop for TDS-DATA-02. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-EMV-001.

## Rule TDS-DATA-03: 3DS messages and authentication values are purged/minimised per configured retention (controllabl...
Severity: HIGH
Category: MM
Scenario: data-handling-protocol-version
Requirement: MUST
Invariant: 3DS messages and authentication values are purged/minimised per configured retention (controllable clock).

Source check `3DS-DATA-03` from `checks.json` (behavioural; deterministic: yes). Covers: Data handling & protocol version · Authentication data elements logged or over-retained · EMV 3-D Secure 2.x + card-network rules (as configured); PSD2 SCA interplay. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-PCI-010.
