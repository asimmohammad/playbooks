---
helixPlaybookFormat: helix-playbook/0.1-proposal
playbookId: vigil-nacha
title: "NACHA ACH File, Authorization & Returns"
declaredVersion: 0.1.0
intent: draft
applicability:
  languages: [javascript, typescript]
  scenarios: [ach-formatting, authorization, return-processing]
---
# Helix portable playbook — DRAFT manifest · NACHA ACH File, Authorization & Returns

> **DRAFT — not LOCKED.** Proposed NACHA Rules (Electronic Payments) playbook converted from Vigil skill `SK-NACHA-001`: one runner, two layers, **21 harness checks (8 static, incl. 7 static backstops, + 13 behavioural)**, plus 3 manual/evidence items listed separately because neither layer can verify them. Every invariant, layer and determinism call is **AI-drafted (Helix) and needs compliance review**. No detector or rule code exists yet. Before this manifest can be LOCKED, each row needs its detector/rule, a review, and a commit that adds the check alongside its row.

## Layers

- **static**: a repo-agnostic source scanner parameterised by a `VIGIL_NACHA` preset (no app specifics in the detector). It reads source / SQL / config / IaC / git-diff, **fails CLOSED** on a match, and runs with **no adapter**, so it is the CI gate. *Static backstops* (IDs `-5x`) prove a supporting source invariant for a named behavioural check, the way N-CAP-01 / N-STATE-01 back neobank behaviour. They fire even when the adapter never drives that path. Backstops of ⚑ SME checks stay out of the gate.
- **behavioural**: a rule written once against the canonical `MoneySystem` interface (or a DRAFT extension surface in `adapters/`) and driven through the app adapter. Surfaces needed: **AchSystem** (`adapters/ach.ts`). Every behavioural row reports NOT_EXERCISED until an adapter implements its surface. It returns **CHECKED only when it actually drove the guard's path**.
- **manual/evidence**: organisational process, live-infrastructure, statistical or retention evidence that no source scan or adapter-driven rule can prove. These are **outside the harness**, report `NOT_APPLICABLE` to it, and are tracked as evidence tasks, never as passes.

## Verdicts

`CHECKED` the path ran and the guard held · `FINDING` the guard was violated · `NOT_APPLICABLE` the invariant cannot apply here (incl. every manual/evidence item) · `NOT_EXERCISED` (glyph `????`) the adapter did not drive the path, so nothing is proven. NOT_EXERCISED is **surfaced distinctly and never counted as a pass** (no fake coverage). A ⚑ SME check with no approved parameter matrix reports `NOT_EXERCISED`, never `CHECKED`.

## How to run

- **Not runnable yet**: this draft defines invariants only (no detector/rule code). The intended shape mirrors the neobank playbook:
  - CI gate (adapter-free, blocks on any static FINDING): `run-static` with preset `VIGIL_NACHA`.
  - Full combined table (static + behavioural via the adapter): `run-all`.
- Machine-readable rows: `checks.json` (same IDs; includes source-scenario traceability and neobank overlaps).

## The draft inventory: 8 static + 13 behavioural = 21 checks

| ID | Layer | Deterministic | Invariant (one line) | Covers (automation point · common failure · regulation) |
| --- | --- | --- | --- | --- |
| **NACHA-FMT-01** | static | yes | Generated ACH files pass format validation (94-char records, record types, batch/file control totals, entry hash), with addenda counts allowed per SEC code and no invalid characters/overflow. | ACH formatting · Invalid format · NACHA Rules |
| **NACHA-FMT-02** | behavioural | yes | Trace numbers are unique per scope even under parallel batch creation; control totals stay correct. | ACH formatting · Invalid format · NACHA Rules |
| **NACHA-FMT-51** | static | yes | Trace numbers come from a DB sequence/unique constraint, never from an in-process counter. | backstop for NACHA-FMT-02 · ACH formatting · Invalid format · NACHA Rules |
| **NACHA-FMT-03** | behavioural | yes | A duplicate file/batch transmission is blocked before ODFI submission; a rejected-then-corrected retransmission contains each entry exactly once. | ACH formatting · Invalid format · NACHA Rules |
| **NACHA-FMT-52** | static | yes | File submission records a unique file-ID/hash before transmission and refuses resubmission of a recorded ID. | backstop for NACHA-FMT-03 · ACH formatting · Invalid format · NACHA Rules |
| **NACHA-FMT-04** | behavioural | yes | Effective entry dates roll to valid banking days; Same Day ACH eligibility, window and per-entry limit are enforced (controllable clock). | ACH formatting · Invalid format · NACHA Rules |
| **NACHA-FMT-05** | behavioural | yes | Live entries wait per the prenote policy and a prenote return blocks them; micro-entries use the configured descriptor, cap and offset. | ACH formatting · general control (no source failure) · NACHA Rules |
| **NACHA-AUTH-01** | behavioural | yes | No debit is originated without a valid, retrievable authorization matching its terms and SEC-code capture method, inside its effective window. | Authorization · missing auth · NACHA Rules |
| **NACHA-AUTH-51** | static | yes | Debit origination code requires a non-null authorization reference validated against amount/date terms in the same transaction. | backstop for NACHA-AUTH-01 · Authorization · missing auth · NACHA Rules |
| **NACHA-AUTH-02** | behavioural | yes | Recurring debits outside authorised amount/date range are blocked; originator exposure limits hold over-limit batches. | Authorization · missing auth · NACHA Rules |
| **NACHA-AUTH-52** | static | yes | Originator exposure limits are read from the limits table inside the batching transaction, never from the request payload. | backstop for NACHA-AUTH-02 · Authorization · missing auth · NACHA Rules |
| **NACHA-AUTH-03** | behavioural | yes | A revocation removes the entry from any unsent batch; transmitted entries are flagged. | Authorization · missing auth · NACHA Rules |
| **NACHA-AUTH-04** | behavioural | yes | Authorization store outage blocks origination. | Authorization · missing auth · NACHA Rules |
| **NACHA-AUTH-53** | static | yes | Authorization-store failure handling blocks origination (no default-allow). | backstop for NACHA-AUTH-04 · Authorization · missing auth · NACHA Rules |
| **NACHA-AUTH-05** | behavioural | yes | First-use WEB debits require successful account validation. | Authorization · missing auth · NACHA Rules |
| **NACHA-RET-01** | behavioural | yes | Each return reverses its original entry exactly once and applies its code action per the configured matrix; duplicate return-file ingestion is idempotent. | Return processing · general control (no source failure) · NACHA Rules |
| **NACHA-RET-51** | static | yes | Return ingestion dedupes on (original trace, return code) with a unique constraint; every R-code in the enum has an action-matrix entry. | backstop for NACHA-RET-01 · Return processing · general control (no source failure) · NACHA Rules |
| **NACHA-RET-02** | behavioural | yes | A return received before its original posts is matched once it posts; an unmatched return goes to an exception queue, never auto-posted. | Return processing · general control (no source failure) · NACHA Rules |
| **NACHA-RET-52** | static | yes | The unmatched-return path writes to an exception queue only — never posts to an account resolved by fuzzy match. | backstop for NACHA-RET-02 · Return processing · general control (no source failure) · NACHA Rules |
| **NACHA-RET-03** | behavioural | yes | A return on already-withdrawn funds posts the reversal and handles the negative balance per policy, keeping the ledger balanced. | Return processing · general control (no source failure) · NACHA Rules |
| **NACHA-RET-04** | behavioural | yes | Returns are classified timely/late at the configured deadline; reinitiation only for permitted reasons within count/window; NOCs update account details. | Return processing · general control (no source failure) · NACHA Rules |

## Outside the harness: manual/evidence (3)

These items are not harness checks. Each reports `NOT_APPLICABLE` to the runner and needs an owner and evidence on a schedule.

| ID | Layer | Deterministic | Invariant (one line) | Covers (automation point · common failure · regulation) |
| --- | --- | --- | --- | --- |
| **NACHA-FMT-06** | manual/evidence | no (manual) | Originated files are retained with matching hashes. | ACH formatting · general control (no source failure) · NACHA Rules |
| **NACHA-AUTH-06** | manual/evidence | no (manual) | Unauthorized-return rates per originator are computed and alert/pause at the configured threshold; authorizations are retained after revocation. | Authorization · missing auth · NACHA Rules |
| **NACHA-RET-05** | manual/evidence | no (manual) | Customers receive the correct notice per return-code group; return files and actions are retained. | Return processing · general control (no source failure) · NACHA Rules |

### Determinism

Every harness row (static and behavioural) is drafted as deterministic. Static detectors, including backstops, are pure functions of the committed source/config/diff. Behavioural rules each run against a **fresh `reset()` MoneySystem** (no state leaks between rules), driven by a **controllable clock**; deadlines, windows, expiries and cadences are asserted by advancing that clock, never by wall-clock reads, and no randomness affects a verdict. External dependencies (vendors, registries, feeds) are faked inside the adapter, which is how fault-injection rows stay deterministic. Manual/evidence rows are not deterministic and are not gate checks.

### Coverage note

Converted from 36 AI-drafted source scenarios of `SK-NACHA-001`; each source scenario maps to exactly one non-backstop row (see the appendix). Static backstops add no scenarios and trace through the check they back. The scenarios were merged into crisp invariants by automation point and failure mode, across categories (positive, negative, boundary, failure/recovery, concurrency/idempotency, retention/audit, common failure, core). Automation points covered: ACH formatting, Authorization, Return processing. Source common failures: Invalid format, missing auth. Thresholds, windows and deadlines are *configured* parameters, not asserted statutory values. No regulation or citation was added beyond the source sheet.

### Overlap with the locked neobank playbook (19 checks)

| This check | Neobank check | Strength | Why |
| --- | --- | --- | --- |
| NACHA-FMT-02 | N-IDEMP-01 | related | unique trace numbers |
| NACHA-FMT-51 | N-IDEMP-01 | related | unique-key dedupe on the write path |
| NACHA-FMT-03 | N-IDEMP-01 | related | duplicate file blocked |
| NACHA-FMT-52 | N-IDEMP-01 | related | unique-key dedupe on the write path |
| NACHA-AUTH-02 | N-CAP-01 | related | exposure limits |
| NACHA-AUTH-52 | N-CAP-01 | same | exposure limits read in the txn, never from payload |
| NACHA-AUTH-03 | N-STATE-01 | related | revoked authorization removed from unsent batch |
| NACHA-RET-01 | N-IDEMP-01 | related | return applied once |
| NACHA-RET-01 | N-CHGBK-05 | related | reversal never exceeds original |
| NACHA-RET-51 | N-IDEMP-01 | related | unique-key dedupe on the write path |
| NACHA-RET-03 | LEDGER-CONSERVE | related | ledger balanced after return on withdrawn funds |

`same` means the neobank check already enforces this invariant, so reuse it instead of re-implementing. `related` means the same defect class, but this check needs its own rule or preset.

### Review flags

- No SME-flagged rows. All rows still need compliance review.

## Appendix: traceability to source scenarios

| Check ID | Source scenario IDs | Categories merged |
| --- | --- | --- |
| NACHA-FMT-01 | SC-NACHA-001-01, SC-NACHA-001-04, SC-NACHA-001-05, SC-NACHA-001-20 | Boundary/Edge, Common Failure, Core, Negative |
| NACHA-FMT-02 | SC-NACHA-001-06, SC-NACHA-001-18 | Concurrency/Idempotency, Positive |
| NACHA-FMT-51 | — (static backstop; traced via NACHA-FMT-02) | — |
| NACHA-FMT-03 | DR-NACHA-001-03, SC-NACHA-001-07 | Core, Failure/Recovery |
| NACHA-FMT-52 | — (static backstop; traced via NACHA-FMT-03) | — |
| NACHA-FMT-04 | DR-NACHA-001-01, DR-NACHA-001-02 | Core |
| NACHA-FMT-05 | SC-NACHA-001-08, DR-NACHA-001-08 | Boundary/Edge, Core |
| NACHA-FMT-06 | SC-NACHA-001-19 | Retention/Audit |
| NACHA-AUTH-01 | SC-NACHA-001-02, SC-NACHA-001-12, SC-NACHA-001-21 | Boundary/Edge, Core, Positive |
| NACHA-AUTH-51 | — (static backstop; traced via NACHA-AUTH-01) | — |
| NACHA-AUTH-02 | SC-NACHA-001-09, DR-NACHA-001-09 | Core, Negative |
| NACHA-AUTH-52 | — (static backstop; traced via NACHA-AUTH-02) | — |
| NACHA-AUTH-03 | SC-NACHA-001-10 | Concurrency/Idempotency |
| NACHA-AUTH-04 | SC-NACHA-001-22 | Failure/Recovery |
| NACHA-AUTH-53 | — (static backstop; traced via NACHA-AUTH-04) | — |
| NACHA-AUTH-05 | DR-NACHA-001-07 | Core |
| NACHA-AUTH-06 | DR-NACHA-001-06, SC-NACHA-001-23, SC-NACHA-001-11 | Common Failure, Core, Retention/Audit |
| NACHA-RET-01 | SC-NACHA-001-03, SC-NACHA-001-13, SC-NACHA-001-26 | Common Failure, Concurrency/Idempotency, Core |
| NACHA-RET-51 | — (static backstop; traced via NACHA-RET-01) | — |
| NACHA-RET-02 | SC-NACHA-001-14, SC-NACHA-001-15 | Concurrency/Idempotency, Negative |
| NACHA-RET-52 | — (static backstop; traced via NACHA-RET-02) | — |
| NACHA-RET-03 | SC-NACHA-001-16 | Failure/Recovery |
| NACHA-RET-04 | SC-NACHA-001-24, DR-NACHA-001-05, DR-NACHA-001-04, DR-NACHA-001-10 | Boundary/Edge, Core |
| NACHA-RET-05 | SC-NACHA-001-17, SC-NACHA-001-25 | Positive, Retention/Audit |

# Helix review rules

Generated from `checks.json` (21 static and behavioural checks; manual/evidence items are not code-reviewable and are omitted). Severity is derived from the playbook priority (P0 -> HIGH); Category MM marks money-movement checks. Rule text is the source invariant, unchanged; it is AI-drafted and needs compliance review.

## Rule NACHA-FMT-01: Generated ACH files pass format validation (94-char records, record types, batch/file control tot...
Severity: HIGH
Category: MM
Scenario: ach-formatting
Requirement: MUST
Invariant: Generated ACH files pass format validation (94-char records, record types, batch/file control totals, entry hash), with addenda counts allowed per SEC code and no invalid characters/overflow.

Source check `NACHA-FMT-01` from `checks.json` (static; deterministic: yes). Covers: ACH formatting · Invalid format · NACHA Rules. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-ACH-028.

## Rule NACHA-FMT-02: Trace numbers are unique per scope even under parallel batch creation
Severity: HIGH
Category: MM
Scenario: ach-formatting
Requirement: MUST
Invariant: Trace numbers are unique per scope even under parallel batch creation; control totals stay correct.

Source check `NACHA-FMT-02` from `checks.json` (behavioural; deterministic: yes). Covers: ACH formatting · Invalid format · NACHA Rules. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-ACH-028.

## Rule NACHA-FMT-51: Trace numbers come from a DB sequence/unique constraint, never from an in-process counter
Severity: HIGH
Category: MM
Scenario: ach-formatting
Requirement: MUST
Invariant: Trace numbers come from a DB sequence/unique constraint, never from an in-process counter.

Source check `NACHA-FMT-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: ACH formatting · Invalid format · NACHA Rules. Backstop for NACHA-FMT-02. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-ACH-028.

## Rule NACHA-FMT-03: A duplicate file/batch transmission is blocked before ODFI submission
Severity: HIGH
Category: MM
Scenario: ach-formatting
Requirement: MUST
Invariant: A duplicate file/batch transmission is blocked before ODFI submission; a rejected-then-corrected retransmission contains each entry exactly once.

Source check `NACHA-FMT-03` from `checks.json` (behavioural; deterministic: yes). Covers: ACH formatting · Invalid format · NACHA Rules. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-ACH-028.

## Rule NACHA-FMT-52: File submission records a unique file-ID/hash before transmission and refuses resubmission of a r...
Severity: HIGH
Category: MM
Scenario: ach-formatting
Requirement: MUST
Invariant: File submission records a unique file-ID/hash before transmission and refuses resubmission of a recorded ID.

Source check `NACHA-FMT-52` from `checks.json` (static, static backstop; deterministic: yes). Covers: ACH formatting · Invalid format · NACHA Rules. Backstop for NACHA-FMT-03. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-ACH-028.

## Rule NACHA-FMT-04: Effective entry dates roll to valid banking days
Severity: HIGH
Category: MM
Scenario: ach-formatting
Requirement: MUST
Invariant: Effective entry dates roll to valid banking days; Same Day ACH eligibility, window and per-entry limit are enforced (controllable clock).

Source check `NACHA-FMT-04` from `checks.json` (behavioural; deterministic: yes). Covers: ACH formatting · Invalid format · NACHA Rules. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-ACH-007.

## Rule NACHA-FMT-05: Live entries wait per the prenote policy and a prenote return blocks them
Severity: HIGH
Category: MM
Scenario: ach-formatting
Requirement: MUST
Invariant: Live entries wait per the prenote policy and a prenote return blocks them; micro-entries use the configured descriptor, cap and offset.

Source check `NACHA-FMT-05` from `checks.json` (behavioural; deterministic: yes). Covers: ACH formatting · None · NACHA Rules. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-ACH-025.

## Rule NACHA-AUTH-01: No debit is originated without a valid, retrievable authorization matching its terms and SEC-code...
Severity: HIGH
Category: MM
Scenario: authorization
Requirement: MUST
Invariant: No debit is originated without a valid, retrievable authorization matching its terms and SEC-code capture method, inside its effective window.

Source check `NACHA-AUTH-01` from `checks.json` (behavioural; deterministic: yes). Covers: Authorization · missing auth · NACHA Rules. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-ACH-002, RR-ACH-014.

## Rule NACHA-AUTH-51: Debit origination code requires a non-null authorization reference validated against amount/date...
Severity: HIGH
Category: MM
Scenario: authorization
Requirement: MUST
Invariant: Debit origination code requires a non-null authorization reference validated against amount/date terms in the same transaction.

Source check `NACHA-AUTH-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: Authorization · missing auth · NACHA Rules. Backstop for NACHA-AUTH-01. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-ACH-002, RR-ACH-014.

## Rule NACHA-AUTH-02: Recurring debits outside authorised amount/date range are blocked
Severity: HIGH
Category: MM
Scenario: authorization
Requirement: MUST
Invariant: Recurring debits outside authorised amount/date range are blocked; originator exposure limits hold over-limit batches.

Source check `NACHA-AUTH-02` from `checks.json` (behavioural; deterministic: yes). Covers: Authorization · missing auth · NACHA Rules. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-ACH-014, RR-ACH-001.

## Rule NACHA-AUTH-52: Originator exposure limits are read from the limits table inside the batching transaction, never...
Severity: HIGH
Category: MM
Scenario: authorization
Requirement: MUST
Invariant: Originator exposure limits are read from the limits table inside the batching transaction, never from the request payload.

Source check `NACHA-AUTH-52` from `checks.json` (static, static backstop; deterministic: yes). Covers: Authorization · missing auth · NACHA Rules. Backstop for NACHA-AUTH-02. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-ACH-001.

## Rule NACHA-AUTH-03: A revocation removes the entry from any unsent batch
Severity: HIGH
Category: MM
Scenario: authorization
Requirement: MUST
Invariant: A revocation removes the entry from any unsent batch; transmitted entries are flagged.

Source check `NACHA-AUTH-03` from `checks.json` (behavioural; deterministic: yes). Covers: Authorization · missing auth · NACHA Rules. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-ACH-014, RR-REGE-005.

## Rule NACHA-AUTH-04: Authorization store outage blocks origination
Severity: HIGH
Category: MM
Scenario: authorization
Requirement: MUST
Invariant: Authorization store outage blocks origination.

Source check `NACHA-AUTH-04` from `checks.json` (behavioural; deterministic: yes). Covers: Authorization · missing auth · NACHA Rules. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-ACH-002.

## Rule NACHA-AUTH-53: Authorization-store failure handling blocks origination (no default-allow)
Severity: HIGH
Category: MM
Scenario: authorization
Requirement: MUST
Invariant: Authorization-store failure handling blocks origination (no default-allow).

Source check `NACHA-AUTH-53` from `checks.json` (static, static backstop; deterministic: yes). Covers: Authorization · missing auth · NACHA Rules. Backstop for NACHA-AUTH-04. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-ACH-002.

## Rule NACHA-AUTH-05: First-use WEB debits require successful account validation
Severity: HIGH
Category: MM
Scenario: authorization
Requirement: MUST
Invariant: First-use WEB debits require successful account validation.

Source check `NACHA-AUTH-05` from `checks.json` (behavioural; deterministic: yes). Covers: Authorization · missing auth · NACHA Rules. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-ACH-008.

## Rule NACHA-RET-01: Each return reverses its original entry exactly once and applies its code action per the configur...
Severity: HIGH
Category: MM
Scenario: return-processing
Requirement: MUST
Invariant: Each return reverses its original entry exactly once and applies its code action per the configured matrix; duplicate return-file ingestion is idempotent.

Source check `NACHA-RET-01` from `checks.json` (behavioural; deterministic: yes). Covers: Return processing · None · NACHA Rules. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-ACH-003.

## Rule NACHA-RET-51: Return ingestion dedupes on (original trace, return code) with a unique constraint
Severity: HIGH
Category: MM
Scenario: return-processing
Requirement: MUST
Invariant: Return ingestion dedupes on (original trace, return code) with a unique constraint; every R-code in the enum has an action-matrix entry.

Source check `NACHA-RET-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: Return processing · None · NACHA Rules. Backstop for NACHA-RET-01. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-ACH-003.

## Rule NACHA-RET-02: A return received before its original posts is matched once it posts
Severity: HIGH
Category: MM
Scenario: return-processing
Requirement: MUST
Invariant: A return received before its original posts is matched once it posts; an unmatched return goes to an exception queue, never auto-posted.

Source check `NACHA-RET-02` from `checks.json` (behavioural; deterministic: yes). Covers: Return processing · None · NACHA Rules. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-ACH-003.

## Rule NACHA-RET-52: The unmatched-return path writes to an exception queue only — never posts to an account resolved...
Severity: HIGH
Category: MM
Scenario: return-processing
Requirement: MUST
Invariant: The unmatched-return path writes to an exception queue only — never posts to an account resolved by fuzzy match.

Source check `NACHA-RET-52` from `checks.json` (static, static backstop; deterministic: yes). Covers: Return processing · None · NACHA Rules. Backstop for NACHA-RET-02. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-ACH-003.

## Rule NACHA-RET-03: A return on already-withdrawn funds posts the reversal and handles the negative balance per polic...
Severity: HIGH
Category: MM
Scenario: return-processing
Requirement: MUST
Invariant: A return on already-withdrawn funds posts the reversal and handles the negative balance per policy, keeping the ledger balanced.

Source check `NACHA-RET-03` from `checks.json` (behavioural; deterministic: yes). Covers: Return processing · None · NACHA Rules. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-ACH-003.

## Rule NACHA-RET-04: Returns are classified timely/late at the configured deadline
Severity: HIGH
Category: MM
Scenario: return-processing
Requirement: MUST
Invariant: Returns are classified timely/late at the configured deadline; reinitiation only for permitted reasons within count/window; NOCs update account details.

Source check `NACHA-RET-04` from `checks.json` (behavioural; deterministic: yes). Covers: Return processing · None · NACHA Rules. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-ACH-003, RR-ACH-005, RR-ACH-006.
