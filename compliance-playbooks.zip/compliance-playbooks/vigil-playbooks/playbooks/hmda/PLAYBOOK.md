---
helixPlaybookFormat: helix-playbook/0.1-proposal
playbookId: vigil-hmda
title: "HMDA LAR Completeness & Edit Checks"
declaredVersion: 0.1.0
intent: draft
applicability:
  languages: [javascript, typescript]
  scenarios: [loan-application-register, data-reporting]
---
# Helix portable playbook — DRAFT manifest · HMDA LAR Completeness & Edit Checks

> **DRAFT — not LOCKED.** Proposed HMDA (Lending) playbook converted from Vigil skill `SK-HMDA-001`: one runner, two layers, **8 harness checks (2 static, incl. 2 static backstops, + 6 behavioural)**, plus 2 manual/evidence items listed separately because neither layer can verify them. Every invariant, layer and determinism call is **AI-drafted (Helix) and needs compliance review**. No detector or rule code exists yet. Before this manifest can be LOCKED, each row needs its detector/rule, a review, and a commit that adds the check alongside its row.

## Layers

- **static**: a repo-agnostic source scanner parameterised by a `VIGIL_HMDA` preset (no app specifics in the detector). It reads source / SQL / config / IaC / git-diff, **fails CLOSED** on a match, and runs with **no adapter**, so it is the CI gate. *Static backstops* (IDs `-5x`) prove a supporting source invariant for a named behavioural check, the way N-CAP-01 / N-STATE-01 back neobank behaviour. They fire even when the adapter never drives that path. Backstops of ⚑ SME checks stay out of the gate.
- **behavioural**: a rule written once against the canonical `MoneySystem` interface (or a DRAFT extension surface in `adapters/`) and driven through the app adapter. Surfaces needed: **MortgageSystem** (`adapters/mortgage.ts`). Every behavioural row reports NOT_EXERCISED until an adapter implements its surface. It returns **CHECKED only when it actually drove the guard's path**.
- **manual/evidence**: organisational process, live-infrastructure, statistical or retention evidence that no source scan or adapter-driven rule can prove. These are **outside the harness**, report `NOT_APPLICABLE` to it, and are tracked as evidence tasks, never as passes.

## Verdicts

`CHECKED` the path ran and the guard held · `FINDING` the guard was violated · `NOT_APPLICABLE` the invariant cannot apply here (incl. every manual/evidence item) · `NOT_EXERCISED` (glyph `????`) the adapter did not drive the path, so nothing is proven. NOT_EXERCISED is **surfaced distinctly and never counted as a pass** (no fake coverage). A ⚑ SME check with no approved parameter matrix reports `NOT_EXERCISED`, never `CHECKED`.

## How to run

- **Not runnable yet**: this draft defines invariants only (no detector/rule code). The intended shape mirrors the neobank playbook:
  - CI gate (adapter-free, blocks on any static FINDING): `run-static` with preset `VIGIL_HMDA`.
  - Full combined table (static + behavioural via the adapter): `run-all`.
- Machine-readable rows: `checks.json` (same IDs; includes source-scenario traceability and neobank overlaps).

## The draft inventory: 2 static + 6 behavioural = 8 checks

| ID | Layer | Deterministic | Invariant (one line) | Covers (automation point · common failure · regulation) |
| --- | --- | --- | --- | --- |
| **HMDA-LAR-01** | behavioural | yes | Every reportable application appears exactly once in the LAR with action taken and dates consistent with LOS events; non-reportable ones are excluded with reason. | Loan application register · Missing data · HMDA |
| **HMDA-LAR-51** | static | yes | The LAR generator selects by a unique application key (one row per application) with an explicit reportability filter and reason. | backstop for HMDA-LAR-01 · Loan application register · Missing data · HMDA |
| **HMDA-LAR-02** | behavioural | yes | Amended applications regenerate their LAR row with the latest values and change history. | Loan application register / Data reporting · Missing data · HMDA |
| **HMDA-LAR-03** | behavioural | yes | Demographic fields hold provided values or correct not-provided codes — no inference. | Loan application register · Missing data · HMDA |
| **HMDA-LAR-04** | behavioural | yes | An LOS extract failure marks the LAR incomplete. | Loan application register · Missing data · HMDA |
| **HMDA-REP-01** | behavioural | yes | A clean LAR passes all edit checks and every seeded violation is caught with its edit ID; edit failures block submission. | Data reporting · edit failure · HMDA |
| **HMDA-REP-02** | behavioural | yes | Field values match source within defined rules; geocoding failures are queued/retried and never submitted as blank census fields. | Data reporting · edit failure · HMDA |
| **HMDA-REP-51** | static | yes | Census fields from geocoding failures are null-flagged and block submission (no blank-string default). | backstop for HMDA-REP-02 · Data reporting · edit failure · HMDA |

## Outside the harness: manual/evidence (2)

These items are not harness checks. Each reports `NOT_APPLICABLE` to the runner and needs an owner and evidence on a schedule.

| ID | Layer | Deterministic | Invariant (one line) | Covers (automation point · common failure · regulation) |
| --- | --- | --- | --- | --- |
| **HMDA-LAR-05** | manual/evidence | no (manual) | LAR submissions are retained. | Loan application register · general control (no source failure) · HMDA |
| **HMDA-REP-03** | manual/evidence | no (manual) | Sample-based accuracy stays below the configured error tolerance; submission/resubmission deadlines are tracked; filed LAR and edit results retained. | Data reporting · edit failure · HMDA |

### Determinism

Every harness row (static and behavioural) is drafted as deterministic. Static detectors, including backstops, are pure functions of the committed source/config/diff. Behavioural rules each run against a **fresh `reset()` MoneySystem** (no state leaks between rules), driven by a **controllable clock**; deadlines, windows, expiries and cadences are asserted by advancing that clock, never by wall-clock reads, and no randomness affects a verdict. External dependencies (vendors, registries, feeds) are faked inside the adapter, which is how fault-injection rows stay deterministic. Manual/evidence rows are not deterministic and are not gate checks.

### Coverage note

Converted from 17 AI-drafted source scenarios of `SK-HMDA-001`; each source scenario maps to exactly one non-backstop row (see the appendix). Static backstops add no scenarios and trace through the check they back. The scenarios were merged into crisp invariants by automation point and failure mode, across categories (positive, negative, boundary, failure/recovery, concurrency/idempotency, retention/audit, common failure, core). Automation points covered: Loan application register, Data reporting. Source common failures: Missing data, edit failure. Thresholds, windows and deadlines are *configured* parameters, not asserted statutory values. No regulation or citation was added beyond the source sheet.

### Overlap with the locked neobank playbook (19 checks)

None. This playbook's invariants are not covered by the neobank set.

### Review flags

- No SME-flagged rows. All rows still need compliance review.

## Appendix: traceability to source scenarios

| Check ID | Source scenario IDs | Categories merged |
| --- | --- | --- |
| HMDA-LAR-01 | SC-HMDA-001-01, SC-HMDA-001-04, SC-HMDA-001-13, SC-HMDA-001-05 | Boundary/Edge, Common Failure, Core, Positive |
| HMDA-LAR-51 | — (static backstop; traced via HMDA-LAR-01) | — |
| HMDA-LAR-02 | SC-HMDA-001-07, SC-HMDA-001-16 | Concurrency/Idempotency |
| HMDA-LAR-03 | SC-HMDA-001-06 | Negative |
| HMDA-LAR-04 | SC-HMDA-001-14 | Failure/Recovery |
| HMDA-LAR-05 | SC-HMDA-001-15 | Retention/Audit |
| HMDA-REP-01 | SC-HMDA-001-03, SC-HMDA-001-08, SC-HMDA-001-17 | Common Failure, Core, Negative |
| HMDA-REP-02 | SC-HMDA-001-02, SC-HMDA-001-09 | Core, Failure/Recovery |
| HMDA-REP-51 | — (static backstop; traced via HMDA-REP-02) | — |
| HMDA-REP-03 | SC-HMDA-001-12, SC-HMDA-001-10, SC-HMDA-001-11 | Boundary/Edge, Positive, Retention/Audit |

# Helix review rules

Generated from `checks.json` (8 static and behavioural checks; manual/evidence items are not code-reviewable and are omitted). Severity is derived from the playbook priority (P1 -> MEDIUM); Category MM marks money-movement checks. Rule text is the source invariant, unchanged; it is AI-drafted and needs compliance review.

## Rule HMDA-LAR-01: Every reportable application appears exactly once in the LAR with action taken and dates consiste...
Severity: MEDIUM
Category: NON_MM
Scenario: loan-application-register
Requirement: MUST
Invariant: Every reportable application appears exactly once in the LAR with action taken and dates consistent with LOS events; non-reportable ones are excluded with reason.

Source check `HMDA-LAR-01` from `checks.json` (behavioural; deterministic: yes). Covers: Loan application register · Missing data · HMDA. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-HMDA-001.

## Rule HMDA-LAR-51: The LAR generator selects by a unique application key (one row per application) with an explicit...
Severity: MEDIUM
Category: NON_MM
Scenario: loan-application-register
Requirement: MUST
Invariant: The LAR generator selects by a unique application key (one row per application) with an explicit reportability filter and reason.

Source check `HMDA-LAR-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: Loan application register · Missing data · HMDA. Backstop for HMDA-LAR-01. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-HMDA-001.

## Rule HMDA-LAR-02: Amended applications regenerate their LAR row with the latest values and change history
Severity: MEDIUM
Category: NON_MM
Scenario: loan-application-register
Requirement: MUST
Invariant: Amended applications regenerate their LAR row with the latest values and change history.

Source check `HMDA-LAR-02` from `checks.json` (behavioural; deterministic: yes). Covers: Loan application register, Data reporting · Missing data · HMDA. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-HMDA-001.

## Rule HMDA-LAR-03: Demographic fields hold provided values or correct not-provided codes — no inference
Severity: MEDIUM
Category: NON_MM
Scenario: loan-application-register
Requirement: MUST
Invariant: Demographic fields hold provided values or correct not-provided codes — no inference.

Source check `HMDA-LAR-03` from `checks.json` (behavioural; deterministic: yes). Covers: Loan application register · Missing data · HMDA. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-HMDA-001.

## Rule HMDA-LAR-04: An LOS extract failure marks the LAR incomplete
Severity: MEDIUM
Category: NON_MM
Scenario: loan-application-register
Requirement: MUST
Invariant: An LOS extract failure marks the LAR incomplete.

Source check `HMDA-LAR-04` from `checks.json` (behavioural; deterministic: yes). Covers: Loan application register · Missing data · HMDA. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-HMDA-001.

## Rule HMDA-REP-01: A clean LAR passes all edit checks and every seeded violation is caught with its edit ID
Severity: MEDIUM
Category: NON_MM
Scenario: data-reporting
Requirement: MUST
Invariant: A clean LAR passes all edit checks and every seeded violation is caught with its edit ID; edit failures block submission.

Source check `HMDA-REP-01` from `checks.json` (behavioural; deterministic: yes). Covers: Data reporting · edit failure · HMDA. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-HMDA-001.

## Rule HMDA-REP-02: Field values match source within defined rules
Severity: MEDIUM
Category: NON_MM
Scenario: data-reporting
Requirement: MUST
Invariant: Field values match source within defined rules; geocoding failures are queued/retried and never submitted as blank census fields.

Source check `HMDA-REP-02` from `checks.json` (behavioural; deterministic: yes). Covers: Data reporting · edit failure · HMDA. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-HMDA-001.

## Rule HMDA-REP-51: Census fields from geocoding failures are null-flagged and block submission (no blank-string defa...
Severity: MEDIUM
Category: NON_MM
Scenario: data-reporting
Requirement: MUST
Invariant: Census fields from geocoding failures are null-flagged and block submission (no blank-string default).

Source check `HMDA-REP-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: Data reporting · edit failure · HMDA. Backstop for HMDA-REP-02. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-HMDA-001.
