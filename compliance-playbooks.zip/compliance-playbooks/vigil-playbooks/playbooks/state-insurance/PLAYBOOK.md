---
helixPlaybookFormat: helix-playbook/0.1-proposal
playbookId: vigil-state-insurance
title: "State Insurance Rate, Form & Claims Compliance"
declaredVersion: 0.1.0
intent: draft
applicability:
  languages: [javascript, typescript]
  scenarios: [rate-filing, form-filing, claims-handling]
---
# Helix portable playbook — DRAFT manifest · State Insurance Rate, Form & Claims Compliance

> **DRAFT — not LOCKED.** Proposed State Insurance Regs (Insurance) playbook converted from Vigil skill `SK-STINS-001`: one runner, two layers, **12 harness checks (4 static, incl. 3 static backstops, + 8 behavioural)**, plus 3 manual/evidence items listed separately because neither layer can verify them. Every invariant, layer and determinism call is **AI-drafted (Helix) and needs compliance review**; 5 check(s) are **⚑ SME-flagged** and cannot gate until an SME/counsel supplies their parameter matrix. No detector or rule code exists yet. Before this manifest can be LOCKED, each row needs its detector/rule, a review, and a commit that adds the check alongside its row.

## Layers

- **static**: a repo-agnostic source scanner parameterised by a `VIGIL_STINS` preset (no app specifics in the detector). It reads source / SQL / config / IaC / git-diff, **fails CLOSED** on a match, and runs with **no adapter**, so it is the CI gate. *Static backstops* (IDs `-5x`) prove a supporting source invariant for a named behavioural check, the way N-CAP-01 / N-STATE-01 back neobank behaviour. They fire even when the adapter never drives that path. Backstops of ⚑ SME checks stay out of the gate.
- **behavioural**: a rule written once against the canonical `MoneySystem` interface (or a DRAFT extension surface in `adapters/`) and driven through the app adapter. Surfaces needed: **InsuranceSystem** (`adapters/insurance.ts`). Every behavioural row reports NOT_EXERCISED until an adapter implements its surface. It returns **CHECKED only when it actually drove the guard's path**.
- **manual/evidence**: organisational process, live-infrastructure, statistical or retention evidence that no source scan or adapter-driven rule can prove. These are **outside the harness**, report `NOT_APPLICABLE` to it, and are tracked as evidence tasks, never as passes.

## Verdicts

`CHECKED` the path ran and the guard held · `FINDING` the guard was violated · `NOT_APPLICABLE` the invariant cannot apply here (incl. every manual/evidence item) · `NOT_EXERCISED` (glyph `????`) the adapter did not drive the path, so nothing is proven. NOT_EXERCISED is **surfaced distinctly and never counted as a pass** (no fake coverage). A ⚑ SME check with no approved parameter matrix reports `NOT_EXERCISED`, never `CHECKED`.

## How to run

- **Not runnable yet**: this draft defines invariants only (no detector/rule code). The intended shape mirrors the neobank playbook:
  - CI gate (adapter-free, blocks on any static FINDING): `run-static` with preset `VIGIL_STINS`.
  - Full combined table (static + behavioural via the adapter): `run-all`.
- Machine-readable rows: `checks.json` (same IDs; includes source-scenario traceability and neobank overlaps).

## The draft inventory: 4 static + 8 behavioural = 12 checks

| ID | Layer | Deterministic | Invariant (one line) | Covers (automation point · common failure · regulation) |
| --- | --- | --- | --- | --- |
| **STINS-RATE-01** | behavioural | yes ⚑ SME | Quotes use only the approved, effective rate version for the state (state matrix from SME), with new-vs-renewal effective-date rules; pending rates never quote. | Rate filing · Unapproved rate · State Insurance Regs |
| **STINS-RATE-51** | static | yes ⚑ SME | The quote path selects rate versions filtered by state, approved status and effective date; pending versions are unreachable. | backstop for STINS-RATE-01 · Rate filing · Unapproved rate · State Insurance Regs |
| **STINS-RATE-02** | static | yes | An unfiled rating factor is rejected in config validation. | Rate filing · Unapproved rate · State Insurance Regs |
| **STINS-RATE-03** | behavioural | yes | A rate-table load failure keeps the previous approved version active; a rate change during in-flight quotes follows the configured lock/requote rule. | Rate filing · Unapproved rate · State Insurance Regs |
| **STINS-FORM-01** | behavioural | yes ⚑ SME | Policies issue only with the approved form set and required state endorsements per the state matrix; any unapproved/missing form blocks issuance. | Form filing · general control (no source failure) · State Insurance Regs |
| **STINS-FORM-51** | static | yes ⚑ SME | Issuance requires every form in the state matrix's required set to be present and approved. | backstop for STINS-FORM-01 · Form filing · general control (no source failure) · State Insurance Regs |
| **STINS-FORM-02** | behavioural | yes | Form versions follow the new-vs-renewal effective-date rule and concurrent issuance never mixes versions within a policy. | Form filing · general control (no source failure) · State Insurance Regs |
| **STINS-FORM-03** | behavioural | yes | Document-generation failure blocks issuance. | Form filing · general control (no source failure) · State Insurance Regs |
| **STINS-CLM-01** | behavioural | yes ⚑ SME | Claims are acknowledged and decided within the state-matrix timelines, timers survive outages and overdue claims escalate (controllable clock). | Claims handling · slow claims · State Insurance Regs |
| **STINS-CLM-02** | behavioural | yes | Each approved claim pays exactly once; duplicates are flagged. | Claims handling · slow claims · State Insurance Regs |
| **STINS-CLM-51** | static | yes | Claim payments are keyed by a unique (claim, payment) idempotency key. | backstop for STINS-CLM-02 · Claims handling · slow claims · State Insurance Regs |
| **STINS-CLM-03** | behavioural | yes | A claim cannot close without the required decision notice. | Claims handling · slow claims · State Insurance Regs |

## Outside the harness: manual/evidence (3)

These items are not harness checks. Each reports `NOT_APPLICABLE` to the runner and needs an owner and evidence on a schedule.

| ID | Layer | Deterministic | Invariant (one line) | Covers (automation point · common failure · regulation) |
| --- | --- | --- | --- | --- |
| **STINS-RATE-04** | manual/evidence | no (manual) | Rate versions and approvals are retained. | Rate filing · general control (no source failure) · State Insurance Regs |
| **STINS-FORM-04** | manual/evidence | no (manual) | Issued form copies are retained. | Form filing · general control (no source failure) · State Insurance Regs |
| **STINS-CLM-04** | manual/evidence | no (manual) | Claim files are retained. | Claims handling · general control (no source failure) · State Insurance Regs |

### Determinism

Every harness row (static and behavioural) is drafted as deterministic. Static detectors, including backstops, are pure functions of the committed source/config/diff. Behavioural rules each run against a **fresh `reset()` MoneySystem** (no state leaks between rules), driven by a **controllable clock**; deadlines, windows, expiries and cadences are asserted by advancing that clock, never by wall-clock reads, and no randomness affects a verdict. External dependencies (vendors, registries, feeds) are faked inside the adapter, which is how fault-injection rows stay deterministic. Manual/evidence rows are not deterministic and are not gate checks. ⚑ SME rows are deterministic once parameters exist, but are excluded from the gate until then.

### Coverage note

Converted from 24 AI-drafted source scenarios of `SK-STINS-001`; each source scenario maps to exactly one non-backstop row (see the appendix). Static backstops add no scenarios and trace through the check they back. The scenarios were merged into crisp invariants by automation point and failure mode, across categories (positive, negative, boundary, failure/recovery, concurrency/idempotency, retention/audit, common failure, core). Automation points covered: Rate filing, Form filing, Claims handling. Source common failures: Unapproved rate, slow claims. Thresholds, windows and deadlines are *configured* parameters, not asserted statutory values. No regulation or citation was added beyond the source sheet.

### Overlap with the locked neobank playbook (19 checks)

| This check | Neobank check | Strength | Why |
| --- | --- | --- | --- |
| STINS-CLM-02 | N-IDEMP-01 | related | claim paid once |
| STINS-CLM-51 | N-IDEMP-01 | related | unique-key dedupe on the write path |

`same` means the neobank check already enforces this invariant, so reuse it instead of re-implementing. `related` means the same defect class, but this check needs its own rule or preset.

### Review flags

- ⚑ **STINS-RATE-01**: needs an SME/counsel parameter matrix (source scenarios carry review status "+ SME input").
- ⚑ **STINS-RATE-51**: needs an SME/counsel parameter matrix (source scenarios carry review status "+ SME input").
- ⚑ **STINS-FORM-01**: needs an SME/counsel parameter matrix (source scenarios carry review status "+ SME input").
- ⚑ **STINS-FORM-51**: needs an SME/counsel parameter matrix (source scenarios carry review status "+ SME input").
- ⚑ **STINS-CLM-01**: needs an SME/counsel parameter matrix (source scenarios carry review status "+ SME input").

## Appendix: traceability to source scenarios

| Check ID | Source scenario IDs | Categories merged |
| --- | --- | --- |
| STINS-RATE-01 | SC-STINS-001-01, SC-STINS-001-04, SC-STINS-001-05, SC-STINS-001-12 | Boundary/Edge, Common Failure, Core, Positive |
| STINS-RATE-51 | — (static backstop; traced via STINS-RATE-01) | — |
| STINS-RATE-02 | SC-STINS-001-13 | Negative |
| STINS-RATE-03 | SC-STINS-001-14, SC-STINS-001-15 | Concurrency/Idempotency, Failure/Recovery |
| STINS-RATE-04 | SC-STINS-001-16 | Retention/Audit |
| STINS-FORM-01 | SC-STINS-001-02, SC-STINS-001-06, SC-STINS-001-10, SC-STINS-001-17 | Common Failure, Core, Negative, Positive |
| STINS-FORM-51 | — (static backstop; traced via STINS-FORM-01) | — |
| STINS-FORM-02 | SC-STINS-001-11, SC-STINS-001-19 | Boundary/Edge, Concurrency/Idempotency |
| STINS-FORM-03 | SC-STINS-001-18 | Failure/Recovery |
| STINS-FORM-04 | SC-STINS-001-20 | Retention/Audit |
| STINS-CLM-01 | SC-STINS-001-03, SC-STINS-001-07, SC-STINS-001-21, SC-STINS-001-23, SC-STINS-001-24 | Boundary/Edge, Common Failure, Core, Failure/Recovery, Positive |
| STINS-CLM-02 | SC-STINS-001-08 | Concurrency/Idempotency |
| STINS-CLM-51 | — (static backstop; traced via STINS-CLM-02) | — |
| STINS-CLM-03 | SC-STINS-001-22 | Negative |
| STINS-CLM-04 | SC-STINS-001-09 | Retention/Audit |

# Helix review rules

Generated from `checks.json` (12 static and behavioural checks; manual/evidence items are not code-reviewable and are omitted). Severity is derived from the playbook priority (P2 -> LOW); Category MM marks money-movement checks. Rule text is the source invariant, unchanged; it is AI-drafted and needs compliance review.

## Rule STINS-RATE-01: Quotes use only the approved, effective rate version for the state (state matrix from SME), with...
Severity: LOW
Category: NON_MM
Scenario: rate-filing
Requirement: MUST
Invariant: Quotes use only the approved, effective rate version for the state (state matrix from SME), with new-vs-renewal effective-date rules; pending rates never quote.

Source check `STINS-RATE-01` from `checks.json` (behavioural; deterministic: yes). Covers: Rate filing · Unapproved rate · State Insurance Regs. Flagged for SME input in the source; needs an approved parameter matrix. Review status in source: Drafted (AI) – needs compliance review + SME input.

## Rule STINS-RATE-51: The quote path selects rate versions filtered by state, approved status and effective date
Severity: LOW
Category: NON_MM
Scenario: rate-filing
Requirement: MUST
Invariant: The quote path selects rate versions filtered by state, approved status and effective date; pending versions are unreachable.

Source check `STINS-RATE-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: Rate filing · Unapproved rate · State Insurance Regs. Backstop for STINS-RATE-01. Flagged for SME input in the source; needs an approved parameter matrix. Review status in source: Drafted (AI) – needs compliance review + SME input.

## Rule STINS-RATE-02: An unfiled rating factor is rejected in config validation
Severity: LOW
Category: NON_MM
Scenario: rate-filing
Requirement: MUST
Invariant: An unfiled rating factor is rejected in config validation.

Source check `STINS-RATE-02` from `checks.json` (static; deterministic: yes). Covers: Rate filing · Unapproved rate · State Insurance Regs. Review status in source: Drafted (AI) – needs compliance review.

## Rule STINS-RATE-03: A rate-table load failure keeps the previous approved version active
Severity: LOW
Category: NON_MM
Scenario: rate-filing
Requirement: MUST
Invariant: A rate-table load failure keeps the previous approved version active; a rate change during in-flight quotes follows the configured lock/requote rule.

Source check `STINS-RATE-03` from `checks.json` (behavioural; deterministic: yes). Covers: Rate filing · Unapproved rate · State Insurance Regs. Review status in source: Drafted (AI) – needs compliance review.

## Rule STINS-FORM-01: Policies issue only with the approved form set and required state endorsements per the state matrix
Severity: LOW
Category: NON_MM
Scenario: form-filing
Requirement: MUST
Invariant: Policies issue only with the approved form set and required state endorsements per the state matrix; any unapproved/missing form blocks issuance.

Source check `STINS-FORM-01` from `checks.json` (behavioural; deterministic: yes). Covers: Form filing · None · State Insurance Regs. Flagged for SME input in the source; needs an approved parameter matrix. Review status in source: Drafted (AI) – needs compliance review + SME input.

## Rule STINS-FORM-51: Issuance requires every form in the state matrix's required set to be present and approved
Severity: LOW
Category: NON_MM
Scenario: form-filing
Requirement: MUST
Invariant: Issuance requires every form in the state matrix's required set to be present and approved.

Source check `STINS-FORM-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: Form filing · None · State Insurance Regs. Backstop for STINS-FORM-01. Flagged for SME input in the source; needs an approved parameter matrix. Review status in source: Drafted (AI) – needs compliance review + SME input.

## Rule STINS-FORM-02: Form versions follow the new-vs-renewal effective-date rule and concurrent issuance never mixes v...
Severity: LOW
Category: NON_MM
Scenario: form-filing
Requirement: MUST
Invariant: Form versions follow the new-vs-renewal effective-date rule and concurrent issuance never mixes versions within a policy.

Source check `STINS-FORM-02` from `checks.json` (behavioural; deterministic: yes). Covers: Form filing · None · State Insurance Regs. Review status in source: Drafted (AI) – needs compliance review.

## Rule STINS-FORM-03: Document-generation failure blocks issuance
Severity: LOW
Category: NON_MM
Scenario: form-filing
Requirement: MUST
Invariant: Document-generation failure blocks issuance.

Source check `STINS-FORM-03` from `checks.json` (behavioural; deterministic: yes). Covers: Form filing · None · State Insurance Regs. Review status in source: Drafted (AI) – needs compliance review.

## Rule STINS-CLM-01: Claims are acknowledged and decided within the state-matrix timelines, timers survive outages and...
Severity: LOW
Category: NON_MM
Scenario: claims-handling
Requirement: MUST
Invariant: Claims are acknowledged and decided within the state-matrix timelines, timers survive outages and overdue claims escalate (controllable clock).

Source check `STINS-CLM-01` from `checks.json` (behavioural; deterministic: yes). Covers: Claims handling · slow claims · State Insurance Regs. Flagged for SME input in the source; needs an approved parameter matrix. Review status in source: Drafted (AI) – needs compliance review + SME input.

Regulation references: RR-STATE-014.

## Rule STINS-CLM-02: Each approved claim pays exactly once
Severity: LOW
Category: NON_MM
Scenario: claims-handling
Requirement: MUST
Invariant: Each approved claim pays exactly once; duplicates are flagged.

Source check `STINS-CLM-02` from `checks.json` (behavioural; deterministic: yes). Covers: Claims handling · slow claims · State Insurance Regs. Review status in source: Drafted (AI) – needs compliance review.

## Rule STINS-CLM-51: Claim payments are keyed by a unique (claim, payment) idempotency key
Severity: LOW
Category: NON_MM
Scenario: claims-handling
Requirement: MUST
Invariant: Claim payments are keyed by a unique (claim, payment) idempotency key.

Source check `STINS-CLM-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: Claims handling · slow claims · State Insurance Regs. Backstop for STINS-CLM-02. Review status in source: Drafted (AI) – needs compliance review.

## Rule STINS-CLM-03: A claim cannot close without the required decision notice
Severity: LOW
Category: NON_MM
Scenario: claims-handling
Requirement: MUST
Invariant: A claim cannot close without the required decision notice.

Source check `STINS-CLM-03` from `checks.json` (behavioural; deterministic: yes). Covers: Claims handling · slow claims · State Insurance Regs. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-STATE-014.
