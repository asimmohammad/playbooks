---
helixPlaybookFormat: helix-playbook/0.1-proposal
playbookId: vigil-gdpr
title: "GDPR Data Subject Rights & Consent"
declaredVersion: 0.1.0
intent: draft
applicability:
  languages: [javascript, typescript]
  scenarios: [consent, data-deletion, data-portability, breach-notification]
---
# Helix portable playbook — DRAFT manifest · GDPR Data Subject Rights & Consent

> **DRAFT — not LOCKED.** Proposed GDPR (Data Privacy) playbook converted from Vigil skill `SK-GDPR-001`: one runner, two layers, **23 harness checks (7 static, incl. 5 static backstops, + 16 behavioural)**, plus 3 manual/evidence items listed separately because neither layer can verify them. Every invariant, layer and determinism call is **AI-drafted (Helix) and needs compliance review**. No detector or rule code exists yet. Before this manifest can be LOCKED, each row needs its detector/rule, a review, and a commit that adds the check alongside its row.

## Layers

- **static**: a repo-agnostic source scanner parameterised by a `VIGIL_GDPR` preset (no app specifics in the detector). It reads source / SQL / config / IaC / git-diff, **fails CLOSED** on a match, and runs with **no adapter**, so it is the CI gate. *Static backstops* (IDs `-5x`) prove a supporting source invariant for a named behavioural check, the way N-CAP-01 / N-STATE-01 back neobank behaviour. They fire even when the adapter never drives that path. Backstops of ⚑ SME checks stay out of the gate.
- **behavioural**: a rule written once against the canonical `MoneySystem` interface (or a DRAFT extension surface in `adapters/`) and driven through the app adapter. Surfaces needed: **PrivacySystem** (`adapters/privacy.ts`). Every behavioural row reports NOT_EXERCISED until an adapter implements its surface. It returns **CHECKED only when it actually drove the guard's path**.
- **manual/evidence**: organisational process, live-infrastructure, statistical or retention evidence that no source scan or adapter-driven rule can prove. These are **outside the harness**, report `NOT_APPLICABLE` to it, and are tracked as evidence tasks, never as passes.

## Verdicts

`CHECKED` the path ran and the guard held · `FINDING` the guard was violated · `NOT_APPLICABLE` the invariant cannot apply here (incl. every manual/evidence item) · `NOT_EXERCISED` (glyph `????`) the adapter did not drive the path, so nothing is proven. NOT_EXERCISED is **surfaced distinctly and never counted as a pass** (no fake coverage). A ⚑ SME check with no approved parameter matrix reports `NOT_EXERCISED`, never `CHECKED`.

## How to run

- **Not runnable yet**: this draft defines invariants only (no detector/rule code). The intended shape mirrors the neobank playbook:
  - CI gate (adapter-free, blocks on any static FINDING): `run-static` with preset `VIGIL_GDPR`.
  - Full combined table (static + behavioural via the adapter): `run-all`.
- Machine-readable rows: `checks.json` (same IDs; includes source-scenario traceability and neobank overlaps).

## The draft inventory: 7 static + 16 behavioural = 23 checks

| ID | Layer | Deterministic | Invariant (one line) | Covers (automation point · common failure · regulation) |
| --- | --- | --- | --- | --- |
| **GDPR-CON-01** | behavioural | yes | Consent-based processing runs only for purposes with a current, versioned consent record (purpose, timestamp, notice version, channel); a purpose change needs renewed consent. | Consent · Missing consent · GDPR |
| **GDPR-CON-51** | static | yes | Every consent-gated processing job/route checks a consent lookup keyed by purpose before executing (purpose registry ↔ call sites complete). | backstop for GDPR-CON-01 · Consent · Missing consent · GDPR |
| **GDPR-CON-02** | static | yes | Consent UI has no pre-ticked or bundled optional purposes, and no third-party tracking SDK initialises before consent is evaluated. | Consent · Missing consent · GDPR |
| **GDPR-CON-03** | behavioural | yes | Withdrawal or objection takes effect from its timestamp: subjects are re-checked at send time and excluded from in-flight marketing batches and audience uploads. | Consent · Missing consent · GDPR |
| **GDPR-CON-04** | behavioural | yes | Consent store outage fails closed — consent-based processing treated as no consent; essential processing unaffected. | Consent · Missing consent · GDPR |
| **GDPR-CON-52** | static | yes | Consent-lookup failure handling returns 'no consent' — no catch/timeout branch defaults to granted. | backstop for GDPR-CON-04 · Consent · Missing consent · GDPR |
| **GDPR-CON-05** | behavioural | yes | Below the configured member-state age, consent requires the parental-consent path (boundary at the configured age). | Consent · Missing consent · GDPR |
| **GDPR-DEL-01** | behavioural | yes | A verified erasure removes or anonymises personal data in every mapped store (incl. logs, indexes, ML features, processors) except configured retention exceptions, which stay restricted. | Data deletion · incomplete deletion · GDPR |
| **GDPR-DEL-51** | static | yes | Every store holding personal-data fields in the data map has a registered erasure handler; a new PII column/store without one fails the scan. | backstop for GDPR-DEL-01 · Data deletion · incomplete deletion · GDPR |
| **GDPR-DEL-02** | behavioural | yes | An unverified erasure request erases nothing and is logged. | Data deletion · incomplete deletion · GDPR |
| **GDPR-DEL-03** | behavioural | yes | Erasure is idempotent and resumable: duplicates run one workflow; an interrupted job resumes and the request is not complete until every system confirms. | Data deletion · incomplete deletion · GDPR |
| **GDPR-DEL-04** | behavioural | yes | Restore from backup does not resurrect erased subjects; rectification updates every mapped copy. | Data deletion · incomplete deletion · GDPR |
| **GDPR-DEL-52** | static | yes | Backup-restore tooling replays the erasure ledger (suppression list) before restored data becomes readable. | backstop for GDPR-DEL-04 · Data deletion · incomplete deletion · GDPR |
| **GDPR-DEL-05** | static | yes | The erasure audit tombstone contains no personal data (non-reversible reference only). | Data deletion · general control (no source failure) · GDPR |
| **GDPR-POR-01** | behavioural | yes | A portability export is complete (no pagination truncation), machine-readable in the configured format, scoped to configured categories and contains only the requesting subject's data. | Data portability · general control (no source failure) · GDPR |
| **GDPR-POR-51** | static | yes | Export queries filter by the requesting subject ID at every join/source; no unbounded pagination (explicit page loop to completion). | backstop for GDPR-POR-01 · Data portability · general control (no source failure) · GDPR |
| **GDPR-POR-02** | behavioural | yes | Export download is restricted to the authenticated subject before link expiry. | Data portability · general control (no source failure) · GDPR |
| **GDPR-POR-03** | behavioural | yes | A failed export never delivers a partial file as complete; concurrent export requests dedupe to one job or identical output. | Data portability · general control (no source failure) · GDPR |
| **GDPR-POR-04** | behavioural | yes | Verified data-subject requests complete before the configured deadline or carry an extension notice (controllable clock). | Data portability · general control (no source failure) · GDPR |
| **GDPR-BRN-01** | behavioural | yes | An exfiltration indicator or processor report opens one breach case with its awareness timestamp; concurrent reports of one incident merge into one case. | Breach notification · general control (no source failure) · GDPR |
| **GDPR-BRN-02** | behavioural | yes | Notification deadlines are computed in elapsed hours from awareness (weekends/holidays included) and escalate before expiry; overdue is flagged. | Breach notification · general control (no source failure) · GDPR |
| **GDPR-BRN-03** | behavioural | yes | A notification cannot reach 'ready to send' until every configured required element is populated; high-risk breaches identify and notify all affected subjects. | Breach notification · general control (no source failure) · GDPR |
| **GDPR-BRN-04** | behavioural | yes | Primary notification-channel failure falls back to an alternate channel with deadline tracking intact. | Breach notification · general control (no source failure) · GDPR |

## Outside the harness: manual/evidence (3)

These items are not harness checks. Each reports `NOT_APPLICABLE` to the runner and needs an owner and evidence on a schedule.

| ID | Layer | Deterministic | Invariant (one line) | Covers (automation point · common failure · regulation) |
| --- | --- | --- | --- | --- |
| **GDPR-CON-06** | manual/evidence | no (manual) | Proof-of-consent records (with exact notice text version) are retained for the configured period. | Consent · general control (no source failure) · GDPR |
| **GDPR-POR-05** | manual/evidence | no (manual) | Export request, verification and delivery records are retained for the configured period. | Data portability · general control (no source failure) · GDPR |
| **GDPR-BRN-05** | manual/evidence | no (manual) | The breach register records every incident, including non-notified ones, with rationale, and is retained. | Breach notification · general control (no source failure) · GDPR |

### Determinism

Every harness row (static and behavioural) is drafted as deterministic. Static detectors, including backstops, are pure functions of the committed source/config/diff. Behavioural rules each run against a **fresh `reset()` MoneySystem** (no state leaks between rules), driven by a **controllable clock**; deadlines, windows, expiries and cadences are asserted by advancing that clock, never by wall-clock reads, and no randomness affects a verdict. External dependencies (vendors, registries, feeds) are faked inside the adapter, which is how fault-injection rows stay deterministic. Manual/evidence rows are not deterministic and are not gate checks.

### Coverage note

Converted from 43 AI-drafted source scenarios of `SK-GDPR-001`; each source scenario maps to exactly one non-backstop row (see the appendix). Static backstops add no scenarios and trace through the check they back. The scenarios were merged into crisp invariants by automation point and failure mode, across categories (positive, negative, boundary, failure/recovery, concurrency/idempotency, retention/audit, common failure, core). Automation points covered: Consent, Data deletion, Data portability, Breach notification. Source common failures: Missing consent, incomplete deletion. Thresholds, windows and deadlines are *configured* parameters, not asserted statutory values. No regulation or citation was added beyond the source sheet.

### Overlap with the locked neobank playbook (19 checks)

| This check | Neobank check | Strength | Why |
| --- | --- | --- | --- |
| GDPR-DEL-03 | N-IDEMP-01 | related | erasure idempotent |
| GDPR-POR-03 | N-IDEMP-01 | related | export dedupe |

`same` means the neobank check already enforces this invariant, so reuse it instead of re-implementing. `related` means the same defect class, but this check needs its own rule or preset.

### Review flags

- No SME-flagged rows. All rows still need compliance review.

## Appendix: traceability to source scenarios

| Check ID | Source scenario IDs | Categories merged |
| --- | --- | --- |
| GDPR-CON-01 | SC-GDPR-001-01, SC-GDPR-001-22, DR-GDPR-001-05 | Core, Positive |
| GDPR-CON-51 | — (static backstop; traced via GDPR-CON-01) | — |
| GDPR-CON-02 | SC-GDPR-001-23, SC-GDPR-001-24, DR-GDPR-001-04 | Common Failure, Core, Negative |
| GDPR-CON-03 | SC-GDPR-001-05, DR-GDPR-001-03, DR-GDPR-001-09 | Concurrency/Idempotency, Core |
| GDPR-CON-04 | SC-GDPR-001-06 | Failure/Recovery |
| GDPR-CON-52 | — (static backstop; traced via GDPR-CON-04) | — |
| GDPR-CON-05 | SC-GDPR-001-07 | Boundary/Edge |
| GDPR-CON-06 | SC-GDPR-001-04 | Retention/Audit |
| GDPR-DEL-01 | SC-GDPR-001-02, SC-GDPR-001-09, SC-GDPR-001-25, SC-GDPR-001-26, DR-GDPR-001-07 | Boundary/Edge, Common Failure, Core, Positive |
| GDPR-DEL-51 | — (static backstop; traced via GDPR-DEL-01) | — |
| GDPR-DEL-02 | SC-GDPR-001-08 | Negative |
| GDPR-DEL-03 | SC-GDPR-001-10, SC-GDPR-001-11 | Concurrency/Idempotency, Failure/Recovery |
| GDPR-DEL-04 | DR-GDPR-001-06, DR-GDPR-001-10 | Core |
| GDPR-DEL-52 | — (static backstop; traced via GDPR-DEL-04) | — |
| GDPR-DEL-05 | SC-GDPR-001-12 | Retention/Audit |
| GDPR-POR-01 | SC-GDPR-001-03, SC-GDPR-001-13, SC-GDPR-001-14, SC-GDPR-001-27, SC-GDPR-001-30 | Boundary/Edge, Common Failure, Core, Positive |
| GDPR-POR-51 | — (static backstop; traced via GDPR-POR-01) | — |
| GDPR-POR-02 | SC-GDPR-001-15 | Negative |
| GDPR-POR-03 | SC-GDPR-001-16, SC-GDPR-001-28 | Concurrency/Idempotency, Failure/Recovery |
| GDPR-POR-04 | DR-GDPR-001-08 | Core |
| GDPR-POR-05 | SC-GDPR-001-29 | Retention/Audit |
| GDPR-BRN-01 | SC-GDPR-001-17, SC-GDPR-001-18, SC-GDPR-001-32, DR-GDPR-001-01 | Boundary/Edge, Concurrency/Idempotency, Core, Positive |
| GDPR-BRN-02 | SC-GDPR-001-21, SC-GDPR-001-33 | Boundary/Edge, Common Failure |
| GDPR-BRN-03 | SC-GDPR-001-19, DR-GDPR-001-02 | Core, Negative |
| GDPR-BRN-04 | SC-GDPR-001-31 | Failure/Recovery |
| GDPR-BRN-05 | SC-GDPR-001-20 | Retention/Audit |

# Helix review rules

Generated from `checks.json` (23 static and behavioural checks; manual/evidence items are not code-reviewable and are omitted). Severity is derived from the playbook priority (P0 -> HIGH); Category MM marks money-movement checks. Rule text is the source invariant, unchanged; it is AI-drafted and needs compliance review.

## Rule GDPR-CON-01: Consent-based processing runs only for purposes with a current, versioned consent record (purpose...
Severity: HIGH
Category: NON_MM
Scenario: consent
Requirement: MUST
Invariant: Consent-based processing runs only for purposes with a current, versioned consent record (purpose, timestamp, notice version, channel); a purpose change needs renewed consent.

Source check `GDPR-CON-01` from `checks.json` (behavioural; deterministic: yes). Covers: Consent · Missing consent · GDPR. Review status in source: Drafted (AI) – needs compliance review.

## Rule GDPR-CON-51: Every consent-gated processing job/route checks a consent lookup keyed by purpose before executin...
Severity: HIGH
Category: NON_MM
Scenario: consent
Requirement: MUST
Invariant: Every consent-gated processing job/route checks a consent lookup keyed by purpose before executing (purpose registry ↔ call sites complete).

Source check `GDPR-CON-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: Consent · Missing consent · GDPR. Backstop for GDPR-CON-01. Review status in source: Drafted (AI) – needs compliance review.

## Rule GDPR-CON-02: Consent UI has no pre-ticked or bundled optional purposes, and no third-party tracking SDK initia...
Severity: HIGH
Category: NON_MM
Scenario: consent
Requirement: MUST
Invariant: Consent UI has no pre-ticked or bundled optional purposes, and no third-party tracking SDK initialises before consent is evaluated.

Source check `GDPR-CON-02` from `checks.json` (static; deterministic: yes). Covers: Consent · Missing consent · GDPR. Review status in source: Drafted (AI) – needs compliance review.

## Rule GDPR-CON-03: Withdrawal or objection takes effect from its timestamp
Severity: HIGH
Category: NON_MM
Scenario: consent
Requirement: MUST
Invariant: Withdrawal or objection takes effect from its timestamp: subjects are re-checked at send time and excluded from in-flight marketing batches and audience uploads.

Source check `GDPR-CON-03` from `checks.json` (behavioural; deterministic: yes). Covers: Consent · Missing consent · GDPR. Review status in source: Drafted (AI) – needs compliance review.

## Rule GDPR-CON-04: Consent store outage fails closed — consent-based processing treated as no consent
Severity: HIGH
Category: NON_MM
Scenario: consent
Requirement: MUST
Invariant: Consent store outage fails closed — consent-based processing treated as no consent; essential processing unaffected.

Source check `GDPR-CON-04` from `checks.json` (behavioural; deterministic: yes). Covers: Consent · Missing consent · GDPR. Review status in source: Drafted (AI) – needs compliance review.

## Rule GDPR-CON-52: Consent-lookup failure handling returns 'no consent' — no catch/timeout branch defaults to granted
Severity: HIGH
Category: NON_MM
Scenario: consent
Requirement: MUST
Invariant: Consent-lookup failure handling returns 'no consent' — no catch/timeout branch defaults to granted.

Source check `GDPR-CON-52` from `checks.json` (static, static backstop; deterministic: yes). Covers: Consent · Missing consent · GDPR. Backstop for GDPR-CON-04. Review status in source: Drafted (AI) – needs compliance review.

## Rule GDPR-CON-05: Below the configured member-state age, consent requires the parental-consent path (boundary at th...
Severity: HIGH
Category: NON_MM
Scenario: consent
Requirement: MUST
Invariant: Below the configured member-state age, consent requires the parental-consent path (boundary at the configured age).

Source check `GDPR-CON-05` from `checks.json` (behavioural; deterministic: yes). Covers: Consent · Missing consent · GDPR. Review status in source: Drafted (AI) – needs compliance review.

## Rule GDPR-DEL-01: A verified erasure removes or anonymises personal data in every mapped store (incl
Severity: HIGH
Category: NON_MM
Scenario: data-deletion
Requirement: MUST
Invariant: A verified erasure removes or anonymises personal data in every mapped store (incl. logs, indexes, ML features, processors) except configured retention exceptions, which stay restricted.

Source check `GDPR-DEL-01` from `checks.json` (behavioural; deterministic: yes). Covers: Data deletion · incomplete deletion · GDPR. Review status in source: Drafted (AI) – needs compliance review.

## Rule GDPR-DEL-51: Every store holding personal-data fields in the data map has a registered erasure handler
Severity: HIGH
Category: NON_MM
Scenario: data-deletion
Requirement: MUST
Invariant: Every store holding personal-data fields in the data map has a registered erasure handler; a new PII column/store without one fails the scan.

Source check `GDPR-DEL-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: Data deletion · incomplete deletion · GDPR. Backstop for GDPR-DEL-01. Review status in source: Drafted (AI) – needs compliance review.

## Rule GDPR-DEL-02: An unverified erasure request erases nothing and is logged
Severity: HIGH
Category: NON_MM
Scenario: data-deletion
Requirement: MUST
Invariant: An unverified erasure request erases nothing and is logged.

Source check `GDPR-DEL-02` from `checks.json` (behavioural; deterministic: yes). Covers: Data deletion · incomplete deletion · GDPR. Review status in source: Drafted (AI) – needs compliance review.

## Rule GDPR-DEL-03: Erasure is idempotent and resumable
Severity: HIGH
Category: NON_MM
Scenario: data-deletion
Requirement: MUST
Invariant: Erasure is idempotent and resumable: duplicates run one workflow; an interrupted job resumes and the request is not complete until every system confirms.

Source check `GDPR-DEL-03` from `checks.json` (behavioural; deterministic: yes). Covers: Data deletion · incomplete deletion · GDPR. Review status in source: Drafted (AI) – needs compliance review.

## Rule GDPR-DEL-04: Restore from backup does not resurrect erased subjects
Severity: HIGH
Category: NON_MM
Scenario: data-deletion
Requirement: MUST
Invariant: Restore from backup does not resurrect erased subjects; rectification updates every mapped copy.

Source check `GDPR-DEL-04` from `checks.json` (behavioural; deterministic: yes). Covers: Data deletion · incomplete deletion · GDPR. Review status in source: Drafted (AI) – needs compliance review.

## Rule GDPR-DEL-52: Backup-restore tooling replays the erasure ledger (suppression list) before restored data becomes...
Severity: HIGH
Category: NON_MM
Scenario: data-deletion
Requirement: MUST
Invariant: Backup-restore tooling replays the erasure ledger (suppression list) before restored data becomes readable.

Source check `GDPR-DEL-52` from `checks.json` (static, static backstop; deterministic: yes). Covers: Data deletion · incomplete deletion · GDPR. Backstop for GDPR-DEL-04. Review status in source: Drafted (AI) – needs compliance review.

## Rule GDPR-DEL-05: The erasure audit tombstone contains no personal data (non-reversible reference only)
Severity: HIGH
Category: NON_MM
Scenario: data-deletion
Requirement: MUST
Invariant: The erasure audit tombstone contains no personal data (non-reversible reference only).

Source check `GDPR-DEL-05` from `checks.json` (static; deterministic: yes). Covers: Data deletion · None · GDPR. Review status in source: Drafted (AI) – needs compliance review.

## Rule GDPR-POR-01: A portability export is complete (no pagination truncation), machine-readable in the configured f...
Severity: HIGH
Category: NON_MM
Scenario: data-portability
Requirement: MUST
Invariant: A portability export is complete (no pagination truncation), machine-readable in the configured format, scoped to configured categories and contains only the requesting subject's data.

Source check `GDPR-POR-01` from `checks.json` (behavioural; deterministic: yes). Covers: Data portability · None · GDPR. Review status in source: Drafted (AI) – needs compliance review.

## Rule GDPR-POR-51: Export queries filter by the requesting subject ID at every join/source
Severity: HIGH
Category: NON_MM
Scenario: data-portability
Requirement: MUST
Invariant: Export queries filter by the requesting subject ID at every join/source; no unbounded pagination (explicit page loop to completion).

Source check `GDPR-POR-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: Data portability · None · GDPR. Backstop for GDPR-POR-01. Review status in source: Drafted (AI) – needs compliance review.

## Rule GDPR-POR-02: Export download is restricted to the authenticated subject before link expiry
Severity: HIGH
Category: NON_MM
Scenario: data-portability
Requirement: MUST
Invariant: Export download is restricted to the authenticated subject before link expiry.

Source check `GDPR-POR-02` from `checks.json` (behavioural; deterministic: yes). Covers: Data portability · None · GDPR. Review status in source: Drafted (AI) – needs compliance review.

## Rule GDPR-POR-03: A failed export never delivers a partial file as complete
Severity: HIGH
Category: NON_MM
Scenario: data-portability
Requirement: MUST
Invariant: A failed export never delivers a partial file as complete; concurrent export requests dedupe to one job or identical output.

Source check `GDPR-POR-03` from `checks.json` (behavioural; deterministic: yes). Covers: Data portability · None · GDPR. Review status in source: Drafted (AI) – needs compliance review.

## Rule GDPR-POR-04: Verified data-subject requests complete before the configured deadline or carry an extension noti...
Severity: HIGH
Category: NON_MM
Scenario: data-portability
Requirement: MUST
Invariant: Verified data-subject requests complete before the configured deadline or carry an extension notice (controllable clock).

Source check `GDPR-POR-04` from `checks.json` (behavioural; deterministic: yes). Covers: Data portability · None · GDPR. Review status in source: Drafted (AI) – needs compliance review.

## Rule GDPR-BRN-01: An exfiltration indicator or processor report opens one breach case with its awareness timestamp
Severity: HIGH
Category: NON_MM
Scenario: breach-notification
Requirement: MUST
Invariant: An exfiltration indicator or processor report opens one breach case with its awareness timestamp; concurrent reports of one incident merge into one case.

Source check `GDPR-BRN-01` from `checks.json` (behavioural; deterministic: yes). Covers: Breach notification · None · GDPR. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-DATA-001.

## Rule GDPR-BRN-02: Notification deadlines are computed in elapsed hours from awareness (weekends/holidays included)...
Severity: HIGH
Category: NON_MM
Scenario: breach-notification
Requirement: MUST
Invariant: Notification deadlines are computed in elapsed hours from awareness (weekends/holidays included) and escalate before expiry; overdue is flagged.

Source check `GDPR-BRN-02` from `checks.json` (behavioural; deterministic: yes). Covers: Breach notification · None · GDPR. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-DATA-001.

## Rule GDPR-BRN-03: A notification cannot reach 'ready to send' until every configured required element is populated
Severity: HIGH
Category: NON_MM
Scenario: breach-notification
Requirement: MUST
Invariant: A notification cannot reach 'ready to send' until every configured required element is populated; high-risk breaches identify and notify all affected subjects.

Source check `GDPR-BRN-03` from `checks.json` (behavioural; deterministic: yes). Covers: Breach notification · None · GDPR. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-DATA-001.

## Rule GDPR-BRN-04: Primary notification-channel failure falls back to an alternate channel with deadline tracking in...
Severity: HIGH
Category: NON_MM
Scenario: breach-notification
Requirement: MUST
Invariant: Primary notification-channel failure falls back to an alternate channel with deadline tracking intact.

Source check `GDPR-BRN-04` from `checks.json` (behavioural; deterministic: yes). Covers: Breach notification · None · GDPR. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-DATA-001.
