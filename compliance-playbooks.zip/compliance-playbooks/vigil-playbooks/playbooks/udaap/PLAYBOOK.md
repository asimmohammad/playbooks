---
helixPlaybookFormat: helix-playbook/0.1-proposal
playbookId: vigil-udaap
title: "CFPB UDAAP Claims, Fees & Complaints"
declaredVersion: 0.1.0
intent: draft
applicability:
  languages: [javascript, typescript]
  scenarios: [unfair, deceptive, abusive]
---
# Helix portable playbook — DRAFT manifest · CFPB UDAAP Claims, Fees & Complaints

> **DRAFT — not LOCKED.** Proposed UDAAP (CFPB) playbook converted from Vigil skill `SK-UDAAP-001`: one runner, two layers, **10 harness checks (5 static, incl. 3 static backstops, + 5 behavioural)**, plus 3 manual/evidence items listed separately because neither layer can verify them. Every invariant, layer and determinism call is **AI-drafted (Helix) and needs compliance review**; 2 check(s) are **⚑ SME-flagged** and cannot gate until an SME/counsel supplies their parameter matrix. No detector or rule code exists yet. Before this manifest can be LOCKED, each row needs its detector/rule, a review, and a commit that adds the check alongside its row.

## Layers

- **static**: a repo-agnostic source scanner parameterised by a `VIGIL_UDAAP` preset (no app specifics in the detector). It reads source / SQL / config / IaC / git-diff, **fails CLOSED** on a match, and runs with **no adapter**, so it is the CI gate. *Static backstops* (IDs `-5x`) prove a supporting source invariant for a named behavioural check, the way N-CAP-01 / N-STATE-01 back neobank behaviour. They fire even when the adapter never drives that path. Backstops of ⚑ SME checks stay out of the gate.
- **behavioural**: a rule written once against the canonical `MoneySystem` interface (or a DRAFT extension surface in `adapters/`) and driven through the app adapter. Surfaces needed: **FeeSystem** (`adapters/fees.ts`), **CustomerJourneySystem** (`adapters/customer-journey.ts`). Every behavioural row reports NOT_EXERCISED until an adapter implements its surface. It returns **CHECKED only when it actually drove the guard's path**.
- **manual/evidence**: organisational process, live-infrastructure, statistical or retention evidence that no source scan or adapter-driven rule can prove. These are **outside the harness**, report `NOT_APPLICABLE` to it, and are tracked as evidence tasks, never as passes.

## Verdicts

`CHECKED` the path ran and the guard held · `FINDING` the guard was violated · `NOT_APPLICABLE` the invariant cannot apply here (incl. every manual/evidence item) · `NOT_EXERCISED` (glyph `????`) the adapter did not drive the path, so nothing is proven. NOT_EXERCISED is **surfaced distinctly and never counted as a pass** (no fake coverage). A ⚑ SME check with no approved parameter matrix reports `NOT_EXERCISED`, never `CHECKED`.

## How to run

- **Not runnable yet**: this draft defines invariants only (no detector/rule code). The intended shape mirrors the neobank playbook:
  - CI gate (adapter-free, blocks on any static FINDING): `run-static` with preset `VIGIL_UDAAP`.
  - Full combined table (static + behavioural via the adapter): `run-all`.
- Machine-readable rows: `checks.json` (same IDs; includes source-scenario traceability and neobank overlaps).

## The draft inventory: 5 static + 5 behavioural = 10 checks

| ID | Layer | Deterministic | Invariant (one line) | Covers (automation point · common failure · regulation) |
| --- | --- | --- | --- | --- |
| **UDAAP-UNF-01** | behavioural | yes | Only scheduled fees are charged, exactly once per triggering item (no repeat NSF/overdraft on re-presentment, no duplicate under retries), with configured waivers honoured. | Unfair / Abusive · unfair fee · UDAAP |
| **UDAAP-UNF-51** | static | yes | Fee assessment is keyed by (triggering item, fee type) with a unique constraint; fee codes resolve only from the published schedule. | backstop for UDAAP-UNF-01 · Unfair / Abusive · unfair fee · UDAAP |
| **UDAAP-UNF-02** | behavioural | yes | Concurrent transactions follow the configured ordering policy and trigger no artificial overdraft fees; authorize-positive/settle-negative items follow the configured policy. | Unfair · unfair fee · UDAAP |
| **UDAAP-UNF-52** | static | yes | Transaction posting order follows the configured ordering policy constant; no reorder-by-amount path. | backstop for UDAAP-UNF-02 · Unfair · unfair fee · UDAAP |
| **UDAAP-UNF-03** | behavioural | yes | Fees caused by system error are auto-identified and reversed with customer notice. | Unfair · unfair fee · UDAAP |
| **UDAAP-DEC-01** | static | yes | Advertised rates/fees and claims (e.g. 'no fees') match the product/fee configuration — mismatches block publish, including concurrent publishes and after config changes. | Deceptive · Misleading disclosure · UDAAP |
| **UDAAP-DEC-02** | behavioural | yes | Promotional expiry is disclosed and post-expiry terms apply exactly as disclosed. | Deceptive · Misleading disclosure · UDAAP |
| **UDAAP-ABU-01** | static | yes | Material terms meet configured prominence rules in each flow; violations block release. | Abusive · Misleading disclosure · UDAAP |
| **UDAAP-ABU-02** | behavioural | yes ⚑ SME | Cancellation is available in the sign-up channel within the configured step count (SME-provided friction limit) and is honoured even during an outage. | Abusive · general control (no source failure) · UDAAP |
| **UDAAP-ABU-51** | static | yes ⚑ SME | A cancellation route exists for every sign-up channel, and its flow step count ≤ the configured limit (SME-provided). | backstop for UDAAP-ABU-02 · Abusive · general control (no source failure) · UDAAP |

## Outside the harness: manual/evidence (3)

These items are not harness checks. Each reports `NOT_APPLICABLE` to the runner and needs an owner and evidence on a schedule.

| ID | Layer | Deterministic | Invariant (one line) | Covers (automation point · common failure · regulation) |
| --- | --- | --- | --- | --- |
| **UDAAP-UNF-04** | manual/evidence | no (manual) | Fee decisions are retained. | Unfair · general control (no source failure) · UDAAP |
| **UDAAP-DEC-03** | manual/evidence | no (manual) | Disclosure versions are retained with display evidence. | Deceptive · general control (no source failure) · UDAAP |
| **UDAAP-ABU-03** | manual/evidence | no (manual) | Complaints are categorised and routed, and recurring themes above the configured threshold create compliance review items; complaint/cancellation records retained. | Abusive · general control (no source failure) · UDAAP |

### Determinism

Every harness row (static and behavioural) is drafted as deterministic. Static detectors, including backstops, are pure functions of the committed source/config/diff. Behavioural rules each run against a **fresh `reset()` MoneySystem** (no state leaks between rules), driven by a **controllable clock**; deadlines, windows, expiries and cadences are asserted by advancing that clock, never by wall-clock reads, and no randomness affects a verdict. External dependencies (vendors, registries, feeds) are faked inside the adapter, which is how fault-injection rows stay deterministic. Manual/evidence rows are not deterministic and are not gate checks. ⚑ SME rows are deterministic once parameters exist, but are excluded from the gate until then.

### Coverage note

Converted from 24 AI-drafted source scenarios of `SK-UDAAP-001`; each source scenario maps to exactly one non-backstop row (see the appendix). Static backstops add no scenarios and trace through the check they back. The scenarios were merged into crisp invariants by automation point and failure mode, across categories (positive, negative, boundary, failure/recovery, concurrency/idempotency, retention/audit, common failure, core). Automation points covered: Unfair, Deceptive, Abusive. Source common failures: Misleading disclosure, unfair fee. Thresholds, windows and deadlines are *configured* parameters, not asserted statutory values. No regulation or citation was added beyond the source sheet.

### Overlap with the locked neobank playbook (19 checks)

| This check | Neobank check | Strength | Why |
| --- | --- | --- | --- |
| UDAAP-UNF-01 | N-RWD-04 | related | fee once per item |
| UDAAP-UNF-51 | N-IDEMP-01 | related | unique-key dedupe on the write path |
| UDAAP-UNF-02 | N-ATOMIC | related | concurrent transactions do not manufacture overdraft fees |
| UDAAP-UNF-03 | N-RWD-04 | related | erroneous fee reversed |

`same` means the neobank check already enforces this invariant, so reuse it instead of re-implementing. `related` means the same defect class, but this check needs its own rule or preset.

### Review flags

- ⚑ **UDAAP-ABU-02**: needs an SME/counsel parameter matrix (source scenarios carry review status "+ SME input").
- ⚑ **UDAAP-ABU-51**: needs an SME/counsel parameter matrix (source scenarios carry review status "+ SME input").

## Appendix: traceability to source scenarios

| Check ID | Source scenario IDs | Categories merged |
| --- | --- | --- |
| UDAAP-UNF-01 | SC-UDAAP-001-02, SC-UDAAP-001-04, SC-UDAAP-001-14, SC-UDAAP-001-15, SC-UDAAP-001-13 | Common Failure, Concurrency/Idempotency, Core, Negative, Positive |
| UDAAP-UNF-51 | — (static backstop; traced via UDAAP-UNF-01) | — |
| UDAAP-UNF-02 | SC-UDAAP-001-16, SC-UDAAP-001-05 | Boundary/Edge, Concurrency/Idempotency |
| UDAAP-UNF-52 | — (static backstop; traced via UDAAP-UNF-02) | — |
| UDAAP-UNF-03 | SC-UDAAP-001-06 | Failure/Recovery |
| UDAAP-UNF-04 | SC-UDAAP-001-17 | Retention/Audit |
| UDAAP-DEC-01 | SC-UDAAP-001-07, SC-UDAAP-001-18, SC-UDAAP-001-21, SC-UDAAP-001-20, SC-UDAAP-001-19, SC-UDAAP-001-01 | Common Failure, Concurrency/Idempotency, Core, Failure/Recovery, Negative, Positive |
| UDAAP-DEC-02 | SC-UDAAP-001-08 | Boundary/Edge |
| UDAAP-DEC-03 | SC-UDAAP-001-09 | Retention/Audit |
| UDAAP-ABU-01 | SC-UDAAP-001-10 | Negative |
| UDAAP-ABU-02 | SC-UDAAP-001-11, SC-UDAAP-001-22, SC-UDAAP-001-23 | Boundary/Edge, Common Failure, Failure/Recovery |
| UDAAP-ABU-51 | — (static backstop; traced via UDAAP-ABU-02) | — |
| UDAAP-ABU-03 | SC-UDAAP-001-03, SC-UDAAP-001-12, SC-UDAAP-001-24 | Core, Positive, Retention/Audit |

# Helix review rules

Generated from `checks.json` (10 static and behavioural checks; manual/evidence items are not code-reviewable and are omitted). Severity is derived from the playbook priority (P1 -> MEDIUM); Category MM marks money-movement checks. Rule text is the source invariant, unchanged; it is AI-drafted and needs compliance review.

## Rule UDAAP-UNF-01: Only scheduled fees are charged, exactly once per triggering item (no repeat NSF/overdraft on re-...
Severity: MEDIUM
Category: MM
Scenario: unfair
Requirement: MUST
Invariant: Only scheduled fees are charged, exactly once per triggering item (no repeat NSF/overdraft on re-presentment, no duplicate under retries), with configured waivers honoured.

Source check `UDAAP-UNF-01` from `checks.json` (behavioural; deterministic: yes). Covers: Unfair, Abusive · unfair fee · UDAAP. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-CFPB-001.

## Rule UDAAP-UNF-51: Fee assessment is keyed by (triggering item, fee type) with a unique constraint
Severity: MEDIUM
Category: NON_MM
Scenario: unfair
Requirement: MUST
Invariant: Fee assessment is keyed by (triggering item, fee type) with a unique constraint; fee codes resolve only from the published schedule.

Source check `UDAAP-UNF-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: Unfair, Abusive · unfair fee · UDAAP. Backstop for UDAAP-UNF-01. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-CFPB-001.

## Rule UDAAP-UNF-02: Concurrent transactions follow the configured ordering policy and trigger no artificial overdraft...
Severity: MEDIUM
Category: MM
Scenario: unfair
Requirement: MUST
Invariant: Concurrent transactions follow the configured ordering policy and trigger no artificial overdraft fees; authorize-positive/settle-negative items follow the configured policy.

Source check `UDAAP-UNF-02` from `checks.json` (behavioural; deterministic: yes). Covers: Unfair · unfair fee · UDAAP. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-CFPB-001.

## Rule UDAAP-UNF-52: Transaction posting order follows the configured ordering policy constant
Severity: MEDIUM
Category: NON_MM
Scenario: unfair
Requirement: MUST
Invariant: Transaction posting order follows the configured ordering policy constant; no reorder-by-amount path.

Source check `UDAAP-UNF-52` from `checks.json` (static, static backstop; deterministic: yes). Covers: Unfair · unfair fee · UDAAP. Backstop for UDAAP-UNF-02. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-CFPB-001.

## Rule UDAAP-UNF-03: Fees caused by system error are auto-identified and reversed with customer notice
Severity: MEDIUM
Category: MM
Scenario: unfair
Requirement: MUST
Invariant: Fees caused by system error are auto-identified and reversed with customer notice.

Source check `UDAAP-UNF-03` from `checks.json` (behavioural; deterministic: yes). Covers: Unfair · unfair fee · UDAAP. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-CFPB-001.

## Rule UDAAP-DEC-01: Advertised rates/fees and claims (e.g
Severity: MEDIUM
Category: NON_MM
Scenario: deceptive
Requirement: MUST
Invariant: Advertised rates/fees and claims (e.g. 'no fees') match the product/fee configuration — mismatches block publish, including concurrent publishes and after config changes.

Source check `UDAAP-DEC-01` from `checks.json` (static; deterministic: yes). Covers: Deceptive · Misleading disclosure · UDAAP. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-CFPB-001.

## Rule UDAAP-DEC-02: Promotional expiry is disclosed and post-expiry terms apply exactly as disclosed
Severity: MEDIUM
Category: NON_MM
Scenario: deceptive
Requirement: MUST
Invariant: Promotional expiry is disclosed and post-expiry terms apply exactly as disclosed.

Source check `UDAAP-DEC-02` from `checks.json` (behavioural; deterministic: yes). Covers: Deceptive · Misleading disclosure · UDAAP. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-CFPB-001.

## Rule UDAAP-ABU-01: Material terms meet configured prominence rules in each flow
Severity: MEDIUM
Category: NON_MM
Scenario: abusive
Requirement: MUST
Invariant: Material terms meet configured prominence rules in each flow; violations block release.

Source check `UDAAP-ABU-01` from `checks.json` (static; deterministic: yes). Covers: Abusive · Misleading disclosure · UDAAP. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-CFPB-001.

## Rule UDAAP-ABU-02: Cancellation is available in the sign-up channel within the configured step count (SME-provided f...
Severity: MEDIUM
Category: NON_MM
Scenario: abusive
Requirement: MUST
Invariant: Cancellation is available in the sign-up channel within the configured step count (SME-provided friction limit) and is honoured even during an outage.

Source check `UDAAP-ABU-02` from `checks.json` (behavioural; deterministic: yes). Covers: Abusive · None · UDAAP. Flagged for SME input in the source; needs an approved parameter matrix. Review status in source: Drafted (AI) – needs compliance review + SME input.

Regulation references: RR-CFPB-001.

## Rule UDAAP-ABU-51: A cancellation route exists for every sign-up channel, and its flow step count ≤ the configured l...
Severity: MEDIUM
Category: NON_MM
Scenario: abusive
Requirement: MUST
Invariant: A cancellation route exists for every sign-up channel, and its flow step count ≤ the configured limit (SME-provided).

Source check `UDAAP-ABU-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: Abusive · None · UDAAP. Backstop for UDAAP-ABU-02. Flagged for SME input in the source; needs an approved parameter matrix. Review status in source: Drafted (AI) – needs compliance review + SME input.

Regulation references: RR-CFPB-001.
