---
helixPlaybookFormat: helix-playbook/0.1-proposal
playbookId: vigil-fca-handbook
title: "FCA Consumer Duty, Op Resilience & SMCR"
declaredVersion: 0.1.0
intent: draft
applicability:
  languages: [javascript, typescript]
  scenarios: [consumer-duty, smcr]
---
# Helix portable playbook — DRAFT manifest · FCA Consumer Duty, Op Resilience & SMCR

> **DRAFT — not LOCKED.** Proposed FCA Handbook (UK Regulation) playbook converted from Vigil skill `SK-FCA-001`: one runner, two layers, **4 harness checks (1 static, incl. 0 static backstops, + 3 behavioural)**, plus 5 manual/evidence items listed separately because neither layer can verify them. Every invariant, layer and determinism call is **AI-drafted (Helix) and needs compliance review**; 3 check(s) are **⚑ SME-flagged** and cannot gate until an SME/counsel supplies their parameter matrix. No detector or rule code exists yet. Before this manifest can be LOCKED, each row needs its detector/rule, a review, and a commit that adds the check alongside its row.

## Layers

- **static**: a repo-agnostic source scanner parameterised by a `VIGIL_FCA` preset (no app specifics in the detector). It reads source / SQL / config / IaC / git-diff, **fails CLOSED** on a match, and runs with **no adapter**, so it is the CI gate. *Static backstops* (IDs `-5x`) prove a supporting source invariant for a named behavioural check, the way N-CAP-01 / N-STATE-01 back neobank behaviour. They fire even when the adapter never drives that path. Backstops of ⚑ SME checks stay out of the gate.
- **behavioural**: a rule written once against the canonical `MoneySystem` interface (or a DRAFT extension surface in `adapters/`) and driven through the app adapter. Surfaces needed: **CustomerJourneySystem** (`adapters/customer-journey.ts`), **GovernanceSystem** (`adapters/governance.ts`). Every behavioural row reports NOT_EXERCISED until an adapter implements its surface. It returns **CHECKED only when it actually drove the guard's path**.
- **manual/evidence**: organisational process, live-infrastructure, statistical or retention evidence that no source scan or adapter-driven rule can prove. These are **outside the harness**, report `NOT_APPLICABLE` to it, and are tracked as evidence tasks, never as passes.

## Verdicts

`CHECKED` the path ran and the guard held · `FINDING` the guard was violated · `NOT_APPLICABLE` the invariant cannot apply here (incl. every manual/evidence item) · `NOT_EXERCISED` (glyph `????`) the adapter did not drive the path, so nothing is proven. NOT_EXERCISED is **surfaced distinctly and never counted as a pass** (no fake coverage). A ⚑ SME check with no approved parameter matrix reports `NOT_EXERCISED`, never `CHECKED`.

## How to run

- **Not runnable yet**: this draft defines invariants only (no detector/rule code). The intended shape mirrors the neobank playbook:
  - CI gate (adapter-free, blocks on any static FINDING): `run-static` with preset `VIGIL_FCA`.
  - Full combined table (static + behavioural via the adapter): `run-all`.
- Machine-readable rows: `checks.json` (same IDs; includes source-scenario traceability and neobank overlaps).

## The draft inventory: 1 static + 3 behavioural = 4 checks

| ID | Layer | Deterministic | Invariant (one line) | Covers (automation point · common failure · regulation) |
| --- | --- | --- | --- | --- |
| **FCA-CD-01** | static | yes | Key customer communications meet the configured readability threshold before publish, and communications reflect the current price under concurrent price changes. | Consumer duty · Missing test · FCA Handbook |
| **FCA-CD-02** | behavioural | yes | A vulnerability flag persists across channels and drives the configured adjusted treatment in every journey. | Consumer duty · Missing test · FCA Handbook |
| **FCA-CD-03** | behavioural | yes | Closure/cancel/switch journeys stay within the configured friction ratio of opening, with no hidden steps. | Consumer duty · Missing test · FCA Handbook |
| **FCA-SMCR-02** | behavioural | yes ⚑ SME | System permissions tied to certified roles are suspended when certification expires (controllable clock); overdue renewals are flagged. | SMCR · governance gap · FCA Handbook |

## Outside the harness: manual/evidence (5)

These items are not harness checks. Each reports `NOT_APPLICABLE` to the runner and needs an owner and evidence on a schedule.

| ID | Layer | Deterministic | Invariant (one line) | Covers (automation point · common failure · regulation) |
| --- | --- | --- | --- | --- |
| **FCA-CD-04** | manual/evidence | no (manual) | Outcome-monitoring metrics for board reporting are complete, reproducible and lineage-tracked; pipeline failure marks the dashboard stale. | Consumer duty · governance gap · FCA Handbook |
| **FCA-OR-01** | manual/evidence | no (manual) | Important business services recover within impact tolerance under single, concurrent and severe-but-plausible failures; over-tolerance triggers the breach workflow (chaos/drill). | Operational resilience · Missing test · FCA Handbook |
| **FCA-OR-02** | manual/evidence | no (manual) | The important-business-service dependency map is current; unmapped dependencies are flagged; self-assessment evidence retained. | Operational resilience · governance gap · FCA Handbook |
| **FCA-SMCR-01** | manual/evidence | no (manual) | Every prescribed responsibility in the SME-provided matrix maps to one current approved senior manager; role changes, leavers and concurrent edits flag reassignment with versions kept. | SMCR · governance gap · FCA Handbook |
| **FCA-SMCR-03** | manual/evidence | no (manual) | Statements of responsibilities are retained. | SMCR · general control (no source failure) · FCA Handbook |

### Determinism

Every harness row (static and behavioural) is drafted as deterministic. Static detectors, including backstops, are pure functions of the committed source/config/diff. Behavioural rules each run against a **fresh `reset()` MoneySystem** (no state leaks between rules), driven by a **controllable clock**; deadlines, windows, expiries and cadences are asserted by advancing that clock, never by wall-clock reads, and no randomness affects a verdict. External dependencies (vendors, registries, feeds) are faked inside the adapter, which is how fault-injection rows stay deterministic. Manual/evidence rows are not deterministic and are not gate checks. ⚑ SME rows are deterministic once parameters exist, but are excluded from the gate until then.

### Coverage note

Converted from 24 AI-drafted source scenarios of `SK-FCA-001`; each source scenario maps to exactly one non-backstop row (see the appendix). Static backstops add no scenarios and trace through the check they back. The scenarios were merged into crisp invariants by automation point and failure mode, across categories (positive, negative, boundary, failure/recovery, concurrency/idempotency, retention/audit, common failure, core). Automation points covered: Consumer duty, Operational resilience, SMCR. Source common failures: Missing test, governance gap. Thresholds, windows and deadlines are *configured* parameters, not asserted statutory values. No regulation or citation was added beyond the source sheet.

### Overlap with the locked neobank playbook (19 checks)

| This check | Neobank check | Strength | Why |
| --- | --- | --- | --- |
| FCA-SMCR-02 | N-STATE-01 | related | lapsed certification suspends permissions |

`same` means the neobank check already enforces this invariant, so reuse it instead of re-implementing. `related` means the same defect class, but this check needs its own rule or preset.

### Review flags

- ⚑ **FCA-SMCR-01**: needs an SME/counsel parameter matrix (source scenarios carry review status "+ SME input").
- ⚑ **FCA-SMCR-02**: needs an SME/counsel parameter matrix (source scenarios carry review status "+ SME input").
- ⚑ **FCA-SMCR-03**: needs an SME/counsel parameter matrix (source scenarios carry review status "+ SME input").
- **FCA-CD-02**: expert input noted in source feasibility: outcome metrics need SME definition.

## Appendix: traceability to source scenarios

| Check ID | Source scenario IDs | Categories merged |
| --- | --- | --- |
| FCA-CD-01 | SC-FCA-001-05, SC-FCA-001-15 | Boundary/Edge, Concurrency/Idempotency |
| FCA-CD-02 | SC-FCA-001-06, SC-FCA-001-16, SC-FCA-001-01 | Common Failure, Core, Positive |
| FCA-CD-03 | SC-FCA-001-04 | Negative |
| FCA-CD-04 | SC-FCA-001-07, SC-FCA-001-14 | Failure/Recovery, Retention/Audit |
| FCA-OR-01 | SC-FCA-001-02, SC-FCA-001-09, SC-FCA-001-10, SC-FCA-001-17, SC-FCA-001-19 | Boundary/Edge, Concurrency/Idempotency, Core, Failure/Recovery, Positive |
| FCA-OR-02 | SC-FCA-001-08, SC-FCA-001-18, SC-FCA-001-11 | Common Failure, Negative, Retention/Audit |
| FCA-SMCR-01 | SC-FCA-001-03, SC-FCA-001-20, SC-FCA-001-13, SC-FCA-001-21, SC-FCA-001-22 | Concurrency/Idempotency, Core, Failure/Recovery, Negative, Positive |
| FCA-SMCR-02 | SC-FCA-001-12, SC-FCA-001-24 | Boundary/Edge, Common Failure |
| FCA-SMCR-03 | SC-FCA-001-23 | Retention/Audit |

# Helix review rules

Generated from `checks.json` (4 static and behavioural checks; manual/evidence items are not code-reviewable and are omitted). Severity is derived from the playbook priority (P1 -> MEDIUM); Category MM marks money-movement checks. Rule text is the source invariant, unchanged; it is AI-drafted and needs compliance review.

## Rule FCA-CD-01: Key customer communications meet the configured readability threshold before publish, and communi...
Severity: MEDIUM
Category: NON_MM
Scenario: consumer-duty
Requirement: MUST
Invariant: Key customer communications meet the configured readability threshold before publish, and communications reflect the current price under concurrent price changes.

Source check `FCA-CD-01` from `checks.json` (static; deterministic: yes). Covers: Consumer duty · Missing test · FCA Handbook. Review status in source: Drafted (AI) – needs compliance review.

## Rule FCA-CD-02: A vulnerability flag persists across channels and drives the configured adjusted treatment in eve...
Severity: MEDIUM
Category: NON_MM
Scenario: consumer-duty
Requirement: MUST
Invariant: A vulnerability flag persists across channels and drives the configured adjusted treatment in every journey.

Source check `FCA-CD-02` from `checks.json` (behavioural; deterministic: yes). Covers: Consumer duty · Missing test · FCA Handbook. Review status in source: Drafted (AI) – needs compliance review.

## Rule FCA-CD-03: Closure/cancel/switch journeys stay within the configured friction ratio of opening, with no hidd...
Severity: MEDIUM
Category: NON_MM
Scenario: consumer-duty
Requirement: MUST
Invariant: Closure/cancel/switch journeys stay within the configured friction ratio of opening, with no hidden steps.

Source check `FCA-CD-03` from `checks.json` (behavioural; deterministic: yes). Covers: Consumer duty · Missing test · FCA Handbook. Review status in source: Drafted (AI) – needs compliance review.

## Rule FCA-SMCR-02: System permissions tied to certified roles are suspended when certification expires (controllable...
Severity: MEDIUM
Category: NON_MM
Scenario: smcr
Requirement: MUST
Invariant: System permissions tied to certified roles are suspended when certification expires (controllable clock); overdue renewals are flagged.

Source check `FCA-SMCR-02` from `checks.json` (behavioural; deterministic: yes). Covers: SMCR · governance gap · FCA Handbook. Flagged for SME input in the source; needs an approved parameter matrix. Review status in source: Drafted (AI) – needs compliance review + SME input.
