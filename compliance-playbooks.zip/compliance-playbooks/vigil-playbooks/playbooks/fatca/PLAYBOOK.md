---
helixPlaybookFormat: helix-playbook/0.1-proposal
playbookId: vigil-fatca
title: "FATCA Classification, Withholding & Reporting"
declaredVersion: 0.1.0
intent: draft
applicability:
  languages: [javascript, typescript]
  scenarios: [due-diligence, withholding, foreign-account-reporting]
---
# Helix portable playbook — DRAFT manifest · FATCA Classification, Withholding & Reporting

> **DRAFT — not LOCKED.** Proposed FATCA (Tax) playbook converted from Vigil skill `SK-FATCA-001`: one runner, two layers, **7 harness checks (1 static, incl. 1 static backstops, + 6 behavioural)**, plus 2 manual/evidence items listed separately because neither layer can verify them. Every invariant, layer and determinism call is **AI-drafted (Helix) and needs compliance review**. No detector or rule code exists yet. Before this manifest can be LOCKED, each row needs its detector/rule, a review, and a commit that adds the check alongside its row.

## Layers

- **static**: a repo-agnostic source scanner parameterised by a `VIGIL_FATCA` preset (no app specifics in the detector). It reads source / SQL / config / IaC / git-diff, **fails CLOSED** on a match, and runs with **no adapter**, so it is the CI gate. *Static backstops* (IDs `-5x`) prove a supporting source invariant for a named behavioural check, the way N-CAP-01 / N-STATE-01 back neobank behaviour. They fire even when the adapter never drives that path. Backstops of ⚑ SME checks stay out of the gate.
- **behavioural**: a rule written once against the canonical `MoneySystem` interface (or a DRAFT extension surface in `adapters/`) and driven through the app adapter. Surfaces needed: **OnboardingSystem** (`adapters/onboarding.ts`), **TaxReportingSystem** (`adapters/tax-reporting.ts`). Every behavioural row reports NOT_EXERCISED until an adapter implements its surface. It returns **CHECKED only when it actually drove the guard's path**.
- **manual/evidence**: organisational process, live-infrastructure, statistical or retention evidence that no source scan or adapter-driven rule can prove. These are **outside the harness**, report `NOT_APPLICABLE` to it, and are tracked as evidence tasks, never as passes.

## Verdicts

`CHECKED` the path ran and the guard held · `FINDING` the guard was violated · `NOT_APPLICABLE` the invariant cannot apply here (incl. every manual/evidence item) · `NOT_EXERCISED` (glyph `????`) the adapter did not drive the path, so nothing is proven. NOT_EXERCISED is **surfaced distinctly and never counted as a pass** (no fake coverage). A ⚑ SME check with no approved parameter matrix reports `NOT_EXERCISED`, never `CHECKED`.

## How to run

- **Not runnable yet**: this draft defines invariants only (no detector/rule code). The intended shape mirrors the neobank playbook:
  - CI gate (adapter-free, blocks on any static FINDING): `run-static` with preset `VIGIL_FATCA`.
  - Full combined table (static + behavioural via the adapter): `run-all`.
- Machine-readable rows: `checks.json` (same IDs; includes source-scenario traceability and neobank overlaps).

## The draft inventory: 1 static + 6 behavioural = 7 checks

| ID | Layer | Deterministic | Invariant (one line) | Covers (automation point · common failure · regulation) |
| --- | --- | --- | --- | --- |
| **FATCA-DD-01** | behavioural | yes | Each account is classified from validated onboarding self-certification; indicia conflicts trigger a documentation request within the configured time; a validation outage queues accounts with no default classification. | Due diligence · Missing classification · FATCA |
| **FATCA-DD-02** | behavioural | yes | A change in circumstances reclassifies pending documentation (restarting any open review) and documentation expiry triggers renewal at the configured date. | Due diligence · Missing classification · FATCA |
| **FATCA-WH-01** | behavioural | yes | Withholding applies only where the classification requires it at the configured rate — never to documented compliant accounts — switching exactly at documentation expiry, consistently across concurrent payments. | Withholding · wrong withholding · FATCA |
| **FATCA-WH-51** | static | yes | Withholding decisions read the classification snapshot keyed by payment; documented-compliant status short-circuits withholding. | backstop for FATCA-WH-01 · Withholding · wrong withholding · FATCA |
| **FATCA-WH-02** | behavioural | yes | Withheld amounts reconcile to deposits per period; retroactive documentation refunds update ledger and reports. | Withholding · wrong withholding · FATCA |
| **FATCA-RPT-01** | behavioural | yes | The report includes every reportable account (at the configured balance threshold) with required data and balances, excludes non-reportable ones, and regenerates identically. | Foreign account reporting · Missing classification · FATCA |
| **FATCA-RPT-02** | behavioural | yes | Schema validation errors block submission; filed reports are retained. | Foreign account reporting · general control (no source failure) · FATCA |

## Outside the harness: manual/evidence (2)

These items are not harness checks. Each reports `NOT_APPLICABLE` to the runner and needs an owner and evidence on a schedule.

| ID | Layer | Deterministic | Invariant (one line) | Covers (automation point · common failure · regulation) |
| --- | --- | --- | --- | --- |
| **FATCA-DD-03** | manual/evidence | no (manual) | Due-diligence documentation is retained. | Due diligence · general control (no source failure) · FATCA |
| **FATCA-WH-03** | manual/evidence | no (manual) | Withholding records are retained. | Withholding · general control (no source failure) · FATCA |

### Determinism

Every harness row (static and behavioural) is drafted as deterministic. Static detectors, including backstops, are pure functions of the committed source/config/diff. Behavioural rules each run against a **fresh `reset()` MoneySystem** (no state leaks between rules), driven by a **controllable clock**; deadlines, windows, expiries and cadences are asserted by advancing that clock, never by wall-clock reads, and no randomness affects a verdict. External dependencies (vendors, registries, feeds) are faked inside the adapter, which is how fault-injection rows stay deterministic. Manual/evidence rows are not deterministic and are not gate checks.

### Coverage note

Converted from 24 AI-drafted source scenarios of `SK-FATCA-001`; each source scenario maps to exactly one non-backstop row (see the appendix). Static backstops add no scenarios and trace through the check they back. The scenarios were merged into crisp invariants by automation point and failure mode, across categories (positive, negative, boundary, failure/recovery, concurrency/idempotency, retention/audit, common failure, core). Automation points covered: Foreign account reporting, Withholding, Due diligence. Source common failures: Missing classification, wrong withholding. Thresholds, windows and deadlines are *configured* parameters, not asserted statutory values. No regulation or citation was added beyond the source sheet.

### Overlap with the locked neobank playbook (19 checks)

| This check | Neobank check | Strength | Why |
| --- | --- | --- | --- |
| FATCA-WH-02 | LEDGER-CONSERVE | related | withheld = deposited |

`same` means the neobank check already enforces this invariant, so reuse it instead of re-implementing. `related` means the same defect class, but this check needs its own rule or preset.

### Review flags

- No SME-flagged rows. All rows still need compliance review.

## Appendix: traceability to source scenarios

| Check ID | Source scenario IDs | Categories merged |
| --- | --- | --- |
| FATCA-DD-01 | SC-FATCA-001-01, SC-FATCA-001-21, SC-FATCA-001-04, SC-FATCA-001-22 | Common Failure, Core, Failure/Recovery, Positive |
| FATCA-DD-02 | SC-FATCA-001-05, SC-FATCA-001-23, SC-FATCA-001-06 | Boundary/Edge, Concurrency/Idempotency, Negative |
| FATCA-DD-03 | SC-FATCA-001-24 | Retention/Audit |
| FATCA-WH-01 | SC-FATCA-001-02, SC-FATCA-001-07, SC-FATCA-001-16, SC-FATCA-001-17, SC-FATCA-001-18 | Boundary/Edge, Concurrency/Idempotency, Core, Negative, Positive |
| FATCA-WH-51 | — (static backstop; traced via FATCA-WH-01) | — |
| FATCA-WH-02 | SC-FATCA-001-20, SC-FATCA-001-08 | Common Failure, Failure/Recovery |
| FATCA-WH-03 | SC-FATCA-001-19 | Retention/Audit |
| FATCA-RPT-01 | SC-FATCA-001-03, SC-FATCA-001-09, SC-FATCA-001-11, SC-FATCA-001-12, SC-FATCA-001-13, SC-FATCA-001-15 | Boundary/Edge, Common Failure, Concurrency/Idempotency, Core, Negative, Positive |
| FATCA-RPT-02 | SC-FATCA-001-10, SC-FATCA-001-14 | Failure/Recovery, Retention/Audit |

# Helix review rules

Generated from `checks.json` (7 static and behavioural checks; manual/evidence items are not code-reviewable and are omitted). Severity is derived from the playbook priority (P2 -> LOW); Category MM marks money-movement checks. Rule text is the source invariant, unchanged; it is AI-drafted and needs compliance review.

## Rule FATCA-DD-01: Each account is classified from validated onboarding self-certification
Severity: LOW
Category: NON_MM
Scenario: due-diligence
Requirement: MUST
Invariant: Each account is classified from validated onboarding self-certification; indicia conflicts trigger a documentation request within the configured time; a validation outage queues accounts with no default classification.

Source check `FATCA-DD-01` from `checks.json` (behavioural; deterministic: yes). Covers: Due diligence · Missing classification · FATCA. Review status in source: Drafted (AI) – needs compliance review.

## Rule FATCA-DD-02: A change in circumstances reclassifies pending documentation (restarting any open review) and doc...
Severity: LOW
Category: NON_MM
Scenario: due-diligence
Requirement: MUST
Invariant: A change in circumstances reclassifies pending documentation (restarting any open review) and documentation expiry triggers renewal at the configured date.

Source check `FATCA-DD-02` from `checks.json` (behavioural; deterministic: yes). Covers: Due diligence · Missing classification · FATCA. Review status in source: Drafted (AI) – needs compliance review.

## Rule FATCA-WH-01: Withholding applies only where the classification requires it at the configured rate — never to d...
Severity: LOW
Category: NON_MM
Scenario: withholding
Requirement: MUST
Invariant: Withholding applies only where the classification requires it at the configured rate — never to documented compliant accounts — switching exactly at documentation expiry, consistently across concurrent payments.

Source check `FATCA-WH-01` from `checks.json` (behavioural; deterministic: yes). Covers: Withholding · wrong withholding · FATCA. Review status in source: Drafted (AI) – needs compliance review.

## Rule FATCA-WH-51: Withholding decisions read the classification snapshot keyed by payment
Severity: LOW
Category: NON_MM
Scenario: withholding
Requirement: MUST
Invariant: Withholding decisions read the classification snapshot keyed by payment; documented-compliant status short-circuits withholding.

Source check `FATCA-WH-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: Withholding · wrong withholding · FATCA. Backstop for FATCA-WH-01. Review status in source: Drafted (AI) – needs compliance review.

## Rule FATCA-WH-02: Withheld amounts reconcile to deposits per period
Severity: LOW
Category: NON_MM
Scenario: withholding
Requirement: MUST
Invariant: Withheld amounts reconcile to deposits per period; retroactive documentation refunds update ledger and reports.

Source check `FATCA-WH-02` from `checks.json` (behavioural; deterministic: yes). Covers: Withholding · wrong withholding · FATCA. Review status in source: Drafted (AI) – needs compliance review.

## Rule FATCA-RPT-01: The report includes every reportable account (at the configured balance threshold) with required...
Severity: LOW
Category: NON_MM
Scenario: foreign-account-reporting
Requirement: MUST
Invariant: The report includes every reportable account (at the configured balance threshold) with required data and balances, excludes non-reportable ones, and regenerates identically.

Source check `FATCA-RPT-01` from `checks.json` (behavioural; deterministic: yes). Covers: Foreign account reporting · Missing classification · FATCA. Review status in source: Drafted (AI) – needs compliance review.

## Rule FATCA-RPT-02: Schema validation errors block submission
Severity: LOW
Category: NON_MM
Scenario: foreign-account-reporting
Requirement: MUST
Invariant: Schema validation errors block submission; filed reports are retained.

Source check `FATCA-RPT-02` from `checks.json` (behavioural; deterministic: yes). Covers: Foreign account reporting · None · FATCA. Review status in source: Drafted (AI) – needs compliance review.
