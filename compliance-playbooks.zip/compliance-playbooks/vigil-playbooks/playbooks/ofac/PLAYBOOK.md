---
helixPlaybookFormat: helix-playbook/0.1-proposal
playbookId: vigil-ofac
title: "OFAC Sanctions Screening & Blocking"
declaredVersion: 0.1.0
intent: draft
applicability:
  languages: [javascript, typescript]
  scenarios: [sanctions-screening, blocked-property, reporting]
---
# Helix portable playbook — DRAFT manifest · OFAC Sanctions Screening & Blocking

> **DRAFT — not LOCKED.** Proposed OFAC (Crypto Regulation) playbook converted from Vigil skill `SK-OFAC-001`: one runner, two layers, **16 harness checks (5 static, incl. 4 static backstops, + 11 behavioural)**, plus 3 manual/evidence items listed separately because neither layer can verify them. Every invariant, layer and determinism call is **AI-drafted (Helix) and needs compliance review**. No detector or rule code exists yet. Before this manifest can be LOCKED, each row needs its detector/rule, a review, and a commit that adds the check alongside its row.

## Layers

- **static**: a repo-agnostic source scanner parameterised by a `VIGIL_OFAC` preset (no app specifics in the detector). It reads source / SQL / config / IaC / git-diff, **fails CLOSED** on a match, and runs with **no adapter**, so it is the CI gate. *Static backstops* (IDs `-5x`) prove a supporting source invariant for a named behavioural check, the way N-CAP-01 / N-STATE-01 back neobank behaviour. They fire even when the adapter never drives that path. Backstops of ⚑ SME checks stay out of the gate.
- **behavioural**: a rule written once against the canonical `MoneySystem` interface (or a DRAFT extension surface in `adapters/`) and driven through the app adapter. Surfaces needed: **ScreeningSystem** (`adapters/screening.ts`). Every behavioural row reports NOT_EXERCISED until an adapter implements its surface. It returns **CHECKED only when it actually drove the guard's path**.
- **manual/evidence**: organisational process, live-infrastructure, statistical or retention evidence that no source scan or adapter-driven rule can prove. These are **outside the harness**, report `NOT_APPLICABLE` to it, and are tracked as evidence tasks, never as passes.

## Verdicts

`CHECKED` the path ran and the guard held · `FINDING` the guard was violated · `NOT_APPLICABLE` the invariant cannot apply here (incl. every manual/evidence item) · `NOT_EXERCISED` (glyph `????`) the adapter did not drive the path, so nothing is proven. NOT_EXERCISED is **surfaced distinctly and never counted as a pass** (no fake coverage). A ⚑ SME check with no approved parameter matrix reports `NOT_EXERCISED`, never `CHECKED`.

## How to run

- **Not runnable yet**: this draft defines invariants only (no detector/rule code). The intended shape mirrors the neobank playbook:
  - CI gate (adapter-free, blocks on any static FINDING): `run-static` with preset `VIGIL_OFAC`.
  - Full combined table (static + behavioural via the adapter): `run-all`.
- Machine-readable rows: `checks.json` (same IDs; includes source-scenario traceability and neobank overlaps).

## The draft inventory: 5 static + 11 behavioural = 16 checks

| ID | Layer | Deterministic | Invariant (one line) | Covers (automation point · common failure · regulation) |
| --- | --- | --- | --- | --- |
| **OFAC-SCR-01** | static | yes | Every money-out/payout rail and onboarding path invokes sanctions screening before release — a new rail without the screening hook fails CI. | Sanctions screening · Missed screening · OFAC |
| **OFAC-SCR-02** | behavioural | yes | A true hit on any party or free-text field (incl. sanctioned wallet addresses and listed jurisdictions) blocks the transaction and opens a case; a non-match releases without delay. | Sanctions screening · Missed screening · OFAC |
| **OFAC-SCR-03** | behavioural | yes | Screening fails closed: on outage/timeout no money movement or onboarding completes without a result; corrupt/partial list files are rejected and the last good list kept. | Sanctions screening · Missed screening · OFAC |
| **OFAC-SCR-51** | static | yes | List ingestion validates checksum/record count before swapping the active list; screening errors hold, never release. | backstop for OFAC-SCR-03 · Sanctions screening · Missed screening · OFAC |
| **OFAC-SCR-04** | behavioural | yes | List updates apply within the configured window, with list version recorded per decision, and a release-time re-check catches hits added during in-flight payments. | Sanctions screening · Missed screening · OFAC |
| **OFAC-SCR-05** | behavioural | yes | Alerts fire at/above the configured match threshold only; clearance requires rationale and reviewer and allow-list entries are re-screened on list change. | Sanctions screening · Missed screening · OFAC |
| **OFAC-BLK-01** | behavioural | yes | Blocked funds sit in segregated blocked status with no outbound movement by any path — including automated jobs — and the ledger stays balanced. | Blocked property · improper blocking · OFAC |
| **OFAC-BLK-51** | static | yes | Every outbound money path and scheduled job checks the blocked flag on the source account inside its transaction. | backstop for OFAC-BLK-01 · Blocked property · improper blocking · OFAC |
| **OFAC-BLK-02** | behavioural | yes | Concurrent withdrawals on a blocked account are all rejected. | Blocked property · improper blocking · OFAC |
| **OFAC-BLK-03** | behavioural | yes | Unblock succeeds only with a recorded authorization and dual approval. | Blocked property · improper blocking · OFAC |
| **OFAC-BLK-52** | static | yes | The unblock handler requires an authorization record ID and two distinct approver IDs. | backstop for OFAC-BLK-03 · Blocked property · improper blocking · OFAC |
| **OFAC-BLK-04** | behavioural | yes | Entities owned at/above the configured aggregate threshold by blocked persons are treated as blocked; joint accounts follow the configured blocked-interest policy (needs SME/counsel policy). | Blocked property · improper blocking · OFAC |
| **OFAC-REP-01** | behavioural | yes | Each blocking or reject event creates exactly one report task with required data before the configured deadline; cleared false positives create none; rejected transactions are not frozen. | Reporting · general control (no source failure) · OFAC |
| **OFAC-REP-02** | behavioural | yes | Report values equal case and ledger data; the blocked-property inventory lists every held item and totals equal the ledger. | Reporting · general control (no source failure) · OFAC |
| **OFAC-REP-03** | behavioural | yes | A report is not marked submitted until confirmed and retries never duplicate a submission. | Reporting · general control (no source failure) · OFAC |
| **OFAC-REP-51** | static | yes | Report submission marks 'submitted' only on confirmed acknowledgement, with a unique submission key per blocking event. | backstop for OFAC-REP-03 · Reporting · general control (no source failure) · OFAC |

## Outside the harness: manual/evidence (3)

These items are not harness checks. Each reports `NOT_APPLICABLE` to the runner and needs an owner and evidence on a schedule.

| ID | Layer | Deterministic | Invariant (one line) | Covers (automation point · common failure · regulation) |
| --- | --- | --- | --- | --- |
| **OFAC-SCR-06** | manual/evidence | no (manual) | Fuzzy-match recall on known name variants meets the configured target (re-run on threshold change); screening decisions are retained with input, list version, score and reviewer. | Sanctions screening · Missed screening · OFAC |
| **OFAC-BLK-05** | manual/evidence | no (manual) | Blocked-property records are retained for the configured period. | Blocked property · general control (no source failure) · OFAC |
| **OFAC-REP-04** | manual/evidence | no (manual) | Submitted reports are retained. | Reporting · general control (no source failure) · OFAC |

### Determinism

Every harness row (static and behavioural) is drafted as deterministic. Static detectors, including backstops, are pure functions of the committed source/config/diff. Behavioural rules each run against a **fresh `reset()` MoneySystem** (no state leaks between rules), driven by a **controllable clock**; deadlines, windows, expiries and cadences are asserted by advancing that clock, never by wall-clock reads, and no randomness affects a verdict. External dependencies (vendors, registries, feeds) are faked inside the adapter, which is how fault-injection rows stay deterministic. Manual/evidence rows are not deterministic and are not gate checks.

### Coverage note

Converted from 34 AI-drafted source scenarios of `SK-OFAC-001`; each source scenario maps to exactly one non-backstop row (see the appendix). Static backstops add no scenarios and trace through the check they back. The scenarios were merged into crisp invariants by automation point and failure mode, across categories (positive, negative, boundary, failure/recovery, concurrency/idempotency, retention/audit, common failure, core). Automation points covered: Sanctions screening, Blocked property, Reporting. Source common failures: Missed screening, improper blocking. Thresholds, windows and deadlines are *configured* parameters, not asserted statutory values. No regulation or citation was added beyond the source sheet.

### Overlap with the locked neobank playbook (19 checks)

| This check | Neobank check | Strength | Why |
| --- | --- | --- | --- |
| OFAC-SCR-01 | N-SCREEN-02 | related | every money-out rail invokes screening |
| OFAC-SCR-02 | PARTY-SCREEN | related | true hit blocks the transaction |
| OFAC-BLK-01 | LEDGER-CONSERVE | related | blocked funds segregated, ledger balanced |
| OFAC-BLK-51 | N-STATE-01 | related | blocked flag re-read inside txn |
| OFAC-BLK-02 | N-ATOMIC | related | competing withdrawals on blocked account all refused |
| OFAC-BLK-04 | N-SCREEN-02 | related | ownership-based blocking of related parties |
| OFAC-REP-02 | LEDGER-CONSERVE | related | report totals = ledger |
| OFAC-REP-03 | N-IDEMP-01 | related | no duplicate submission |

`same` means the neobank check already enforces this invariant, so reuse it instead of re-implementing. `related` means the same defect class, but this check needs its own rule or preset.

### Review flags

- **OFAC-BLK-04**: expert input noted in source feasibility: policy needs counsel input.

## Appendix: traceability to source scenarios

| Check ID | Source scenario IDs | Categories merged |
| --- | --- | --- |
| OFAC-SCR-01 | SC-OFAC-001-16, SC-OFAC-001-01 | Common Failure, Core |
| OFAC-SCR-02 | DR-OFAC-001-02, DR-OFAC-001-03, DR-OFAC-001-08, SC-OFAC-001-14, SC-OFAC-001-15 | Core, Negative, Positive |
| OFAC-SCR-03 | DR-OFAC-001-07, SC-OFAC-001-05 | Core, Failure/Recovery |
| OFAC-SCR-51 | — (static backstop; traced via OFAC-SCR-03) | — |
| OFAC-SCR-04 | SC-OFAC-001-04, SC-OFAC-001-06 | Boundary/Edge, Concurrency/Idempotency |
| OFAC-SCR-05 | SC-OFAC-001-07, DR-OFAC-001-05 | Boundary/Edge, Core |
| OFAC-SCR-06 | DR-OFAC-001-01, SC-OFAC-001-08 | Core, Retention/Audit |
| OFAC-BLK-01 | SC-OFAC-001-02, SC-OFAC-001-17, SC-OFAC-001-09 | Common Failure, Core, Positive |
| OFAC-BLK-51 | — (static backstop; traced via OFAC-BLK-01) | — |
| OFAC-BLK-02 | SC-OFAC-001-19 | Concurrency/Idempotency |
| OFAC-BLK-03 | SC-OFAC-001-10, SC-OFAC-001-18 | Failure/Recovery, Negative |
| OFAC-BLK-52 | — (static backstop; traced via OFAC-BLK-03) | — |
| OFAC-BLK-04 | DR-OFAC-001-04, SC-OFAC-001-11 | Boundary/Edge, Core |
| OFAC-BLK-05 | SC-OFAC-001-20 | Retention/Audit |
| OFAC-REP-01 | SC-OFAC-001-03, SC-OFAC-001-23, SC-OFAC-001-21, SC-OFAC-001-22, DR-OFAC-001-06 | Boundary/Edge, Concurrency/Idempotency, Core, Negative |
| OFAC-REP-02 | SC-OFAC-001-12, DR-OFAC-001-09, SC-OFAC-001-25 | Common Failure, Core, Positive |
| OFAC-REP-03 | SC-OFAC-001-13 | Failure/Recovery |
| OFAC-REP-51 | — (static backstop; traced via OFAC-REP-03) | — |
| OFAC-REP-04 | SC-OFAC-001-24 | Retention/Audit |

# Helix review rules

Generated from `checks.json` (16 static and behavioural checks; manual/evidence items are not code-reviewable and are omitted). Severity is derived from the playbook priority (P0 -> HIGH); Category MM marks money-movement checks. Rule text is the source invariant, unchanged; it is AI-drafted and needs compliance review.

## Rule OFAC-SCR-01: Every money-out/payout rail and onboarding path invokes sanctions screening before release — a ne...
Severity: HIGH
Category: MM
Scenario: sanctions-screening
Requirement: MUST
Invariant: Every money-out/payout rail and onboarding path invokes sanctions screening before release — a new rail without the screening hook fails CI.

Source check `OFAC-SCR-01` from `checks.json` (static; deterministic: yes). Covers: Sanctions screening · Missed screening · OFAC. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-OFAC-001.

## Rule OFAC-SCR-02: A true hit on any party or free-text field (incl
Severity: HIGH
Category: MM
Scenario: sanctions-screening
Requirement: MUST
Invariant: A true hit on any party or free-text field (incl. sanctioned wallet addresses and listed jurisdictions) blocks the transaction and opens a case; a non-match releases without delay.

Source check `OFAC-SCR-02` from `checks.json` (behavioural; deterministic: yes). Covers: Sanctions screening · Missed screening · OFAC. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-OFAC-001, RR-OFAC-005.

## Rule OFAC-SCR-03: Screening fails closed
Severity: HIGH
Category: MM
Scenario: sanctions-screening
Requirement: MUST
Invariant: Screening fails closed: on outage/timeout no money movement or onboarding completes without a result; corrupt/partial list files are rejected and the last good list kept.

Source check `OFAC-SCR-03` from `checks.json` (behavioural; deterministic: yes). Covers: Sanctions screening · Missed screening · OFAC. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-OFAC-001.

## Rule OFAC-SCR-51: List ingestion validates checksum/record count before swapping the active list
Severity: HIGH
Category: MM
Scenario: sanctions-screening
Requirement: MUST
Invariant: List ingestion validates checksum/record count before swapping the active list; screening errors hold, never release.

Source check `OFAC-SCR-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: Sanctions screening · Missed screening · OFAC. Backstop for OFAC-SCR-03. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-OFAC-001.

## Rule OFAC-SCR-04: List updates apply within the configured window, with list version recorded per decision, and a r...
Severity: HIGH
Category: MM
Scenario: sanctions-screening
Requirement: MUST
Invariant: List updates apply within the configured window, with list version recorded per decision, and a release-time re-check catches hits added during in-flight payments.

Source check `OFAC-SCR-04` from `checks.json` (behavioural; deterministic: yes). Covers: Sanctions screening · Missed screening · OFAC. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-OFAC-001.

## Rule OFAC-SCR-05: Alerts fire at/above the configured match threshold only
Severity: HIGH
Category: MM
Scenario: sanctions-screening
Requirement: MUST
Invariant: Alerts fire at/above the configured match threshold only; clearance requires rationale and reviewer and allow-list entries are re-screened on list change.

Source check `OFAC-SCR-05` from `checks.json` (behavioural; deterministic: yes). Covers: Sanctions screening · Missed screening · OFAC. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-OFAC-001.

## Rule OFAC-BLK-01: Blocked funds sit in segregated blocked status with no outbound movement by any path — including...
Severity: HIGH
Category: MM
Scenario: blocked-property
Requirement: MUST
Invariant: Blocked funds sit in segregated blocked status with no outbound movement by any path — including automated jobs — and the ledger stays balanced.

Source check `OFAC-BLK-01` from `checks.json` (behavioural; deterministic: yes). Covers: Blocked property · improper blocking · OFAC. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-OFAC-001.

## Rule OFAC-BLK-51: Every outbound money path and scheduled job checks the blocked flag on the source account inside...
Severity: HIGH
Category: MM
Scenario: blocked-property
Requirement: MUST
Invariant: Every outbound money path and scheduled job checks the blocked flag on the source account inside its transaction.

Source check `OFAC-BLK-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: Blocked property · improper blocking · OFAC. Backstop for OFAC-BLK-01. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-OFAC-001.

## Rule OFAC-BLK-02: Concurrent withdrawals on a blocked account are all rejected
Severity: HIGH
Category: MM
Scenario: blocked-property
Requirement: MUST
Invariant: Concurrent withdrawals on a blocked account are all rejected.

Source check `OFAC-BLK-02` from `checks.json` (behavioural; deterministic: yes). Covers: Blocked property · improper blocking · OFAC. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-OFAC-001.

## Rule OFAC-BLK-03: Unblock succeeds only with a recorded authorization and dual approval
Severity: HIGH
Category: MM
Scenario: blocked-property
Requirement: MUST
Invariant: Unblock succeeds only with a recorded authorization and dual approval.

Source check `OFAC-BLK-03` from `checks.json` (behavioural; deterministic: yes). Covers: Blocked property · improper blocking · OFAC. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-OFAC-001.

## Rule OFAC-BLK-52: The unblock handler requires an authorization record ID and two distinct approver IDs
Severity: HIGH
Category: MM
Scenario: blocked-property
Requirement: MUST
Invariant: The unblock handler requires an authorization record ID and two distinct approver IDs.

Source check `OFAC-BLK-52` from `checks.json` (static, static backstop; deterministic: yes). Covers: Blocked property · improper blocking · OFAC. Backstop for OFAC-BLK-03. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-OFAC-001.

## Rule OFAC-BLK-04: Entities owned at/above the configured aggregate threshold by blocked persons are treated as blocked
Severity: HIGH
Category: MM
Scenario: blocked-property
Requirement: MUST
Invariant: Entities owned at/above the configured aggregate threshold by blocked persons are treated as blocked; joint accounts follow the configured blocked-interest policy (needs SME/counsel policy).

Source check `OFAC-BLK-04` from `checks.json` (behavioural; deterministic: yes). Covers: Blocked property · improper blocking · OFAC. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-OFAC-001.

## Rule OFAC-REP-01: Each blocking or reject event creates exactly one report task with required data before the confi...
Severity: HIGH
Category: MM
Scenario: reporting
Requirement: MUST
Invariant: Each blocking or reject event creates exactly one report task with required data before the configured deadline; cleared false positives create none; rejected transactions are not frozen.

Source check `OFAC-REP-01` from `checks.json` (behavioural; deterministic: yes). Covers: Reporting · None · OFAC. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-OFAC-002, RR-OFAC-003.

## Rule OFAC-REP-02: Report values equal case and ledger data
Severity: HIGH
Category: MM
Scenario: reporting
Requirement: MUST
Invariant: Report values equal case and ledger data; the blocked-property inventory lists every held item and totals equal the ledger.

Source check `OFAC-REP-02` from `checks.json` (behavioural; deterministic: yes). Covers: Reporting · None · OFAC. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-OFAC-002.

## Rule OFAC-REP-03: A report is not marked submitted until confirmed and retries never duplicate a submission
Severity: HIGH
Category: MM
Scenario: reporting
Requirement: MUST
Invariant: A report is not marked submitted until confirmed and retries never duplicate a submission.

Source check `OFAC-REP-03` from `checks.json` (behavioural; deterministic: yes). Covers: Reporting · None · OFAC. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-OFAC-002, RR-OFAC-003.

## Rule OFAC-REP-51: Report submission marks 'submitted' only on confirmed acknowledgement, with a unique submission k...
Severity: HIGH
Category: MM
Scenario: reporting
Requirement: MUST
Invariant: Report submission marks 'submitted' only on confirmed acknowledgement, with a unique submission key per blocking event.

Source check `OFAC-REP-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: Reporting · None · OFAC. Backstop for OFAC-REP-03. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-OFAC-002, RR-OFAC-003.
