---
helixPlaybookFormat: helix-playbook/0.1-proposal
playbookId: vigil-sox
title: "SOX Financial Controls & Ledger Integrity"
declaredVersion: 0.1.0
intent: draft
applicability:
  languages: [javascript, typescript]
  scenarios: [internal-controls, audit-trail, data-integrity]
---
# Helix portable playbook — DRAFT manifest · SOX Financial Controls & Ledger Integrity

> **DRAFT — not LOCKED.** Proposed SOX (Financial Reporting) playbook converted from Vigil skill `SK-SOX-001`: one runner, two layers, **23 harness checks (9 static, incl. 7 static backstops, + 14 behavioural)**, plus 3 manual/evidence items listed separately because neither layer can verify them. Every invariant, layer and determinism call is **AI-drafted (Helix) and needs compliance review**. No detector or rule code exists yet. Before this manifest can be LOCKED, each row needs its detector/rule, a review, and a commit that adds the check alongside its row.

## Layers

- **static**: a repo-agnostic source scanner parameterised by a `VIGIL_SOX` preset (no app specifics in the detector). It reads source / SQL / config / IaC / git-diff, **fails CLOSED** on a match, and runs with **no adapter**, so it is the CI gate. *Static backstops* (IDs `-5x`) prove a supporting source invariant for a named behavioural check, the way N-CAP-01 / N-STATE-01 back neobank behaviour. They fire even when the adapter never drives that path. Backstops of ⚑ SME checks stay out of the gate.
- **behavioural**: a rule written once against the canonical `MoneySystem` interface (or a DRAFT extension surface in `adapters/`) and driven through the app adapter. Surfaces needed: **LedgerControlsSystem** (`adapters/ledger-controls.ts`), **MoneySystem** (`adapters/money-system.ts`). Every behavioural row reports NOT_EXERCISED until an adapter implements its surface. It returns **CHECKED only when it actually drove the guard's path**.
- **manual/evidence**: organisational process, live-infrastructure, statistical or retention evidence that no source scan or adapter-driven rule can prove. These are **outside the harness**, report `NOT_APPLICABLE` to it, and are tracked as evidence tasks, never as passes.

## Verdicts

`CHECKED` the path ran and the guard held · `FINDING` the guard was violated · `NOT_APPLICABLE` the invariant cannot apply here (incl. every manual/evidence item) · `NOT_EXERCISED` (glyph `????`) the adapter did not drive the path, so nothing is proven. NOT_EXERCISED is **surfaced distinctly and never counted as a pass** (no fake coverage). A ⚑ SME check with no approved parameter matrix reports `NOT_EXERCISED`, never `CHECKED`.

## How to run

- **Not runnable yet**: this draft defines invariants only (no detector/rule code). The intended shape mirrors the neobank playbook:
  - CI gate (adapter-free, blocks on any static FINDING): `run-static` with preset `VIGIL_SOX`.
  - Full combined table (static + behavioural via the adapter): `run-all`.
- Machine-readable rows: `checks.json` (same IDs; includes source-scenario traceability and neobank overlaps).

## The draft inventory: 9 static + 14 behavioural = 23 checks

| ID | Layer | Deterministic | Invariant (one line) | Covers (automation point · common failure · regulation) |
| --- | --- | --- | --- | --- |
| **SOX-CTL-01** | behavioural | yes | A financially significant action needs two distinct approvers on its final version; self-approval, single-user and edit-after-approval are blocked. | Internal controls · control failure · SOX |
| **SOX-CTL-51** | static | yes | The approval write path compares approver ≠ initiator and re-validates approvals against the entry's current version hash before posting. | backstop for SOX-CTL-01 · Internal controls · control failure · SOX |
| **SOX-CTL-02** | behavioural | yes | Each item routes to the approval tier for its amount at configured boundaries, and split transactions are aggregated so tiers cannot be circumvented. | Internal controls · control failure · SOX |
| **SOX-CTL-03** | behavioural | yes | Delegated approvals are valid only inside their window (controllable clock); out-of-window approvals are rejected and logged. | Internal controls · general control (no source failure) · SOX |
| **SOX-CTL-04** | behavioural | yes | Postings to a closed accounting period are rejected except via the approved reopening workflow. | Internal controls · control failure · SOX |
| **SOX-CTL-52** | static | yes | Every posting write path checks the period-status table inside the same transaction; no posting path bypasses the closed-period guard. | backstop for SOX-CTL-04 · Internal controls · control failure · SOX |
| **SOX-CTL-05** | behavioural | yes | Approval service outage holds postings — never auto-approves; release after recovery still requires approval. | Internal controls · control failure · SOX |
| **SOX-CTL-53** | static | yes | Approval-service error handling never sets an approved/auto-approved state (no default-allow in catch/timeout branches). | backstop for SOX-CTL-05 · Internal controls · control failure · SOX |
| **SOX-CTL-06** | static | yes | Financial-rule/control configuration and production changes ship only with peer approval and a linked ticket; unapproved config drift is flagged in the diff. | Internal controls · control failure · SOX |
| **SOX-AUD-01** | behavioural | yes | Every financial change, rule-config change and rejected attempt has an append-only audit record (who, when, before/after, reason) with service identity for batch entries. | Audit trail · Missing audit trail · SOX |
| **SOX-AUD-51** | static | yes | Audit tables are append-only: no UPDATE/DELETE statements or ORM mutations target them, and migrations grant no update/delete on them. | backstop for SOX-AUD-01 · Audit trail · Missing audit trail · SOX |
| **SOX-AUD-02** | behavioural | yes | Concurrent edits to one ledger entity are both audited and the final state equals the last committed write. | Audit trail · Missing audit trail · SOX |
| **SOX-AUD-03** | behavioural | yes | The audit hash chain/sequence is continuous across migration and restore, and any gap or break is detected with its location. | Audit trail · Missing audit trail · SOX |
| **SOX-AUD-52** | static | yes | Audit rows carry a sequence/hash-chain column populated on every insert path; restore/migration scripts preserve it. | backstop for SOX-AUD-03 · Audit trail · Missing audit trail · SOX |
| **SOX-INT-01** | behavioural | yes | Every money-movement event yields exactly one balanced posting set; trial balance is zero and sub-ledgers equal GL. | Data integrity · control failure · SOX |
| **SOX-INT-51** | static | yes | Every money-movement handler posts through the single balanced-posting function (debits = credits asserted); no direct balance writes outside it. | backstop for SOX-INT-01 · Data integrity · control failure · SOX |
| **SOX-INT-02** | behavioural | yes | A duplicate event or duplicate bank-statement line changes the ledger exactly once; recon stays balanced. | Data integrity · control failure · SOX |
| **SOX-INT-52** | static | yes | Event-ingestion and statement-line import paths dedupe on a unique event/line key (unique constraint or idempotency table). | backstop for SOX-INT-02 · Data integrity · control failure · SOX |
| **SOX-INT-03** | static | yes | Money is stored as integer minor units/decimal — no floating-point money types in schema or arithmetic; rounding follows the configured rule. | Data integrity · general control (no source failure) · SOX |
| **SOX-INT-04** | behavioural | yes | A reversal links to its original and nets to the configured outcome; no orphan reversals. | Data integrity · control failure · SOX |
| **SOX-INT-05** | behavioural | yes | Inbound processor/bank files are ingested completely (counts and control totals match); late files post per the configured cutoff; accruals sum to the period posting. | Data integrity · control failure · SOX |
| **SOX-INT-06** | behavioural | yes | A data migration conserves every per-account balance and total. | Data integrity · control failure · SOX |
| **SOX-INT-07** | behavioural | yes | Reconciliation breaks age and escalate at each configured threshold (controllable clock) and stay visible until resolved. | Data integrity · control failure · SOX |

## Outside the harness: manual/evidence (3)

These items are not harness checks. Each reports `NOT_APPLICABLE` to the runner and needs an owner and evidence on a schedule.

| ID | Layer | Deterministic | Invariant (one line) | Covers (automation point · common failure · regulation) |
| --- | --- | --- | --- | --- |
| **SOX-CTL-07** | manual/evidence | no (manual) | Segregation of duties (devs cannot post or alter prod financial data), approved finance-app provisioning, key-report (IPE) completeness, and control design/test evidence retained per period. | Internal controls · control failure · SOX |
| **SOX-AUD-04** | manual/evidence | no (manual) | Privileged ledger access is reviewed on cadence; audit and financial records are retained for the full configured period. | Audit trail · Missing audit trail · SOX |
| **SOX-INT-08** | manual/evidence | no (manual) | Report totals tie to mapped ledger accounts; recon results and break resolutions are retained per configured period. | Data integrity · general control (no source failure) · SOX |

### Determinism

Every harness row (static and behavioural) is drafted as deterministic. Static detectors, including backstops, are pure functions of the committed source/config/diff. Behavioural rules each run against a **fresh `reset()` MoneySystem** (no state leaks between rules), driven by a **controllable clock**; deadlines, windows, expiries and cadences are asserted by advancing that clock, never by wall-clock reads, and no randomness affects a verdict. External dependencies (vendors, registries, feeds) are faked inside the adapter, which is how fault-injection rows stay deterministic. Manual/evidence rows are not deterministic and are not gate checks.

### Coverage note

Converted from 37 AI-drafted source scenarios of `SK-SOX-001`; each source scenario maps to exactly one non-backstop row (see the appendix). Static backstops add no scenarios and trace through the check they back. The scenarios were merged into crisp invariants by automation point and failure mode, across categories (positive, negative, boundary, failure/recovery, concurrency/idempotency, retention/audit, common failure, core). Automation points covered: Internal controls, Audit trail, Data integrity. Source common failures: Missing audit trail, control failure. Thresholds, windows and deadlines are *configured* parameters, not asserted statutory values. No regulation or citation was added beyond the source sheet.

### Overlap with the locked neobank playbook (19 checks)

| This check | Neobank check | Strength | Why |
| --- | --- | --- | --- |
| SOX-INT-01 | LEDGER-CONSERVE | same | balanced posting set per event; trial balance 0 |
| SOX-INT-51 | LEDGER-CONSERVE | related | single balanced-posting path |
| SOX-INT-02 | N-IDEMP-01 | related | duplicate event posts once |
| SOX-INT-52 | N-IDEMP-01 | related | unique-key dedupe on the write path |
| SOX-INT-04 | N-CHGBK-05 | related | reversal nets to configured outcome |
| SOX-INT-05 | LEDGER-CONSERVE | related | inbound files complete |
| SOX-INT-06 | LEDGER-CONSERVE | related | migration conserves balances |

`same` means the neobank check already enforces this invariant, so reuse it instead of re-implementing. `related` means the same defect class, but this check needs its own rule or preset.

### Review flags

- No SME-flagged rows. All rows still need compliance review.

## Appendix: traceability to source scenarios

| Check ID | Source scenario IDs | Categories merged |
| --- | --- | --- |
| SOX-CTL-01 | SC-SOX-001-01, SC-SOX-001-07, DR-SOX-001-06 | Concurrency/Idempotency, Core |
| SOX-CTL-51 | — (static backstop; traced via SOX-CTL-01) | — |
| SOX-CTL-02 | SC-SOX-001-04, SC-SOX-001-05 | Boundary/Edge, Negative |
| SOX-CTL-03 | SC-SOX-001-06 | Boundary/Edge |
| SOX-CTL-04 | DR-SOX-001-05 | Core |
| SOX-CTL-52 | — (static backstop; traced via SOX-CTL-04) | — |
| SOX-CTL-05 | SC-SOX-001-24 | Failure/Recovery |
| SOX-CTL-53 | — (static backstop; traced via SOX-CTL-05) | — |
| SOX-CTL-06 | SC-SOX-001-08, DR-SOX-001-02 | Common Failure, Core |
| SOX-CTL-07 | DR-SOX-001-01, SC-SOX-001-10, SC-SOX-001-09, SC-SOX-001-25 | Core, Negative, Positive, Retention/Audit |
| SOX-AUD-01 | SC-SOX-001-02, SC-SOX-001-11, SC-SOX-001-12, SC-SOX-001-13 | Boundary/Edge, Core, Negative, Positive |
| SOX-AUD-51 | — (static backstop; traced via SOX-AUD-01) | — |
| SOX-AUD-02 | SC-SOX-001-26 | Concurrency/Idempotency |
| SOX-AUD-03 | SC-SOX-001-14, SC-SOX-001-15 | Common Failure, Failure/Recovery |
| SOX-AUD-52 | — (static backstop; traced via SOX-AUD-03) | — |
| SOX-AUD-04 | DR-SOX-001-08, SC-SOX-001-16 | Core, Retention/Audit |
| SOX-INT-01 | DR-SOX-001-03, SC-SOX-001-03 | Core |
| SOX-INT-51 | — (static backstop; traced via SOX-INT-01) | — |
| SOX-INT-02 | DR-SOX-001-04, SC-SOX-001-21 | Concurrency/Idempotency, Core |
| SOX-INT-52 | — (static backstop; traced via SOX-INT-02) | — |
| SOX-INT-03 | SC-SOX-001-17 | Boundary/Edge |
| SOX-INT-04 | SC-SOX-001-18 | Negative |
| SOX-INT-05 | DR-SOX-001-07, SC-SOX-001-19, SC-SOX-001-23 | Boundary/Edge, Core, Positive |
| SOX-INT-06 | SC-SOX-001-22 | Failure/Recovery |
| SOX-INT-07 | SC-SOX-001-20, SC-SOX-001-28 | Common Failure, Failure/Recovery |
| SOX-INT-08 | DR-SOX-001-09, SC-SOX-001-27 | Core, Retention/Audit |

# Helix review rules

Generated from `checks.json` (23 static and behavioural checks; manual/evidence items are not code-reviewable and are omitted). Severity is derived from the playbook priority (P0 -> HIGH); Category MM marks money-movement checks. Rule text is the source invariant, unchanged; it is AI-drafted and needs compliance review.

## Rule SOX-CTL-01: A financially significant action needs two distinct approvers on its final version
Severity: HIGH
Category: MM
Scenario: internal-controls
Requirement: MUST
Invariant: A financially significant action needs two distinct approvers on its final version; self-approval, single-user and edit-after-approval are blocked.

Source check `SOX-CTL-01` from `checks.json` (behavioural; deterministic: yes). Covers: Internal controls · control failure · SOX. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-SOX-001.

## Rule SOX-CTL-51: The approval write path compares approver ≠ initiator and re-validates approvals against the entr...
Severity: HIGH
Category: NON_MM
Scenario: internal-controls
Requirement: MUST
Invariant: The approval write path compares approver ≠ initiator and re-validates approvals against the entry's current version hash before posting.

Source check `SOX-CTL-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: Internal controls · control failure · SOX. Backstop for SOX-CTL-01. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-SOX-001.

## Rule SOX-CTL-02: Each item routes to the approval tier for its amount at configured boundaries, and split transact...
Severity: HIGH
Category: MM
Scenario: internal-controls
Requirement: MUST
Invariant: Each item routes to the approval tier for its amount at configured boundaries, and split transactions are aggregated so tiers cannot be circumvented.

Source check `SOX-CTL-02` from `checks.json` (behavioural; deterministic: yes). Covers: Internal controls · control failure · SOX. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-SOX-001.

## Rule SOX-CTL-03: Delegated approvals are valid only inside their window (controllable clock)
Severity: HIGH
Category: MM
Scenario: internal-controls
Requirement: MUST
Invariant: Delegated approvals are valid only inside their window (controllable clock); out-of-window approvals are rejected and logged.

Source check `SOX-CTL-03` from `checks.json` (behavioural; deterministic: yes). Covers: Internal controls · None · SOX. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-SOX-001.

## Rule SOX-CTL-04: Postings to a closed accounting period are rejected except via the approved reopening workflow
Severity: HIGH
Category: MM
Scenario: internal-controls
Requirement: MUST
Invariant: Postings to a closed accounting period are rejected except via the approved reopening workflow.

Source check `SOX-CTL-04` from `checks.json` (behavioural; deterministic: yes). Covers: Internal controls · control failure · SOX. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-SOX-001.

## Rule SOX-CTL-52: Every posting write path checks the period-status table inside the same transaction
Severity: HIGH
Category: NON_MM
Scenario: internal-controls
Requirement: MUST
Invariant: Every posting write path checks the period-status table inside the same transaction; no posting path bypasses the closed-period guard.

Source check `SOX-CTL-52` from `checks.json` (static, static backstop; deterministic: yes). Covers: Internal controls · control failure · SOX. Backstop for SOX-CTL-04. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-SOX-001.

## Rule SOX-CTL-05: Approval service outage holds postings — never auto-approves
Severity: HIGH
Category: MM
Scenario: internal-controls
Requirement: MUST
Invariant: Approval service outage holds postings — never auto-approves; release after recovery still requires approval.

Source check `SOX-CTL-05` from `checks.json` (behavioural; deterministic: yes). Covers: Internal controls · control failure · SOX. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-SOX-001.

## Rule SOX-CTL-53: Approval-service error handling never sets an approved/auto-approved state (no default-allow in c...
Severity: HIGH
Category: NON_MM
Scenario: internal-controls
Requirement: MUST
Invariant: Approval-service error handling never sets an approved/auto-approved state (no default-allow in catch/timeout branches).

Source check `SOX-CTL-53` from `checks.json` (static, static backstop; deterministic: yes). Covers: Internal controls · control failure · SOX. Backstop for SOX-CTL-05. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-SOX-001.

## Rule SOX-CTL-06: Financial-rule/control configuration and production changes ship only with peer approval and a li...
Severity: HIGH
Category: NON_MM
Scenario: internal-controls
Requirement: MUST
Invariant: Financial-rule/control configuration and production changes ship only with peer approval and a linked ticket; unapproved config drift is flagged in the diff.

Source check `SOX-CTL-06` from `checks.json` (static; deterministic: yes). Covers: Internal controls · control failure · SOX. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-SOX-001.

## Rule SOX-AUD-01: Every financial change, rule-config change and rejected attempt has an append-only audit record (...
Severity: HIGH
Category: MM
Scenario: audit-trail
Requirement: MUST
Invariant: Every financial change, rule-config change and rejected attempt has an append-only audit record (who, when, before/after, reason) with service identity for batch entries.

Source check `SOX-AUD-01` from `checks.json` (behavioural; deterministic: yes). Covers: Audit trail · Missing audit trail · SOX. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-SOX-001.

## Rule SOX-AUD-51: Audit tables are append-only
Severity: HIGH
Category: NON_MM
Scenario: audit-trail
Requirement: MUST
Invariant: Audit tables are append-only: no UPDATE/DELETE statements or ORM mutations target them, and migrations grant no update/delete on them.

Source check `SOX-AUD-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: Audit trail · Missing audit trail · SOX. Backstop for SOX-AUD-01. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-SOX-001.

## Rule SOX-AUD-02: Concurrent edits to one ledger entity are both audited and the final state equals the last commit...
Severity: HIGH
Category: MM
Scenario: audit-trail
Requirement: MUST
Invariant: Concurrent edits to one ledger entity are both audited and the final state equals the last committed write.

Source check `SOX-AUD-02` from `checks.json` (behavioural; deterministic: yes). Covers: Audit trail · Missing audit trail · SOX. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-SOX-001.

## Rule SOX-AUD-03: The audit hash chain/sequence is continuous across migration and restore, and any gap or break is...
Severity: HIGH
Category: MM
Scenario: audit-trail
Requirement: MUST
Invariant: The audit hash chain/sequence is continuous across migration and restore, and any gap or break is detected with its location.

Source check `SOX-AUD-03` from `checks.json` (behavioural; deterministic: yes). Covers: Audit trail · Missing audit trail · SOX. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-SOX-001.

## Rule SOX-AUD-52: Audit rows carry a sequence/hash-chain column populated on every insert path
Severity: HIGH
Category: NON_MM
Scenario: audit-trail
Requirement: MUST
Invariant: Audit rows carry a sequence/hash-chain column populated on every insert path; restore/migration scripts preserve it.

Source check `SOX-AUD-52` from `checks.json` (static, static backstop; deterministic: yes). Covers: Audit trail · Missing audit trail · SOX. Backstop for SOX-AUD-03. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-SOX-001.

## Rule SOX-INT-01: Every money-movement event yields exactly one balanced posting set
Severity: HIGH
Category: MM
Scenario: data-integrity
Requirement: MUST
Invariant: Every money-movement event yields exactly one balanced posting set; trial balance is zero and sub-ledgers equal GL.

Source check `SOX-INT-01` from `checks.json` (behavioural; deterministic: yes). Covers: Data integrity · control failure · SOX. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-SOX-001, RR-ACCT-001.

## Rule SOX-INT-51: Every money-movement handler posts through the single balanced-posting function (debits = credits...
Severity: HIGH
Category: NON_MM
Scenario: data-integrity
Requirement: MUST
Invariant: Every money-movement handler posts through the single balanced-posting function (debits = credits asserted); no direct balance writes outside it.

Source check `SOX-INT-51` from `checks.json` (static, static backstop; deterministic: yes). Covers: Data integrity · control failure · SOX. Backstop for SOX-INT-01. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-SOX-001, RR-ACCT-001.

## Rule SOX-INT-02: A duplicate event or duplicate bank-statement line changes the ledger exactly once
Severity: HIGH
Category: MM
Scenario: data-integrity
Requirement: MUST
Invariant: A duplicate event or duplicate bank-statement line changes the ledger exactly once; recon stays balanced.

Source check `SOX-INT-02` from `checks.json` (behavioural; deterministic: yes). Covers: Data integrity · control failure · SOX. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-SOX-001.

## Rule SOX-INT-52: Event-ingestion and statement-line import paths dedupe on a unique event/line key (unique constra...
Severity: HIGH
Category: NON_MM
Scenario: data-integrity
Requirement: MUST
Invariant: Event-ingestion and statement-line import paths dedupe on a unique event/line key (unique constraint or idempotency table).

Source check `SOX-INT-52` from `checks.json` (static, static backstop; deterministic: yes). Covers: Data integrity · control failure · SOX. Backstop for SOX-INT-02. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-SOX-001.

## Rule SOX-INT-03: Money is stored as integer minor units/decimal — no floating-point money types in schema or arith...
Severity: HIGH
Category: NON_MM
Scenario: data-integrity
Requirement: MUST
Invariant: Money is stored as integer minor units/decimal — no floating-point money types in schema or arithmetic; rounding follows the configured rule.

Source check `SOX-INT-03` from `checks.json` (static; deterministic: yes). Covers: Data integrity · None · SOX. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-SOX-001.

## Rule SOX-INT-04: A reversal links to its original and nets to the configured outcome
Severity: HIGH
Category: MM
Scenario: data-integrity
Requirement: MUST
Invariant: A reversal links to its original and nets to the configured outcome; no orphan reversals.

Source check `SOX-INT-04` from `checks.json` (behavioural; deterministic: yes). Covers: Data integrity · control failure · SOX. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-SOX-001, RR-ACCT-001.

## Rule SOX-INT-05: Inbound processor/bank files are ingested completely (counts and control totals match)
Severity: HIGH
Category: MM
Scenario: data-integrity
Requirement: MUST
Invariant: Inbound processor/bank files are ingested completely (counts and control totals match); late files post per the configured cutoff; accruals sum to the period posting.

Source check `SOX-INT-05` from `checks.json` (behavioural; deterministic: yes). Covers: Data integrity · control failure · SOX. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-SOX-001.

## Rule SOX-INT-06: A data migration conserves every per-account balance and total
Severity: HIGH
Category: MM
Scenario: data-integrity
Requirement: MUST
Invariant: A data migration conserves every per-account balance and total.

Source check `SOX-INT-06` from `checks.json` (behavioural; deterministic: yes). Covers: Data integrity · control failure · SOX. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-SOX-001.

## Rule SOX-INT-07: Reconciliation breaks age and escalate at each configured threshold (controllable clock) and stay...
Severity: HIGH
Category: MM
Scenario: data-integrity
Requirement: MUST
Invariant: Reconciliation breaks age and escalate at each configured threshold (controllable clock) and stay visible until resolved.

Source check `SOX-INT-07` from `checks.json` (behavioural; deterministic: yes). Covers: Data integrity · control failure · SOX. Review status in source: Drafted (AI) – needs compliance review.

Regulation references: RR-SOX-001.
