# Overlap with the locked neobank playbook (19 checks)

For each locked neobank check, this lists the DRAFT compliance checks whose invariant it already enforces (`same`: reuse the neobank check or its detector) or that share its defect class (`related`: same pattern, but needs its own rule/preset). All mappings are AI-drafted and need review.

| Neobank check | Layer | Neobank invariant | Same | Related |
| --- | --- | --- | --- | --- |
| **N-DEPLOY-01** | static | A merged migration is append-only — never edited/renamed/deleted. | — | — |
| **N-PARITY-01** | static | In-memory and SQL stores stay in lockstep. | — | — |
| **N-TEST-01** | static | No branch greens CI by silently weakening a money assertion. | — | — |
| **N-CAP-01** | static | Aggregate caps and per-member limits are read & enforced inside the atomic op under a lock, never from the payload. | PSD2-SCA-53, NACHA-AUTH-52, 3DS-EXM-52 | PSD2-SCA-03, NACHA-AUTH-02, REGE-LIA-01, REGE-LIA-51, REGZ-FIN-03, ECOA-PR-02, ADV-DIS-02, MIFID-UB-02, MIFID-UB-51, MICA-RES-51, 3DS-EXM-02, FRD-VEL-02, FRD-VEL-51, FRD-REF-52 |
| **N-SCHED-01** | static | A scheduled-start card declines before activation; start survives reissue. | — | FRD-BLK-04 |
| **N-SCREEN-02** | static | A money/activation op re-screens the actual holder (KYC + sanctions) and funding account, not just the owner. | BSA-KYC-01, PAT-CIP-51 | BSA-OFAC-02, BSA-OFAC-52, OFAC-SCR-01, OFAC-BLK-04 |
| **N-STATE-01** | static | A money op re-reads subject state from the LOCKED row and rejects removed/canceled subjects. | FRD-ATO-51, FRD-BLK-52 | PCI-ACC-02, PCI-ACC-52, PSD2-CON-02, PAT-CIP-04, NACHA-AUTH-03, OFAC-BLK-51, FCA-SMCR-02, MICA-LIC-02, FIN-MSB-02, FRD-ATO-01, FRD-BLK-01, FRD-BLK-02 |
| **N-ORPHAN-01** | static | Issuer card cancelled only on durable-write failure, never on a post-commit step throwing. | — | — |
| **N-IDEMP-01** | static | Money routes gate on an Idempotency-Key; conditional updates report success only after a row changed. | PSD2-SCA-52, PSD2-XS2A-03, PSD2-XS2A-51, SOC2-PI-02, SOC2-PI-51, UCC4A-WIRE-01, UCC4A-WIRE-51, 3DS-FLOW-53, 3DS-AV-52 | PCI-ENC-07, SOX-INT-02, SOX-INT-52, GDPR-DEL-03, GDPR-POR-03, CCPA-ACC-03, PSD2-SCA-02, BSA-TM-03, BSA-OFAC-05, NACHA-FMT-02, NACHA-FMT-51, NACHA-FMT-03, NACHA-FMT-52, NACHA-RET-01, NACHA-RET-51, OFAC-REP-03, REGE-ERR-03, REGE-ERR-51, SCI-SYS-03, FINRA-TR-02, FINRA-TR-51, DFA-SW-51, BASEL-RWA-03, MIFID-TR-51, STP-RTS-03, STP-OPT-02, FIN-TR-03, FIN-TR-52, STINS-CLM-02, STINS-CLM-51, RESPA-ESC-02, RESPA-ESC-51, IRS-BW-01, IRS-BW-51, UCC4-CHK-02, UCC4-CHK-51, UCC4-RET-51, UDAAP-UNF-51, 3DS-FLOW-04, 3DS-AV-03, 3DS-AV-04, 3DS-ERR-03, FRD-RPT-02, FRD-RPT-51 |
| **N-CAS-01** | static | A status transition is a locked compare-and-set (no unlocked read then blind write). | BSA-SAR-52, FRD-REL-51 | PSD2-XS2A-02, BSA-SAR-03, PAT-CDD-04, FINRA-SUP-02, CB-COV-51, CDD-CDD-03, CDD-CDD-51, FRD-REL-02 |
| **N-SCOPE-01** | static | A bulk restore reactivates only what its pairing op set (by provenance). | — | — |
| **N-UNWIND-01** | static | A terminal unwind first asserts no unresolved money (dispute / provisional credit / pending inbound). | — | — |
| **PARTY-SCREEN** | behavioral | A sanctioned / un-KYC'd party never holds an active instrument, by any issuance path. | BSA-KYC-02, BSA-OFAC-01, PAT-CIP-01, PAT-CIP-06 | PAT-BO-01, OFAC-SCR-02, UCC4A-WIRE-02, CDD-BO-01 |
| **LEDGER-CONSERVE** | behavioral | Trial balance is 0 and every transaction is internally balanced. | SOX-INT-01, FRD-LEDG-01 | SOX-INT-51, SOX-INT-05, SOX-INT-06, BSA-TM-01, NACHA-RET-03, SOC2-PI-01, OFAC-BLK-01, OFAC-REP-02, REGE-LIA-02, ADV-CUS-01, MICA-RES-03, NAIC-FIN-01, TRID-CD-02, IRS-1099-01, IRS-1098-01, FATCA-WH-02, UCC4A-ERR-02, FRD-LEDG-51 |
| **N-ATOMIC** | behavioral | A money op is atomic & lock-safe: no partial write; two competing debits never both commit. | — | BSA-KYC-05, OFAC-BLK-02, REGZ-RES-02, MICA-RES-01, MICA-RES-51, CB-COV-03, UDAAP-UNF-02, 3DS-AV-03, FRD-VEL-02, FRD-LEDG-01, FRD-BLK-02 |
| **N-CHGBK-05** | behavioral | Cumulative recovery on one captured charge never exceeds what was captured. | FRD-REF-02 | SOX-INT-04, NACHA-RET-01, UCC4-RET-01, FRD-REF-52 |
| **N-RWD-04** | behavioral | A card fee is recomputed on the captured amount and kept on a full refund. | — | REGZ-FIN-04, UDAAP-UNF-01, UDAAP-UNF-03 |
| **N-ORDER-01** | behavioral | A money op commits durably BEFORE any irreversible external call. | SOC2-AVL-51, FRD-BLK-53 | SOC2-AVL-01, UCC4A-WIRE-01, UCC4A-WIRE-51, FRD-BLK-03 |
| **N-AUTHN** | behavioral | An untrusted money event is authenticated before any effect. | 3DS-FLOW-05 | PSD2-TPP-02, 3DS-FLOW-52 |

**28 same + 129 related mappings** across 13 of the 19 neobank checks. With no compliance counterpart: N-DEPLOY-01, N-PARITY-01, N-TEST-01, N-ORPHAN-01, N-SCOPE-01, N-UNWIND-01. These are harness-integrity or Family-Cards-specific checks.

## Detail

| Neobank check | Draft check | Playbook | Strength | Why |
| --- | --- | --- | --- | --- |
| N-CAP-01 | PSD2-SCA-03 | psd2 | related | cumulative exemption limits enforced server-side |
| N-CAP-01 | PSD2-SCA-53 | psd2 | same | limits read under lock in the txn, never from payload |
| N-CAP-01 | NACHA-AUTH-02 | nacha | related | exposure limits |
| N-CAP-01 | NACHA-AUTH-52 | nacha | same | exposure limits read in the txn, never from payload |
| N-CAP-01 | REGE-LIA-01 | reg-e | related | liability cap across concurrent disputes |
| N-CAP-01 | REGE-LIA-51 | reg-e | related | cap table read in decision txn |
| N-CAP-01 | REGZ-FIN-03 | reg-z | related | fee cap |
| N-CAP-01 | ECOA-PR-02 | ecoa-fha | related | pricing exception limit |
| N-CAP-01 | ADV-DIS-02 | sec-form-adv | related | billing ≤ disclosed rate |
| N-CAP-01 | MIFID-UB-02 | mifid-ii | related | research budget cap under concurrency |
| N-CAP-01 | MIFID-UB-51 | mifid-ii | related | budget decremented under lock |
| N-CAP-01 | MICA-RES-51 | mica | related | cap-style guard under lock |
| N-CAP-01 | 3DS-EXM-02 | 3ds | related | cumulative exemption limits enforced server-side, atomically |
| N-CAP-01 | 3DS-EXM-52 | 3ds | same | limits read under lock in the txn, never from payload |
| N-CAP-01 | FRD-VEL-02 | card-fraud-stolen | related | velocity counter enforced atomically |
| N-CAP-01 | FRD-VEL-51 | card-fraud-stolen | related | counter enforced under lock in the txn |
| N-CAP-01 | FRD-REF-52 | card-fraud-stolen | related | cap read under lock |
| N-SCHED-01 | FRD-BLK-04 | card-fraud-stolen | related | card state survives reissue (block, here, rather than scheduled start) |
| N-SCREEN-02 | BSA-KYC-01 | bsa-aml | same | every rail/activation gates on the actual party's KYC |
| N-SCREEN-02 | BSA-OFAC-02 | bsa-aml | related | re-screen on party change / list update |
| N-SCREEN-02 | BSA-OFAC-52 | bsa-aml | related | re-screen on party change |
| N-SCREEN-02 | PAT-CIP-51 | usa-patriot-act | same | activation checks every customer person, not just the owner |
| N-SCREEN-02 | OFAC-SCR-01 | ofac | related | every money-out rail invokes screening |
| N-SCREEN-02 | OFAC-BLK-04 | ofac | related | ownership-based blocking of related parties |
| N-STATE-01 | PCI-ACC-02 | pci-dss | related | revoked subject rejected on next request |
| N-STATE-01 | PCI-ACC-52 | pci-dss | related | re-read subject state per request |
| N-STATE-01 | PSD2-CON-02 | psd2 | related | revoked consent rejected |
| N-STATE-01 | PAT-CIP-04 | usa-patriot-act | related | verification tied to current data |
| N-STATE-01 | NACHA-AUTH-03 | nacha | related | revoked authorization removed from unsent batch |
| N-STATE-01 | OFAC-BLK-51 | ofac | related | blocked flag re-read inside txn |
| N-STATE-01 | FCA-SMCR-02 | fca-handbook | related | lapsed certification suspends permissions |
| N-STATE-01 | MICA-LIC-02 | mica | related | revoked licence blocks new activity |
| N-STATE-01 | FIN-MSB-02 | fincen | related | expired registration blocks feature |
| N-STATE-01 | FRD-ATO-01 | card-fraud-stolen | related | card add evaluated against current (post-change) subject state |
| N-STATE-01 | FRD-ATO-51 | card-fraud-stolen | same | re-read subject state from the LOCKED row |
| N-STATE-01 | FRD-BLK-01 | card-fraud-stolen | related | every token re-reads blocked status |
| N-STATE-01 | FRD-BLK-02 | card-fraud-stolen | related | auth re-reads state from locked row |
| N-STATE-01 | FRD-BLK-52 | card-fraud-stolen | same | money op re-reads subject state from the LOCKED row and rejects blocked subjects |
| N-IDEMP-01 | PCI-ENC-07 | pci-dss | related | tokenise/re-key idempotent |
| N-IDEMP-01 | SOX-INT-02 | sox | related | duplicate event posts once |
| N-IDEMP-01 | SOX-INT-52 | sox | related | unique-key dedupe on the write path |
| N-IDEMP-01 | GDPR-DEL-03 | gdpr | related | erasure idempotent |
| N-IDEMP-01 | GDPR-POR-03 | gdpr | related | export dedupe |
| N-IDEMP-01 | CCPA-ACC-03 | ccpa-cpra | related | duplicate requests |
| N-IDEMP-01 | PSD2-SCA-02 | psd2 | related | auth code single-use |
| N-IDEMP-01 | PSD2-SCA-52 | psd2 | same | conditional update reports success only when a row changed |
| N-IDEMP-01 | PSD2-XS2A-03 | psd2 | same | idempotency key → one payment, no double debit |
| N-IDEMP-01 | PSD2-XS2A-51 | psd2 | same | PIS routes gate on Idempotency-Key |
| N-IDEMP-01 | BSA-TM-03 | bsa-aml | related | duplicates never double-alert |
| N-IDEMP-01 | BSA-OFAC-05 | bsa-aml | related | screened exactly once |
| N-IDEMP-01 | NACHA-FMT-02 | nacha | related | unique trace numbers |
| N-IDEMP-01 | NACHA-FMT-51 | nacha | related | unique-key dedupe on the write path |
| N-IDEMP-01 | NACHA-FMT-03 | nacha | related | duplicate file blocked |
| N-IDEMP-01 | NACHA-FMT-52 | nacha | related | unique-key dedupe on the write path |
| N-IDEMP-01 | NACHA-RET-01 | nacha | related | return applied once |
| N-IDEMP-01 | NACHA-RET-51 | nacha | related | unique-key dedupe on the write path |
| N-IDEMP-01 | SOC2-PI-02 | soc-2 | same | idempotency key → exactly one payment |
| N-IDEMP-01 | SOC2-PI-51 | soc-2 | same | payment routes gate on Idempotency-Key |
| N-IDEMP-01 | OFAC-REP-03 | ofac | related | no duplicate submission |
| N-IDEMP-01 | REGE-ERR-03 | reg-e | related | one provisional credit per dispute |
| N-IDEMP-01 | REGE-ERR-51 | reg-e | related | unique-key dedupe on the write path |
| N-IDEMP-01 | SCI-SYS-03 | sec-reg-sci | related | each message once |
| N-IDEMP-01 | FINRA-TR-02 | finra | related | one accepted report per event |
| N-IDEMP-01 | FINRA-TR-51 | finra | related | unique-key dedupe on the write path |
| N-IDEMP-01 | DFA-SW-51 | dodd-frank | related | unique-key dedupe on the write path |
| N-IDEMP-01 | BASEL-RWA-03 | basel | related | reprocessing idempotent |
| N-IDEMP-01 | MIFID-TR-51 | mifid-ii | related | unique-key dedupe on the write path |
| N-IDEMP-01 | STP-RTS-03 | state-privacy | related | duplicate requests |
| N-IDEMP-01 | STP-OPT-02 | state-privacy | related | repeat opt-out |
| N-IDEMP-01 | FIN-TR-03 | fincen | related | one travel-rule message per transfer |
| N-IDEMP-01 | FIN-TR-52 | fincen | related | unique-key dedupe on the write path |
| N-IDEMP-01 | STINS-CLM-02 | state-insurance | related | claim paid once |
| N-IDEMP-01 | STINS-CLM-51 | state-insurance | related | unique-key dedupe on the write path |
| N-IDEMP-01 | RESPA-ESC-02 | respa | related | disbursement paid once |
| N-IDEMP-01 | RESPA-ESC-51 | respa | related | unique-key dedupe on the write path |
| N-IDEMP-01 | IRS-BW-01 | irs-reporting | related | withholding once per payment |
| N-IDEMP-01 | IRS-BW-51 | irs-reporting | related | unique-key dedupe on the write path |
| N-IDEMP-01 | UCC4-CHK-02 | ucc-article-4 | related | no double credit on re-presentment |
| N-IDEMP-01 | UCC4-CHK-51 | ucc-article-4 | related | unique-key dedupe on the write path |
| N-IDEMP-01 | UCC4-RET-51 | ucc-article-4 | related | unique-key dedupe on the write path |
| N-IDEMP-01 | UCC4A-WIRE-01 | ucc-article-4a | same | one wire per order |
| N-IDEMP-01 | UCC4A-WIRE-51 | ucc-article-4a | same | wire route gates on Idempotency-Key |
| N-IDEMP-01 | UDAAP-UNF-51 | udaap | related | unique-key dedupe on the write path |
| N-IDEMP-01 | 3DS-FLOW-04 | 3ds | related | results message applied once |
| N-IDEMP-01 | 3DS-FLOW-53 | 3ds | same | conditional update reports success only when a row changed |
| N-IDEMP-01 | 3DS-AV-03 | 3ds | related | authentication value single-use |
| N-IDEMP-01 | 3DS-AV-52 | 3ds | same | single-use conditional update; success only when a row changed |
| N-IDEMP-01 | 3DS-AV-04 | 3ds | related | authorization retry idempotent |
| N-IDEMP-01 | 3DS-ERR-03 | 3ds | related | one authentication per purchase on retry |
| N-IDEMP-01 | FRD-RPT-02 | card-fraud-stolen | related | report submitted exactly once |
| N-IDEMP-01 | FRD-RPT-51 | card-fraud-stolen | related | unique-key dedupe on the write path |
| N-CAS-01 | PSD2-XS2A-02 | psd2 | related | status lifecycle transitions |
| N-CAS-01 | BSA-SAR-03 | bsa-aml | related | single filing under race |
| N-CAS-01 | BSA-SAR-52 | bsa-aml | same | locked compare-and-set on status |
| N-CAS-01 | PAT-CDD-04 | usa-patriot-act | related | refresh vs update race |
| N-CAS-01 | FINRA-SUP-02 | finra | related | one decision per item |
| N-CAS-01 | CB-COV-51 | cost-basis | related | row lock before decrement |
| N-CAS-01 | CDD-CDD-03 | cdd-rule | related | no lost update |
| N-CAS-01 | CDD-CDD-51 | cdd-rule | related | versioned/locked update |
| N-CAS-01 | FRD-REL-02 | card-fraud-stolen | related | one terminal hold decision |
| N-CAS-01 | FRD-REL-51 | card-fraud-stolen | same | locked compare-and-set on status |
| PARTY-SCREEN | BSA-KYC-02 | bsa-aml | same | un-KYC'd party never gets an active, money-moving account |
| PARTY-SCREEN | BSA-OFAC-01 | bsa-aml | same | sanctioned party never activated/funded |
| PARTY-SCREEN | PAT-CIP-01 | usa-patriot-act | same | no account without completed CIP for every customer person |
| PARTY-SCREEN | PAT-CIP-06 | usa-patriot-act | same | list-matched applicant never opened |
| PARTY-SCREEN | PAT-BO-01 | usa-patriot-act | related | entity owners verified & screened before activation |
| PARTY-SCREEN | OFAC-SCR-02 | ofac | related | true hit blocks the transaction |
| PARTY-SCREEN | UCC4A-WIRE-02 | ucc-article-4a | related | sanctioned beneficiary held |
| PARTY-SCREEN | CDD-BO-01 | cdd-rule | related | entity owners captured & verified before activation |
| LEDGER-CONSERVE | SOX-INT-01 | sox | same | balanced posting set per event; trial balance 0 |
| LEDGER-CONSERVE | SOX-INT-51 | sox | related | single balanced-posting path |
| LEDGER-CONSERVE | SOX-INT-05 | sox | related | inbound files complete |
| LEDGER-CONSERVE | SOX-INT-06 | sox | related | migration conserves balances |
| LEDGER-CONSERVE | BSA-TM-01 | bsa-aml | related | monitoring population = ledger population |
| LEDGER-CONSERVE | NACHA-RET-03 | nacha | related | ledger balanced after return on withdrawn funds |
| LEDGER-CONSERVE | SOC2-PI-01 | soc-2 | related | inputs = outputs |
| LEDGER-CONSERVE | OFAC-BLK-01 | ofac | related | blocked funds segregated, ledger balanced |
| LEDGER-CONSERVE | OFAC-REP-02 | ofac | related | report totals = ledger |
| LEDGER-CONSERVE | REGE-LIA-02 | reg-e | related | credit = disputed − liability, no drift |
| LEDGER-CONSERVE | ADV-CUS-01 | sec-form-adv | related | holdings reconcile to custodian |
| LEDGER-CONSERVE | MICA-RES-03 | mica | related | redemption at par |
| LEDGER-CONSERVE | NAIC-FIN-01 | naic | related | statement ties to GL |
| LEDGER-CONSERVE | TRID-CD-02 | trid | related | cure posts to ledger |
| LEDGER-CONSERVE | IRS-1099-01 | irs-reporting | related | form amounts = ledger |
| LEDGER-CONSERVE | IRS-1098-01 | irs-reporting | related | 1098 = interest received |
| LEDGER-CONSERVE | FATCA-WH-02 | fatca | related | withheld = deposited |
| LEDGER-CONSERVE | UCC4A-ERR-02 | ucc-article-4a | related | recall/refund keeps ledger balanced |
| LEDGER-CONSERVE | FRD-LEDG-01 | card-fraud-stolen | same | trial balance 0, every fraud reversal balanced |
| LEDGER-CONSERVE | FRD-LEDG-51 | card-fraud-stolen | related | single balanced-posting path |
| N-ATOMIC | BSA-KYC-05 | bsa-aml | related | concurrent applications, one proceeds |
| N-ATOMIC | OFAC-BLK-02 | ofac | related | competing withdrawals on blocked account all refused |
| N-ATOMIC | REGZ-RES-02 | reg-z | related | no partial disbursement under race |
| N-ATOMIC | MICA-RES-01 | mica | related | competing mint/redeem never break reserve ≥ liabilities |
| N-ATOMIC | MICA-RES-51 | mica | related | reserve check + mint in one locked txn |
| N-ATOMIC | CB-COV-03 | cost-basis | related | lot consumed once under concurrent sells |
| N-ATOMIC | UDAAP-UNF-02 | udaap | related | concurrent transactions do not manufacture overdraft fees |
| N-ATOMIC | 3DS-AV-03 | 3ds | related | two competing authorizations never both commit |
| N-ATOMIC | FRD-VEL-02 | card-fraud-stolen | related | concurrent attempts never exceed limit |
| N-ATOMIC | FRD-LEDG-01 | card-fraud-stolen | related | no partial reversal posting |
| N-ATOMIC | FRD-BLK-02 | card-fraud-stolen | related | block vs auth race |
| N-CHGBK-05 | SOX-INT-04 | sox | related | reversal nets to configured outcome |
| N-CHGBK-05 | NACHA-RET-01 | nacha | related | reversal never exceeds original |
| N-CHGBK-05 | UCC4-RET-01 | ucc-article-4 | related | return reverses credit once |
| N-CHGBK-05 | FRD-REF-02 | card-fraud-stolen | same | cumulative recovery on one capture never exceeds captured |
| N-CHGBK-05 | FRD-REF-52 | card-fraud-stolen | related | static guard for cumulative recovery ≤ captured |
| N-RWD-04 | REGZ-FIN-04 | reg-z | related | fee refunds adjust totals |
| N-RWD-04 | UDAAP-UNF-01 | udaap | related | fee once per item |
| N-RWD-04 | UDAAP-UNF-03 | udaap | related | erroneous fee reversed |
| N-ORDER-01 | SOC2-AVL-01 | soc-2 | related | outage never duplicates money movement |
| N-ORDER-01 | SOC2-AVL-51 | soc-2 | same | durable commit before irreversible external call |
| N-ORDER-01 | UCC4A-WIRE-01 | ucc-article-4a | related | reconcile external status before retry |
| N-ORDER-01 | UCC4A-WIRE-51 | ucc-article-4a | related | status query before external resend |
| N-ORDER-01 | FRD-BLK-03 | card-fraud-stolen | related | durable block before external TSP call |
| N-ORDER-01 | FRD-BLK-53 | card-fraud-stolen | same | durable commit before irreversible external call |
| N-AUTHN | PSD2-TPP-02 | psd2 | related | untrusted TPP certificate rejected before effect |
| N-AUTHN | 3DS-FLOW-05 | 3ds | same | untrusted results message authenticated before any effect |
| N-AUTHN | 3DS-FLOW-52 | 3ds | related | authenticity verified before effect, statically |
