# Helix Vigil compliance playbooks: DRAFT manifests

Generated 2026-10-12T22:38:39-04:00: 40 playbooks from `vigil-compliance-skills.json` (40 skills, 1,142 scenarios) plus 2 playbooks (`3ds`, `card-fraud-stolen`) built from 100 inline AI-drafted scenarios that are not in the source sheet. Follows the locked neobank manifest format: Layers, Verdicts, How to run, inventory table `ID | Layer | Deterministic | Invariant | Covers`, Determinism and Coverage note.

> **All 42 manifests are DRAFT, not LOCKED.** Every invariant, layer and determinism call is AI-drafted and needs compliance review. ⚑ SME rows need an SME/counsel parameter matrix before they can gate. No detector or rule code is included. Thresholds and deadlines are *configured* parameters. No regulations or citations were added.

**Totals: 700 checks = 184 static (incl. 146 static backstops) + 380 behavioural (564 harness checks) + 136 manual/evidence (outside the harness). 59 ⚑ SME-flagged. 1242 scenarios traced (1142 source + 100 inline), each to exactly one check.**

## Layout

```
vigil-playbooks/
├── README.md                 ← this index
├── NEOBANK-OVERLAP.md        ← draft checks mapped to the 19 locked neobank checks
├── index.json                ← machine-readable index (per-playbook counts + paths)
├── adapters/                 ← DRAFT TypeScript surface types (no implementations) + ADAPTER-SURFACES.md
└── playbooks/<slug>/
    ├── PLAYBOOK.md           ← DRAFT manifest in the locked-manifest style
    └── checks.json           ← same rows, machine-readable, with source-scenario traceability
```

## Conventions

- **IDs** are regulation-prefixed: `<REG>-<AREA>-<nn>`, e.g. `PCI-ENC-01`. They are unique across all playbooks.
- **Layer** is `static` (source/SQL/config/IaC/diff scanner, preset `VIGIL_<CODE>`, fails closed, CI gate), `behavioural` (rule against the canonical MoneySystem via an adapter; CHECKED only when it drove the path) or `manual/evidence` (outside the harness, NOT_APPLICABLE to it).
- **Deterministic**: `yes` is required for every harness row (static and behavioural use a fresh `reset()` and a controllable clock). `yes ⚑ SME` means deterministic once parameters exist, but not gate-eligible yet. `no (manual)` marks manual/evidence rows. `gate` in checks.json is true only for deterministic, non-SME harness rows.
- **Covers** = automation point(s) · source common failure (or "general control") · regulation.
- **Static backstops** (IDs `<REG>-<AREA>-5x`, `backs` in checks.json) are source/SQL/config/diff invariants that support one behavioural check. They are deterministic and fail closed, have no source scenarios of their own (traceability goes through the backed check) and inherit ⚑ SME, which keeps them out of the gate.
- **Adapter surfaces**: each behavioural row names its surface (`adapter_surface`). DRAFT TypeScript types for every surface are in `adapters/`, and `adapters/ADAPTER-SURFACES.md` maps each surface to the checks it unlocks. Until an adapter implements a surface, its rows report `NOT_EXERCISED`, never a pass.

## Playbooks

| # | Playbook | Skill | Regulation | Priority | Static (backstops) | Behavioural | Harness | Manual/evidence | Total | ⚑ SME | Scenarios traced | Neobank overlap (same/related) | Adapter surface |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | [`pci-dss`](playbooks/pci-dss/PLAYBOOK.md) | SK-PCI-001 | PCI-DSS 4.0 | P0 | 11 (7) | 12 | 23 | 7 | 30 |  | 49 | 0/3 | CardVaultSystem, IdentityAccessSystem |
| 2 | [`sox`](playbooks/sox/PLAYBOOK.md) | SK-SOX-001 | SOX | P0 | 9 (7) | 14 | 23 | 3 | 26 |  | 37 | 1/6 | LedgerControlsSystem, MoneySystem |
| 3 | [`gdpr`](playbooks/gdpr/PLAYBOOK.md) | SK-GDPR-001 | GDPR | P0 | 7 (5) | 16 | 23 | 3 | 26 |  | 43 | 0/2 | PrivacySystem |
| 4 | [`ccpa-cpra`](playbooks/ccpa-cpra/PLAYBOOK.md) | SK-CCPA-001 | CCPA/CPRA | P0 | 4 (3) | 12 | 16 | 2 | 18 |  | 34 | 0/1 | PrivacySystem |
| 5 | [`psd2`](playbooks/psd2/PLAYBOOK.md) | SK-PSD2-001 | PSD2 (EU) | P1 | 6 (6) | 14 | 20 | 4 | 24 |  | 34 | 4/5 | OpenBankingSystem |
| 6 | [`bsa-aml`](playbooks/bsa-aml/PLAYBOOK.md) | SK-BSA-001 | BSA/AML | P0 | 8 (7) | 19 | 27 | 4 | 31 |  | 43 | 4/7 | OnboardingSystem, ComplianceCaseSystem, ScreeningSystem |
| 7 | [`usa-patriot-act`](playbooks/usa-patriot-act/PLAYBOOK.md) | SK-PATRIOT-001 | USA PATRIOT Act | P0 | 6 (6) | 17 | 23 | 4 | 27 |  | 40 | 3/3 | OnboardingSystem |
| 8 | [`nacha`](playbooks/nacha/PLAYBOOK.md) | SK-NACHA-001 | NACHA Rules | P0 | 8 (7) | 13 | 21 | 3 | 24 |  | 36 | 1/10 | AchSystem |
| 9 | [`soc-2`](playbooks/soc-2/PLAYBOOK.md) | SK-SOC2-001 | SOC 2 Type II | P0 | 6 (3) | 6 | 12 | 7 | 19 |  | 43 | 3/2 | MoneySystem, DataProtectionSystem |
| 10 | [`ofac`](playbooks/ofac/PLAYBOOK.md) | SK-OFAC-001 | OFAC | P0 | 5 (4) | 11 | 16 | 3 | 19 |  | 34 | 0/8 | ScreeningSystem |
| 11 | [`reg-e`](playbooks/reg-e/PLAYBOOK.md) | SK-REGE-001 | EFTA / Reg E | P1 | 4 (4) | 11 | 15 | 2 | 17 |  | 25 | 0/5 | DisputesSystem |
| 12 | [`reg-z`](playbooks/reg-z/PLAYBOOK.md) | SK-REGZ-001 | TILA / Reg Z | P1 | 4 (3) | 11 | 15 | 3 | 18 |  | 25 | 0/3 | LendingSystem |
| 13 | [`ecoa-fha`](playbooks/ecoa-fha/PLAYBOOK.md) | SK-ECOA-001 | ECOA / FHA | P1 | 3 (2) | 5 | 8 | 4 | 12 | 1 | 24 | 0/1 | LendingSystem |
| 14 | [`fdcpa`](playbooks/fdcpa/PLAYBOOK.md) | SK-FDCPA-001 | FDCPA | P2 | 4 (4) | 6 | 10 | 3 | 13 |  | 24 | 0/0 | CollectionsSystem |
| 15 | [`sec-reg-sci`](playbooks/sec-reg-sci/PLAYBOOK.md) | SK-REGSCI-001 | SEC Reg SCI | P2 | 1 (0) | 3 | 4 | 6 | 10 |  | 24 | 0/1 | SecuritiesSystem |
| 16 | [`finra`](playbooks/finra/PLAYBOOK.md) | SK-FINRA-001 | FINRA Rules | P1 | 4 (3) | 8 | 12 | 2 | 14 |  | 24 | 0/3 | SecuritiesSystem |
| 17 | [`sec-form-adv`](playbooks/sec-form-adv/PLAYBOOK.md) | SK-ADV-001 | SEC Form ADV | P2 | 3 (2) | 9 | 12 | 2 | 14 |  | 24 | 0/2 | AdvisorySystem |
| 18 | [`dodd-frank`](playbooks/dodd-frank/PLAYBOOK.md) | SK-DFA-001 | Dodd-Frank Act | P2 | 2 (2) | 5 | 7 | 4 | 11 | 1 | 24 | 0/1 | CapitalEngine, SecuritiesSystem |
| 19 | [`basel`](playbooks/basel/PLAYBOOK.md) | SK-BASEL-001 | Basel Capital Requirements | P2 | 3 (3) | 8 | 11 | 3 | 14 | 6 | 24 | 0/1 | CapitalEngine |
| 20 | [`fca-handbook`](playbooks/fca-handbook/PLAYBOOK.md) | SK-FCA-001 | FCA Handbook | P1 | 1 (0) | 3 | 4 | 5 | 9 | 3 | 24 | 0/1 | CustomerJourneySystem, GovernanceSystem |
| 21 | [`mifid-ii`](playbooks/mifid-ii/PLAYBOOK.md) | SK-MIFID-001 | MiFID II | P1 | 3 (2) | 7 | 10 | 3 | 13 |  | 24 | 0/3 | SecuritiesSystem |
| 22 | [`mica`](playbooks/mica/PLAYBOOK.md) | SK-MICA-001 | MiCA (Crypto) | P1 | 5 (3) | 7 | 12 | 3 | 15 | 3 | 25 | 0/5 | CryptoSystem, CustomerJourneySystem |
| 23 | [`glba`](playbooks/glba/PLAYBOOK.md) | SK-GLBA-001 | GLBA | P1 | 2 (2) | 5 | 7 | 5 | 12 |  | 24 | 0/0 | IdentityAccessSystem, PrivacySystem |
| 24 | [`iso-27001`](playbooks/iso-27001/PLAYBOOK.md) | SK-ISO-001 | ISO 27001 | P1 | 1 (0) | 3 | 4 | 4 | 8 |  | 25 | 0/0 | GovernanceSystem |
| 25 | [`state-privacy`](playbooks/state-privacy/PLAYBOOK.md) | SK-STPRIV-001 | State Privacy Laws | P1 | 5 (4) | 11 | 16 | 1 | 17 | 15 | 52 | 0/2 | PrivacySystem |
| 26 | [`hipaa`](playbooks/hipaa/PLAYBOOK.md) | SK-HIPAA-001 | HIPAA | P2 | 5 (3) | 6 | 11 | 3 | 14 |  | 24 | 0/0 | DataProtectionSystem |
| 27 | [`fincen`](playbooks/fincen/PLAYBOOK.md) | SK-FINCEN-001 | FinCEN | P1 | 3 (2) | 7 | 10 | 3 | 13 |  | 25 | 0/3 | CryptoSystem, ComplianceCaseSystem |
| 28 | [`hmda`](playbooks/hmda/PLAYBOOK.md) | SK-HMDA-001 | HMDA | P1 | 2 (2) | 6 | 8 | 2 | 10 |  | 17 | 0/0 | MortgageSystem |
| 29 | [`cra`](playbooks/cra/PLAYBOOK.md) | SK-CRA-001 | CRA | P2 | 1 (1) | 5 | 6 | 3 | 9 | 5 | 24 | 0/0 | LendingSystem |
| 30 | [`state-insurance`](playbooks/state-insurance/PLAYBOOK.md) | SK-STINS-001 | State Insurance Regs | P2 | 4 (3) | 8 | 12 | 3 | 15 | 5 | 24 | 0/2 | InsuranceSystem |
| 31 | [`naic`](playbooks/naic/PLAYBOOK.md) | SK-NAIC-001 | NAIC | P2 | 1 (1) | 4 | 5 | 4 | 9 | 3 | 24 | 0/1 | InsuranceSystem, CapitalEngine |
| 32 | [`respa`](playbooks/respa/PLAYBOOK.md) | SK-RESPA-001 | RESPA | P2 | 3 (2) | 5 | 8 | 3 | 11 | 4 | 24 | 0/2 | MortgageSystem |
| 33 | [`trid`](playbooks/trid/PLAYBOOK.md) | SK-TRID-001 | TILA-RESPA Integrated Disclosures (TRID) | P1 | 3 (2) | 5 | 8 | 3 | 11 |  | 24 | 0/1 | MortgageSystem |
| 34 | [`irs-reporting`](playbooks/irs-reporting/PLAYBOOK.md) | SK-IRS-001 | IRS Reporting | P1 | 2 (2) | 8 | 10 | 4 | 14 |  | 34 | 0/4 | TaxReportingSystem |
| 35 | [`fatca`](playbooks/fatca/PLAYBOOK.md) | SK-FATCA-001 | FATCA | P2 | 1 (1) | 6 | 7 | 2 | 9 |  | 24 | 0/1 | OnboardingSystem, TaxReportingSystem |
| 36 | [`cost-basis`](playbooks/cost-basis/PLAYBOOK.md) | SK-COSTB-001 | Cost Basis Reporting | P2 | 2 (2) | 7 | 9 | 2 | 11 |  | 24 | 0/2 | SecuritiesSystem |
| 37 | [`ucc-article-4`](playbooks/ucc-article-4/PLAYBOOK.md) | SK-UCC4-001 | UCC Article 4 | P2 | 2 (2) | 6 | 8 | 3 | 11 |  | 24 | 0/4 | CheckSystem |
| 38 | [`ucc-article-4a`](playbooks/ucc-article-4a/PLAYBOOK.md) | SK-UCC4A-001 | UCC Article 4A | P2 | 4 (3) | 7 | 11 | 3 | 14 |  | 24 | 2/4 | WireSystem |
| 39 | [`cdd-rule`](playbooks/cdd-rule/PLAYBOOK.md) | SK-CDD-001 | CDD Rule | P1 | 2 (2) | 6 | 8 | 2 | 10 |  | 17 | 0/3 | OnboardingSystem |
| 40 | [`udaap`](playbooks/udaap/PLAYBOOK.md) | SK-UDAAP-001 | UDAAP | P1 | 5 (3) | 5 | 10 | 3 | 13 | 2 | 24 | 0/4 | FeeSystem, CustomerJourneySystem |
| 41 | [`3ds`](playbooks/3ds/PLAYBOOK.md) | SK-3DS-INLINE | EMV 3-D Secure 2.x + card-network rules (as configured); PSD2 SCA interplay | P0 | 13 (11) | 24 | 37 | 1 | 38 | 6 | 48 | 4/7 | ThreeDSecureSystem |
| 42 | [`card-fraud-stolen`](playbooks/card-fraud-stolen/PLAYBOOK.md) | SK-FRD-INLINE | Card-network fraud, reporting & chargeback rules (as configured) | P0 | 16 (15) | 29 | 45 | 2 | 47 | 5 | 52 | 6/16 | FraudDecisionSystem, CardAuthorizationSystem |
| | **Total** | | | | **184 (146)** | **380** | **564** | **136** | **700** | **59** | **1242** | | |

### By priority

| Priority | Static | Behavioural | Manual/evidence | Total |
| --- | --- | --- | --- | --- |
| P0 | 93 | 173 | 39 | 305 |
| P1 | 55 | 122 | 53 | 230 |
| P2 | 36 | 85 | 44 | 165 |

## Caveats

- The format is the neobank LOCKED manifest; these files are DRAFT. LOCKING one requires review, detector/rule code and a commit per row.
- Merging was done by hand-judgement per skill: one invariant per guard, with its positive, negative, boundary, failure, concurrency and regression scenarios folded in. Retention rows are mostly manual/evidence.
- Layer calls are proposals. Some static rows (e.g. IaC encryption, secret scanning, fee/rate config consistency) assume the relevant config lives in the repo.
- Static backstops (146) assume the guard lives in this repo's source/SQL/config. Each names a code pattern a scanner could prove (lock-in-txn, unique key, default-deny error branch, single-source config), not app-specific identifiers. A backstop never replaces its behavioural check.
- `adapters/` holds DRAFT TypeScript types only. `money-system.ts` is an assumed placeholder for the canonical interface, which was not available.
- `3ds` and `card-fraud-stolen` have no source-sheet rows. Their scenarios are generated inline (`3DS-S-nnn`, `FRD-S-nnn`) and live only in those playbooks, not in `vigil-skills`. Network schemes (ECI/liability matrices, TC40/SAFE reporting, reason codes) are configured parameters marked ⚑ SME, not asserted rule values.
- Statistical, performance, chaos/DR-drill, live-network and org-process items are manual/evidence rather than pretending to be deterministic gates.
- ⚑ SME rows are Basel, Dodd-Frank, State Privacy, CRA, NAIC RBC, RESPA, state insurance, ECOA fair lending, FCA SMCR, MiCA licensing/consumer, UDAAP abusive, 3DS liability/TRA/scope matrices and card-fraud MCC/velocity thresholds, network reporting and reason codes. Other rows with expert-input notes are listed under each playbook's Review flags.
