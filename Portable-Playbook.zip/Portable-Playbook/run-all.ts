// helix-portable — the ONE combined runner (CLI).
//
// Runs the whole locked playbook in one pass: every adapter-free STATIC detector, then every
// adapter-driven BEHAVIOURAL rule against the neobank adapter, and prints a single table with a
// LAYER column. The CI gate stays `run-static.ts` (static only, blocks on any static FINDING); this
// entry is the full picture for humans. A behavioural rule whose path the adapter does not drive
// reports NOT_EXERCISED — surfaced, never counted as a pass.
//
// Run it (no Deno needed): `npx tsx helix-portable/run-all.ts`.
import factory from "./adapters/neobank.ts";
import { runAll, formatVerdictTable } from "./run.ts";

const results = await runAll(factory);
// eslint-disable-next-line no-console
console.log(formatVerdictTable(results));

// The gate blocks on any STATIC finding; behavioural rows are informational.
const gateFailed = results.some((r) => r.layer === "static" && r.verdict.status === "FINDING");
const g = globalThis as unknown as { Deno?: { exit(code?: number): never } };
if (g.Deno) g.Deno.exit(gateFailed ? 1 : 0);
