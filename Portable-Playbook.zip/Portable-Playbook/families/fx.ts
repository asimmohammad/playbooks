// ===========================================================================================
//  FAMILY 10 — FX & MULTI-CURRENCY                           ⚠ DESIGNED — NOT VALIDATED ⚠
// ===========================================================================================
//
//  STATUS: designed-not-validated. There is NO reference implementation of a multi-currency
//  money system behind this interface yet, and these rules have NEVER RUN. Everything below is
//  a RUBRIC and a set of SIGNATURES. Nothing here executes (the detectors are ambient
//  `declare`d signatures with no bodies). Do not cite a verdict from this file — a designed
//  rule proves nothing until it runs against a real adapter and is shown to flag a known-bad
//  implementation and clear a known-good one.
//
//  WHY A NEW FAMILY: the live playbook assumes ONE currency — `Cents` is a bare integer with
//  no currency tag, so every existing rule silently treats all money as fungible. The moment a
//  second currency exists, the dangerous defect is a *type error the type system doesn't catch*:
//  adding USD cents to EUR cents produces a plausible integer that is pure nonsense. This family
//  exists to make currency a first-class part of money arithmetic and to police conversion.
//
//  INTERFACE NOTE: money-system.ts is owned elsewhere and MUST NOT be edited from here. The
//  additions below are PROPOSED as comments for a future, minimal interface PR. The central
//  move is to stop passing bare `Cents` across currency boundaries and pass a tagged `Money`:
//
//    // proposed Capability members:
//    //   MultiCurrency = "multi-currency"  // the system holds balances in >1 currency
//    //   FxConvert     = "fx-convert"       // the system converts between currencies at a sourced rate
//    //
//    // proposed types:
//    //   type CurrencyCode = string;                         // ISO-4217, e.g. "USD", "EUR", "JPY"
//    //   interface Money { amountMinor: Cents; currency: CurrencyCode; }  // tagged integer minor units
//    //   interface Rate { base: CurrencyCode; quote: CurrencyCode; ratePpm: number;   // parts-per-million, integer
//    //                     source: string; asOf: Date; }     // provenance + timestamp are REQUIRED, not optional
//    //
//    // proposed MoneySystem methods (all behind supports(cap)):
//    //   balancesOf(party: Party): Promise<Money[]>;         // one entry per currency held
//    //   quote(base: CurrencyCode, quote: CurrencyCode, at: Date): Promise<Rate | null>;  // null = no fresh rate
//    //   convert(m: Money, to: CurrencyCode, at: Date): Promise<{ out: Money; rate: Rate; roundingMinor: Cents }>;
//    //   minorUnitDigits(currency: CurrencyCode): number;    // 2 for USD/EUR, 0 for JPY — rounding precision
//
//  All amounts stay integer minor units; rates are integer parts-per-million. No float money,
//  no float rates: a rule that wants a float has found a design bug.

import type { Cents, MoneySystem, Party, Verdict } from "../money-system.ts";

/** Marker so tooling can filter unproven families out of any "what do we prove" report. */
export type FamilyStatus = "designed-not-validated";
export declare const STATUS: FamilyStatus;

/** Config a future runner would pass; part of the design, not a running default. */
export interface FxConfig {
  /** The single sanctioned rate source; a rate from anywhere else is not trusted. */
  rateSource: string;
  /** Max age of a rate, in ms, before a conversion must refuse rather than use it. */
  maxRateStalenessMs: number;
  /** Rounding rule for the result of a conversion, e.g. "round-half-even". */
  roundingRule: string;
}

// -------------------------------------------------------------------------------------------
//  THE RUBRIC — five defect classes, each a would-be detector. `declare`d (no bodies) because
//  no implementation exists to run them against. The prose is the spec to implement to.
// -------------------------------------------------------------------------------------------

/**
 * X-SINGLE-CCY — SINGLE-CURRENCY ARITHMETIC ONLY.
 * Money arithmetic (add, subtract, compare) is defined only within one currency. Two `Money`
 * values of different currencies can never be combined without an explicit conversion first.
 * METHOD: attempt, through the system, to add/compare a USD balance and a EUR balance (e.g. a
 *   transfer that would net them, a limit that would sum them); FINDING if the system produces
 *   a combined amount instead of refusing or forcing a conversion. A green result requires the
 *   operation to be rejected with a currency-mismatch, not silently summed.
 * REQUIRES: MultiCurrency.
 */
export declare function singleCurrencyArithmetic(sys: MoneySystem, cfg: FxConfig): Promise<Verdict>;

/**
 * X-RATE-SRC — RATE SOURCING & STALENESS.
 * A conversion uses a rate from cfg.rateSource whose `asOf` is within cfg.maxRateStalenessMs of
 * the clock. A missing, wrong-source, or stale rate must REFUSE the conversion — never fall back
 * to 1.0, to the last-known rate, or to a hard-coded constant.
 * METHOD: drive the clock past the staleness window (or remove the quote) and attempt convert();
 *   FINDING if the conversion succeeds, if it used a rate from another source, or if it defaulted
 *   the rate instead of refusing.
 * REQUIRES: MultiCurrency, FxConvert, Clock.
 */
export declare function rateSourcingStaleness(sys: MoneySystem, cfg: FxConfig): Promise<Verdict>;

/**
 * X-ROUND — CONVERSION ROUNDING.
 * A conversion rounds EXACTLY ONCE, by cfg.roundingRule, at the target currency's minor-unit
 * precision (minorUnitDigits), and surfaces the sub-unit residual as its own `roundingMinor`
 * so value is neither minted nor lost. Round-trip convert(A→B→A) loses at most one minor unit
 * and is accounted for.
 * METHOD: convert an amount whose exact image has a sub-unit tail (and a JPY case: 0 digits);
 *   FINDING if the result is rounded twice (intermediate + final), rounded at the wrong
 *   precision, or if out + roundingMinor ≠ the exact converted value.
 * REQUIRES: MultiCurrency, FxConvert.
 */
export declare function conversionRounding(sys: MoneySystem, cfg: FxConfig): Promise<Verdict>;

/**
 * X-NET — NETTING CORRECTNESS.
 * Netting a set of cross-currency obligations nets PER CURRENCY first, then converts the per-
 * currency nets — it never sums amounts across currencies before converting. The order matters:
 * convert-then-net and net-then-convert differ by rounding, and only per-currency netting is
 * correct.
 * METHOD: present a basket of obligations in two+ currencies; FINDING if the system's net
 *   differs from (net each currency, then convert each net once), or if it produced a single
 *   cross-currency sum at any intermediate step.
 * REQUIRES: MultiCurrency, FxConvert.
 */
export declare function nettingCorrectness(sys: MoneySystem, cfg: FxConfig): Promise<Verdict>;

/**
 * X-NO-MIX — NO MIXED-CURRENCY LEDGER OPS.
 * Within a single ledger transaction every posting line is the same currency; a cross-currency
 * movement is modeled as an explicit conversion with its own rounding line, not as one txn whose
 * debits and credits are in different currencies (which cannot balance meaningfully).
 * METHOD: inspect the lines of a cross-currency flow's ledger txn(s); FINDING if any one txn
 *   mixes currencies across its lines, or if a conversion has no explicit rounding line to
 *   absorb the residual.
 * REQUIRES: MultiCurrency, Ledger.
 */
export declare function noMixedCurrencyOps(sys: MoneySystem, cfg: FxConfig): Promise<Verdict>;

/** The family's rule set, in the shape a future runner would consume. Declared, never built. */
export interface FxFamily {
  readonly status: FamilyStatus;
  readonly detectors: ReadonlyArray<(sys: MoneySystem, cfg: FxConfig) => Promise<Verdict>>;
}
export declare const FX_FAMILY: FxFamily;

// `Cents` and `Party` are imported for the signatures and the proposed interface additions,
// anchoring this design to the same integer-money vocabulary — the eventual implementation adds
// a currency tag to money, it never relaxes money into a float.
export type { Cents, Party };
