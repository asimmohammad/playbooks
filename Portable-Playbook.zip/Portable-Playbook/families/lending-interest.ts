// ===========================================================================================
//  FAMILY 9 — LENDING & INTEREST                              ⚠ DESIGNED — NOT VALIDATED ⚠
// ===========================================================================================
//
//  STATUS: designed-not-validated. There is NO reference implementation of a lending system
//  behind this interface yet, and these rules have NEVER RUN against code. Everything below
//  is a RUBRIC and a set of SIGNATURES — a design for how the family would be checked once an
//  adapter exists. Nothing here executes (the detectors are ambient `declare`d signatures).
//  Do not cite a verdict from this file: a designed rule proves nothing until it runs on a
//  real adapter and is shown to flag a known-bad implementation and clear a known-good one.
//
//  WHY A NEW FAMILY: lending introduces a time-integral of money (interest) and a stateful
//  obligation (a loan balance with a schedule). Its defects are not variants of transfer or
//  ledger defects — they are about the *arithmetic of accrual over time* and the *legal
//  envelope* around it. Hence a family of its own.
//
//  INTERFACE NOTE: these rules need capabilities the canonical `MoneySystem` does not yet
//  carry. money-system.ts is owned elsewhere and MUST NOT be edited from here; the additions
//  below are PROPOSED (shown as comments) so a future interface PR can add them minimally,
//  one capability at a time, the way the existing surface grew.
//
//    // proposed Capability members:
//    //   Lending   = "lending"    // can open a loan/credit line and read its schedule + balance
//    //   Interest  = "interest"   // can run interest accrual/posting deterministically via the clock
//    //
//    // proposed types:
//    //   type Rate = { bps: number };                 // basis points; integer, no float rate math
//    //   type Period = { startAt: Date; endAt: Date };
//    //   interface Loan { id: string; principalCents: Cents; apr: Rate; openedAt: Date; }
//    //   interface ScheduleRow { period: Period; dueCents: Cents; principalCents: Cents;
//    //                           interestCents: Cents; feeCents: Cents; endingBalanceCents: Cents; }
//    //   interface Payment { atCents: Cents; postedAt: Date; }
//    //
//    // proposed MoneySystem methods (all behind supports(cap)):
//    //   openLoan(party: Party, spec: { principalCents: Cents; apr: Rate; termPeriods: number }): Promise<Loan>;
//    //   schedule(loan: Loan): Promise<ScheduleRow[]>;        // the amortization plan
//    //   accrueInterest(loan: Loan, through: Date): Promise<Cents>;   // deterministic; driven by clock
//    //   applyPayment(loan: Loan, p: Payment): Promise<{ toFees: Cents; toInterest: Cents; toPrincipal: Cents; balanceCents: Cents }>;
//    //   loanBalance(loan: Loan): Promise<Cents>;
//
//  All amounts are integer minor units (`Cents`); rates are integer basis points. A rule that
//  needs a float has found a bug in the design, not a reason to use a float.

import type { Cents, MoneySystem, Party, Verdict } from "../money-system.ts";

/** Marker so tooling and humans can filter unproven families out of any "what do we prove" report. */
export type FamilyStatus = "designed-not-validated";
export declare const STATUS: FamilyStatus;

/** Config a future runner would pass; shape is part of the design, not a running default. */
export interface LendingConfig {
  /** How a payment is split when it does not cover everything due. Policy, not a guess. */
  allocationOrder: ReadonlyArray<"fees" | "interest" | "principal">;
  /** Day-count / rounding convention the accrual must match exactly, e.g. "actual/365, round-half-even". */
  accrualConvention: string;
  /** Hard legal ceiling on effective APR (incl. fees), in basis points. */
  usuryCapBps: number;
  /** Whether the product is permitted to negatively amortize at all (almost always false). */
  allowNegativeAmortization: boolean;
}

// -------------------------------------------------------------------------------------------
//  THE RUBRIC — six defect classes, each a would-be detector.
//
//  Each detector is written to DRIVE the system through the (proposed) interface and read
//  back outcomes — exactly like a live behavioral rule — and to return a Verdict. They are
//  `declare`d (no bodies) because no implementation exists to run them against. The prose on
//  each is the spec a future author implements to.
// -------------------------------------------------------------------------------------------

/**
 * L-ACCRUE-DET — ACCRUAL DETERMINISM.
 * Running accrual twice over the identical (principal, rate, period, basis) yields the
 * identical cents, and the result is independent of wall-clock, timezone, and call count.
 * METHOD: open a loan; set the clock; accrueInterest(loan, T) twice (reset between);
 *   FINDING if the two results differ, if a second accrual for an already-accrued day adds
 *   anything (double-accrual), or if changing only the system timezone changes the cents.
 * REQUIRES: Lending, Interest, Clock.
 */
export declare function accrualDeterminism(sys: MoneySystem, cfg: LendingConfig): Promise<Verdict>;

/**
 * L-ALLOC-ORDER — PAYMENT-ALLOCATION ORDER.
 * A payment is applied strictly in cfg.allocationOrder (e.g. fees → interest → principal).
 * A partial payment must never reduce principal while interest or fees are outstanding.
 * METHOD: open a loan, accrue interest and a fee, applyPayment() for less than the total due;
 *   FINDING if toPrincipal > 0 while (toInterest < interestDue || toFees < feesDue), or if
 *   the split does not follow cfg.allocationOrder, or if the three legs do not sum to the
 *   payment amount.
 * REQUIRES: Lending, Interest.
 */
export declare function paymentAllocationOrder(
  sys: MoneySystem,
  cfg: LendingConfig,
): Promise<Verdict>;

/**
 * L-SCHED-INT — SCHEDULE INTEGRITY.
 * The amortization schedule closes: Σ principalCents over rows === opening principal;
 * Σ interestCents === total interest the accrual would produce for the same plan; each row's
 * endingBalance === prior balance − row.principalCents; and the final row's endingBalance
 * === 0 (no stranded cent, no overpay).
 * METHOD: openLoan(); schedule(); fold the rows; FINDING on any mismatch or a non-zero final
 *   balance.
 * REQUIRES: Lending.
 */
export declare function scheduleIntegrity(sys: MoneySystem, cfg: LendingConfig): Promise<Verdict>;

/**
 * L-ROUND — ROUNDING OF INTEREST.
 * Per-period interest is rounded by exactly one declared rule (cfg.accrualConvention) and the
 * sub-cent residual is carried, so Σ(rounded per-period interest) === the exactly-computed
 * total interest — rounding neither leaks nor mints cents.
 * METHOD: pick a principal/rate/term whose exact interest has a sub-cent tail; sum the
 *   schedule's interest legs; FINDING if the rounded sum ≠ the exact total, or if any period
 *   is rounded by a different rule than its neighbours.
 * REQUIRES: Lending, Interest.
 */
export declare function interestRounding(sys: MoneySystem, cfg: LendingConfig): Promise<Verdict>;

/**
 * L-APR-CAP — APR / USURY CAP.
 * The effective APR — the rate that makes the scheduled cash-flows net to the principal,
 * INCLUDING fees, not the nominal note rate — never exceeds cfg.usuryCapBps.
 * METHOD: derive the effective APR from schedule() + any origination/periodic fees; FINDING
 *   if effectiveAprBps > cfg.usuryCapBps. (A product that discloses a nominal rate under the
 *   cap but whose fee-inclusive APR breaches it is the exact defect this catches.)
 * REQUIRES: Lending.
 */
export declare function aprUsuryCap(sys: MoneySystem, cfg: LendingConfig): Promise<Verdict>;

/**
 * L-NO-NEGAM — NO NEGATIVE AMORTIZATION.
 * Unless cfg.allowNegativeAmortization, every scheduled payment covers at least that period's
 * interest, so the principal balance is non-increasing period over period.
 * METHOD: scan schedule() for any row where interestCents > dueCents (unpaid interest
 *   capitalized) or endingBalance > prior balance; FINDING unless explicitly permitted.
 * REQUIRES: Lending.
 */
export declare function noNegativeAmortization(
  sys: MoneySystem,
  cfg: LendingConfig,
): Promise<Verdict>;

/** The family's rule set, in the shape a future runner would consume. Declared, never built. */
export interface LendingFamily {
  readonly status: FamilyStatus;
  readonly detectors: ReadonlyArray<(sys: MoneySystem, cfg: LendingConfig) => Promise<Verdict>>;
}
export declare const LENDING_FAMILY: LendingFamily;

// Note: `Cents` and `Party` are imported for the signatures above and in the proposed
// interface additions; they anchor this design to the same integer-money vocabulary the live
// families use, so the eventual implementation cannot drift into float or untyped money.
export type { Cents, Party };
