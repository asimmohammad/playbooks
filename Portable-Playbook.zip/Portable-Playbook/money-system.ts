// helix-portable — the canonical MoneySystem interface.
//
// This is the KEYSTONE of a scalable money-correctness playbook. A behavioural rule is
// written ONCE against this interface and then runs against ANY money app through a thin
// adapter that implements MoneySystem. The rule never learns an app's route strings,
// method names, table names or field names — it speaks only in CAPABILITIES:
//
//     "issue an instrument to this party and tell me the outcome"
//
// not
//
//     "POST /cards" / "addFamilyMember then issueCard" / "invite then acceptInvite".
//
// That indirection is the whole point: the behavioural rules get a standard plug instead
// of a soldered one, so they stop being neobank-only. A neobank-direct adapter binds
// issueInstrumentToParty to addFamilyMember+issueCard; an invite-flow adapter binds the
// same call to invite+acceptInvite. The rule is identical for both.
//
// Design constraints:
//   - MINIMAL. This surface carries only what the three shipped rules (PARTY-SCREEN,
//     NO-ORPHAN, LEDGER-CONSERVE) actually exercise. It is expected to grow, one
//     capability at a time, as more rules are ported. Resist adding speculative methods.
//   - CAPABILITY-NEGOTIATED. A system that cannot do something a rule needs is not a
//     failure: the rule returns NOT_APPLICABLE after asking supports(cap).
//   - OUTCOME-ORIENTED. Calls return structured outcomes (ok / refusedReason / ids)
//     rather than throwing for expected refusals, so a rule reasons about results instead
//     of catching app-specific exceptions.

// ---------------------------------------------------------------------------------------
// Scalar aliases
// ---------------------------------------------------------------------------------------

/** Minor currency units (e.g. US cents). Integer. */
export type Cents = number;

// ---------------------------------------------------------------------------------------
// Capabilities — the unit of negotiation
// ---------------------------------------------------------------------------------------

/**
 * What a MoneySystem implementation can do. A rule declares the capabilities it needs
 * (`Rule.requires`) and double-checks at runtime with `sys.supports(cap)`; when a needed
 * capability is missing it returns NOT_APPLICABLE rather than a false FINDING.
 */
export enum Capability {
  /** Can mint test actors/parties on demand (createActor). */
  CreateActor = "create-actor",
  /** Can set a party's compliance standing: KYC pass/fail and sanctions hit (setEligibility). */
  Eligibility = "eligibility",
  /** Can attempt to issue a money instrument to a party and report the outcome. */
  IssueInstrument = "issue-instrument",
  /** Exposes the status of the external provider object behind an instrument. */
  ExternalObjects = "external-objects",
  /** Can inject faults at named points for failure-mode testing (injectFailure). */
  FaultInjection = "fault-injection",
  /** Exposes the double-entry ledger: a money-flow battery + trial balance + per-txn lines. */
  Ledger = "ledger",
  /** Exposes a controllable clock. */
  Clock = "clock",

  // --- added for the behavioural ports below -------------------------------------------

  /** Has a pre-seeded, funded principal whose balance can be read and moved (balance / move / principal). */
  MoveMoney = "move-money",
  /** Enforces exactly-once money: an unkeyed money op is refused, a replay with the same key is inert. */
  IdempotencyKeys = "idempotency-keys",
  /** Can authorise+capture a charge against an instrument (levying any fee) and refund it (authorizeAndCapture / refund). */
  Charge = "charge",
  /** Can recover a captured charge through a chargeback/dispute in the party's favour (disputeAndRecover). */
  Chargeback = "chargeback",
  /** Ingests money-moving events from an UNTRUSTED external channel and authenticates them before any effect. */
  ExternalEventAuth = "external-event-auth",
  /** Can run a terminal money op that also makes an irreversible external call, with the durable commit faulted. */
  CommitOrdering = "commit-ordering",
}

// ---------------------------------------------------------------------------------------
// Parties & eligibility
// ---------------------------------------------------------------------------------------

/** How to mint an actor. The adapter maps this onto whatever "create a user" means locally. */
export interface ActorSpec {
  /** Legal/display name. Adapters that screen sanctions by name key off this. */
  legalName: string;
  /** Optional contact address. Invite-flow adapters bind an invitation to this. */
  email?: string;
}

/** An opaque handle to an actor. Only the issuing MoneySystem interprets `id`. */
export interface Party {
  id: string;
  /** Human label for verdict output. Never used for lookups. */
  label?: string;
}

/**
 * A party's compliance standing, stated as intent. HOW a system realises it — a sanctions
 * name list, a KYC vendor stub, an admin override — is the adapter's concern.
 */
export interface Eligibility {
  /** true = the party has passed KYC and may hold money; false = unverified/rejected. */
  kyc: boolean;
  /** true = the party is a sanctions/watch-list hit. */
  sanctioned: boolean;
}

// ---------------------------------------------------------------------------------------
// Instruments & external objects
// ---------------------------------------------------------------------------------------

/**
 * Normalised lifecycle status of a money instrument (card, wallet, account…), independent
 * of any app's own vocabulary. "active" is the only status that means the party can move
 * money right now.
 */
export type InstrumentStatus =
  | "active"
  | "inactive" // issued but not usable (e.g. physical card awaiting activation)
  | "pending" // requested, not yet issued
  | "scheduled" // issued with a future start date; not yet usable
  | "canceled";

/** A money instrument held by a party. */
export interface Instrument {
  id: string;
  status: InstrumentStatus;
  /** Id of the external provider object (issuer card, etc.) behind this instrument, if any. */
  externalId?: string;
}

/** Status of an external provider object, as the provider reports it. */
export type ExternalStatus = "active" | "inactive" | "canceled";

/** Options for an issuance attempt. All optional; adapters apply sensible defaults. */
export interface IssueOpts {
  /** Abstract instrument class (e.g. "virtual" / "physical"); adapter-interpreted. */
  instrumentKind?: string;
  /** Future activation time. Adapters that support scheduled start map onto this. */
  scheduledStartAt?: Date;
}

/**
 * The outcome of issueInstrumentToParty.
 *
 * Contract for failure-mode rules: `externalId` is populated WHENEVER an external provider
 * object was created, INCLUDING when the overall issuance then failed (record-write error,
 * injected fault). So `ok: false` together with a set `externalId` means "the provider
 * object exists but no durable record was committed" — exactly the orphan NO-ORPHAN hunts.
 * On an expected refusal (screening, policy) nothing is created, so `externalId` is absent.
 */
export interface IssueOutcome {
  /** true = a durable, consistent instrument record now exists. */
  ok: boolean;
  /** The instrument id, when one was durably created. */
  instrumentId?: string;
  /** The external provider object id, when one was created (even if the op then failed). */
  externalId?: string;
  /** Stable, machine-ish reason for a refusal or failure (e.g. "member_screening_failed"). */
  refusedReason?: string;
}

// ---------------------------------------------------------------------------------------
// Clock & fault injection
// ---------------------------------------------------------------------------------------

/** A controllable clock. Adapters drive deterministic time-dependent flows through it. */
export interface Clock {
  now(): Date;
  /** Jump forward by `ms` milliseconds. */
  advance(ms: number): void;
  /** Set absolute time. */
  set(at: Date): void;
}

/**
 * A named point at which a fault can be injected. Open-ended on purpose; the one the
 * shipped rules need is "post-create-db": fail the durable record-write that is supposed
 * to happen *after* the external provider object has been created.
 */
export type FailurePoint = "post-create-db" | (string & {});

// ---------------------------------------------------------------------------------------
// Ledger surface
// ---------------------------------------------------------------------------------------

/** One posting line of a ledger transaction. Account/party are opaque labels. */
export interface LedgerLine {
  account?: string;
  party?: string | null;
  debit: Cents;
  credit: Cents;
}

/** A ledger transaction: a set of lines that must net to zero (debits === credits). */
export interface LedgerTxn {
  id: string;
  kind: string;
  lines: LedgerLine[];
}

// ---------------------------------------------------------------------------------------
// Behavioural-port surfaces (move / charge / chargeback / events / commit-ordering)
//
// Each cluster below is the MINIMAL capability one of the six additional behavioural rules
// needs (N-ATOMIC, N-IDEMP, N-CHGBK-05, N-RWD-04, N-AUTHN, N-ORDER-01). As with the rest of
// the interface these speak in intent ("move money out of this party", "recover this charge
// through a chargeback"), never in an app's routes, tables or method names.
// ---------------------------------------------------------------------------------------

/** A party's money position, in minor units. */
export interface Balance {
  /** Settled/posted balance. */
  postedCents: Cents;
  /** Spendable right now (posted minus active holds). */
  availableCents: Cents;
}

/** Options for a generic money move. */
export interface MoveOpts {
  /** Exactly-once key. Omitted => the adapter supplies a fresh one, UNLESS `withoutKey` is set. */
  idempotencyKey?: string;
  /** Deliberately submit with NO idempotency key, to check the system refuses an unkeyed money op. */
  withoutKey?: boolean;
}

/** Outcome of a generic money move. Does NOT throw for an expected refusal. */
export interface MoveOutcome {
  /** true = money moved (or, on a replay, the first call's effect stands). */
  ok: boolean;
  /** true = this call returned a prior result for the same key WITHOUT moving money again. */
  replayed?: boolean;
  /** Stable reason for a refusal (e.g. "insufficient_funds", "idempotency_key_required"). */
  refusedReason?: string;
}

/** How to authorise+capture a charge against a party's instrument. */
export interface ChargeSpec {
  /** Authorised amount. */
  amountCents: Cents;
  /** Captured amount; defaults to amountCents. A partial capture settles less than authorised. */
  captureCents?: Cents;
  /** Cross-border / fee-bearing charge (adapters that levy an FX fee key off this). */
  foreign?: boolean;
  /** Abstract merchant category; adapter-interpreted (maps onto an MCC, a product code, …). */
  category?: string;
}

/** A captured charge plus the fee actually levied AT CAPTURE. */
export interface Charge {
  ok: boolean;
  /** Opaque handle to the captured charge; only the issuing system interprets it. */
  id: string;
  capturedCents: Cents;
  /** Fee charged at capture time (0 when none). */
  feeCents: Cents;
  refusedReason?: string;
}

/** Outcome of a refund against a captured charge. */
export interface RefundOutcome {
  ok: boolean;
  refusedReason?: string;
}

/** Outcome of recovering a captured charge through a chargeback/dispute. */
export interface Recovery {
  ok: boolean;
  /** Amount credited back to the party. */
  recoveredCents: Cents;
  refusedReason?: string;
}

/** An untrusted money-moving event delivered from outside (e.g. a provider webhook). */
export interface ExternalEvent {
  /** Abstract event type; adapter-interpreted. */
  kind: string;
  payload: Record<string, unknown>;
}

/** How an external event is authenticated on delivery. */
export interface EventAuth {
  /** Whether the event carries a VALID authenticator (e.g. a good signature). */
  valid: boolean;
  /** Deliver with a timestamp this many ms away from "now", to probe the replay window. */
  staleByMs?: number;
}

/** The result of delivering an external event. */
export interface EventOutcome {
  /** The system accepted the event (a 2xx). */
  accepted: boolean;
  /** The event produced a durable money effect. */
  effectApplied: boolean;
  rejectedReason?: string;
}

/** Evidence about commit-vs-external-call ordering for a terminal money operation. */
export interface OrderProbe {
  /** The durable-commit boundary was actually reached (so the probe is meaningful). */
  reachedCommit: boolean;
  /** The durable commit landed (expected false when the commit is faulted). */
  committed: boolean;
  /** Irreversible external effects that happened although the commit did NOT land — each is a violation. */
  externalEffectsBeforeCommit: string[];
}

// ---------------------------------------------------------------------------------------
// The interface
// ---------------------------------------------------------------------------------------

/**
 * The canonical money system. Every rule receives one of these and nothing else. An
 * adapter is a factory that returns a fresh, seeded MoneySystem (see MoneySystemFactory).
 */
export interface MoneySystem {
  /** Capability negotiation. A rule asks before using anything optional. */
  supports(cap: Capability): boolean;

  /** Return the system to a clean, seeded baseline (e.g. an approved owner, zero ledger). */
  reset(): Promise<void>;

  /** The controllable clock (present iff supports(Capability.Clock)). */
  readonly clock: Clock;

  /** Mint an actor. Requires Capability.CreateActor. */
  createActor(spec: ActorSpec): Promise<Party>;

  /** Establish a party's compliance standing. Requires Capability.Eligibility. */
  setEligibility(party: Party, eligibility: Eligibility): Promise<void>;

  /**
   * Attempt to issue a money instrument to `party`, by whatever path the app provides
   * (direct issuance, invite+accept, …). Returns the outcome; does NOT throw for expected
   * refusals. Requires Capability.IssueInstrument.
   */
  issueInstrumentToParty(party: Party, opts?: IssueOpts): Promise<IssueOutcome>;

  /** Every instrument currently held by `party`. Requires Capability.IssueInstrument. */
  listInstruments(party: Party): Promise<Instrument[]>;

  /**
   * The current status of an external provider object, or null if it no longer / never
   * existed. Requires Capability.ExternalObjects.
   */
  externalObjectStatus(externalId: string): Promise<ExternalStatus | null>;

  /** Arm a fault at `point`; it fires on the next operation that reaches it. Requires Capability.FaultInjection. */
  injectFailure(point: FailurePoint): void;

  /**
   * Run a deterministic battery of ordinary money flows (deposits, transfers, moves, …).
   * Requires Capability.Ledger.
   */
  runMoneyFlows(): Promise<void>;

  /** Sum of (debit - credit) across ALL ledger lines. Must be 0. Requires Capability.Ledger. */
  trialBalance(): Promise<Cents>;

  /** Every ledger transaction with its lines, for per-txn balance checks. Requires Capability.Ledger. */
  ledgerTransactions(): Promise<LedgerTxn[]>;

  // --- behavioural-port methods --------------------------------------------------------

  /**
   * The system's pre-seeded principal: an approved, funded party that already holds a usable
   * instrument. Rules that need to transact (move / charge / chargeback) use this rather than
   * minting a bare party. Meaningful when supports(MoveMoney) or supports(Charge).
   */
  principal(): Promise<Party>;

  /** Read a party's balance. Requires Capability.MoveMoney. */
  balance(party: Party): Promise<Balance>;

  /**
   * Move `cents` out of `party`'s balance by whatever ordinary debit path the app provides —
   * all-or-nothing and cap-enforced. Returns the outcome; does NOT throw for expected refusals.
   * Requires Capability.MoveMoney.
   */
  move(party: Party, cents: Cents, opts?: MoveOpts): Promise<MoveOutcome>;

  /** Authorise then capture a charge against `party`'s primary instrument. Requires Capability.Charge. */
  authorizeAndCapture(party: Party, spec: ChargeSpec): Promise<Charge>;

  /** Refund `cents` against a captured charge. Requires Capability.Charge. */
  refund(charge: Charge, cents: Cents): Promise<RefundOutcome>;

  /**
   * Recover a captured charge through a full chargeback/dispute decided in the party's favour
   * (open -> credit -> resolve won). Does NOT throw for an expected refusal. Requires Capability.Chargeback.
   */
  disputeAndRecover(charge: Charge, cents: Cents): Promise<Recovery>;

  /** Deliver an untrusted external money event with the given authentication. Requires Capability.ExternalEventAuth. */
  deliverExternalEvent(event: ExternalEvent, auth: EventAuth): Promise<EventOutcome>;

  /**
   * Run a terminal money operation that moves the principal's money out AND makes an irreversible
   * external call, with the durable commit faulted, then report the ordering evidence. A correct
   * system commits BEFORE any irreversible external call, so a faulted commit leaves the external
   * side untouched. Requires Capability.CommitOrdering.
   */
  retireWithCommitFault(): Promise<OrderProbe>;
}

/** An adapter: a factory that yields a fresh, isolated, seeded MoneySystem per rule run. */
export type MoneySystemFactory = () => MoneySystem | Promise<MoneySystem>;

// ---------------------------------------------------------------------------------------
// Verdicts & rules
// ---------------------------------------------------------------------------------------

/**
 * The terminal states of a rule run:
 *   - CHECKED        the guard's code path RAN and the property held. A pass means "proven",
 *                    never "nothing went wrong while we weren't looking".
 *   - FINDING        the property was exercised and was violated.
 *   - NOT_APPLICABLE the system lacks a capability the rule needs; nothing was concluded.
 *   - NOT_EXERCISED  the rule could not actually DRIVE the guard's code path (the adapter never
 *                    touched the surface, a precondition could not be staged, …), so the property
 *                    was neither confirmed nor refuted. This is NOT a pass. It exists because a
 *                    behavioural rule that silently returns CHECKED without running the path gives
 *                    a FALSE GREEN: on a large new PR the hand-written adapter often never reaches a
 *                    brand-new surface, and "we didn't see a violation" must not read as "safe".
 *                    A rule MUST return NOT_EXERCISED (not CHECKED) whenever it did not reach the
 *                    very path it exists to prove. Static detectors never return this: they scan
 *                    the source and always run, independent of any adapter.
 */
export type VerdictStatus = "CHECKED" | "FINDING" | "NOT_APPLICABLE" | "NOT_EXERCISED";

export interface Verdict {
  status: VerdictStatus;
  /** One-line human explanation shown in the verdict table. */
  reason: string;
  /** Optional structured evidence for logs / triage. */
  detail?: Record<string, unknown>;
}

export const checked = (reason: string, detail?: Record<string, unknown>): Verdict => ({
  status: "CHECKED",
  reason,
  detail,
});
export const finding = (reason: string, detail?: Record<string, unknown>): Verdict => ({
  status: "FINDING",
  reason,
  detail,
});
export const notApplicable = (reason: string, detail?: Record<string, unknown>): Verdict => ({
  status: "NOT_APPLICABLE",
  reason,
  detail,
});
/**
 * The rule could not drive its guard's code path, so nothing was proven. Return this — never
 * `checked` — when the path the rule exists to exercise was not actually reached. It is surfaced
 * as "not proven" and is never counted as a pass.
 */
export const notExercised = (reason: string, detail?: Record<string, unknown>): Verdict => ({
  status: "NOT_EXERCISED",
  reason,
  detail,
});

/**
 * A portable behavioural rule. `run` receives a MoneySystem and returns a Verdict. A rule
 * MUST import only this module — never app code, never a literal route/method/field name.
 *
 * Verdict discipline: return `checked` ONLY after the guard's path actually ran and held. If the
 * path could not be driven (the adapter never reached the surface, a precondition could not be
 * staged), return `notExercised` — a false green is worse than an honest "not proven". When a
 * capability the rule needs is simply absent, return `notApplicable`. A guard that fires regardless
 * of adapter coverage belongs in a static detector (see StaticDetector), not here.
 */
export interface Rule {
  /** Stable id, e.g. "PARTY-SCREEN". */
  id: string;
  /** One-line statement of the invariant. */
  title: string;
  /** Capabilities the rule needs; the runner short-circuits to NOT_APPLICABLE if any is missing. */
  requires: Capability[];
  run(sys: MoneySystem): Promise<Verdict>;
}
