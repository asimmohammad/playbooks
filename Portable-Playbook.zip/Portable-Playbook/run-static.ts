// helix-portable — CI entry for the static detectors (the auto-gate).
//
// The static detectors (N-DEPLOY-01, N-PARITY-01, N-CAP-01, N-TEST-01) are pure source
// scanners: no adapter, no running MoneySystem, no per-PR setup. This entry runs them against
// the repo and exits non-zero on any FINDING, so `.github/workflows/helix-portable.yml` can gate
// every PR on them automatically. The behavioural rules (which need an adapter) run as a separate
// step through the app adapter.
import { runStaticDetectors, formatVerdictTable } from "./run.ts";

const results = runStaticDetectors();
// eslint-disable-next-line no-console
console.log(formatVerdictTable(results));
const anyFinding = results.some((r) => r.verdict.status === "FINDING");
const g = globalThis as unknown as { Deno?: { exit(code?: number): never } };
if (g.Deno) g.Deno.exit(anyFinding ? 1 : 0);
