// gate.ts — the committed CONFORMANCE HARNESS for the money-correctness detectors.
//
//   node --experimental-transform-types gate.ts     (or: npm run gate / deno task gate)
//
// Every detector must hold its three-way gate, deterministically and with no fs / no LLM:
//   FINDING@vulnerable   — it fires on a fixture that HAS the money bug,
//   CHECKED@fixed        — it stays quiet (no violation) on a fixture where the guard is in place,
//   NOT_APPLICABLE@absent — it is dormant on a fixture where the invariant does not apply.
// Each gate/cases/<check>.ts drives the detector's PURE scan over tiny in-memory fixtures and returns
// { check, vulnerable, fixed, absent }. This file runs them all and EXITS NON-ZERO if any gate fails —
// wire it into CI so a detector that stops catching its bug (regression) or starts false-positiving on a
// fix blocks the merge. This is what makes "deterministic and proven" true instead of prose.

import nScoreHonest from "./gate/cases/n-score-honest.ts";
import nPassthruLiab from "./gate/cases/n-passthru-liab.ts";
import nObligDup from "./gate/cases/n-oblig-dup.ts";
import nTenantIso from "./gate/cases/n-tenant-iso.ts";
import nGlTie from "./gate/cases/n-gl-tie.ts";
import nSod from "./gate/cases/n-sod.ts";
import nOnce from "./gate/cases/n-once.ts";
import nCardFresh from "./gate/cases/n-card-fresh.ts";
import nLifecycle from "./gate/cases/n-lifecycle.ts";
import nAudit from "./gate/cases/n-audit.ts";
import nRouteUnique from "./gate/cases/n-route-unique.ts";
import nDeployBackfill from "./gate/cases/n-deploy-backfill.ts";
import nOrder from "./gate/cases/n-order.ts";
import nFxCompare from "./gate/cases/n-fx-compare.ts";
import nEnumFailClosed from "./gate/cases/n-enum-failclosed.ts";
import nWriteCheck from "./gate/cases/n-write-check.ts";
import nAccountValid from "./gate/cases/n-account-valid.ts";
import nPiiProjection from "./gate/cases/n-pii-projection.ts";
import nFailClosedRead from "./gate/cases/n-failclosed-read.ts";
import nAging from "./gate/cases/n-aging.ts";
import nAggStatus from "./gate/cases/n-agg-status.ts";
import nRejectCascade from "./gate/cases/n-reject-cascade.ts";

type CaseResult = { check: string; vulnerable: boolean; fixed: boolean; absent: boolean; notes?: string };

const cases: Array<() => CaseResult> = [
  nScoreHonest, nPassthruLiab, nObligDup, nTenantIso, nGlTie, nSod, nOnce, nCardFresh,
  nLifecycle, nAudit, nRouteUnique, nDeployBackfill, nOrder, nFxCompare, nEnumFailClosed,
  nWriteCheck, nAccountValid, nPiiProjection, nFailClosedRead, nAging, nAggStatus, nRejectCascade,
] as unknown as Array<() => CaseResult>;

const mark = (b: boolean): string => (b ? "✓" : "✗");
let fail = 0;
console.log("\n=== money-detector conformance gate (FINDING@vuln · CHECKED@fix · NA@absent) ===\n");
for (const run of cases) {
  let r: CaseResult;
  try {
    r = run();
  } catch (e) {
    r = { check: "(threw)", vulnerable: false, fixed: false, absent: false, notes: String((e as Error)?.message ?? e).slice(0, 140) };
  }
  const ok = r.vulnerable && r.fixed && r.absent;
  if (!ok) fail++;
  console.log(
    `[${ok ? "PASS" : "FAIL"}] ${String(r.check).padEnd(20)} vuln:${mark(r.vulnerable)} fix:${mark(r.fixed)} absent:${mark(r.absent)}` +
      (r.notes ? `  — ${r.notes}` : ""),
  );
}
console.log(`\n==== ${cases.length - fail}/${cases.length} detectors conformant ====`);
if (fail) console.log(`    ${fail} detector(s) FAILED their 3-way gate — the gate is not trustworthy until these are green.`);

const g = globalThis as unknown as { Deno?: { exit(code?: number): never } };
if (g.Deno) g.Deno.exit(fail ? 1 : 0);
else process.exitCode = fail ? 1 : 0;
