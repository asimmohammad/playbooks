# pmar onboarding — work log (for Zak)

How we brought the **pmar** repo under the portable money-correctness playbook, built the first
deterministic checks for it, and tested whether a cheaper model can do the review. Everything below
is on the **`main`** branch of `Portable-Playbook` (the hardening since then is on **`main`**).

---

## TL;DR
- **pmar is bound** to the playbook (one ~30-line "card").
- **8 deterministic money checks** built, gate-verified, and shipped to `v3`. 7 flag real bugs on pmar's current head; 1 (card-freshness) confirms the card is in sync.
- Ran a **blind cost experiment** (Haiku vs Opus) on the pmar PR to decide model/cost strategy.
- All of it lives on **`main`** — code, runner, manifest, backlog, and the onboarding RUNBOOK.

---

## What I did, step by step

### 1. Deep-dived pmar to find its money surface
Ran **7 parallel agents**, one per money domain (double-entry ledger · idempotency/executor · cards & expenses · AP/AR · reconciliation · tax · connectors). Each returned: the money flows, the invariants that must hold, which of our existing primitives already cover them, and the **new** bug classes pmar reveals.
→ Output: **24 candidate money-bug "primitives,"** deduped into 5 clusters, saved as `CANDIDATES.md`.

### 2. Bound pmar to the playbook (the "card")
Wrote **`adapters/pmar.ts`** — the money-surface manifest (pmar's money tables, service folders, schema file, HTTP entry) plus a money-touch skip-gate.
Key fact: **pmar's money logic is TypeScript** (schema embedded in `src/lib/db.ts`), *not* SQL migrations like neobank — so pmar's checks are **TS-source scanners**. Same invariant as neobank's, different reader.

### 3. Built + gated 8 deterministic checks (2 batches)
Each check is a small TS scanner that reads pmar's source for **one** money mistake. Every check had to pass the **gate** before landing:
> **FINDING** on pmar's real bug  ∧  **CHECKED** on a fixed fixture  ∧  **NOT_APPLICABLE** where the flow is absent.

I **re-verified every gate myself** (did not trust the build agents' self-reports). That discipline paid off: it caught (a) the card wrongly listing tables pmar doesn't have, and (b) a bad test on the freshness check. Nothing landed until it was green in my own re-run.

The 8 checks (`static/n-*.ts`):
| Check | Catches |
|---|---|
| N-SCORE-HONEST | a reconciliation score that reads "perfect" while money is unaccounted for |
| N-PASSTHRU-LIAB | tax booked as revenue instead of a liability you owe |
| N-OBLIG-DUP | the same vendor invoice paid/recorded twice (no unique economic key) |
| N-CARD-FRESH | the money-map (card) drifting out of sync with the code |
| N-TENANT-ISO | moving another org's money via an unauthenticated `x-org-id` header |
| N-GL-TIE | a bill not fully booked (expense/AP never recognized) so the books don't tie |
| N-SOD | self-approval / approver with no identity or authority check |
| N-ONCE | a payment that can be sent twice on retry (not exactly-once) |

### 4. Cost experiment — can a cheaper model do the review?
Blind 3-arm test on the pmar PR, graded against 19 known bugs:
- **Haiku alone: 16/19** caught — *beat* Opus-alone (~10/19) — at **~1/20th the cost**.
- **Cascade (Haiku → Opus):** Haiku's breadth + Opus's precision = best of both.
- **The 3 subtlest bugs** (score-honesty, tax-liability, duplicate-obligation) were caught by **no model tier** — which is exactly why they're now deterministic checks (#1–#3 above).
- Re-ran the cascade's verify on **Opus 5.5, scoped**: $0.86, sharper pruning (better precision); but scoping-via-a-fresh-session **didn't cut cost** — the real cost win is the deterministic floor (≈$0) + in-pipeline caching, not cheaper sessions.

### 5. Versioning
Cut the **`v3`** branch as the multi-app line (v1 = gen-1 · v2 = portable/neobank, 19 checks · **v3 = multi-app + pmar**). All pmar work is now on `main`.

---

## Where everything is (`main` branch)
```
adapters/pmar.ts     the card (where pmar's money lives)
static/n-*.ts        the 8 checks
run-pmar.ts          the runner
PLAYBOOK.md          manifest — see the "pmar checks (v3)" section
CANDIDATES.md        backlog: 7 shipped, 17 pending + the shipped list
RUNBOOK.md           how to onboard any new repo (derive card → run → gate → land)
```
Link: https://github.com/helix-fintech-apps/Portable-Playbook/tree/main

---

## How to run / extend (Zak)

**Run the pmar checks:**
```bash
cd Portable-Playbook           # on branch main
node --experimental-transform-types run-pmar.ts /abs/path/to/pmar
```
Each line prints `FINDING` (a bug, with file:line), `CHECKED` (safe), or `N/A` (no such flow).

**Onboard a new repo, or promote a new check:** follow `RUNBOOK.md`. The loop is: derive the card from the repo → write it → run the checks → for a new bug class, write a check and pass the gate → land it on `main`.

**The one rule:** a candidate only becomes a real check when it's **FINDING on the bug ∧ CHECKED on a fix ∧ NA where absent**, re-verified. Never bulk-flip the backlog to "shipped."

---

## Honest notes / gotchas
- **Runner:** use `node --experimental-transform-types` — `tsx` isn't installed, and plain `--experimental-strip-types` rejects the `enum` in `money-system.ts`.
- **TS vs SQL:** pmar checks scan TypeScript; neobank's scan SQL migrations. Same invariant, different source reader — that's why each check carries a per-app config.
- **CI gate (done):** `ci/pmar-money-gate.yml` is the drop-in pmar gate — it checks out the playbook (main) + pmar and runs `run-pmar.ts`, blocking the PR on any FINDING (the pmar analogue of neobank's `run-static.ts`). It's a template added to the pmar repo by its maintainers (pmar is outside this session's push scope); see `RUNBOOK.md` → Step 7. `run-pmar.ts` now reads its path arg under both Deno (CI) and Node.
- **Card drift (done):** `N-CARD-FRESH` now flags drift in **both** directions — a missing money table, a **phantom** table the card lists but the schema doesn't define (the `transfers`/`holds` copy smell), and a dead path. Re-verified: still CHECKED on pmar's real card.

## What's left
1. **17 candidates** still in the backlog — promote in batches, same gate.
2. Decide model strategy from the experiment: deterministic floor (free) catches the subtle bugs; use **Haiku for breadth** + a stronger model only for precision on the residue.
