// Conformance case for N-ACCOUNT-VALID — an account CODE money is posted to is validated by EXISTENCE
// in the chart of accounts (a lookup), never merely by its SHAPE (a regex).
// Drives the detector's PURE scan (scanAccountValid) over in-memory fixtures (no fs, no temp dirs) and
// proves the 3-way gate: FINDING on the bug, CHECKED on the fix, NOT_APPLICABLE when dormant.
import { scanAccountValid, ACCOUNT_VALID_SMELLS } from "../../static/n-account-valid.ts";

const cfg = { ...ACCOUNT_VALID_SMELLS, scanPaths: [] } as any;
const F = (text: string) => [{ path: "x.ts", text }];

export default function run() {
  // SMELL A [shape-not-chart]: the account code is validated only by a SHAPE regex (a digit-count
  // pattern) and the file has NO chart-of-accounts existence lookup — a well-shaped but UNSEEDED code
  // (e.g. 6999) passes, money is posted to it, and the debit/credit then vanishes from every balance.
  const vuln = scanAccountValid(
    F(`
  function postAccrual(line, ctx) {
    const CODE = /^6\\d{3}$/;
    if (!CODE.test(line.gl_account)) throw new Error("bad account code");
    return ctx.ledger.postEntry({ gl_account: line.gl_account, amount_minor: line.amount_minor, side: "debit" });
  }`),
    cfg,
  );

  // GUARD: the account code is looked up in the chart of accounts (getAccount) before the line is
  // posted — a posting can only name a real, seeded account.
  const fixd = scanAccountValid(
    F(`
  function postAccrual(line, ctx) {
    const acct = getAccount(line.gl_account);
    if (!acct) throw new Error("account not in chart of accounts");
    return ctx.ledger.postEntry({ gl_account: acct.code, amount_minor: line.amount_minor, side: "debit" });
  }`),
    cfg,
  );

  // DORMANT: no account-coded journal/ledger posting idiom here (a plain non-ledger insert) — there is
  // no account-validity boundary to check (the invariant is dormant).
  const absn = scanAccountValid(
    F(`
  function createWidget(input, ctx) {
    return ctx.sb.from("widgets").insert({ id: crypto.randomUUID(), qty: 3 });
  }`),
    cfg,
  );

  return {
    check: "N-ACCOUNT-VALID",
    vulnerable: vuln.violations.length > 0 && vuln.present,   // FINDING on the shape-only validation
    fixed: fixd.violations.length === 0 && fixd.present,       // CHECKED: chart-existence lookup before post
    absent: absn.violations.length === 0 && !absn.present,     // NOT_APPLICABLE: no account-coded posting (dormant)
  };
}
