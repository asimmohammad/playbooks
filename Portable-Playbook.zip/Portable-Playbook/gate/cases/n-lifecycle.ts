// CONFORMANCE CASE — N-LIFECYCLE. Proves the 3-way gate against in-memory fixtures through the
// detector's PURE scan function (no fs, no temp dirs). Each fixture instantiates exactly one leg of
// the detector's header contract: SMELL A [prior-status] (a status-setting UPDATE with NO prior-status
// predicate) = FINDING; its GUARD (the same write made status-filtered with `.eq("status", …)`) =
// CHECKED; and a routine with no status write / no money release / no clearance gate = DORMANT.
import { scanLifecycle, LIFECYCLE_SMELLS } from "../../static/n-lifecycle.ts";

const cfg = { ...LIFECYCLE_SMELLS, scanPaths: [] } as any;
const F = (text: string) => [{ path: "x.ts", text }];

export default function run() {
  // SMELL A: `.update({ status })` flips the status with no `and status = <expected>` claim — two
  // concurrent callers both "win" the transition and money is released twice.
  const vuln = scanLifecycle(
    F(`\n  async approve(id){ await sb.from("expenses").update({ status: "approved" }).eq("id", id); }`),
    cfg,
  );
  // GUARD: the write is status-filtered (`.eq("status", "submitted")`) — the predicate IS the lock, so
  // exactly one caller wins the transition.
  const fixd = scanLifecycle(
    F(`\n  async approve(id){ await sb.from("expenses").update({ status: "approved" }).eq("id", id).eq("status", "submitted"); }`),
    cfg,
  );
  // DORMANT: a plain insert into a non-money table — no status transition, no release, no clearance
  // gate, so there is no lifecycle gate to check.
  const absn = scanLifecycle(
    F(`\n  async f(){ await sb.from("widgets").insert({ id, qty: 3 }); }`),
    cfg,
  );

  return {
    check: "N-LIFECYCLE",
    vulnerable: vuln.violations.length > 0 && vuln.present,   // FINDING on the unguarded status flip
    fixed: fixd.violations.length === 0 && fixd.present,       // CHECKED: status-filtered write, no violations
    absent: absn.violations.length === 0 && !absn.present,     // NOT_APPLICABLE: no transition site (dormant)
  };
}
