// CONFORMANCE CASE — N-ROUTE-UNIQUE. Proves the 3-way gate against in-memory fixtures through the
// detector's PURE scan function `scanRoutes(entries, moneyFiles, cfg)` (no fs, no temp dirs). Each
// fixture instantiates exactly the header's canonical bug on the expense-approval route: a first-match
// HTTP router serves the FIRST registration of a (method, path). The SMELL (the same money/approval
// route `POST /v1/expenses/:id/approve` registered twice — the winning registration recognizes money
// directly via `expenses.approve(...)`, while the shadowed, unreachable one is the workflow-aware
// `policy.approveLevel(...)` multi-level approver) = FINDING [smell B: approval-bypass-shadow]; its
// GUARD (the money/approval route registered exactly once, as the workflow-aware handler) = CHECKED;
// and an entry with no money/approval route at all (only a health check) = DORMANT.
//
// Handlers are classified by their inline vocabulary (directMove vs workflowAware), so no money files
// need to be read — `moneyFiles` is an empty map and classification is purely inline. The config is the
// generic ROUTE_REGEXES binding (scanRoutes needs only the route/approval/workflow regexes, not the
// file lists, which `detect` uses for fs reads).
import { scanRoutes, ROUTE_REGEXES } from "../../static/n-route-unique.ts";

const cfg = { ...ROUTE_REGEXES } as any;
const E = (text: string) => [{ path: "src/http/server.ts", text }];
const NO_MONEY_FILES = new Map<string, string>();

export default function run() {
  // SMELL: `POST /v1/expenses/:id/approve` is registered TWICE. Under a first-match router the first
  // registration wins — and it dispatches `expenses.approve(...)`, a direct single-step money move that
  // recognizes the expense straight onto the P&L. The later registration, `policy.approveLevel(...)`,
  // is the workflow-aware multi-level approver (the BR-018 chain) — but it is SHADOWED and never reached,
  // so every approval silently skips its approval chain.
  const vuln = scanRoutes(
    E(`
app.post("/v1/expenses/:id/approve", (req, res) => expenses.approve(req.params.id));
app.post("/v1/expenses/:id/approve", (req, res) => policy.approveLevel(req.params.id, req.principal));
`),
    NO_MONEY_FILES,
    cfg,
  );

  // GUARD: the money/approval route is registered exactly ONCE, as the workflow-aware approver. There is
  // no duplicate to shadow it, so no approval can bypass the multi-level chain.
  const fixd = scanRoutes(
    E(`
app.post("/v1/expenses/:id/approve", (req, res) => policy.approveLevel(req.params.id, req.principal));
`),
    NO_MONEY_FILES,
    cfg,
  );

  // DORMANT: the only route is a non-money health check — its path matches no approval/money vocabulary,
  // so no money/approval route is registered and there is no approval chain to shadow.
  const absn = scanRoutes(
    E(`
app.get("/v1/health", (req, res) => res.json({ ok: true }));
`),
    NO_MONEY_FILES,
    cfg,
  );

  return {
    check: "N-ROUTE-UNIQUE",
    vulnerable: vuln.violations.length > 0 && vuln.present,   // FINDING on the duplicate, approval-bypassing route
    fixed: fixd.violations.length === 0 && fixd.present,       // CHECKED: the money/approval route is registered once
    absent: absn.violations.length === 0 && !absn.present,     // NOT_APPLICABLE: no money/approval route (dormant)
  };
}
