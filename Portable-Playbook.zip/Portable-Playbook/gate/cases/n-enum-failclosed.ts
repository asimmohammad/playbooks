// CONFORMANCE CASE — N-ENUM-FAILCLOSED. Proves the 3-way gate against in-memory fixtures through the
// detector's PURE scan function `scanEnumFailClosed(files, cfg)` (no fs, no temp dirs). Each fixture
// instantiates exactly one leg of the detector's header contract: SMELL B [unvalidated-default-allow]
// (a money-gating `action` read from a DB row is cast to a closed union with a PERMISSIVE `?? "flag"`
// fallback, and nothing validates the raw value against the set — this is the PR6 enum-validity bug,
// where an unknown/typo'd/null action silently becomes the ALLOW case and a rule meant to block
// out-of-policy spend stops blocking it) = FINDING; its GUARD (a closed-set membership check that
// throws on an unknown action — the file fails closed) = CHECKED; and a routine with no money-gating
// enum / action / decision dispatch at all = DORMANT.
import { scanEnumFailClosed, ENUM_SMELLS } from "../../static/n-enum-failclosed.ts";

const cfg = { ...ENUM_SMELLS, scanPaths: [] } as any;
const F = (text: string) => [{ path: "x.ts", text }];

export default function run() {
  // SMELL B: an unknown DB `action` is cast to the closed union "flag"|"block" and defaulted to the
  // PERMISSIVE "flag" with `?? "flag"`; the only gate is a bare `=== "block"`, so a typo'd or
  // schema-drifted action silently falls through to allow — the money control never fires.
  const vuln = scanEnumFailClosed(
    F(`\n  function enforce(r){\n    const action = (r.action as "flag" | "block") ?? "flag";\n    if (action === "block") return "stop";\n    return "allow";\n  }`),
    cfg,
  );

  // GUARD: the raw action is validated against a KNOWN closed set and the file THROWS on an unknown
  // value before dispatching — the enum domain is closed and fails closed, so an unrecognised action
  // can never silently disable the control.
  const fixd = scanEnumFailClosed(
    F(`\n  const KNOWN_ACTIONS = new Set(["flag", "block"]);\n  function enforce(r){\n    if (!KNOWN_ACTIONS.has(r.action)) throw new Error("unknown action");\n    const action = r.action;\n    if (action === "block") return "stop";\n    return "allow";\n  }`),
    cfg,
  );

  // DORMANT: a plain insert routine with no money-gating action/decision/verdict dispatch — there is
  // no closed-set fail-closed boundary here, so the invariant does not apply.
  const absn = scanEnumFailClosed(
    F(`\n  async function createWidget(input){\n    await sb.from("widgets").insert({ id: crypto.randomUUID(), qty: 3 });\n  }`),
    cfg,
  );

  return {
    check: "N-ENUM-FAILCLOSED",
    vulnerable: vuln.violations.length > 0 && vuln.present,   // FINDING on the permissive-default open enum
    fixed: fixd.violations.length === 0 && fixd.present,       // CHECKED: closed-set membership + throw (fail closed)
    absent: absn.violations.length === 0 && !absn.present,     // NOT_APPLICABLE: no money-gating dispatch (dormant)
  };
}
