// CONFORMANCE CASE — N-REJECT-CASCADE. Proves the 3-way gate against in-memory fixtures through the
// detector's PURE scan function `scanRejectCascade(files, cfg)` (no fs, no temp dirs). Each fixture
// instantiates the header's gating-decision contract: a combined approve/reject handler over a money
// object must transition the PARENT on BOTH outcomes.
// The SMELL (decideException records the decision on the child record, then transitions the parent
// expense ONLY on the `=== "approved"` branch, with no reject branch and no `else`) = FINDING; its GUARD
// (an explicit `=== "rejected"` branch that also drives the parent to a terminal state) = CHECKED; and a
// handler with no approve/reject decision at all (a plain `widgets` insert) = DORMANT.
//
// cfg is the REJECT_VOCAB decision vocabulary with an empty scanPaths (the fixtures are passed straight to
// the scan, so no paths are read). The fixtures use the pmar idioms the detector expects: a supabase
// `.from("t").update({ status })` parent transition and a `decision: "approved" | "rejected"` discriminator.
import { scanRejectCascade, REJECT_VOCAB } from "../../static/n-reject-cascade.ts";

const cfg = { ...REJECT_VOCAB, scanPaths: [] } as any;
const F = (text: string) => [{ path: "x.ts", text }];

export default function run() {
  // SMELL: decideException writes the decision onto the child exception record, then — only inside the
  // `=== "approved"` block — transitions the PARENT expense (`.update({ status: "approved" })`). There is
  // no `=== "rejected"` branch and no `else`, so a rejected decision never moves the expense: it stays in
  // its exception_pending / pending state forever, still shown as pending and re-decidable as open money.
  const vuln = scanRejectCascade(
    F(`
async function decideException(input: { decision: "approved" | "rejected"; exceptionId: string; expenseId: string }) {
  await ctx.sb.from("expense_exceptions").update({ decision: input.decision }).eq("id", input.exceptionId);
  if (input.decision === "approved") {
    await ctx.sb.from("expenses").update({ status: "approved" }).eq("id", input.expenseId);
  }
}`),
    cfg,
  );

  // GUARD: the handler carries an explicit reject branch (`else if (input.decision === "rejected")`) that
  // drives the parent expense to a terminal state (`.update({ status: "denied" })`) — so BOTH outcomes
  // transition the parent and a rejected decision is cleanly denied, never left pending.
  const fixd = scanRejectCascade(
    F(`
async function decideException(input: { decision: "approved" | "rejected"; exceptionId: string; expenseId: string }) {
  await ctx.sb.from("expense_exceptions").update({ decision: input.decision }).eq("id", input.exceptionId);
  if (input.decision === "approved") {
    await ctx.sb.from("expenses").update({ status: "approved" }).eq("id", input.expenseId);
  } else if (input.decision === "rejected") {
    await ctx.sb.from("expenses").update({ status: "denied" }).eq("id", input.expenseId);
  }
}`),
    cfg,
  );

  // DORMANT: a plain creation handler with no approve/reject decision and no parent transition — there is
  // no gating decision over a money object whose reject path could be dropped (the invariant is dormant).
  const absn = scanRejectCascade(
    F(`
async function createWidget(input: any) {
  const id = crypto.randomUUID();
  await ctx.sb.from("widgets").insert({ id, qty: 3 });
}`),
    cfg,
  );

  return {
    check: "N-REJECT-CASCADE",
    vulnerable: vuln.violations.length > 0 && vuln.present,   // FINDING on the approve-only transition
    fixed: fixd.violations.length === 0 && fixd.present,       // CHECKED: both outcomes transition the parent
    absent: absn.violations.length === 0 && !absn.present,     // NOT_APPLICABLE: no approve/reject gating (dormant)
  };
}
