// CONFORMANCE CASE — N-PASSTHRU-LIAB. Proves the 3-way gate against in-memory fixtures through the
// detector's PURE scan function `scanChart(chartText, cfg)` (no fs, no temp dirs), on leg A of the
// detector's header contract: collected pass-through tax (sales/VAT/withholding — money the org owes
// onward, not its income) must have a tax-payable LIABILITY account to be booked to.
//
// The detector is APPLICABLE only when a tax engine is present (an app that never computes tax has no
// pass-through liability to book). Applicability is the config's own predicate — `cfg.taxEngineMarker`
// run over the tax-engine source — exactly as `detect()` gates it before reading the chart; here it is
// run in-memory over a fixture. `scanChart` then reports whether the chart declares a tax-payable
// liability account (`.present`). The two together reproduce `detect()`'s leg-A verdict faithfully:
//   FINDING  = tax engine present AND chart declares NO tax-payable liability account (only generic
//              "Accounts Payable") — collected tax has nowhere to land and is recognized as revenue or
//              dropped. (applicable && !chart.present)
//   CHECKED  = tax engine present AND chart declares a "Sales Tax Payable" liability account.
//              (applicable && chart.present)
//   DORMANT  = no tax engine — no collected pass-through tax exists to book. (!applicable)
//
// `scanChart`'s `.present` cannot by itself separate FINDING from DORMANT (both yield no tax-payable
// account); the tax-engine applicability predicate is what distinguishes them, which is precisely why
// `detect()` checks the engine first. Leg B (`scanRevenuePostings` — tax credited to a revenue account)
// is a separate scanner of the same detector and is not exercised here.
import { scanChart, PMAR } from "../../static/n-passthru-liab.ts";

const cfg = { ...PMAR } as any;

export default function run() {
  // A tax engine (pmar's `class TaxService` summing `totalTaxMinor` from per-line `taxMinor`): its
  // presence is what makes the pass-through-liability invariant live.
  const taxEngine = `
  export class TaxService {
    compute(lines) {
      let totalTaxMinor = 0;
      for (const l of lines) totalTaxMinor += l.taxMinor;
      return { totalTaxMinor };
    }
  }`;
  // No tax engine: an app that never computes tax, so the invariant is dormant.
  const noEngine = `
  export class PricingService {
    total(lines) {
      let sum = 0;
      for (const l of lines) sum += l.amountMinor;
      return sum;
    }
  }`;
  // A chart that declares a tax-payable LIABILITY account — collected tax has somewhere to land.
  const chartWithTaxPayable = `
  export const STANDARD_ACCOUNTS = [
    { code: "2100", name: "Accounts Payable", type: "liability" },
    { code: "2200", name: "Sales Tax Payable", type: "liability" },
    { code: "4000", name: "Sales Revenue", type: "revenue" },
  ];`;
  // A chart with a generic payable but NO tax-payable account — collected tax has nowhere to be booked.
  const chartNoTaxPayable = `
  export const STANDARD_ACCOUNTS = [
    { code: "2100", name: "Accounts Payable", type: "liability" },
    { code: "4000", name: "Sales Revenue", type: "revenue" },
  ];`;

  const applicable = (engineText: string) => cfg.taxEngineMarker.test(engineText);

  // FINDING: tax engine present, but the chart declares no tax-payable liability account.
  const vApplicable = applicable(taxEngine);
  const vChart = scanChart(chartNoTaxPayable, cfg);

  // CHECKED: tax engine present, and the chart declares a "Sales Tax Payable" liability account.
  const fApplicable = applicable(taxEngine);
  const fChart = scanChart(chartWithTaxPayable, cfg);

  // DORMANT: no tax engine — nothing computes collected tax, so there is no pass-through liability.
  const aApplicable = applicable(noEngine);

  return {
    check: "N-PASSTHRU-LIAB",
    vulnerable: vApplicable && !vChart.present,   // FINDING: tax engine, no tax-payable liability account
    fixed: fApplicable && fChart.present,          // CHECKED: tax-payable liability account declared
    absent: !aApplicable,                          // NOT_APPLICABLE: no tax engine (dormant)
  };
}
