// CONFORMANCE CASE — N-OBLIG-DUP. Proves the 3-way gate against in-memory fixtures through the
// detector's PURE scan function `scanObligations(schemaText, serviceTexts, cfg)` (no fs, no temp
// dirs). Each fixture instantiates exactly one leg of the detector's header contract on the classic
// payable/receivable leg (the raw `INSERT INTO <table> (...)` idiom): SMELL (an obligation insert
// mints a random-UUID PK with NO preceding economic-duplicate SELECT, and the table declares NO
// UNIQUE natural key AND NO document-number column — the same invoice can be recorded twice) =
// FINDING; its GUARD (a preceding economic-duplicate SELECT on the obligation's economic key) =
// CHECKED; and an insert into a NON-obligation table = DORMANT.
//
// scanObligations reads only `cfg.obligations` (the bills/invoices flows), so the config is the PMAR
// binding; the fixtures key their service text under an obligation's serviceFile ("src/services/ap.ts"
// = the bills flow). The request/supabase-insert leg (REQUEST_REGEXES / scanRequestInserts) is a
// separate scanner and not exercised here.
import { scanObligations, PMAR } from "../../static/n-oblig-dup.ts";

const cfg = { ...PMAR } as any;
// the bills flow's service file is "src/services/ap.ts"; key the fixture text there so it is scanned.
const S = (text: string) => new Map<string, string>([["src/services/ap.ts", text]]);

export default function run() {
  // `bills` has no document-number column and no UNIQUE natural key; the schema is shared by the vuln
  // and fixed fixtures so the ONLY difference is the app-level guard.
  const schema = `create table bills ( id uuid primary key, vendor_id uuid, amount_minor bigint, status text );`;
  const widgetsSchema = `create table widgets ( id uuid, qty int );`;

  // SMELL: createBill mints a random-UUID primary key and inserts straight into `bills` with NO
  // preceding economic-duplicate SELECT. `bills` declares no UNIQUE natural key and no document-number
  // column, so re-submitting the same vendor invoice inserts a SECOND payable — AP pays it twice.
  const vuln = scanObligations(
    schema,
    S(`
async function createBill(input){
  const id = crypto.randomUUID();
  await db.query("INSERT INTO bills (id, vendor_id, amount_minor, status) VALUES ($1,$2,$3,'open')", [id, input.vendorId, input.amountMinor]);
}`),
    cfg,
  );

  // GUARD: before the insert, createBill SELECTs an existing bill by its economic key (vendor_id +
  // amount_minor) and returns it instead of inserting again — the same economic obligation cannot be
  // recorded twice, so the random-UUID insert is guarded.
  const fixd = scanObligations(
    schema,
    S(`
async function createBill(input){
  const existing = await db.query("SELECT id FROM bills WHERE vendor_id = $1 AND amount_minor = $2", [input.vendorId, input.amountMinor]);
  if (existing.rows.length) return existing.rows[0];
  const id = crypto.randomUUID();
  await db.query("INSERT INTO bills (id, vendor_id, amount_minor, status) VALUES ($1,$2,$3,'open')", [id, input.vendorId, input.amountMinor]);
}`),
    cfg,
  );

  // DORMANT: the only insert is into `widgets`, not an obligation table (bills/invoices) — there is no
  // payable/receivable create here, so the duplicate-obligation invariant does not apply.
  const absn = scanObligations(
    widgetsSchema,
    S(`
async function createWidget(input){
  const id = crypto.randomUUID();
  await db.query("INSERT INTO widgets (id, qty) VALUES ($1, $2)", [id, 3]);
}`),
    cfg,
  );

  return {
    check: "N-OBLIG-DUP",
    vulnerable: vuln.violations.length > 0 && vuln.present,   // FINDING on the duplicate-able obligation insert
    fixed: fixd.violations.length === 0 && fixd.present,       // CHECKED: preceding economic-dup SELECT guards it
    absent: absn.violations.length === 0 && !absn.present,     // NOT_APPLICABLE: no obligation insert (dormant)
  };
}
