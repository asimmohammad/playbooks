// CONFORMANCE CASE — N-FAILCLOSED-READ. Proves the 3-way gate against in-memory fixtures through the
// detector's PURE scan function (no fs, no temp dirs). Each fixture instantiates exactly one leg of
// the detector's header contract: SMELL A [swallowed-variance-read] (inside a variance/reconciliation
// region, a supabase `.select()` destructures `{ data }` and swallows `error`, then coalesces the
// empty read to a benign `?? []` so a broken read computes a clean zero variance) = FINDING; its GUARD
// (capture `{ data, error }` and `throw error`) = CHECKED; and a plain read in a routine that is NOT a
// variance/reconciliation/assurance computation = DORMANT.
import { scanFailClosed, FAILCLOSED_SMELLS } from "../../static/n-failclosed-read.ts";

const cfg = { ...FAILCLOSED_SMELLS, scanPaths: [] } as any;
const F = (text: string) => [{ path: "x.ts", text }];

export default function run() {
  // SMELL A: a reconciliation/variance read destructures `{ data }` alone (swallows `error`) and then
  // coalesces to `?? []` — a DB error or missing rows returns empty and the variance silently computes
  // to zero, masking an unreconciled state as healthy.
  const vuln = scanFailClosed(
    F(`\n  async reconcileVariance(sb, org_id){\n    let base = 0;\n    const { data } = await sb.from("bank_feed").select("amount_minor");\n    const variance_minor = (data ?? []).reduce((s, r) => s + r.amount_minor, base);\n    return variance_minor;\n  }`),
    cfg,
  );
  // GUARD: the same reconciliation read captures `{ data, error }` and raises on `error` — a failed or
  // empty read is loud, never turned into a benign zero variance.
  const fixd = scanFailClosed(
    F(`\n  async reconcileVariance(sb, org_id){\n    const { data, error } = await sb.from("bank_feed").select("amount_minor");\n    if (error) throw error;\n    const variance_minor = (data ?? []).reduce((s, r) => s + r.amount_minor, 0);\n    return variance_minor;\n  }`),
    cfg,
  );
  // DORMANT: the routine is a plain listing, not a variance/reconciliation/assurance computation — the
  // same `{ data }`-only read carries no fail-closed obligation, so the invariant is dormant.
  const absn = scanFailClosed(
    F(`\n  async listWidgets(sb, org_id){\n    const { data } = await sb.from("widgets").select("id");\n    return data ?? [];\n  }`),
    cfg,
  );

  return {
    check: "N-FAILCLOSED-READ",
    vulnerable: vuln.violations.length > 0 && vuln.present,   // FINDING on the swallowed variance read
    fixed: fixd.violations.length === 0 && fixd.present,       // CHECKED: error captured + raised, no violations
    absent: absn.violations.length === 0 && !absn.present,     // NOT_APPLICABLE: no variance/recon read (dormant)
  };
}
