// CONFORMANCE CASE — N-FX-COMPARE. Proves the 3-way gate against in-memory fixtures through the
// detector's PURE scan function (no fs, no temp dirs). Each fixture instantiates exactly one leg of
// the detector's header contract: SMELL B [compare-norm] (a money comparison whose operands carry a
// DYNAMIC currency field, made without converting or asserting the currencies equal) = FINDING; its
// GUARD (assert `currency` first, then convert with `convertMinor`, then compare the converted minor
// amount) = CHECKED; and single-currency code (no FX, no dynamic currency read) = DORMANT.
import { scanFxCompare, FX_SMELLS } from "../../static/n-fx-compare.ts";

const cfg = { ...FX_SMELLS, scanPaths: [] } as any;
const F = (text: string) => [{ path: "x.ts", text }];

export default function run() {
  // SMELL B: `expense.amount_minor` (a foreign amount — `expense.currency` is read, so it is dynamic)
  // is compared raw against a limit with NO conversion and no currency-equality check: ¥50000 and $500
  // are both "50000 minor", so the wrong spend is approved or blocked.
  const vuln = scanFxCompare(
    F(`\n  async check(expense, limit_minor){\n    const cur = expense.currency;\n    if (expense.amount_minor > limit_minor) throw new Error("over");\n  }`),
    cfg,
  );
  // GUARD: the currency is asserted, the amount is converted (`convertMinor`) to the base currency,
  // and only the converted minor amount is compared — the operands are commensurable.
  const fixd = scanFxCompare(
    F(`\n  async check(expense, cap_minor){\n    if (expense.currency !== "USD") throw new Error("must convert");\n    const converted_minor = convertMinor(expense.amount_minor, expense.currency, "USD");\n    if (converted_minor > cap_minor) throw new Error("over");\n  }`),
    cfg,
  );
  // DORMANT: no currency conversion and no dynamic currency field is read — the app is single-currency
  // here, so there is nothing to normalize before comparing.
  const absn = scanFxCompare(
    F(`\n  async check(expense, cap_minor){\n    if (expense.amount_minor > cap_minor) throw new Error("over");\n  }`),
    cfg,
  );

  return {
    check: "N-FX-COMPARE",
    vulnerable: vuln.violations.length > 0 && vuln.present,   // FINDING on the un-normalized comparison
    fixed: fixd.violations.length === 0 && fixd.present,       // CHECKED: converted before compare, no violations
    absent: absn.violations.length === 0 && !absn.present,     // NOT_APPLICABLE: single-currency (dormant)
  };
}
