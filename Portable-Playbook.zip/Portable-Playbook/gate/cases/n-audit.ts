// Conformance case for N-AUDIT — every money-mutating service path leaves an attributed audit trail.
// Drives the detector's PURE scan (scanAudit) over in-memory fixtures (no fs, no temp dirs) and proves
// the 3-way gate: FINDING on the bug, CHECKED on the fix, NOT_APPLICABLE when the invariant is dormant.
import { scanAudit, AUDIT_VOCAB, buildTableWrite } from "../../static/n-audit.ts";

const cfg = { ...AUDIT_VOCAB, files: ["x.ts"], moneyTableWrite: buildTableWrite([]) } as any;
const M = (text: string) => new Map<string, string>([["x.ts", text]]);

export default function run() {
  // SMELL [unaudited-mutation]: a money-mutating service path posts the ledger but writes NO audit row
  // in the same path — the books moved with nothing recording who did it, why, or the before/after.
  const vuln = scanAudit(
    M(`
async function approveExpense(input: any, principal: any) {
  await ctx.ledger.postEntry({ debitAccountId: "exp", creditAccountId: "accrued", amount_minor: input.amount_minor });
}
`),
    cfg,
  );

  // GUARD: the same money mutation now writes an attributed audit row, and the actor comes from a
  // server-authenticated principal (principal.sub) — not a constant, null, or a request-body value.
  const fixd = scanAudit(
    M(`
async function approveExpense(input: any, principal: any) {
  await ctx.ledger.postEntry({ debitAccountId: "exp", creditAccountId: "accrued", amount_minor: input.amount_minor });
  await auditLog({ actorId: principal.sub, action: "approve", expenseId: input.id });
}
`),
    cfg,
  );

  // DORMANT: no money-mutating action and no audit/decision write — there is no audit-trail boundary
  // to check (the insert targets a non-money table and stamps no actor).
  const absn = scanAudit(
    M(`
async function createWidget(input: any) {
  await sb.from("widgets").insert({ id: crypto.randomUUID(), qty: 3 });
}
`),
    cfg,
  );

  return {
    check: "N-AUDIT",
    vulnerable: vuln.violations.length > 0 && vuln.present, // FINDING on the bug
    fixed: fixd.violations.length === 0 && fixd.present,     // CHECKED: audited + authenticated actor
    absent: absn.violations.length === 0 && !absn.present,   // NOT_APPLICABLE: invariant dormant
  };
}
