// Conformance case: N-AGING — an insert into an aging-bearing money table must populate its due date.
// FINDING@vuln (null-defaulted due date) ∧ CHECKED@fix (required due date) ∧ NA@absent (no aging table).
import { scanAging, AGING_VOCAB } from "../../static/n-aging.ts";

const cfg = { ...AGING_VOCAB, scanPaths: [], schemaFiles: [] } as any;
const F = (text: string) => [{ path: "src/services/ar.ts", text }];

export default function run() {
  const schema = `create table invoices ( id uuid primary key, org_id uuid, amount_minor bigint, status text, due_date date );`;
  const absentSchema = `create table widgets ( id uuid primary key, qty int );`;

  const vuln = scanAging(
    F(`\n  async createInvoice(orgId, input) {\n    await this.sb.from("invoices").insert({ id, org_id: orgId, amount_minor: total, status: "open", due_date: input.dueDate ?? null });\n  }\n`),
    schema,
    cfg,
  );
  const fixd = scanAging(
    F(`\n  async createInvoice(orgId, input) {\n    await this.sb.from("invoices").insert({ id, org_id: orgId, amount_minor: total, status: "open", due_date: input.dueDate });\n  }\n`),
    schema,
    cfg,
  );
  const absn = scanAging(
    F(`\n  async makeWidget(input) {\n    await this.sb.from("widgets").insert({ id, qty: 3 });\n  }\n`),
    absentSchema,
    cfg,
  );

  return {
    check: "N-AGING",
    vulnerable: vuln.violations.length > 0 && vuln.present,
    fixed: fixd.violations.length === 0 && fixd.present && fixd.guarded.length > 0,
    absent: absn.violations.length === 0 && !absn.present,
  };
}
