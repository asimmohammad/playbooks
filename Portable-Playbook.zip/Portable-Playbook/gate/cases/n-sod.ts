// CONFORMANCE CASE — N-SOD. Proves the 3-way gate against in-memory fixtures through the detector's
// PURE scan function `scanApprovals(fileTexts, cfg)` (no fs, no temp dirs). Each fixture instantiates
// exactly the header's amount-scoped maker-checker contract on the expense-approval surface: an
// approve method must (a) take an approver/actor parameter, (b) not stamp a constant/null actor,
// (c) compare the approver against an originator field (no self-approval), and (d) look up an approval
// limit keyed by actor + amount. The SMELL (an `approve` that takes no approver, never checks the
// originator, and has no amount-scoped limit) = FINDING; its GUARD (all four defences present) =
// CHECKED; and a non-approval method (no name match, no approved-status UPDATE) = DORMANT.
//
// scanApprovals keys only on the approval-surface shape and the defence vocabulary, both of which are
// the PMAR binding, so the config is PMAR. The decision-actor smells (e)/(f)/(g) — scanDecisionActors /
// scanRequestActor — are separate scanners and not exercised here. Fixtures carry the "expense approval"
// flow label on PMAR's expenses service file so the surface is scanned.
import { scanApprovals, PMAR } from "../../static/n-sod.ts";

const cfg = { ...PMAR } as any;
// one approval flow, keyed on PMAR's expense-approval service file.
const F = (text: string) => [{ flow: "expense approval", path: "src/services/expenses.ts", text }];

export default function run() {
  // SMELL: `approve` is a money-gating approval surface (its name matches, and it performs an
  // `UPDATE expenses SET status='approved'`) but takes NO approver/actor parameter, never compares an
  // approver against the submitting employee, and looks up no amount-scoped approval limit — defences
  // (a), (c) and (d) are all absent, so anyone can wave any expense straight to `approved`.
  const vuln = scanApprovals(
    F(`
class ExpenseService {
  async approve(expenseId: string) {
    await db.query("update expenses set status = 'approved' where id = $1", [expenseId]);
  }
}`),
    cfg,
  );

  // GUARD: `approve` now takes an authenticated `approverId` (a), records it as `approved_by` with no
  // constant/null actor (b), rejects self-approval by comparing the approver against the expense's
  // `employee_id` originator (c), and looks up an `approval_limit` keyed by the approver and scoped to
  // the `amount_minor` (d) — a maker cannot approve their own spend, and only an authorised approver
  // can clear the amount.
  const fixd = scanApprovals(
    F(`
class ExpenseService {
  async approve(expenseId: string, approverId: string) {
    const expense = await db.query("select employee_id, amount_minor from expenses where id = $1", [expenseId]);
    if (expense.employee_id === approverId) throw new Error("self-approval blocked");
    const authority = await db.query("select approval_limit from approver_authority where approver = $1", [approverId]);
    if (expense.amount_minor > authority.approval_limit) throw new Error("over approval limit");
    await db.query("update expenses set status = 'approved', approved_by = $1 where id = $2", [approverId, expenseId]);
  }
}`),
    cfg,
  );

  // DORMANT: the only method is a plain widget create — its name does not match an approval surface and
  // its body performs no approved-status UPDATE, so there is no money-gating approval here and the
  // separation-of-duties invariant does not apply.
  const absn = scanApprovals(
    F(`
class WidgetService {
  async create(input: { qty: number }) {
    const id = crypto.randomUUID();
    await db.query("insert into widgets (id, qty) values ($1, $2)", [id, input.qty]);
  }
}`),
    cfg,
  );

  return {
    check: "N-SOD",
    vulnerable: vuln.violations.length > 0 && vuln.present,   // FINDING on the self-approvable, unscoped approval
    fixed: fixd.violations.length === 0 && fixd.present,       // CHECKED: approver captured, checked, amount-scoped
    absent: absn.violations.length === 0 && !absn.present,     // NOT_APPLICABLE: no approval surface (dormant)
  };
}
