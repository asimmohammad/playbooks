// CONFORMANCE CASE — N-GL-TIE. Proves the 3-way gate against in-memory fixtures through the detector's
// PURE scan function `scanGlTie(serviceTexts, cfg)` (no fs, no temp dirs). Each fixture instantiates the
// header's payable (bills) contract: an obligation-creating method must post its recognition ledger
// entry (leg A), and the AP control account must be booked on BOTH sides across the service (leg B).
// The SMELL (createBill inserts the bill via the supabase client but posts NO recognition entry, so AP
// is never credited at recognition) = FINDING; its GUARD (createBill posts the DR expense / CR AP
// recognition entry, and payBill posts the DR AP / CR cash settlement — AP booked on both sides) =
// CHECKED; and an insert into a non-obligation table (`widgets`) = DORMANT.
//
// scanGlTie iterates cfg.flows and reads each flow's serviceFiles out of the map; keying the fixture on
// PMAR's bills-flow service file `src/services/ap.ts` exercises only the payable flow (the receivable
// flow's files are absent from the map, so it contributes nothing). The config is the PMAR binding.
import { scanGlTie, PMAR } from "../../static/n-gl-tie.ts";

const cfg = { ...PMAR } as any;
// the bills flow's service file is "src/services/ap.ts"; key the fixture text there so it is scanned.
const S = (text: string) => new Map<string, string>([["src/services/ap.ts", text]]);

export default function run() {
  // SMELL: createBill records the payable through the supabase client (`ctx.sb.from("bills").insert`)
  // but posts NO recognition ledger entry in its body — no postEntry / ledger.post. The bill exists in
  // its own table but is invisible to the GL: the AP control account is never CREDITed at recognition,
  // so the sub-ledger diverges from the ledger and the trial balance understates liabilities.
  const vuln = scanGlTie(
    S(`
async function createBill(input: any) {
  const id = crypto.randomUUID();
  await ctx.sb.from("bills").insert({ id, vendor_id: input.vendorId, amount_minor: input.amountMinor, status: "open" });
  await ctx.sb.from("bill_lines").insert(input.lines);
}`),
    cfg,
  );

  // GUARD: createBill posts its recognition entry at the moment the obligation is created (DR expense /
  // CR AP via `ctx.ledger.postEntry`), and payBill books the settlement leg (DR AP / CR cash) — so the
  // AP control account is credited at recognition and debited at settlement, booked on BOTH sides, and
  // the bills sub-ledger ties out to the GL.
  const fixd = scanGlTie(
    S(`
async function createBill(input: any) {
  const id = crypto.randomUUID();
  await ctx.sb.from("bills").insert({ id, vendor_id: input.vendorId, amount_minor: input.amountMinor, status: "open" });
  await ctx.ledger.postEntry({ lines: [
    { debitAccountId: ACCOUNTS.EXPENSE, amount_minor: input.amountMinor },
    { creditAccountId: ACCOUNTS.AP, amount_minor: input.amountMinor },
  ] });
}
async function payBill(input: any) {
  await ctx.ledger.postEntry({ lines: [
    { debitAccountId: ACCOUNTS.AP, amount_minor: input.amountMinor },
    { creditAccountId: ACCOUNTS.CASH, amount_minor: input.amountMinor },
  ] });
  await ctx.sb.from("bills").update({ status: "paid" }).eq("id", input.billId);
}`),
    cfg,
  );

  // DORMANT: the only insert is into `widgets`, not an obligation table (bills/invoices/their lines) —
  // there is no payable/receivable recognized here, so the GL-tie invariant does not apply.
  const absn = scanGlTie(
    S(`
async function createWidget(input: any) {
  const id = crypto.randomUUID();
  await ctx.sb.from("widgets").insert({ id, qty: 3 });
}`),
    cfg,
  );

  return {
    check: "N-GL-TIE",
    vulnerable: vuln.violations.length > 0 && vuln.present,   // FINDING on the un-recognized obligation insert
    fixed: fixd.violations.length === 0 && fixd.present,       // CHECKED: recognition posted, AP booked both sides
    absent: absn.violations.length === 0 && !absn.present,     // NOT_APPLICABLE: no obligation insert (dormant)
  };
}
