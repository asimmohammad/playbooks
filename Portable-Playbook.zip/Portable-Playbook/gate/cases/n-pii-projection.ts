// CONFORMANCE CASE — N-PII-PROJECTION. Proves the 3-way gate against in-memory fixtures through the
// detector's PURE scan function `scanPiiProjection(schemaText, files, cfg)` (no fs, no temp dirs).
// Each fixture instantiates exactly one leg of the detector's header contract: SMELL A
// [wildcard-projection] (a client-facing `.from("vendors").select("*")` over a table that carries a
// SENSITIVE column — the vendor `tin` — projecting it straight to the client) = FINDING; its GUARD
// (an explicit column set that EXCLUDES the sensitive column) = CHECKED; and a read of a table with
// NO sensitive column = DORMANT.
import { scanPiiProjection, PII_SMELLS } from "../../static/n-pii-projection.ts";

const cfg = { ...PII_SMELLS, scanPaths: [], schemaFiles: [], knownMoneyTables: [] } as any;
const F = (text: string) => [{ path: "x.ts", text }];

export default function run() {
  // `vendors` carries a sensitive `tin` (taxpayer id); `widgets` carries no sensitive column.
  const sensitiveSchema = `create table vendors ( id uuid, name text, tin text );`;
  const benignSchema = `create table widgets ( id uuid, qty int );`;

  // SMELL A: a client-facing list of vendors reads `select("*")` over a sensitive-column table, so the
  // raw `tin` of every vendor rides out in the response payload — a silent sensitive-field leak.
  const vuln = scanPiiProjection(
    sensitiveSchema,
    F(`\n  async listVendors(sb){\n    const { data } = await sb.from("vendors").select("*");\n    return data ?? [];\n  }`),
    cfg,
  );

  // GUARD: the same read names an EXPLICIT column set that excludes the sensitive `tin` — only id and
  // name reach the client, never the taxpayer id.
  const fixd = scanPiiProjection(
    sensitiveSchema,
    F(`\n  async listVendors(sb){\n    const { data } = await sb.from("vendors").select("id, name");\n    return data ?? [];\n  }`),
    cfg,
  );

  // DORMANT: the only read is of `widgets`, which carries no sensitive identity/bank column — even a
  // `select("*")` leaks nothing, so there is no projection boundary to check here.
  const absn = scanPiiProjection(
    benignSchema,
    F(`\n  async listWidgets(sb){\n    const { data } = await sb.from("widgets").select("*");\n    return data ?? [];\n  }`),
    cfg,
  );

  return {
    check: "N-PII-PROJECTION",
    vulnerable: vuln.violations.length > 0 && vuln.present,   // FINDING on the wildcard projection of `tin`
    fixed: fixd.violations.length === 0 && fixd.present,       // CHECKED: explicit set excludes the sensitive column
    absent: absn.violations.length === 0 && !absn.present,     // NOT_APPLICABLE: no sensitive-column table read (dormant)
  };
}
