// Conformance case for N-ORDER — a money op clears its liability / marks the item paid only AFTER the
// irreversible external provider call has succeeded, each under a durable payment-state guard.
// Drives the detector's PURE scan (scanOrderExt) over in-memory fixtures (no fs, no temp dirs) and proves
// the 3-way gate: FINDING on the bug, CHECKED on the fix, NOT_APPLICABLE when the invariant is dormant.
import { scanOrderExt, ORDER_EXT_REGEXES } from "../../static/n-order-ext.ts";

const cfg = { ...ORDER_EXT_REGEXES, files: ["x.ts"] } as any;
const M = (text: string) => new Map<string, string>([["x.ts", text]]);

export default function run() {
  // SMELL: the ledger post that DEBITS a liability (clears Accounts Payable) commits BEFORE the
  // irreversible provider call, and there is no durable payment-state guard — a failed/retried call
  // leaves the liability cleared with the payee unpaid (and a retry double-pays).
  const vuln = scanOrderExt(
    M(`
async function reimburse(e: any) {
  await ctx.ledger.postEntry({ debitAccountId: ACCOUNTS.ACCOUNTS_PAYABLE, side: "debit", creditAccountId: "cash", amount_minor: e.amount_minor });
  await ctx.connectors.payments.createPayment({ amount: e.amount_minor });
}
`),
    cfg,
  );

  // GUARD: the irreversible provider call happens FIRST, under a durable payment-state guard (an
  // already-paid status check + an idempotency key); the liability-clearing ledger post runs only
  // after the payment is known to have gone through.
  const fixd = scanOrderExt(
    M(`
async function reimburse(e: any) {
  if (e.status === "paid") return;
  const res = await ctx.connectors.payments.createPayment({ amount: e.amount_minor, idempotencyKey: e.id });
  await ctx.ledger.postEntry({ debitAccountId: ACCOUNTS.ACCOUNTS_PAYABLE, side: "debit", creditAccountId: "cash", amount_minor: e.amount_minor });
}
`),
    cfg,
  );

  // DORMANT: no function that BOTH clears a liability / marks paid AND makes an irreversible external
  // provider call — there is no commit-vs-external-call ordering surface here to check.
  const absn = scanOrderExt(
    M(`
async function createWidget(input: any) {
  await sb.from("widgets").insert({ id: crypto.randomUUID(), qty: 3 });
}
`),
    cfg,
  );

  return {
    check: "N-ORDER",
    vulnerable: vuln.violations.length > 0 && vuln.present, // FINDING on the bug
    fixed: fixd.violations.length === 0 && fixd.present,     // CHECKED: external-first + durable guard
    absent: absn.violations.length === 0 && !absn.present,   // NOT_APPLICABLE: invariant dormant
  };
}
