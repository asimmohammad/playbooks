// CONFORMANCE CASE — N-CARD-FRESH. Proves the 3-way gate for the META detector that audits whether an
// app's money-surface CARD (the MoneySurface manifest) stays in sync with the schema on disk.
//
// This detector is the SPECIAL one: it default-exports `detect(surface: MoneySurface, opts)` and reads the
// schema from the filesystem (`readFileSync(join(cwd, schemaFile))`), so — unlike its pure-scan siblings —
// it cannot be driven fully in memory. The case therefore builds an in-memory MoneySurface and writes a
// real schema file into a UNIQUE temp dir (node:fs, cleaned up in `finally`), then reads the detector's
// actual Verdict.status for each fixture. The 3 booleans reflect the real detect() verdicts.
//
// FINDING = card DRIFT: the schema defines a money-bearing table (`payments`, an `amount_minor` column)
//   that the card's moneyTables omits — the skip-gate and table-keyed detectors would silently miss it.
// CHECKED = card IN SYNC: moneyTables lists exactly the money-bearing tables the schema defines, and every
//   card path exists (moneyPaths/httpEntry left empty so only the existing schema file is path-checked).
// NOT_APPLICABLE = the card names no schema file that exists under cwd — there is no schema to check drift
//   against, so the invariant is dormant.
import { mkdtempSync, writeFileSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import detect from "../../static/n-card-fresh.ts";
import { type MoneySurface } from "../../adapters/pmar.ts";

// pmar's money-column shape: a table is "money-bearing" when its body has one of these columns.
const MONEY_COLUMNS = /_minor\b|amount|_cents\b|balance|rate|debit|credit/i;

export default function run() {
  const dir = mkdtempSync(join(tmpdir(), "n-card-fresh-case-"));
  try {
    // A minimal MoneySurface whose only path-checked card entries are schemaFiles (moneyPaths/httpEntry/
    // chartOfAccounts empty, so they contribute no dead paths); cwd is the temp dir holding the schema.
    const card = (over: Partial<MoneySurface>): MoneySurface => ({
      schemaMode: "sql-migrations",
      schemaFiles: ["schema.sql"],
      chartOfAccounts: "",
      moneyTables: [],
      moneyColumns: MONEY_COLUMNS,
      moneyPaths: [],
      seamPaths: [],
      httpEntry: "",
      cwd: dir,
      ...over,
    });

    // FINDING: the schema defines TWO money-bearing tables (expenses + payments, both with amount_minor)
    // but the card lists only `expenses` — `payments` is a missing money table the gate would miss.
    writeFileSync(
      join(dir, "schema.sql"),
      `create table expenses ( id uuid, amount_minor bigint, status text );\n` +
        `create table payments ( id uuid, amount_minor bigint, status text );\n` +
        `create table widgets ( id uuid, qty int );\n`,
    );
    const vuln = detect(card({ moneyTables: ["expenses"] }), { cwd: dir });

    // CHECKED: the card lists exactly the money-bearing table the schema defines (`expenses`); `widgets`
    // has no money column so it is not money-bearing, and the only card path (schema.sql) exists.
    writeFileSync(
      join(dir, "schema.sql"),
      `create table expenses ( id uuid, amount_minor bigint, status text );\n` +
        `create table widgets ( id uuid, qty int );\n`,
    );
    const fixd = detect(card({ moneyTables: ["expenses"] }), { cwd: dir });

    // NOT_APPLICABLE: the card names a schema file that does not exist under cwd — nothing to check drift
    // against (we cannot tell a phantom table from an unread one), so the invariant is dormant.
    const absn = detect(card({ schemaFiles: ["does-not-exist.sql"] }), { cwd: dir });

    return {
      check: "N-CARD-FRESH",
      vulnerable: vuln.status === "FINDING",          // FINDING on the missing money table (card drift)
      fixed: fixd.status === "CHECKED",               // CHECKED: card in sync with the schema
      absent: absn.status === "NOT_APPLICABLE",       // NOT_APPLICABLE: no schema to check (dormant)
    };
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
}
