// CONFORMANCE CASE — N-SCORE-HONEST. Proves the 3-way gate against in-memory fixtures through the
// detector's PURE scan function `scanScoreHonesty(files, cfg)` (no fs, no temp dirs). Each fixture
// instantiates exactly one leg of the detector's header contract on smell (a) [count-weighted score]:
// an unreconciled AMOUNT is computed inside a score-derivation block but the score is derived from a
// matched/total COUNT ratio and never references that amount — so one $1M exception hides behind 999
// one-cent matches and the published assurance score reads ~100 while real money is unaccounted for.
//   FINDING  = smell present: `unreconciledMinor` computed, score = Math.floor(100 * matched/total).
//   CHECKED  = guard present: the score is an amount-weighted lower bound (floored, worst-case 0 on an
//              empty denominator) that transitively references the unreconciled amount.
//   DORMANT  = no score-derivation function in the source at all (the `*score(` vocabulary is absent),
//              so there is no published assurance score to check.
//
// NOTE on the gate mapping: scanScoreHonesty reports applicability as `.applicable` (a score-derivation
// block was located), not `.present` — this case maps the template's `present` onto `.applicable`.
// Smells (b) perfect-on-empty, (c) rounds-up and (d) one-sided-cap are alternative FINDING shapes of
// the same detector and are not separately exercised here; the fixtures avoid tripping them so the
// CHECKED fixture is cleanly guarded.
import { scanScoreHonesty, PMAR } from "../../static/n-score-honest.ts";

const cfg = { ...PMAR } as any;
const F = (text: string) => [{ path: "src/services/recon.ts", text }];

export default function run() {
  // SMELL (a): the block computes the unreconciled VALUE (`unreconciledMinor`) but derives the score
  // from a matched/total COUNT ratio that never references it — the score ignores unreconciled dollars,
  // so it is not an amount-weighted lower bound and can read ~100 with a large exception still open.
  const vuln = scanScoreHonesty(
    F(`
  assuranceScore(rows) {
    const unreconciledMinor = rows.filter(r => !r.matched).reduce((s, r) => s + r.openMinor, 0);
    const matched = rows.filter(r => r.matched).length;
    let score = Math.floor(100 * matched / rows.length);
    return score;
  }`),
    cfg,
  );

  // GUARD: the score is an amount-weighted lower bound — `(total - unreconciled) / total`, floored
  // (never rounded up), and worst-case (0) on an empty denominator. The unreconciled amount flows into
  // the score, so it can only reach 100 when there are zero unreconciled dollars.
  const fixd = scanScoreHonesty(
    F(`
  assuranceScore(rows) {
    const unreconciledMinor = rows.filter(r => !r.matched).reduce((s, r) => s + r.openMinor, 0);
    const totalMinor = rows.reduce((s, r) => s + r.amountMinor, 0);
    let score = totalMinor === 0 ? 0 : Math.floor(100 * (totalMinor - unreconciledMinor) / totalMinor);
    return score;
  }`),
    cfg,
  );

  // DORMANT: no score-derivation function (the assurance/health/integrity/confidence/trust/recon +
  // "score" vocabulary never appears) — there is no published assurance score here to be dishonest.
  const absn = scanScoreHonesty(
    F(`
  computeTotals(rows) {
    const totalMinor = rows.reduce((s, r) => s + r.amountMinor, 0);
    return totalMinor;
  }`),
    cfg,
  );

  return {
    check: "N-SCORE-HONEST",
    vulnerable: vuln.violations.length > 0 && vuln.applicable,   // FINDING on the count-weighted score
    fixed: fixd.violations.length === 0 && fixd.applicable,       // CHECKED: amount-weighted floored lower bound
    absent: absn.violations.length === 0 && !absn.applicable,     // NOT_APPLICABLE: no score derivation (dormant)
  };
}
