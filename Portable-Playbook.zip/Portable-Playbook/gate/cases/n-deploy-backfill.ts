// Conformance case for N-DEPLOY-BACKFILL — a money change ships BOTH an APPLIED (registered) migration
// and a BACKFILL for the orgs/records that already exist. This case exercises leg C
// (migration-not-registered): documented .sql migrations that the migrate runner does (or does not) apply.
// Drives the detector's PURE scan (scanDeployBackfill) over in-memory fixtures (no fs, no temp dirs) and
// proves the 3-way gate: FINDING on the bug, CHECKED on the fix, NOT_APPLICABLE when dormant.
import { scanDeployBackfill, DEPLOY_BACKFILL_REGEXES } from "../../static/n-deploy-backfill.ts";

// Shared vocabulary + declared surface paths; only the file MAP (the fixtures) varies per fixture.
const cfg = {
  ...DEPLOY_BACKFILL_REGEXES,
  schemaFiles: ["migrations/001_init.sql"],
  chartOfAccounts: "accounts.ts",
  moneyPaths: ["gaap.ts"],
  seedFiles: ["seed.ts"],
  migrateRunnerFiles: ["migrate.ts"],
  migrationsDir: "migrations/",
} as any;
const M = (entries: Array<[string, string]>) => new Map<string, string>(entries);

export default function run() {
  // SMELL C [migration-not-registered]: a documented migration exists under migrations/, but the migrate
  // runner is a no-op placeholder — it never reads the migrations dir, applies a migration, or executes
  // their SQL — so the schema change ships UNAPPLIED.
  const vuln = scanDeployBackfill(
    M([["migrate.ts", `
export async function migrate() {
  // not wired up yet
  return;
}`]]),
    cfg,
  );

  // GUARD: the migrate runner reads the migrations directory and executes each documented migration, so
  // the schema change is actually APPLIED as part of the deploy.
  const fixd = scanDeployBackfill(
    M([["migrate.ts", `
import { readdirSync, readFileSync } from "node:fs";
export async function migrate(db) {
  for (const f of readdirSync("migrations").sort()) {
    await db.execute(readFileSync("migrations/" + f, "utf8"));
  }
}`]]),
    cfg,
  );

  // DORMANT: a plain money path with no accrual account read and no settlement debit, and NO migrate
  // runner present — there is no accrual-reading recognition/settlement path and no runner to check, so
  // the deploy-backfill invariant is dormant.
  const absn = scanDeployBackfill(
    M([["gaap.ts", `
export function recordSale(line) {
  return ledger.postEntry({ gl_account: "4000", amount_minor: line.amount_minor });
}`]]),
    cfg,
  );

  return {
    check: "N-DEPLOY-BACKFILL",
    vulnerable: vuln.violations.length > 0 && vuln.present,   // FINDING on the unapplied (no-op runner) migration
    fixed: fixd.violations.length === 0 && fixd.present,       // CHECKED: runner reads + applies the migrations
    absent: absn.violations.length === 0 && !absn.present,     // NOT_APPLICABLE: no backfill surface / runner (dormant)
  };
}
