// CONFORMANCE CASE — N-TENANT-ISO. Proves the 3-way gate against in-memory fixtures through the
// detector's PURE scan function `scanTenantIso(files, cfg)` (no fs, no temp dirs). Each fixture
// instantiates exactly one leg of the detector's header contract on smell A [unauthenticated
// request-supplied tenant]: the per-request org/tenant key is the only thing standing between one
// customer's money and another's, so its PROVENANCE is the whole ballgame.
//   FINDING  = the org key is resolved from a RAW request header (`req.headers["x-org-id"]`) in a file
//              with NO authentication/principal parsing — any caller sets the header to another org and
//              reads/writes that org's money (a cross-tenant breach).
//   CHECKED  = the org key is derived from an AUTHENTICATED principal (`verifyToken(...)` →
//              `principal.orgId`) with no default-tenant fallback — the boundary is an authenticated
//              fact, not a client-supplied suggestion.
//   DORMANT  = no per-request tenant RESOLUTION site: the org key is only READ from the already-built
//              request context (`c.orgId`), which is correct downstream scoping, so there is no
//              isolation boundary here to check.
//
// Smell B [default tenant] (`?? "org_01"`) is an alternative FINDING shape of the same detector and is
// not separately exercised here. The fixture `path` is cosmetic (citations / authByFile only).
import { scanTenantIso, PMAR } from "../../static/n-tenant-iso.ts";

const cfg = { ...PMAR } as any;
const F = (text: string) => [{ path: "src/http/server.ts", text }];

export default function run() {
  // SMELL A: the org key is read straight off a raw request header and the file does no authentication
  // at all (no Authorization read, no token/session verification) — nothing authenticates the tenant the
  // request claims, so any caller can set `x-org-id` to a victim org and operate on its books.
  const vuln = scanTenantIso(
    F(`
  function handlePayments(req, res) {
    const orgId = req.headers["x-org-id"];
    return db.payments.where({ orgId });
  }`),
    cfg,
  );

  // GUARD: the file verifies a bearer token into a principal, then derives the org key from that
  // authenticated principal, with no default-tenant fallback — the tenant is an authenticated fact.
  const fixd = scanTenantIso(
    F(`
  async function handlePayments(req, res) {
    const principal = await verifyToken(req.headers["authorization"]);
    const orgId = principal.orgId;
    return db.payments.where({ orgId });
  }`),
    cfg,
  );

  // DORMANT: no per-request RESOLUTION of the tenant from the transport — `orgId` is only read from the
  // already-built context (`c.orgId`) and passed to a scoped query. That is correct downstream scoping,
  // not a resolution site, so the isolation-boundary invariant is dormant here.
  const absn = scanTenantIso(
    F(`
  async function listPayments(c) {
    const orgId = c.orgId;
    return c.db.payments.where({ orgId });
  }`),
    cfg,
  );

  return {
    check: "N-TENANT-ISO",
    vulnerable: vuln.violations.length > 0 && vuln.present,   // FINDING on the unauthenticated request-supplied tenant
    fixed: fixd.violations.length === 0 && fixd.present,       // CHECKED: authenticated principal, no default tenant
    absent: absn.violations.length === 0 && !absn.present,     // NOT_APPLICABLE: no tenant resolution site (dormant)
  };
}
