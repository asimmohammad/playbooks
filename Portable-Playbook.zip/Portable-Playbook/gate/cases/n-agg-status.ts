// CONFORMANCE CASE — N-AGG-STATUS. Proves the 3-way gate against in-memory fixtures through the detector's
// PURE scan function `scanAggStatus(files, schemaText, cfg)` (no fs, no temp dirs). Each fixture
// instantiates the header's aggregation contract: a money total that SUMs an `amount_minor` column over a
// STATUS-BEARING money table must restrict to economically-final rows.
// The SMELL (bookedVsActual reads `expenses.amount_minor` with NO status predicate and reduces it into a
// total, folding draft / pending / rejected rows into "actual") = FINDING; its GUARD (the same read
// constrains status with `.eq("status","approved")` before the reduce) = CHECKED; and a SUM over a table
// the schema gives no status column (`widgets`) = DORMANT (no status-bearing table is aggregated).
//
// cfg is the AGG_VOCAB aggregation/status vocabulary with empty scanPaths/schemaFiles (the fixture text and
// schema are passed straight to the scan). schemaText tells the scan which tables are status-bearing: the
// expenses schema has a `status` column (vuln/fixd); the widgets schema has none (absn), so the scan is
// dormant. The fixtures use the pmar idioms the detector expects: `.from("t").select("amount_minor")` and
// a `.reduce((s, r) => s + r.amount_minor, 0)` money total.
import { scanAggStatus, AGG_VOCAB } from "../../static/n-agg-status.ts";

const cfg = { ...AGG_VOCAB, scanPaths: [], schemaFiles: [] } as any;
const F = (text: string) => [{ path: "x.ts", text }];

export default function run() {
  // expenses carries a `status` lifecycle column, so not every row is real money (drafts, rejected, void).
  const statusSchema = `create table expenses ( id uuid, amount_minor bigint, status text );`;

  // SMELL: the "actual" total reads `expenses.amount_minor` with NO status predicate, then reduces it —
  // draft / pending / rejected expenses are summed as if they were real money, so the variance is
  // overstated or structurally wrong while still looking plausible.
  const vuln = scanAggStatus(
    F(`
async function bookedVsActual(ctx: any) {
  const { data: rows } = await ctx.sb.from("expenses").select("amount_minor");
  const actual = rows.reduce((s, r) => s + r.amount_minor, 0);
  return actual;
}`),
    statusSchema,
    cfg,
  );

  // GUARD: the same read constrains status (`.eq("status", "approved")`) before the reduce, so draft /
  // pending / rejected rows are excluded and the total reflects only economically-final money.
  const fixd = scanAggStatus(
    F(`
async function bookedVsActual(ctx: any) {
  const { data: rows } = await ctx.sb.from("expenses").select("amount_minor").eq("status", "approved");
  const actual = rows.reduce((s, r) => s + r.amount_minor, 0);
  return actual;
}`),
    statusSchema,
    cfg,
  );

  // DORMANT: the only aggregate SUMs `widgets.qty`, and the widgets schema defines no status/state column —
  // there is no status-bearing money table being summed, so no total could fold non-final rows (dormant).
  const absn = scanAggStatus(
    F(`
async function totalWidgets(ctx: any) {
  const { data: rows } = await ctx.sb.from("widgets").select("qty");
  const n = rows.reduce((s, r) => s + r.qty, 0);
  return n;
}`),
    `create table widgets ( id uuid, qty int );`,
    cfg,
  );

  return {
    check: "N-AGG-STATUS",
    vulnerable: vuln.violations.length > 0 && vuln.present,   // FINDING on the unfiltered money total
    fixed: fixd.violations.length === 0 && fixd.present,       // CHECKED: status constrained before summing
    absent: absn.violations.length === 0 && !absn.present,     // NOT_APPLICABLE: no status-bearing total (dormant)
  };
}
