// Conformance case for N-WRITE-CHECK — a money/approval DB write CHECKS its `{ error }` result before
// the routine reports success (records an approval, flips status, emits, or returns success).
// Drives the detector's PURE scan (scanWriteCheck) over in-memory fixtures (no fs, no temp dirs) and
// proves the 3-way gate: FINDING on the bug, CHECKED on the fix, NOT_APPLICABLE when dormant.
import { scanWriteCheck, WRITE_CHECK_SMELLS } from "../../static/n-write-check.ts";

const cfg = { ...WRITE_CHECK_SMELLS, scanPaths: [], moneyTables: [] } as any;
const F = (text: string) => [{ path: "x.ts", text }];

export default function run() {
  // SMELL A [unchecked-write]: the `update` on `expense_approvals` (a money/approval table) is `await`ed
  // with NO `{ error }` destructured or checked, then the routine returns success — a failed or zero-row
  // write is swallowed, so a DB rejection appears as an approval.
  const vuln = scanWriteCheck(
    F(`
  async approve(input, ctx) {
    await ctx.sb.from("expense_approvals").update({ status: "approved" }).eq("id", input.id);
    return { status: "approved" };
  }`),
    cfg,
  );

  // GUARD: the write destructures `{ error }` and checks it (`if (error) throw`) BEFORE the success
  // return — a failed write can no longer pass for a completed approval.
  const fixd = scanWriteCheck(
    F(`
  async approve(input, ctx) {
    const { error } = await ctx.sb.from("expense_approvals").update({ status: "approved" }).eq("id", input.id);
    if (error) throw new Error(error.message);
    return { status: "approved" };
  }`),
    cfg,
  );

  // DORMANT: the only write targets a non-money table (`widgets`), so no money/approval write exists —
  // there is no result-check boundary to enforce here (the invariant is dormant).
  const absn = scanWriteCheck(
    F(`
  async createWidget(input, ctx) {
    await ctx.sb.from("widgets").insert({ id: crypto.randomUUID(), qty: 3 });
    return { ok: true };
  }`),
    cfg,
  );

  return {
    check: "N-WRITE-CHECK",
    vulnerable: vuln.violations.length > 0 && vuln.present,   // FINDING on the unchecked write
    fixed: fixd.violations.length === 0 && fixd.present,       // CHECKED: `{ error }` checked before success
    absent: absn.violations.length === 0 && !absn.present,     // NOT_APPLICABLE: no money/approval write (dormant)
  };
}
