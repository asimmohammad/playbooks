// Conformance case for N-ONCE — exactly-once money/recognition posting.
// Drives the detector's PURE scan (scanOnce) over in-memory fixtures (no fs, no temp dirs) and proves
// the 3-way gate: FINDING on the bug, CHECKED on the fix, NOT_APPLICABLE when the invariant is dormant.
// This exercises N-ONCE's recognition/accrual leg (the RECOGNITION_REGEXES vocabulary): a recognition
// post is exactly-once only when it is gated by a DURABLE UNIQUE accrual-to-source claim, not a MUTABLE
// lifecycle status, and with no status read-then-write race.
import { scanOnce, RECOGNITION_REGEXES } from "../../static/n-once.ts";

const cfg = { flows: [], recognition: { ...RECOGNITION_REGEXES, files: ["x.ts"] } } as any;
const M = (text: string) => new Map<string, string>([["x.ts", text]]);

export default function run() {
  // SMELL: the only replay guard is a MUTABLE status equality, there is no durable unique claim, and
  // the status is written after the post with no lock/CAS — a re-open/re-submit re-posts the accrual.
  const vuln = scanOnce(
    M(`
export async function recognizeExpense(e: any) {
  if (e.status === "approved") return;
  await ctx.ledger.postEntry({ debitAccountId: "exp", creditAccountId: "accrued", amount_minor: e.amount_minor });
  await sb.from("expenses").update({ status: "approved" }).eq("id", e.id);
}
`),
    cfg,
  );

  // GUARD: recognition is gated by a DURABLE UNIQUE accrual-to-source claim (ON CONFLICT on a
  // recognition table), so a retried/concurrent approval cannot post the accrual twice.
  const fixd = scanOnce(
    M(`
export async function recognizeExpense(e: any) {
  await sb.from("expense_recognitions").insert({ expense_id: e.id }).onConflict("expense_id").ignore();
  await ctx.ledger.postEntry({ debitAccountId: "exp", creditAccountId: "accrued", amount_minor: e.amount_minor });
}
`),
    cfg,
  );

  // DORMANT: no recognition/accrual function (no money post) exists — the exactly-once invariant
  // has nothing to apply to here.
  const absn = scanOnce(
    M(`
export async function createWidget(input: any) {
  await sb.from("widgets").insert({ id: crypto.randomUUID(), qty: 3 });
}
`),
    cfg,
  );

  return {
    check: "N-ONCE",
    vulnerable: vuln.violations.length > 0 && vuln.present, // FINDING on the bug
    fixed: fixd.violations.length === 0 && fixd.present,     // CHECKED: durable claim present, no violations
    absent: absn.violations.length === 0 && !absn.present,   // NOT_APPLICABLE: invariant dormant
  };
}
