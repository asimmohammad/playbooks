# Primitive Candidates — backlog (NOT shipped rules)

> **Status: these are candidates, not active checks.** Each entry below is a money-correctness
> invariant with a proposed detector, discovered by analysis but **not yet verified**. Nothing here
> runs in the gate until it is promoted. A candidate becomes a real rule only after it passes the
> **verification gate**: its detector must be `FINDING` on vulnerable code ∧ `CHECKED` on a fixed
> version ∧ `NOT_APPLICABLE` on an app that lacks the flow. No false-green, no false-positive.
>
> `gate-status: candidate` everywhere below. On promotion, the entry moves into the active catalog
> (`static/`, `rules/`, `PLAYBOOK.md`) and flips to `shipped`.

## ✅ Shipped to v3 (promoted — gate-verified)

| Candidate | Rule file | Gate (independently re-verified) |
|---|---|---|
| SCORE-HONEST (cluster D) | `static/n-score-honest.ts` | FINDING@pmar ∧ CHECKED@fix ∧ NA@absent |
| PASSTHRU-LIAB (cluster C) | `static/n-passthru-liab.ts` | FINDING@pmar ∧ CHECKED@fix ∧ NA@absent |
| OBLIG-DUP (cluster E) | `static/n-oblig-dup.ts` | FINDING@pmar ∧ CHECKED@fix ∧ NA@absent |
| TENANT-ISO (cluster B) | `static/n-tenant-iso.ts` | FINDING@pmar ∧ CHECKED@fix ∧ NA@absent |
| GL-TIE (cluster C) | `static/n-gl-tie.ts` | FINDING@pmar ∧ CHECKED@fix ∧ NA@absent |
| SOD (cluster B) | `static/n-sod.ts` | FINDING@pmar ∧ CHECKED@fix ∧ NA@absent |
| ONCE (cluster A) | `static/n-once.ts` | FINDING@pmar ∧ CHECKED@fix ∧ NA@absent |
| **N-CARD-FRESH** (new meta-check) | `static/n-card-fresh.ts` | FINDING@drifted-card ∧ CHECKED@in-sync ∧ NA@absent |

Run them: `node --experimental-transform-types run-pmar.ts /path/to/pmar` (see `PLAYBOOK.md` → "pmar
checks (v3)"). The first three are the bugs **no LLM tier caught** in the Haiku/Opus blind test. The
remaining candidates below stay in the backlog until they clear the same gate.

## Provenance

Discovered via a 7-domain deep dive of **`helix-fintech-apps/pmar`** @ `feat/pmar-mvp` — a Ramp-class
corporate spend platform (corporate cards, expenses, reimbursements, AP/bill-pay, AR/invoicing, tax,
double-entry ledger, bank reconciliation + assurance score). pmar is structurally different from the
consumer-neobank surface the current 13 primitives were discovered on, which is exactly why it
surfaces new invariant classes. Each candidate was run through the **subsumption test** — it must
prove it is a genuinely new invariant class, not an existing primitive that merely needs a new
adapter or a deeper detector.

## How a candidate graduates (the loop)

```
CANDIDATE → GATE (FINDING on bug ∧ CHECKED on fix ∧ NA where absent)
          → PROMOTE (land detector + rule + rubric into the active catalog; bump VERSION)
          → GENERALIZE (confirm it also runs on neobank via its adapter; static ones are adapter-free)
```

---

## Cluster A — Exactly-once & eventing (the distributed-money core)

| ID | Invariant (one line) | Static smell | Subsumption verdict |
|---|---|---|---|
| ONCE | ledger leg + domain row + idempotency marker co-commit in ONE txn; key claimed *before* the effect; external call behind a durable claim + provider idem-key | idempotency key stored *after* `fn()` returns; >1 commit scope in the executor; connector mutator with no idem-key param | NEW — #2 is local-replay only, #3 is single-row-lock |
| IDEMP-ID | idempotency identity = tenant + endpoint + body-hash; a reused key with a different request returns **409**, never a stale replay | identity tuple omits org or body-hash; lookup replays with no stored-vs-incoming compare | NEW — #2's "replay≠re-execute" is *satisfied*; this is a different failure |
| OUTBOX | domain events written to a durable outbox inside the txn, published only after commit | an `emit` in a DB-writing fn with no outbox insert; emit precedes the final state write; synchronous inline bus | NEW — none of 13 cover event↔state coherence |
| CONSUMER-DEDUP *(latent)* | a money-moving event consumer dedupes on event id | a bus subscriber that mutates with no event-id dedupe; a `replayAll` exists | NEW (latent — zero consumers today; armed for the first) |

## Cluster B — Authority, lifecycle & tenancy (the corporate-spend layer)

| ID | Invariant (one line) | Static smell | Subsumption verdict |
|---|---|---|---|
| TENANT-ISO ⚠️ | org key from an authenticated principal, never a request value; every money read/write scoped to it; no default tenant | tenant read from header/body/query (`X-Org-Id ?? "org_01"`); no principal parsing; money query missing org predicate | NEW — #11 is "may this principal act"; this is "walled off from peer orgs" (orthogonal). **Highest-severity live defect found.** |
| SOD | the approver is identified, ≠ submitter/beneficiary, and holds authority ≥ amount | approve method with no actor param; no approver-vs-originator compare; no amount-tier lookup | NEW — #11 is a *unary* actor check; SoD is *relational* + amount-scoped |
| LIFECYCLE | guarded one-way state machine; terminal states immutable; each money-releasing transition fires once | `UPDATE … SET status` with no prior-status guard; a money op reachable on a terminal record | NEW — the double-pay is *distinct* keyed requests (re-approve→re-pay), which #2 can't stop |
| CARD-2PHASE | a hold decrements available limit (Σ holds+settled−reversed ≤ limit under lock); settle references & is bounded by its auth; controls enforced at settle too | scalar limit test with no aggregate; settle with no auth lookup / no settle≤authorized; controls only in authorize branch | NEW — #4 is single-phase; #13 omits the two-amount hold↔capture bound |

## Cluster C — Double-entry semantics (accounting correctness *beyond* balance)

| ID | Invariant (one line) | Static smell | Subsumption verdict |
|---|---|---|---|
| GL-TIE | every obligation fully booked across its lifecycle; each GL control account == its subledger aggregate; aging never negative | obligation insert with no ledger post; a control account used on only one side; subledger table mutated outside the GL-posting txn | NEW — #1 passes while AP is economically unbooked; #9 is two *stores*, this is two *aggregations within one* |
| PASSTHRU-LIAB | tax/tips/withholdings booked to a **liability**, remitted, never recognized as revenue or dropped | a tax service with no tax-payable liability account; a tax amount credited to a revenue account | NEW — #1 (debit==credit) is blind to account *classification* |
| CUR | line.currency == account.currency; aggregates per currency; movements execute in the source record's declared currency (no hardcoded USD) | `SUM(amount_minor)` with no `GROUP BY currency`; writer with no account-currency check; `currency:"USD"` literal while the record carries a currency col | NEW (merges ledger + cards findings) — didn't exist in single-currency neobank |
| IMMUT-LEDGER | posted entries/lines never UPDATE/DELETE in place; corrections are new compensating entries | any UPDATE/DELETE on journal tables outside a migration; no immutability trigger/constraint | NEW — #12 governs an undo's *shape*, not in-place edits of posted rows |
| XFORM | money produced only by integer ops; rate/split rounded deterministically with residue re-summed to the whole; no float ever stored | `Math.round(minor * floatRate)`; per-part rounding in a loop with no sum-vs-whole reconciliation | NEW (merges ledger + tax findings) — #1 is in-ledger, this is across a transform |

## Cluster D — External reconciliation (internal-vs-**external** truth)

| ID | Invariant (one line) | Static smell | Subsumption verdict |
|---|---|---|---|
| RECON-EXC | an exception closes only by a validated real match or an explicit write-off that posts a balancing entry | a transition into "matched/cleared" with no existence/org/amount check; no write-off path at all | NEW — #9 is internal-vs-internal with "sync the lagging store"; here the counterparty is external & authoritative |
| RECON-MATCH | match relation injective both ways; amount+direction faithful within tolerance; reconciled total never inflated | magnitude-only match (`Math.abs`), direction-blind; no UNIQUE on match table; no already-matched re-check | NEW — #1 is debit==credit *in the ledger*, this is conservation *across the match graph* |
| SCORE-HONEST | a published money-health score is an amount-weighted lower bound: never 100/A with open exceptions, not vacuously perfect, monotone | count-ratio score while an amount field is unused; perfect default when denominator 0; rounds up over open exceptions | NEW — none of 13 govern honesty of a derived metric ("a score that lies is worse than no score") |
| OCR-CORROB | money against a receipt is corroborated by the receipt's own extracted amount; OCR confidence/GL is advisory, never authoritative | OCR surface returns no amount while the claim amount is caller-supplied; confidence gates an auto-state; OCR-GL posts money | NEW — no primitive covers "claim must be backed by an independently extracted document amount" |

## Cluster E — Provenance & safe defaults (where money values & instructions come from)

| ID | Invariant (one line) | Static smell | Subsumption verdict |
|---|---|---|---|
| MONEY-AUTH | any amount driving a charge/posting is recomputed server-side; a client amount is advisory only | a request-body `*Minor`/`*Amount` field used in a posting with no server recompute+compare | NEW **meta-primitive that SUBSUMES #4** (caps-under-lock is one instance) |
| FAILCLOSED | a lookup supplying a money parameter (rate/fee/FX/limit) fails closed on an unknown key; the permissive value only when positively configured | not-found branch returns `0`/a default/another key's value instead of raising | NEW — #5 is fail-closed *screening of a party*; this is the default direction of any money-param lookup |
| OBLIG-DUP | every obligation unique on its economic key (payee/customer + doc# + amount + period); same real invoice can't be paid/recognized twice | obligation insert with random UUID, no economic-dup SELECT, no UNIQUE natural key, no doc-number column | NEW — #2 dedupes *one* retried call by token; this blocks *two distinct* calls for one obligation |
| PAYOUT-DEST | money leaves only to a verified destination pinned to an immutable approval; editing payout details voids approval + forces re-screen | executor sends funds with no destination bound to payee; payee payout details mutable with no re-approval trigger | NEW — #5 is *who*, #8 is *how much*, #11 is *ordering* — none bind the *destination* |
| SEAM | all third-party money I/O crosses the one Connector seam; no direct SDK/network outside connectors/; inbound webhooks signature-authed + dedup'd before any ledger effect | a provider SDK/`fetch` import outside connectors/; `connectors.*` called from the HTTP layer; webhook handler posting a ledger entry with no signature check | NEW — #7 is runtime *state* reconciliation; this is a static *architectural boundary* + inbound authn |
| PARITY-LIVE | stub is contract-compatible with and no more permissive than live, proven by a shared test | stub with fail-open defaults / allow-all policy absent from live; no shared parity test; live is a bare skeleton | NEW — #9 is two *data stores* agreeing; this is two *implementations* agreeing on behavior |
| AUDIT | every money mutation writes an attributed (actor+reason+before/after) audit row in the same txn; no path skips it | a money-table INSERT/UPDATE fn with no reachable audit call; audit with constant/null actor + no reason | NEW — no existing primitive covers audit coverage |

---

## Existing-primitive deepenings pmar surfaced (NOT new primitives — detector upgrades)

| Primitive | Why too shallow on pmar | Deepen to |
|---|---|---|
| #3 Atomicity | pmar uses transactions, no `FOR UPDATE` row locks | assert **single-transaction co-commit**, not row locks |
| #4 Caps | card limit check is per-swipe; nothing aggregates | require cumulative Σ; becomes an instance of MONEY-AUTH |
| #2 Idempotency | applied only to the executor; some ledger-mutating paths have no key | cover **all** ledger-mutating paths; bind tenant+body → IDEMP-ID |
| #8 Reversal bounds | a reversal path is unbounded, no matching-settlement check | extend to that path; generalize to "Σ settled ≤ obligation" |
| #10 Deploy safety | `CREATE TABLE IF NOT EXISTS` can't apply a newly-added constraint; dead safety-config knobs | add **migration-strengthen-safety** + **config/policy-fidelity** detectors |
| #5 Screening | screens at creation only; discards the sanctions flag; fail-OPEN on unknown entity | re-screen at pay-time; read the sanctions flag; fail-closed on unknown |
| #7 Provider | provider status never polled back → records stuck "submitted" | add a status-convergence detector |
| #9 Store parity (DB) | money-row uniqueness/refs enforced in code only, no DB constraint | require UNIQUE/FK on the money row itself (folds into #2/#10) |

---

## Promotion priority (severity × reuse)

1. **TENANT-ISO, ONCE, GL-TIE, SOD, SCORE-HONEST** — highest severity, broadest reuse.
2. LIFECYCLE, RECON-EXC, PASSTHRU-LIAB, FAILCLOSED, OBLIG-DUP, MONEY-AUTH (restructures #4).
3. Architectural / rubric-first: SEAM, PARITY-LIVE, AUDIT, IMMUT-LEDGER.

~18 of 24 are static (adapter-free); only the behavioral assertions (exactly-once under crash, two-phase cumulative cap, score monotonicity) need a per-app adapter.

---

## ✅ Shipped to v4 (from the pmar Qodo reviews, PRs #5–#13)

v4 replaced the static card with a **derived binding** (`derive.ts`) and promoted 13 detectors from the
Qodo coverage gap — each gate-verified (FINDING@vuln ∧ CHECKED@fix ∧ NA@absent) and independently re-run
before landing. On the live `feat/gaap` stack: **18 of 19 checks FINDING**.

| Detector | New/Deepen | Qodo class closed |
|---|---|---|
| N-LIFECYCLE | new | lifecycle-state-machine (12 findings, 10 High) |
| N-AUDIT | new | audit-coverage |
| N-ROUTE-UNIQUE | new | approval-route-bypass |
| N-DEPLOY-BACKFILL | new | deploy-backfill |
| N-ORDER (static) | new | order-of-ops-external |
| N-FX-COMPARE | new | money-scale + currency match/normalize/mismatch |
| N-ENUM-FAILCLOSED | new | enum-validity |
| N-WRITE-CHECK | new | atomicity / unchecked-write |
| N-ACCOUNT-VALID | new | account-chart-validity |
| N-PII-PROJECTION | new | sensitive-field-exposure |
| N-FAILCLOSED-READ | new | error-swallow / recon-status-filter |
| N-ONCE / N-SOD / N-OBLIG-DUP / N-GL-TIE | deepen | recognition-idempotency, sod + actor-provenance, obligation-dup on new paths, supabase-insert binding |

## ✅ Shipped to v5 (the three money misses the v4-vs-Qodo head-to-head found)

We ran v4 against all nine Qodo-reviewed PRs and mapped every finding. v4 caught 43 of Qodo's 46
money-movement findings and missed exactly 3. v5 closes all three (each gate-verified
FINDING@vuln ∧ CHECKED@fix ∧ NA@absent, then confirmed on the real pmar site). On `feat/gaap`:
**20 of 21 checks FINDING**.

| Detector | New/Deepen | Qodo miss closed | Real site |
|---|---|---|---|
| (derivation fix) | `derive.ts` | **FX minor-unit scale** — leaf money module `fx.ts` now enters the surface, so the existing **N-FX-COMPARE** leg-A catches `Math.round(amountMinor * rate)` with no per-currency scale | `fx.ts:24` |
| N-AGING | new | **receivable/payable created with no due date** → never ages / goes overdue / gets dunned (`due_date: … ?? null`) | `ar.ts:39` (invoices), `ap.ts:87` (bills) |
| N-AGG-STATUS | new | **money total/variance over a status-bearing table with no status filter** → draft/rejected rows summed as real money | `travel.ts:134` (bookedVsActual) |

## ✅ Shipped to v6 (the one money miss the fresh v5-vs-Qodo head-to-head found)

Re-running the full head-to-head against v5 left exactly one money miss (PR#6, Medium). v6 closes it,
gate-verified (FINDING@vuln ∧ CHECKED@fix ∧ NA@absent **+ two false-positive guards**), confirmed on the
real pmar site. On `feat/gaap`: **21 of 22 checks FINDING**.

| Detector | New/Deepen | Qodo miss closed | Real site |
|---|---|---|---|
| N-REJECT-CASCADE | new | **a rejected decision leaves money stuck pending** — a combined approve/reject handler transitions the parent money object only on approve, so a reject/deny leaves the expense/invoice/bill in its pending/gated state | `policy.ts:173` (`decideException`) |

## Deferred — general, not money movement (Qodo's lane, not the money gate's)

These Qodo findings are real but are **not** money-correctness/movement, so they stay out of the gate:
list truncation at the Supabase row cap (read-completeness), live-connector test-infra breakage
(connector-mode), API-expense ↔ trip join (data-linkage), empty-trip-after-failed-ingest (data hygiene),
workflow config validation. Fair for an LLM reviewer (Qodo) to catch; not a deterministic money invariant.
