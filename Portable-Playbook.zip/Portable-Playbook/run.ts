// helix-portable — the runner.
//
// Given an adapter (a MoneySystemFactory) and a set of rules, run each rule against a
// FRESH MoneySystem and print a verdict table: id, status (CHECKED / FINDING /
// NOT_APPLICABLE) and reason. The runner is adapter-agnostic — point it at any adapter.
//
// There is deliberately NO adapter in this repo yet. Import this module and call
// runPlaybook(yourFactory) once an adapter exists, or run this file with an adapter
// module path as the first CLI argument (the module's default export must be a
// MoneySystemFactory).

import {
  type MoneySystem,
  type MoneySystemFactory,
  type Rule,
  type Verdict,
} from "./money-system.ts";
import { partyScreen } from "./rules/party-screen.ts";
import { ledgerConserve } from "./rules/ledger-conserve.ts";
import { nAtomic } from "./rules/n-atomic.ts";
import { nChgbk05 } from "./rules/n-chgbk-05.ts";
import { nRwd04 } from "./rules/n-rwd-04.ts";
import { nOrder01 } from "./rules/n-order-01.ts";
import { nAuthn } from "./rules/n-authn.ts";
import detectDeploy01, { NEOBANK as DEPLOY_NEOBANK } from "./static/n-deploy-01.ts";
import detectParity01, { NEOBANK as PARITY_NEOBANK } from "./static/n-parity-01.ts";
import detectTest01, { NEOBANK as TEST_NEOBANK } from "./static/n-test-01.ts";
import detectCap01, { NEOBANK as CAP_NEOBANK } from "./static/n-cap-01.ts";
import detectSched01, { NEOBANK as SCHED_NEOBANK } from "./static/n-sched-01.ts";
import detectScreen02, { NEOBANK as SCREEN_NEOBANK } from "./static/n-screen-02.ts";
import detectState01, { NEOBANK as STATE_NEOBANK } from "./static/n-state-01.ts";
import detectOrphan01, { NEOBANK as ORPHAN_NEOBANK } from "./static/n-orphan-01.ts";
import detectIdemp01, { NEOBANK as IDEMP_NEOBANK } from "./static/n-idemp-01.ts";
import detectCas01, { NEOBANK as CAS_NEOBANK } from "./static/n-cas-01.ts";
import detectScope01, { NEOBANK as SCOPE_NEOBANK } from "./static/n-scope-01.ts";
import detectUnwind01, { NEOBANK as UNWIND_NEOBANK } from "./static/n-unwind-01.ts";

/**
 * The behavioural rules this playbook ships with (they need an adapter to drive). NO-ORPHAN and
 * N-IDEMP were CONVERTED to adapter-free static detectors (N-ORPHAN-01 / N-IDEMP-01) because the
 * #28 defects live on surfaces the hand-written adapter never drove — so no behavioural duplicate
 * remains here.
 */
export const ALL_RULES: Rule[] = [
  partyScreen,
  ledgerConserve,
  nAtomic,
  nChgbk05,
  nRwd04,
  nOrder01,
  nAuthn,
];

/** Which layer produced a result: an adapter-free source scan, or an adapter-driven behavioural run. */
export type Layer = "static" | "behavioral";

/** A verdict plus the id/title/layer it was produced for. */
export interface RuleResult {
  id: string;
  title: string;
  layer: Layer;
  verdict: Verdict;
}

// --- static detectors --------------------------------------------------------------------
//
// The repo-agnostic source scanners in ./static/*. Unlike the behavioural rules they drive no
// adapter and need no running MoneySystem — each reads source / SQL / git-diff deterministically —
// so they are registered here with their binding (the neobank preset) and run on their own. New
// portable static detectors append to ALL_STATIC_DETECTORS.
export interface StaticDetector {
  /** Stable id, e.g. "N-CAP-01". */
  id: string;
  /** One-line statement of the invariant. */
  title: string;
  /** Run the scan against the live repo and return its verdict. */
  run(): Verdict;
}

/** The static detectors this playbook ships with. New portable detectors append here. */
export const ALL_STATIC_DETECTORS: StaticDetector[] = [
  {
    id: "N-DEPLOY-01",
    title: "Deployed artifacts under protected paths are append-only.",
    run: () => detectDeploy01(DEPLOY_NEOBANK),
  },
  {
    id: "N-PARITY-01",
    title: "The in-memory and SQL stores stay in lockstep (ops, SQL fns, guard codes, CI).",
    run: () => detectParity01(PARITY_NEOBANK),
  },
  {
    id: "N-TEST-01",
    title: "No branch greens the pipeline by silently weakening a money assertion.",
    run: () => detectTest01(TEST_NEOBANK),
  },
  {
    id: "N-CAP-01",
    title:
      "Every declared aggregate cap — and every per-member spend limit used at authorization — is read and enforced inside the atomic SQL op under a lock, never from the request payload.",
    run: () => detectCap01(CAP_NEOBANK),
  },
  {
    id: "N-SCHED-01",
    title:
      "A scheduled-start card never authorizes before its activation instant, and the start survives card replacement/reissue.",
    run: () => detectSched01(SCHED_NEOBANK),
  },
  {
    id: "N-SCREEN-02",
    title:
      "A money/activation op for a member re-screens the actual card holder (KYC + sanctions) and the funding account, not just the owner.",
    run: () => detectScreen02(SCREEN_NEOBANK),
  },
  {
    id: "N-STATE-01",
    title:
      "A money op on a member/card re-reads member & card state from the locked row and rejects a removed/invalid subject before moving money.",
    run: () => detectState01(STATE_NEOBANK),
  },
  {
    id: "N-ORPHAN-01",
    title:
      "The issuer card is cancelled only when the durable write fails — never because a post-commit step (e.g. audit) throws after the card is committed-active.",
    run: () => detectOrphan01(ORPHAN_NEOBANK),
  },
  {
    id: "N-IDEMP-01",
    title:
      "Money routes gate on an Idempotency-Key (read-first/replay); a conditional state update reports success/audits only after confirming a row changed.",
    run: () => detectIdemp01(IDEMP_NEOBANK),
  },
  {
    id: "N-CAS-01",
    title:
      "A status transition is a locked compare-and-set: a status-filtered read without FOR UPDATE must not be followed by an unconditional by-id status write (TOCTOU).",
    run: () => detectCas01(CAS_NEOBANK),
  },
  {
    id: "N-SCOPE-01",
    title:
      "A bulk state-restore (unfreeze/resume) reactivates only what its pairing op set — by provenance, not the shared state alone — never rows another path set.",
    run: () => detectScope01(SCOPE_NEOBANK),
  },
  {
    id: "N-UNWIND-01",
    title:
      "A terminal unwind (settle-to-zero + mark removed/closed) first asserts no unresolved money — open dispute / provisional credit / pending inbound.",
    run: () => detectUnwind01(UNWIND_NEOBANK),
  },
];

/**
 * Run the static detectors against the live repo. Like runPlaybook, a detector that throws is
 * captured as a FINDING (a detector that crashes is a failed check, not a pass).
 */
export function runStaticDetectors(
  detectors: StaticDetector[] = ALL_STATIC_DETECTORS,
): RuleResult[] {
  return detectors.map((d): RuleResult => {
    try {
      return { id: d.id, title: d.title, layer: "static", verdict: d.run() };
    } catch (e) {
      return {
        id: d.id,
        title: d.title,
        layer: "static",
        verdict: {
          status: "FINDING",
          reason: `detector threw: ${(e as Error).message}`,
          detail: { stack: (e as Error).stack },
        },
      };
    }
  });
}

/**
 * Run `rules` against `factory`. Each rule gets its own freshly built, reset MoneySystem,
 * so one rule's writes never leak into another's. An unexpected throw from a rule or
 * adapter is captured as a FINDING (a rule that crashes is a failed check, not a pass).
 */
export async function runPlaybook(
  factory: MoneySystemFactory,
  rules: Rule[] = ALL_RULES,
): Promise<RuleResult[]> {
  const results: RuleResult[] = [];
  for (const rule of rules) {
    let verdict: Verdict;
    try {
      const sys: MoneySystem = await factory();
      await sys.reset();
      verdict = await rule.run(sys);
    } catch (e) {
      verdict = {
        status: "FINDING",
        reason: `rule threw: ${(e as Error).message}`,
        detail: { stack: (e as Error).stack },
      };
    }
    results.push({ id: rule.id, title: rule.title, layer: "behavioral", verdict });
  }
  return results;
}

/**
 * The ONE combined runner. Always runs every static detector (adapter-free); when an adapter is
 * given, also runs every behavioural rule against it. Returns a single list, statics first, each
 * tagged with its layer. `run-static.ts` keeps running only the static set as the CI gate.
 */
export async function runAll(factory?: MoneySystemFactory): Promise<RuleResult[]> {
  const statics = runStaticDetectors();
  const behavioural = factory ? await runPlaybook(factory) : [];
  return [...statics, ...behavioural];
}

const GLYPH: Record<Verdict["status"], string> = {
  CHECKED: "ok  ",
  FINDING: "FAIL",
  NOT_APPLICABLE: "n/a ",
  // Distinct from both a pass and a finding: the path was never driven, so nothing is proven.
  NOT_EXERCISED: "????",
};

/** Render results as an aligned text table with a LAYER column (static | behavioral). */
export function formatVerdictTable(results: RuleResult[]): string {
  const idW = Math.max(4, ...results.map((r) => r.id.length));
  const lyW = Math.max(5, ...results.map((r) => r.layer.length));
  const stW = Math.max(14, ...results.map((r) => r.verdict.status.length));
  const head = `${pad("RULE", idW)}  ${pad("LAYER", lyW)}  ${pad("STATUS", stW)}  REASON`;
  const rule = "-".repeat(head.length);
  const rows = results.map(
    (r) =>
      `${pad(r.id, idW)}  ${pad(r.layer, lyW)}  ${GLYPH[r.verdict.status]} ${pad(r.verdict.status, stW)}  ${r.verdict.reason}`,
  );
  return [head, rule, ...rows].join("\n");
}

function pad(s: string, w: number): string {
  return s.length >= w ? s : s + " ".repeat(w - s.length);
}

/** Run and print. Returns the results so callers can also assert on them in CI. */
export async function runAndPrint(
  factory: MoneySystemFactory,
  rules: Rule[] = ALL_RULES,
): Promise<RuleResult[]> {
  const results = await runPlaybook(factory, rules);
  // eslint-disable-next-line no-console
  console.log(formatVerdictTable(results));
  return results;
}

// --- CLI entry (Deno): `deno run -A run.ts ./path/to/adapter.ts` ----------------------
// Guarded so importing this module never triggers execution. No adapter ships here, so
// invoking without one prints usage instead of failing obscurely.
const g = globalThis as unknown as {
  Deno?: { args: string[]; exit(code?: number): never };
};
if (g.Deno && (import.meta as unknown as { main?: boolean }).main) {
  const adapterPath = g.Deno.args[0];
  if (!adapterPath) {
    console.error(
      "usage: deno run -A run.ts <adapter-module>\n" +
        "  <adapter-module> default-exports a MoneySystemFactory () => MoneySystem.\n" +
        "  No adapter ships with helix-portable; write one that implements ./money-system.ts.",
    );
    g.Deno.exit(2);
  }
  const mod = (await import(adapterPath)) as { default?: MoneySystemFactory };
  const factory = mod.default;
  if (typeof factory !== "function") {
    console.error(`adapter ${adapterPath} must default-export a MoneySystemFactory`);
    g.Deno.exit(2);
  } else {
    // The combined CLI path: one table, every static detector + every behavioural rule.
    const results = await runAll(factory);
    // eslint-disable-next-line no-console
    console.log(formatVerdictTable(results));
    // The gate blocks on any STATIC finding; behavioural rows (which depend on adapter coverage) are
    // informational — a NOT_EXERCISED row is surfaced, never counted as a pass.
    const gateFailed = results.some((r) => r.layer === "static" && r.verdict.status === "FINDING");
    g.Deno.exit(gateFailed ? 1 : 0);
  }
}
