# Benchmark — how trustworthy is this gate?

Two kinds of evidence: **conformance** (does each detector provably hold its contract?) and **field results**
(how did it do against a real reviewer on real PRs?). Plus an honest statement of what is *not* yet proven.

## 1. Conformance — 22/22 detectors (reproduce: `npm run gate`)

Every detector passes a committed, deterministic three-way gate (`gate.ts` + `gate/cases/*.ts`):

| Fixture | Asserts | What it rules out |
|---|---|---|
| **vulnerable** → FINDING | the detector fires on code that HAS the bug | false negative on the canonical bug |
| **fixed** → CHECKED | it stays quiet when the guard is in place | false positive on the correct guard |
| **absent** → NOT_APPLICABLE | it is dormant when the invariant doesn't apply | noise where there's no money flow |

`npm run gate` runs all 22 in-memory (no fs, no LLM, deterministic) and **exits non-zero if any detector
regresses** — it is wired into CI (`.github/workflows/conformance.yml`), so a detector that stops catching
its bug, or starts false-positiving on a fix, blocks the merge. Current: **22/22 conformant.**

This proves detector **logic** is correct on its canonical fixture. It does **not** by itself prove the
real-world false-positive rate on arbitrary code (see §3).

## 2. Field results — vs Qodo across 9 reviewed pmar PRs

Run against the published Portable-Playbook, mapped line-by-line against Qodo (`qodo-code-review[bot]`),
then reconciled against the deterministic output:

- Qodo raised **44 money-movement findings**. The gate caught **37 line-exact + 7 right-class (different
  site) = 44/44 covered, 0 missed.** High-severity money: **31 → 0 missed.**
- The gate independently surfaced **21 money-bug categories Qodo raised on zero PRs** — including 3 whole
  classes a diff-only reviewer structurally cannot see (GL can't tie out, tax booked as revenue, a
  reconciliation score that overstates assurance).
- Cost: **~$0/run, deterministic** (same input → same output), vs an LLM reviewer's per-run cost and
  run-to-run variance.

## 3. What is NOT yet proven (honest limits)

- **Two apps, one stack.** Validated on `pmar` and `neobank` — both TypeScript + Supabase/SQL, same shop.
  There is no third, independent app yet. Treat cross-app generalization as unproven.
- **Stack scope.** Today the gate only reads **TypeScript under `src/` with an SQL `create table` schema**.
  Pointed at anything else it now **refuses to pass** (exit 2, loud) instead of a false green — but that
  means its *coverage* is still scoped to that stack. See the README's scope note.
- **Real-world FP rate is unmeasured.** Conformance proves each detector on its own fixture; it does not
  measure how often a detector false-positives across a large corpus of real, varied code. A labelled
  multi-repo corpus is the next step to put a number on precision/recall.

## One line
**Conformance: 22/22, enforced in CI. Field: 44/44 of Qodo's money findings covered + 21 categories it
missed. Unproven: a third stack and a measured real-world false-positive rate.**
