// run-pmar.ts — the pmar money-correctness checks, bound to the DERIVED money surface.
//
//   node --experimental-transform-types run-pmar.ts /abs/path/to/pmar
//
// v4 change: the surface is no longer a hand-written card. deriveMoneySurface(cwd) computes it from the
// repo (deterministic, fail-open), so every detector follows the money into any new module the moment it
// lands — gaap.ts / policy.ts / travel.ts / validation/assurance.ts are covered without touching a card.
// Detectors built for v4 expose forSurface(surface); the earlier ones take their path fields from the
// surface here. v5 adds N-AGING + N-AGG-STATUS and widens derivation to pull leaf money modules (fx.ts)
// into the surface; v6 adds N-REJECT-CASCADE — the gaps the Qodo head-to-head found. Exits non-zero on
// any FINDING.
import { deriveMoneySurface, unusableSurfaceReason } from "./derive.ts";

// v4 detectors (new + deepened) — uniform contract: default detect + forSurface(surface)
import lifecycle, { forSurface as fsLifecycle } from "./static/n-lifecycle.ts";
import once, { forSurface as fsOnce } from "./static/n-once.ts";
import sod, { forSurface as fsSod } from "./static/n-sod.ts";
import oblig, { forSurface as fsOblig } from "./static/n-oblig-dup.ts";
import audit, { forSurface as fsAudit } from "./static/n-audit.ts";
import route, { forSurface as fsRoute } from "./static/n-route-unique.ts";
import deploy, { forSurface as fsDeploy } from "./static/n-deploy-backfill.ts";
import order, { forSurface as fsOrder } from "./static/n-order-ext.ts";

// v4 batch 2 — the rest of the pmar Qodo money-correctness gaps
import fxCompare, { forSurface as fsFx } from "./static/n-fx-compare.ts";
import enumFC, { forSurface as fsEnum } from "./static/n-enum-failclosed.ts";
import writeCheck, { forSurface as fsWrite } from "./static/n-write-check.ts";
import accountValid, { forSurface as fsAcct } from "./static/n-account-valid.ts";
import piiProj, { forSurface as fsPii } from "./static/n-pii-projection.ts";
import failClosedRead, { forSurface as fsFcr } from "./static/n-failclosed-read.ts";

// v5 — the three money-correctness gaps the Qodo head-to-head found v4 missing. N-AGING (a receivable/
// payable created with no due date never ages or goes overdue) and N-AGG-STATUS (a money total/variance
// over a status-bearing table folding draft/rejected rows in) are new detectors; the third miss — the FX
// minor-unit SCALE bug in fx.ts — is now caught by the EXISTING N-FX-COMPARE, because derive.ts (v5)
// pulls leaf money modules like fx.ts into the surface, so no new detector was needed for it.
import aging, { forSurface as fsAging } from "./static/n-aging.ts";
import aggStatus, { forSurface as fsAggStatus } from "./static/n-agg-status.ts";

// v6 — the one money miss the fresh v5-vs-Qodo head-to-head surfaced: a combined approve/reject decision
// that transitions the parent money object ONLY on approval, leaving a rejected item stuck pending.
import rejectCascade, { forSurface as fsReject } from "./static/n-reject-cascade.ts";

// earlier detectors — bound to the derived surface via their config's path fields
import scoreHonest, { PMAR as SCORE } from "./static/n-score-honest.ts";
import passthru, { PMAR as PASS } from "./static/n-passthru-liab.ts";
import tenantIso, { PMAR as TENANT } from "./static/n-tenant-iso.ts";
import glTie, { forSurface as fsGl } from "./static/n-gl-tie.ts";
import cardFresh from "./static/n-card-fresh.ts";

const g0 = globalThis as unknown as { Deno?: { args: string[] } };
const cwd = g0.Deno?.args?.[0] ?? process.argv[2] ?? process.cwd();

const surface = deriveMoneySurface(cwd);

// SAFETY GATE: if the app was not actually scanned, REFUSE to pass. A derived surface with no source files,
// no money files, or no money tables means every check will go NOT_APPLICABLE and the runner would otherwise
// exit 0 — a FALSE GREEN on code we never read (e.g. a non-TypeScript app, a non-`src/` layout, or a
// Prisma/Rails/Django schema). Exit code 2 ("could not scan"), distinct from 1 ("money bug found").
const unusable = unusableSurfaceReason(surface);
if (unusable) {
  const d = surface.derivation;
  console.error(`\n=== MONEY-CORRECTNESS GATE: REFUSING TO PASS (surface not scannable) ===`);
  console.error(`    target : ${cwd}`);
  console.error(`    surface: ${d.moneyFileCount}/${d.scannedTs} .ts files are money · ${surface.moneyTables.length} money tables · schema ${surface.schemaMode}`);
  console.error(`    reason : ${unusable}`);
  console.error(`    A green result here would be FALSE — the gate did not scan your money code. Supported today:`);
  console.error(`    TypeScript under src/, with an SQL \`create table\` schema (supabase migrations) or ts-embedded.\n`);
  const ge = globalThis as unknown as { Deno?: { exit(code?: number): never } };
  if (ge.Deno) ge.Deno.exit(2);
  else process.exit(2);
}

const dirsOf = (paths: string[]): string[] => [...new Set(paths.map((p) => p.split("/").slice(0, -1).join("/")).filter(Boolean))];

const checks: Array<[string, () => { status: string; reason: string }]> = [
  // --- earlier checks, now surface-bound ---
  ["N-SCORE-HONEST", () => scoreHonest({ ...SCORE, scanDirs: dirsOf(surface.moneyPaths), cwd })],
  ["N-PASSTHRU-LIAB", () => passthru({ ...PASS, chartOfAccounts: surface.chartOfAccounts, taxEngineFiles: surface.moneyPaths, cwd })],
  ["N-OBLIG-DUP", () => oblig(fsOblig(surface))],
  ["N-TENANT-ISO", () => tenantIso({ ...TENANT, httpEntryFiles: [surface.httpEntry], cwd })],
  ["N-GL-TIE", () => glTie(fsGl(surface))],
  ["N-SOD", () => sod(fsSod(surface))],
  ["N-ONCE", () => once(fsOnce(surface))],
  ["N-CARD-FRESH", () => cardFresh(surface, { cwd })],
  // --- v4 hardening (Qodo-derived) ---
  ["N-LIFECYCLE", () => lifecycle(fsLifecycle(surface))],
  ["N-AUDIT", () => audit(fsAudit(surface))],
  ["N-ROUTE-UNIQUE", () => route(fsRoute(surface))],
  ["N-DEPLOY-BACKFILL", () => deploy(fsDeploy(surface))],
  ["N-ORDER", () => order(fsOrder(surface))],
  // --- v4 batch 2 ---
  ["N-FX-COMPARE", () => fxCompare(fsFx(surface))],
  ["N-ENUM-FAILCLOSED", () => enumFC(fsEnum(surface))],
  ["N-WRITE-CHECK", () => writeCheck(fsWrite(surface))],
  ["N-ACCOUNT-VALID", () => accountValid(fsAcct(surface))],
  ["N-PII-PROJECTION", () => piiProj(fsPii(surface))],
  ["N-FAILCLOSED-READ", () => failClosedRead(fsFcr(surface))],
  // --- v5 (Qodo head-to-head misses closed) ---
  ["N-AGING", () => aging(fsAging(surface))],
  ["N-AGG-STATUS", () => aggStatus(fsAggStatus(surface))],
  // --- v6 (the last fresh-head-to-head miss) ---
  ["N-REJECT-CASCADE", () => rejectCascade(fsReject(surface))],
];

// Severity tiers. A BLOCK finding fails the gate (exit 1); a WARN finding (medium-severity money hygiene)
// is reported but does NOT fail the build, so a low-tier false positive can't nuke trust in the whole gate.
// Unlisted check => BLOCK (fail-safe: a new/unknown detector blocks until someone deliberately downgrades it).
const WARN_TIER: ReadonlySet<string> = new Set(["N-AGING", "N-AUDIT", "N-ACCOUNT-VALID", "N-PII-PROJECTION"]);
const tierOf = (id: string): "BLOCK" | "WARN" => (WARN_TIER.has(id) ? "WARN" : "BLOCK");

let block = 0;
let warn = 0;
console.log(`\n=== pmar money-correctness checks (derived surface) — ${cwd} ===`);
console.log(`    surface: ${surface.derivation.moneyFileCount}/${surface.derivation.scannedTs} src files are money · ${surface.moneyTables.length} money tables · schema ${surface.schemaMode}\n`);
for (const [id, run] of checks) {
  let v: { status: string; reason: string };
  try { v = run(); } catch (e) { v = { status: "ERROR", reason: String((e as Error)?.message ?? e).slice(0, 160) }; }
  const tier = tierOf(id);
  if (v.status === "FINDING") { if (tier === "BLOCK") block++; else warn++; }
  const sev = v.status === "FINDING" ? (tier === "BLOCK" ? "BLOCK " : "warn  ") : "      ";
  const tag = v.status === "FINDING" ? "FINDING 🚩" : v.status === "CHECKED" ? "CHECKED ✅" : v.status === "ERROR" ? "ERROR ⚠️" : v.status + " ⬜";
  console.log(`${sev}[${tag}] ${id}\n    ${v.reason}\n`);
}
console.log(`==== ${block} blocking + ${warn} warning money finding(s) across ${checks.length} checks ====`);
if (block) console.log(`    GATE FAILS — ${block} blocking money bug(s) must be fixed.`);
else if (warn) console.log(`    gate passes with ${warn} warning(s) — medium-severity hygiene, review but non-blocking.`);
const g = globalThis as unknown as { Deno?: { exit(code?: number): never } };
if (g.Deno) g.Deno.exit(block ? 1 : 0);
else process.exitCode = block ? 1 : 0;
