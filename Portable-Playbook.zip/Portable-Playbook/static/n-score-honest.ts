// N-SCORE-HONEST — portable static detector: a published money-health / assurance score is an
// amount-weighted LOWER BOUND, and never reads as perfect while open exceptions or unreconciled
// value remain.
//
// INVARIANT: a reconciliation / money-movement assurance score that an app PUBLISHES (an API field,
// a dashboard grade) is a claim about how much money is accounted for. It must be computed as an
// amount-weighted LOWER BOUND of that claim: weighted by the unreconciled VALUE (not a count of
// rows), floored (never rounded up), worst-case on no data, and capped on ANY ledger drift (either
// sign). A score that overstates — reaching 100 / grade A while exceptions or unreconciled dollars
// are still open — is a false all-clear: the one number a reviewer trusts says "done" when money is
// still missing.
//
// SMELL (any one is a FINDING, inside the score-derivation block):
//   (a) COUNT-weighted: the score is derived from a matched/total COUNT ratio while an unreconciled
//       AMOUNT is computed in the same block but never flows into the score (one $1M exception and
//       999 one-cent matches score 99.9%).
//   (b) PERFECT-ON-EMPTY: a zero denominator yields a perfect score (`total === 0 ? 1`/`100`) — "no
//       data" is published as "fully assured" instead of worst-case / unknown.
//   (c) ROUNDS UP: the ratio is scaled to the max with Math.round / Math.ceil, so a non-zero
//       exception set (99.6%) rounds to 100 — the max must be reachable ONLY at zero exceptions,
//       i.e. floored / truncated.
//   (d) ONE-SIDED CAP: a drift / exception cap is gated on one sign only (`drift > 0`), so the
//       opposite deviation (overstated cash, `drift < 0`) escapes the cap entirely.
//
// This is a SOURCE scanner over pmar's TypeScript (NOT SQL migrations — see adapters/pmar.ts): it
// reads the service .ts files, locates each score-derivation function by the spec's STABLE score
// vocabulary (assurance / health / integrity / confidence / trust score), scopes to its brace-block,
// and fails CLOSED on any one smell — so it fires regardless of adapter coverage. Dormant
// (NOT_APPLICABLE) when no such score derivation exists in the scanned sources. It cites file:line.

import { readFileSync, readdirSync, statSync } from "node:fs";
import { checked, finding, notApplicable, type Verdict } from "../money-system.ts";

export interface ScoreHonestConfig {
  /** Dirs (relative to cwd) whose *.ts files may hold a money-health / assurance score derivation. */
  scanDirs: string[];
  /** Extra explicit source files to also scan (relative to cwd). */
  sources?: string[];
  /**
   * Locator + applicability gate: the score-derivation FUNCTION header. Its brace-block is the scan
   * scope. Keyed on the spec's stable score vocabulary so it survives a rebuild / rename of the
   * method, and stays dormant on a repo with no such score. Default matches a function whose name
   * contains assurance/health/integrity/confidence/trust/recon + "score".
   */
  scoreFn?: RegExp;
  /**
   * Smell (a): an unreconciled / exception / outstanding AMOUNT computed in the block. Group 1 = the
   * variable name, which the score's value MUST transitively reference (else the score ignores the
   * unreconciled value — not amount-weighted). Dormant when no such amount is computed.
   */
  unreconciledAmount?: RegExp;
  /** Smell (b): a zero-denominator guard that yields a PERFECT score (1 / 1.0 / 100). */
  zeroPerfect?: RegExp;
  /** Smell (c): the score produced by rounding UP (round / ceil) a scaled rate instead of flooring. */
  roundsUp?: RegExp;
  /** Smell (d): a drift / exception cap gated on ONE sign of the deviation only. */
  oneSidedCap?: RegExp;
  /** Repo root. Default process.cwd(). */
  cwd?: string;
}

/**
 * The pmar binding — all pmar specifics live here, in config, never in the detector. pmar's money
 * logic is TypeScript (adapters/pmar.ts, PMAR_SURFACE.moneyPaths); the assurance score lives in
 * src/services/recon.ts (ReconService.assuranceScore).
 */
export const PMAR: ScoreHonestConfig = {
  scanDirs: ["src/services"],
  scoreFn: /\b\w*(?:assurance|health|integrity|confidence|trust|recon(?:ciliation)?)[\s_]*score\w*\s*\(/i,
  unreconciledAmount:
    /(?:const|let|var)\s+(\w*(?:unreconciled|exception|unmatched|outstanding)\w*)\s*=/i,
  zeroPerfect:
    /(?:===?|!==?)\s*0\s*\?\s*(?:1(?:\.0+)?|100)\b|!==?\s*0\s*\?[^:;?]*:\s*(?:1(?:\.0+)?|100)\b/,
  roundsUp:
    /\bscore\s*=\s*[^;]*\bMath\s*\.\s*(?:round|ceil)\s*\(|\bMath\s*\.\s*(?:round|ceil)\s*\(\s*[^;)]*\b(?:rate|ratio|coverage|matched|pct|percent)\b/i,
  oneSidedCap:
    /\bif\s*\(\s*[\w.$]*(?:drift|exception|deviation|variance|unreconciled)[\w.$]*\s*(?:>=?|<=?)\s*0\s*\)[\s\S]{0,140}?(?:Math\s*\.\s*(?:min|max)|\bscore\s*=)/i,
};

// --- pure source-reading primitives (repo-agnostic; mirror the other static detectors) -

const lineAt = (src: string, offset: number): number =>
  src.slice(0, Math.max(0, offset)).split("\n").length;

/** A score-derivation block: its body text and the absolute index of its opening brace in `src`. */
export interface ScoreBlock {
  body: string;
  start: number;
}

/** Every score-derivation function's brace-block, located by `scoreFn` and brace-matched. */
export function scoreBlocks(src: string, scoreFn: RegExp): ScoreBlock[] {
  const re = new RegExp(scoreFn.source, scoreFn.flags.includes("g") ? scoreFn.flags : scoreFn.flags + "g");
  const out: ScoreBlock[] = [];
  for (const m of src.matchAll(re)) {
    let i = m.index + m[0].length;
    // Skip the parameter list / return-type annotation to the body's opening brace. A `;` or `=`
    // first means this was a call / type reference, not a function definition → not a block.
    while (i < src.length && src[i] !== "{" && src[i] !== ";" && src[i] !== "=") i++;
    if (src[i] !== "{") continue;
    const start = i;
    let depth = 0;
    for (; i < src.length; i++) {
      if (src[i] === "{") depth++;
      else if (src[i] === "}") {
        depth--;
        if (depth === 0) {
          i++;
          break;
        }
      }
    }
    out.push({ body: src.slice(start, i), start });
  }
  return out;
}

// --- the score-honesty logic -----------------------------------------------------------

export interface ScoreScan {
  /** "<file>:<line> — <why>" for each smell found in a score-derivation block. */
  violations: string[];
  /** A score-derivation block was found (else the detector is dormant). */
  applicable: boolean;
}

/**
 * Smell (a): an unreconciled AMOUNT is computed in the block but does not transitively flow into the
 * score's value — the score is not amount-weighted. Returns the index (in `body`) of the first `score`
 * assignment to cite, plus the amount variable name, when it is unused; null otherwise.
 */
function amountUnusedInScore(
  body: string,
  cfg: ScoreHonestConfig,
): { at: number; varName: string } | null {
  const amtRe = cfg.unreconciledAmount ?? PMAR.unreconciledAmount!;
  const am = amtRe.exec(body);
  if (!am) return null; // no unreconciled amount computed → nothing to be unused
  const varName = am[1];

  // Local `const/let/var NAME = RHS;` definitions (RHS may span lines; stops at the first `;`).
  const defs = new Map<string, string>();
  for (const d of body.matchAll(/(?:const|let|var)\s+(\w+)\s*=\s*([^;]+);/g)) defs.set(d[1], d[2]);

  // Every RHS assigned to `score` (`let score = …`, `score = …`), excluding `==`/`>=` comparisons.
  const scoreRhs: string[] = [];
  let firstAt = -1;
  for (const s of body.matchAll(/(?:^|[^.\w])score\s*=(?!=)\s*([^;]+);/g)) {
    scoreRhs.push(s[1]);
    if (firstAt < 0) firstAt = s.index + s[0].indexOf("score");
  }
  if (scoreRhs.length === 0) return null; // no scalar `score` assignment → different shape; skip (a)

  // Transitive closure: does any score RHS reach the amount variable through local definitions?
  const seen = new Set<string>();
  const stack = [...scoreRhs];
  while (stack.length) {
    const expr = stack.pop()!;
    for (const id of expr.match(/[A-Za-z_$][\w$]*/g) ?? []) {
      if (id === varName) return null; // amount flows into the score → used → not this smell
      if (defs.has(id) && !seen.has(id)) {
        seen.add(id);
        stack.push(defs.get(id)!);
      }
    }
  }
  return { at: firstAt, varName };
}

/**
 * Pure core. For each score-derivation block, fail CLOSED on any one honesty smell. Each violation
 * is tagged with its source file and 1-based line.
 */
export function scanScoreHonesty(
  files: Array<{ path: string; text: string }>,
  cfg: ScoreHonestConfig,
): ScoreScan {
  const scoreFn = cfg.scoreFn ?? PMAR.scoreFn!;
  const zeroPerfect = cfg.zeroPerfect ?? PMAR.zeroPerfect!;
  const roundsUp = cfg.roundsUp ?? PMAR.roundsUp!;
  const oneSidedCap = cfg.oneSidedCap ?? PMAR.oneSidedCap!;

  const out: ScoreScan = { violations: [], applicable: false };

  for (const { path, text } of files) {
    for (const block of scoreBlocks(text, scoreFn)) {
      out.applicable = true;
      const cite = (bodyIdx: number) => `${path}:${lineAt(text, block.start + bodyIdx)}`;

      // (a) count-weighted: unreconciled amount computed but never reaches the score.
      const unused = amountUnusedInScore(block.body, cfg);
      if (unused) {
        out.violations.push(
          `${cite(unused.at)} — (a) count-weighted score: the unreconciled amount '${unused.varName}' ` +
            `is computed but never flows into the score; the score ignores unreconciled VALUE, so it is ` +
            `not an amount-weighted lower bound (one large exception hides behind many tiny matches)`,
        );
      }

      // (b) perfect-on-empty: a zero denominator published as a perfect score.
      const zp = zeroPerfect.exec(block.body);
      if (zp) {
        out.violations.push(
          `${cite(zp.index)} — (b) perfect-on-empty: a zero denominator yields a perfect score ` +
            `(\`${zp[0].trim()}\`); "no data" is reported as fully assured instead of worst-case / unknown`,
        );
      }

      // (c) rounds up: the ratio scaled to the max with round/ceil, so a non-zero exception set hits 100.
      const ru = roundsUp.exec(block.body);
      if (ru) {
        out.violations.push(
          `${cite(ru.index)} — (c) rounds up: the score is produced with ${/ceil/i.test(ru[0]) ? "Math.ceil" : "Math.round"} ` +
            `(\`${ru[0].trim()}\`), so a non-zero exception set rounds up to the max; the max must be floored / ` +
            `reachable only at zero exceptions`,
        );
      }

      // (d) one-sided cap: a drift / exception cap gated on a single sign of the deviation.
      const os = oneSidedCap.exec(block.body);
      if (os) {
        out.violations.push(
          `${cite(os.index)} — (d) one-sided cap: the drift/exception cap is gated on one sign only ` +
            `(\`${os[0].split(/\)/)[0].trim()})\`); the opposite deviation (e.g. drift < 0, overstated cash) ` +
            `escapes the cap — gate on Math.abs(drift) > 0 or drift !== 0`,
        );
      }
    }
  }
  return out;
}

/** Convenience core, matching the other detectors' `<name>Violations(): string[]` shape. */
export function scoreHonestyViolations(
  files: Array<{ path: string; text: string }>,
  cfg: ScoreHonestConfig,
): string[] {
  return scanScoreHonesty(files, cfg).violations;
}

// --- source collection -----------------------------------------------------------------

/** Recursively collect *.ts files under `dir` (relative to cwd), sorted; absent dir → []. */
function tsUnder(dir: string, cwd?: string): string[] {
  const base = cwd ? `${cwd}/${dir}` : dir;
  let entries: string[];
  try {
    entries = readdirSync(base).sort();
  } catch {
    return []; // dir absent here
  }
  const out: string[] = [];
  for (const e of entries) {
    const rel = `${dir}/${e}`;
    const abs = `${base}/${e}`;
    let st;
    try {
      st = statSync(abs);
    } catch {
      continue;
    }
    if (st.isDirectory()) out.push(...tsUnder(rel, cwd));
    else if (e.endsWith(".ts")) out.push(rel);
  }
  return out;
}

function collectSources(cfg: ScoreHonestConfig): Array<{ path: string; text: string }> {
  const rels = new Set<string>();
  for (const d of cfg.scanDirs) for (const f of tsUnder(d, cfg.cwd)) rels.add(f);
  for (const f of cfg.sources ?? []) rels.add(f);
  const files: Array<{ path: string; text: string }> = [];
  for (const rel of [...rels].sort()) {
    try {
      files.push({ path: rel, text: readFileSync(cfg.cwd ? `${cfg.cwd}/${rel}` : rel, "utf8") });
    } catch {
      // absent here; skip.
    }
  }
  return files;
}

/** Run the detector against the live repo. */
export function detect(config: ScoreHonestConfig): Verdict {
  const files = collectSources(config);
  const scan = scanScoreHonesty(files, config);
  if (!scan.applicable) {
    return notApplicable(
      "no money-health / assurance score derivation found in the scanned sources — nothing to check",
    );
  }
  if (scan.violations.length) {
    return finding(
      `${scan.violations.length} honesty smell(s): the published assurance score can read as perfect while open exceptions or unreconciled value remain (not an amount-weighted lower bound)`,
      { violations: scan.violations },
    );
  }
  return checked(
    "the assurance score is amount-weighted, floored, worst-case on no data, and capped on drift of either sign — a lower bound that cannot read perfect while money is unaccounted for",
  );
}

export default detect;
