// N-OBLIG-DUP — portable static detector: every payable/receivable an app records is UNIQUE on its
// economic key, so the same real invoice cannot be entered, paid, or recognized twice.
//
// INVARIANT: an obligation row (a bill/payable, an invoice/receivable) represents ONE real-world
// document owed to or by one counterparty. Its identity is its ECONOMIC key — payee/customer +
// external document number + amount (+ period) — NOT a surrogate row id the app mints. If the app
// mints a fresh random UUID as the primary key on every create and nothing else pins the economic
// identity, then re-submitting the very same vendor invoice (a retried request, a double-click, a
// re-run import, a webhook redelivery) inserts a SECOND independent row. Downstream everything trusts
// the row: AP pays the duplicate bill a second time (cash out the door twice), AR recognizes the same
// revenue twice and duns the customer for money already owed once. Duplicate obligations are a direct
// money leak, and once two rows exist nothing in the app ever reconciles them back to one.
//
// Two defences make an obligation unique on its economic key, and at least ONE must be present:
//   (1) a DB-level UNIQUE natural key — a UNIQUE constraint over the economic columns (counterparty +
//       document number + amount), so the second insert is rejected by the store itself; or
//   (2) an app-level preceding economic-duplicate SELECT — before the insert, the service looks up an
//       existing row by the economic key and refuses/returns it instead of inserting again.
// Both of those presuppose a PRECONDITION the schema must satisfy: an external DOCUMENT-NUMBER column
// to anchor the key on. A table that has no document-number column at all cannot form the economic
// key — so its absence is itself a smell (there is nothing to be unique ON).
//
// SMELL (any one obligation in this state is a FINDING): an obligation-creating insert mints a
// RANDOM-UUID primary key, with NO preceding economic-duplicate SELECT, AND the schema declares NO
// UNIQUE natural key for that table, AND (the precondition smell) the table has NO external
// document-number column. All four together mean every create is unconditionally a new row: the same
// invoice can be entered/paid/recognized twice.
//
// Like the rest of the family this is a SOURCE scanner (fail-closed, needs no adapter, keys on stable
// surfaces — the CREATE TABLE schema and the service insert idiom — not on a function name). It shares
// its source-reading MODE with N-PASSTHRU-LIAB: pmar's money logic is TypeScript and its schema is an
// embedded CREATE TABLE template string in src/lib/db.ts (there is NO supabase/migrations dir — see
// adapters/pmar.ts), so this reads the schema TS and the AP/AR service TS with node:fs and matches the
// smell with regex. It is parameterised so nothing app-specific — the obligation tables, their service
// files, the economic-key / document-number vocabulary — is baked into the detector; only into the
// config. Dormant (NOT_APPLICABLE) until an obligation-creating insert is actually present.

import { readFileSync } from "node:fs";
import { checked, finding, notApplicable, type Verdict } from "../money-system.ts";
import { type DerivedSurface } from "../derive.ts";
import { PMAR_SURFACE, type MoneySurface } from "../adapters/pmar.ts";

/** One obligation flow (a payable or a receivable) and how to recognise its smell in schema + code. */
export interface ObligationFlow {
  /** Human label for the invariant leg, e.g. "payable (bills)". Verdict output only. */
  name: string;
  /** The obligation table an insert creates a row in, e.g. "bills" / "invoices". */
  table: string;
  /** Service file(s) that create this obligation (where the `INSERT INTO <table>` lives). */
  serviceFiles: string[];
  /**
   * Economic-key vocabulary: the columns that, together, pin the obligation's real identity
   * (counterparty + document number + amount + period). Used two ways — to recognise a UNIQUE natural
   * key as a REAL economic key (not a redundant UNIQUE(id)), and to recognise a preceding SELECT as a
   * genuine economic-duplicate check. e.g. /vendor_id|amount_minor|document_number|period/i.
   */
  econKey: RegExp;
  /**
   * The external DOCUMENT-NUMBER column vocabulary (the precondition). Its presence in the table body
   * means the economic key can be anchored; its total absence is part of the smell. e.g.
   * /document_number|invoice_number|bill_number|external_ref/i.
   */
  docNumberColumn: RegExp;
  /** How the app mints a random-UUID PK. Default /crypto\.randomUUID\s*\(/ . */
  uuidPk?: RegExp;
}

export interface ObligDupConfig {
  /** File(s) holding the schema (CREATE TABLE ...). pmar: the single src/lib/db.ts. */
  schemaFiles: string[];
  /** The obligation flows to check (bills, invoices, ...). */
  obligations: ObligationFlow[];
  /**
   * v4 deepen — the request/obligation/step insert leg (supabase `.from(t).insert({...})` idiom) over
   * the repo's DERIVED money files. Optional: absent => only the classic payable/receivable legs run.
   */
  requests?: RequestDupConfig;
  /** Repo root. Default process.cwd(). */
  cwd?: string;
}

// --- v4 deepen: the request / obligation / step insert leg --------------------------------
//
// Beyond a classic payable/receivable, every obligation-SHAPED row an app creates from a source event
// must be unique on its economic key or created idempotently: a trip/expense auto-created from a
// booking/PNR, an exception row raised per policy violation, an approval STEP created per workflow
// level. If the service mints a fresh random-UUID primary key and nothing pins the economic identity
// (no UNIQUE natural key, no upsert / ON CONFLICT, no preceding economic-duplicate SELECT), then
// re-running the source event — a redelivered PNR, a re-submitted expense, a re-routed approval —
// inserts a SECOND independent row. Downstream everything double-counts: a trip and its draft expenses
// are created twice (BR-008/009 travel ingest), the same exception is raised twice (BR-016/025 policy),
// an approval level is demanded twice (BR-018 workflows). This is the SAME invariant as bills/invoices,
// recognised in the newer supabase insert idiom (`ctx.sb.from("<t>").insert({...})`), and bound to the
// repo's derived money surface so it reaches travel.ts / policy.ts / expenses.ts with no hand-maintenance.

/**
 * The request/obligation/step insert leg. Only `files` / `schemaFiles` are app-specific (bound from the
 * surface); every regex is GENERIC money/obligation vocabulary, shared by the static and derived paths.
 */
export interface RequestDupConfig {
  /** Money files to scan for request/obligation inserts. From surface.moneyPaths (v4) or a static list. */
  files: string[];
  /** Schema file(s) that might declare a UNIQUE natural key for an obligation table. From the surface. */
  schemaFiles: string[];
  /** A supabase-style insert `.from("<t>").insert(` — capture group 1 is the table. */
  insertCall: RegExp;
  /** A random-UUID primary-key mint (crypto.randomUUID / gen_random_uuid / uuidv4). */
  randomUuidPk: RegExp;
  /** A primary-key `id` field on the inserted row (shorthand or `id:`). */
  idField: RegExp;
  /** An idempotent-create / conflict guard (upsert / ON CONFLICT / ignoreDuplicates). */
  upsertGuard: RegExp;
  /** The economic-linkage columns that make a row an obligation/request/step keyed to a source. */
  econRef: RegExp;
}

/**
 * The GENERIC request-leg vocabulary — NO app path/table is baked in, only money/obligation idioms.
 * Shared by the static PMAR binding and the derived forSurface() binding.
 */
export const REQUEST_REGEXES: Omit<RequestDupConfig, "files" | "schemaFiles"> = {
  // `ctx.sb.from("trips").insert(` / `.from('expense_approvals').insert(` — table is group 1.
  insertCall: /\.from\s*\(\s*["'\x60]([a-z_][a-z0-9_]*)["'\x60]\s*\)\s*\.insert\s*\(/i,
  randomUuidPk: /crypto\.randomUUID\s*\(|gen_random_uuid\s*\(|\buuidv4\s*\(|\brandomUUID\s*\(/i,
  idField: /\bid\s*[:,]/,
  upsertGuard: /\.upsert\s*\(|on\s+conflict|\bonConflict\b|\bignoreDuplicates\b|\.onConflict\s*\(/i,
  // expense_id / trip_id / booking_id / pnr_ref / rule_id / workflow_id / employee_id / vendor /
  // invoice / bill / document_number / external_ref / period / level — a source-linkage column.
  econRef:
    /\b(?:expense_id|trip_id|booking_id|pnr_ref|rule_id|workflow_id|employee_id|vendor(?:_id)?|invoice(?:_id|_number)?|bill(?:_id|_number)?|document_number|external_ref|reference|period|level)\b/i,
};

/** The pmar binding — all pmar specifics live here, in config, never in the detector. */
export const PMAR: ObligDupConfig = {
  schemaFiles: PMAR_SURFACE.schemaFiles, // ["src/lib/db.ts"]
  obligations: [
    {
      name: "payable (bills)",
      table: "bills",
      serviceFiles: ["src/services/ap.ts"],
      econKey:
        /vendor_id|amount_minor|document_number|doc_number|doc_no|bill_number|bill_no|invoice_number|invoice_no|external_ref|external_id|external_number|reference|vendor_invoice|period/i,
      docNumberColumn:
        /document_number|doc_number|doc_no|bill_number|bill_no|invoice_number|invoice_no|external_ref|external_id|external_number|reference_number|vendor_invoice(?:_no)?/i,
    },
    {
      name: "receivable (invoices)",
      table: "invoices",
      serviceFiles: ["src/services/ar.ts"],
      econKey:
        /customer|amount_minor|document_number|doc_number|doc_no|invoice_number|invoice_no|external_ref|external_id|external_number|reference|period/i,
      docNumberColumn:
        /document_number|doc_number|doc_no|invoice_number|invoice_no|bill_number|external_ref|external_id|external_number|reference_number/i,
    },
  ],
  // v4 deepen — the supabase request/obligation/step inserts (trips/expenses/exceptions/approvals),
  // generic vocabulary with a static file+schema list for the non-derived path.
  requests: {
    ...REQUEST_REGEXES,
    files: PMAR_SURFACE.moneyPaths,
    schemaFiles: PMAR_SURFACE.schemaFiles,
  },
};

/**
 * v4 — build the detector config from a DERIVED money surface instead of a frozen path list. The generic
 * money-vocabulary regexes stay in the config; only PATHS/TABLES come from the surface, so the
 * request-leg scan reaches every money file the repo currently has (src/services/travel.ts,
 * src/services/policy.ts, src/services/expenses.ts, …) and every schema migration with zero
 * hand-maintenance. The runner does: `detect(forSurface(deriveMoneySurface(cwd)))`.
 */
export function forSurface(surface: DerivedSurface | MoneySurface): ObligDupConfig {
  return {
    // the classic payable/receivable legs (bills/invoices) are reused verbatim; their schema is now
    // whatever the surface derives (SQL migrations, or a ts-embedded db.ts), never a hardcoded path.
    schemaFiles: surface.schemaFiles,
    obligations: PMAR.obligations,
    requests: {
      ...REQUEST_REGEXES,
      files: surface.moneyPaths,
      schemaFiles: surface.schemaFiles,
    },
    cwd: surface.cwd,
  };
}

const DEFAULT_UUID = /crypto\.randomUUID\s*\(/;

// --- pure source-reading primitives (repo-agnostic; mirror the other static detectors) -

const escapeRe = (s: string): string => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

/** 1-based line number of the character at `idx`. */
const lineAt = (text: string, idx: number): number => text.slice(0, idx).split("\n").length;

/**
 * The contents BETWEEN the outermost parens of `CREATE TABLE <table> ( ... )`, or null if the table
 * is not declared. Paren-balanced, so an inner `CHECK (...)` / `UNIQUE (...)` does not end it early.
 */
export function extractTableBody(schema: string, table: string): string | null {
  const re = new RegExp(
    `create\\s+table\\s+(?:if\\s+not\\s+exists\\s+)?(?:public\\.)?${escapeRe(table)}\\s*\\(`,
    "i",
  );
  const m = re.exec(schema);
  if (!m) return null;
  const start = m.index + m[0].length;
  let depth = 1;
  let i = start;
  for (; i < schema.length && depth > 0; i++) {
    const c = schema[i];
    if (c === "(") depth++;
    else if (c === ")") depth--;
  }
  return schema.slice(start, i - 1);
}

// --- the duplicate-obligation logic ----------------------------------------------------

/**
 * A UNIQUE natural key is present iff a UNIQUE clause (table-level `UNIQUE (...)` OR a column-level
 * `<col> ... UNIQUE`) references at least one ECONOMIC-key or document-number column — not a mere
 * redundant UNIQUE over the surrogate id. That is what rejects a second economic duplicate at the store.
 */
export function hasNaturalUnique(tableBody: string, ob: ObligationFlow): boolean {
  // table-level UNIQUE (cols...)
  for (const m of tableBody.matchAll(/\bunique\s*\(([^)]*)\)/gi)) {
    if (ob.econKey.test(m[1]) || ob.docNumberColumn.test(m[1])) return true;
  }
  // column-level: a single column line carrying UNIQUE on an economic / document-number column
  for (const line of tableBody.split("\n")) {
    if (!/\bunique\b/i.test(line)) continue;
    if (/\bunique\s*\(/i.test(line)) continue; // already handled as a table-level clause
    if (ob.econKey.test(line) || ob.docNumberColumn.test(line)) return true;
  }
  return false;
}

/**
 * A preceding economic-duplicate SELECT guards the insert iff, BEFORE the insert, the service selects
 * from the same table AND the select references an economic-key column (or is a COUNT/EXISTS probe). A
 * plain by-id read (`SELECT * FROM <t> WHERE id = ...`) does NOT count: it cannot find an economic twin.
 */
export function hasPrecedingDupSelect(text: string, insertIdx: number, ob: ObligationFlow): boolean {
  const before = text.slice(0, insertIdx);
  const selRe = new RegExp(`select[\\s\\S]{0,160}?from\\s+(?:public\\.)?${escapeRe(ob.table)}\\b[\\s\\S]{0,200}`, "gi");
  for (const m of before.matchAll(selRe)) {
    if (ob.econKey.test(m[0]) || /\bcount\s*\(|\bexists\b/i.test(m[0])) return true;
  }
  return false;
}

export interface ObligScan {
  /** "<name>: <file>:<line> — <why>" for each obligation-creating insert that can double-record. */
  violations: string[];
  /** "<name>: <file>:<line> — <why>" for each obligation-creating insert that is unique-guarded. */
  guarded: string[];
  /** At least one obligation-creating insert was found (else the invariant is dormant). */
  present: boolean;
}

/**
 * Pure core. For each obligation, inspect its schema table (document-number column? UNIQUE natural
 * key?) and every `INSERT INTO <table>` in its service files (random-UUID PK? preceding economic-dup
 * SELECT?). An insert that mints a random-UUID PK with NO preceding economic-dup SELECT, where the
 * table has NO UNIQUE natural key AND NO document-number column, is a violation (the same invoice can
 * be recorded twice). Any single defence present makes it guarded.
 */
export function scanObligations(
  schemaText: string,
  serviceTexts: Map<string, string>,
  cfg: ObligDupConfig,
): ObligScan {
  const out: ObligScan = { violations: [], guarded: [], present: false };
  for (const ob of cfg.obligations) {
    const body = extractTableBody(schemaText, ob.table);
    const hasDocCol = body != null && ob.docNumberColumn.test(body);
    const uniqueKey = body != null && hasNaturalUnique(body, ob);
    const uuidPk = ob.uuidPk ?? DEFAULT_UUID;

    for (const sf of ob.serviceFiles) {
      const text = serviceTexts.get(sf);
      if (text === undefined) continue;
      const insertRe = new RegExp(`insert\\s+into\\s+(?:public\\.)?${escapeRe(ob.table)}\\s*\\(([^)]*)\\)`, "gi");
      for (const m of text.matchAll(insertRe)) {
        out.present = true;
        const idx = m.index ?? 0;
        const cite = `${sf}:${lineAt(text, idx)}`;
        const pkSupplied = /^\s*id\b/i.test(m[1]); // the app supplies the PK as the first column
        const mintsRandomPk = pkSupplied && uuidPk.test(text.slice(Math.max(0, idx - 700), idx));
        const dupSelect = hasPrecedingDupSelect(text, idx, ob);

        if (mintsRandomPk && !dupSelect && !uniqueKey && !hasDocCol) {
          out.violations.push(
            `${ob.name}: ${cite} — INSERT INTO ${ob.table} mints a random-UUID PK (crypto.randomUUID) ` +
              `with no preceding economic-duplicate SELECT, and ${ob.table} has no UNIQUE natural key and ` +
              `no external document-number column — the same invoice can be entered/paid/recognized twice`,
          );
        } else {
          const why = dupSelect
            ? "a preceding economic-duplicate SELECT guards the insert"
            : uniqueKey
              ? `${ob.table} declares a UNIQUE natural key the second economic duplicate is rejected by`
              : hasDocCol
                ? `${ob.table} carries an external document-number column anchoring the economic key`
                : "insert does not mint a random-UUID primary key";
          out.guarded.push(`${ob.name}: ${cite} — ${why}`);
        }
      }
    }
  }
  return out;
}

/** Convenience core, matching the other detectors' `<name>Violations(): string[]` shape. */
export function obligDupViolations(
  schemaText: string,
  serviceTexts: Map<string, string>,
  cfg: ObligDupConfig,
): string[] {
  return scanObligations(schemaText, serviceTexts, cfg).violations;
}

// --- v4 deepen: the request / obligation / step insert scanner -------------------------

/**
 * Is a preceding economic-duplicate SELECT present for a supabase insert? Before the insert, the
 * service queries the SAME table (`.from("<t>").select...`) and the query references an economic-key
 * column — a genuine "does this obligation already exist?" probe, not a by-id read.
 */
export function hasPrecedingReqSelect(before: string, table: string, econKey: RegExp): boolean {
  const re = new RegExp(
    `\\.from\\s*\\(\\s*["'\\x60]${escapeRe(table)}["'\\x60]\\s*\\)\\s*\\.select[\\s\\S]{0,300}`,
    "gi",
  );
  for (const m of before.matchAll(re)) {
    if (econKey.test(m[0])) return true;
  }
  return false;
}

/**
 * Does the schema declare a UNIQUE natural key for `table` over at least one economic column? Covers
 * all three SQL shapes: a table-level / column-level UNIQUE inside the CREATE TABLE body, a separate
 * CREATE UNIQUE INDEX on the table, and an ALTER TABLE ... ADD ... UNIQUE. A mere UNIQUE on the
 * surrogate id does not count — the clause must reference an economic-key column.
 */
export function schemaHasUniqueFor(schema: string, table: string, econKey: RegExp): boolean {
  const body = extractTableBody(schema, table);
  if (body) {
    for (const m of body.matchAll(/\bunique\s*\(([^)]*)\)/gi)) {
      if (econKey.test(m[1])) return true;
    }
    for (const line of body.split("\n")) {
      if (!/\bunique\b/i.test(line)) continue;
      if (/\bunique\s*\(/i.test(line)) continue;
      if (econKey.test(line)) return true;
    }
  }
  const idxRe = new RegExp(
    `create\\s+unique\\s+index[^;]*?\\bon\\s+(?:public\\.)?${escapeRe(table)}\\s*\\(([^)]*)\\)`,
    "gi",
  );
  for (const m of schema.matchAll(idxRe)) {
    if (econKey.test(m[1])) return true;
  }
  const altRe = new RegExp(
    `alter\\s+table\\s+(?:public\\.)?${escapeRe(table)}\\b[^;]*?\\bunique\\s*\\(([^)]*)\\)`,
    "gi",
  );
  for (const m of schema.matchAll(altRe)) {
    if (econKey.test(m[1])) return true;
  }
  return false;
}

export interface RequestScan {
  /** "<table>: <file>:<line> — <why>" for each obligation/request insert that can double-record. */
  violations: string[];
  /** "<table>: <file>:<line> — <why>" for each obligation/request insert that is unique-guarded. */
  guarded: string[];
  /** At least one obligation-shaped request insert was found (else this leg is dormant). */
  present: boolean;
}

/**
 * Pure core for the request/obligation/step leg. For every supabase-style insert in a money file,
 * decide whether the row is obligation-SHAPED — it mints a random-UUID primary key AND carries an
 * economic-linkage column tying it to a source — and, if so, whether it is made unique: an idempotent
 * create (upsert / ON CONFLICT), a preceding economic-duplicate SELECT on the same table, or a UNIQUE
 * natural key on the table's economic columns. An obligation-shaped insert with NONE of those is a
 * violation — re-running the source event inserts a second row and everything downstream double-counts.
 */
export function scanRequestInserts(
  files: Map<string, string>,
  schemaText: string,
  cfg: RequestDupConfig,
): RequestScan {
  const out: RequestScan = { violations: [], guarded: [], present: false };
  const insertG = new RegExp(cfg.insertCall.source, "gi");
  for (const [path, text] of files) {
    insertG.lastIndex = 0;
    let m: RegExpExecArray | null;
    while ((m = insertG.exec(text))) {
      const table = m[1];
      const i = m.index;
      const before = text.slice(0, i);
      // a generous window around the insert: the row object may be inline (`.insert({...})`) or built
      // earlier and passed by name (`const rows=[]; rows.push({id: crypto.randomUUID(), ...}); .insert(rows)`).
      const beforeWin = text.slice(Math.max(0, i - 3000), i);
      const after = text.slice(i, i + 1500);
      const rowWin = beforeWin + "\n" + after;
      const mintsRandom = cfg.randomUuidPk.test(rowWin);
      const hasId = cfg.idField.test(after) || cfg.idField.test(beforeWin);
      const hasEcon = cfg.econRef.test(rowWin);
      if (!(mintsRandom && hasId && hasEcon)) continue; // not an obligation-shaped random-UUID insert
      out.present = true;
      const cite = `${path}:${lineAt(text, i)}`;
      const upsert = cfg.upsertGuard.test(after);
      const dupSelect = hasPrecedingReqSelect(before, table, cfg.econRef);
      const uniqueKey = schemaHasUniqueFor(schemaText, table, cfg.econRef);
      if (!upsert && !dupSelect && !uniqueKey) {
        out.violations.push(
          `${table}: ${cite} — a row is inserted into ${table} with a random-UUID primary key and an ` +
            `economic-source linkage, but there is NO idempotent create (upsert / ON CONFLICT), NO preceding ` +
            `economic-duplicate SELECT, and ${table} declares NO UNIQUE natural key on its economic columns — ` +
            `re-running the source event (a redelivered PNR, a re-submitted expense, a re-routed approval) ` +
            `inserts a SECOND row and everything downstream double-counts it`,
        );
      } else {
        const why = upsert
          ? "the insert is an idempotent create (upsert / ON CONFLICT)"
          : dupSelect
            ? "a preceding economic-duplicate SELECT guards the insert"
            : `${table} declares a UNIQUE natural key on its economic columns`;
        out.guarded.push(`${table}: ${cite} — ${why}`);
      }
    }
  }
  return out;
}

// --- file plumbing ---------------------------------------------------------------------

function readFile(path: string, cwd?: string): string {
  return readFileSync(cwd ? `${cwd}/${path}` : path, "utf8");
}

/** Concatenate whatever of `paths` exist; a missing file is skipped (another repo may lack it). */
function concat(paths: string[], cwd?: string): string {
  const parts: string[] = [];
  for (const f of paths) {
    try {
      parts.push(readFile(f, cwd));
    } catch {
      /* absent here; skip. */
    }
  }
  return parts.join("\n");
}

// --- the verdict -----------------------------------------------------------------------

/** Run the detector against the live repo. */
export function detect(config: ObligDupConfig): Verdict {
  const schemaText = concat(config.schemaFiles, config.cwd);

  const serviceTexts = new Map<string, string>();
  for (const ob of config.obligations) {
    for (const sf of ob.serviceFiles) {
      if (serviceTexts.has(sf)) continue;
      try {
        serviceTexts.set(sf, readFile(sf, config.cwd));
      } catch {
        /* this obligation's service file is absent here; skip it. */
      }
    }
  }

  const scan = scanObligations(schemaText, serviceTexts, config);

  // v4 deepen — the request/obligation/step insert leg (supabase idiom) over the derived money files.
  let reqScan: RequestScan = { violations: [], guarded: [], present: false };
  if (config.requests) {
    const reqSchema = concat(config.requests.schemaFiles, config.cwd);
    const reqFiles = new Map<string, string>();
    for (const p of config.requests.files) {
      try {
        reqFiles.set(p, readFile(p, config.cwd));
      } catch {
        /* absent here, or a glob rather than a concrete path; skip. */
      }
    }
    reqScan = scanRequestInserts(reqFiles, reqSchema, config.requests);
  }

  const present = scan.present || reqScan.present;
  const violations = [...scan.violations, ...reqScan.violations];
  const guarded = [...scan.guarded, ...reqScan.guarded];

  if (!present) {
    return notApplicable(
      "no obligation/request-creating insert (bills/invoices/trips/expenses/exceptions/approval-steps) was " +
        "found — the duplicate-obligation invariant does not apply here",
    );
  }
  if (violations.length) {
    return finding(
      `${violations.length} obligation/request flow(s) can double-record: a payable/receivable/trip/expense/` +
        `exception/approval-step is inserted with a random-UUID PK and no uniqueness defence, so the same ` +
        `economic obligation can be entered, recognized or demanded twice`,
      { violations, guarded },
    );
  }
  if (guarded.length === 0) {
    return notApplicable(
      "obligation tables exist, but no obligation-creating insert was matched — nothing to check",
    );
  }
  return checked(
    "every obligation/request insert is unique on its economic key (a UNIQUE natural key, a preceding " +
      "economic-duplicate SELECT, an idempotent upsert, or a document-number anchor) — the same obligation " +
      "cannot be recorded twice",
    { guarded },
  );
}

export default detect;
