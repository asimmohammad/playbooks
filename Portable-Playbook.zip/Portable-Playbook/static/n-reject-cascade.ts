// N-REJECT-CASCADE — portable static detector: a combined APPROVE/REJECT decision over a money object
// must transition the parent on BOTH outcomes. If it follows through only on approval, a rejected (or
// denied / declined) decision leaves the parent stuck in its pending / gated state.
//
// INVARIANT: a gating decision has two terminal outcomes, and BOTH must move the thing being gated out
// of "pending". When a handler takes a `decision: "approved" | "rejected"` (or accept/deny, grant/decline),
// records that decision on the child record (the exception / approval step / hold / review), and then —
// only on the APPROVED branch — transitions the PARENT money object (re-routes it for approval, clears it,
// marks it submitted/paid), the REJECTED branch does nothing to the parent. The expense/invoice/bill sits
// in `exception_pending` / `pending_approval` forever: it is never cleanly denied, keeps showing in the
// pending queue, and can be re-surfaced, re-decided or silently treated as still-open money. (pmar:
// PolicyService.decideException updates the exception to the decision, then `if (decision === "approved")`
// re-routes the expense — with no `rejected` branch, a rejected expense stays exception_pending. Qodo
// flagged "rejected requests still look pending".)
//
// SMELL (a FINDING): a function that handles BOTH outcomes (it tests a POSITIVE outcome — `=== "approved"`
// / accepted / granted — AND a NEGATIVE outcome term appears: rejected / denied / declined) has a
// POSITIVE-branch block that performs a follow-on PARENT transition (`.update({ status … })` on a record,
// or a route/settle/release/reimburse/post call), but NO negative-branch (no `=== "rejected"` block and no
// `else`) performing a parent transition, and the parent transition is not unconditional.
//
// GUARD (CHECKED): the handler transitions the parent unconditionally after recording the decision, OR has
// an explicit reject branch (`=== "rejected"` / `else`) that drives the parent to a terminal state.
//
// DORMANT (NOT_APPLICABLE): no combined approve/reject decision handler drives a parent transition in the
// derived money files (no such gating over money objects here).
//
// PURE SOURCE scanner (node:fs + regex, fail-closed). v4+ surface-derived: only PATHS come from the
// surface; the decision vocabulary lives here. `detect(forSurface(deriveMoneySurface(cwd)))`.

import { readFileSync } from "node:fs";
import { checked, finding, notApplicable, type Verdict } from "../money-system.ts";
import { deriveMoneySurface, type DerivedSurface } from "../derive.ts";

export interface RejectCascadeConfig {
  scanPaths: string[];
  /** A test of a POSITIVE decision outcome (`=== "approved"`). */
  positiveTest: RegExp;
  /** A test of a NEGATIVE decision outcome (`=== "rejected"`). */
  negativeTest: RegExp;
  /** A NEGATIVE outcome term appearing anywhere (literal or identifier) — marks a reject-capable handler. */
  negativeTerm: RegExp;
  /** A follow-on PARENT transition: a status update, or a route/settle/release/reimburse/post/clear call. */
  transition: RegExp;
  cwd?: string;
}

export const REJECT_VOCAB: Omit<RejectCascadeConfig, "scanPaths" | "cwd"> = {
  positiveTest: /===\s*["'`]?(approved|accepted|granted|cleared|approve)\b/i,
  negativeTest: /===\s*["'`]?(rejected|denied|declined|refused|reject|deny)\b/i,
  negativeTerm: /\b(rejected|denied|declined|refused)\b/i,
  transition:
    /\.update\s*\(\s*\{[^}]*\bstatus\b|\b(route|settle|reimburse|release|capture|post|clear|pay|disburse)[A-Za-z]*\s*\(/i,
};

// --- pure source-reading primitives ------------------------------------------------------

const lineAt = (text: string, idx: number): number => text.slice(0, idx).split("\n").length;
const flat = (re: RegExp): RegExp => new RegExp(re.source, re.flags.replace("g", ""));
const has = (re: RegExp, text: string): boolean => flat(re).test(text);

function allIdx(text: string, re: RegExp): number[] {
  const g = new RegExp(re.source, re.flags.includes("g") ? re.flags : re.flags + "g");
  const out: number[] = [];
  let m: RegExpExecArray | null;
  while ((m = g.exec(text))) {
    out.push(m.index);
    if (m.index === g.lastIndex) g.lastIndex++;
  }
  return out;
}

/** The `{ … }` block starting at the first `{` at/after `from` (within `maxGap` chars), brace-balanced. */
function blockAfter(text: string, from: number, maxGap = 60): { text: string; start: number; end: number } | null {
  const open = text.indexOf("{", from);
  if (open < 0 || open - from > maxGap) return null;
  let depth = 0;
  for (let i = open; i < text.length; i++) {
    const c = text[i];
    if (c === "{") depth++;
    else if (c === "}") {
      depth--;
      if (depth === 0) return { text: text.slice(open, i + 1), start: open, end: i + 1 };
    }
  }
  return null;
}

/**
 * Split a file into function/method regions. Unlike the other detectors' copy, the header match EXCLUDES
 * control-flow keywords (`if`/`for`/`while`/`switch`/`catch`/`else`/`do`/`return`/`with`) — otherwise an
 * `if (decision === "approved") {` reads as a "function header" and splits the branch off from the
 * method's signature and its sibling branches, which would hide the asymmetry this detector looks for.
 */
export function functionRegions(text: string): Array<{ text: string; base: number }> {
  const headerRe =
    /\n[ \t]*(?:export\s+)?(?:public\s+|private\s+|protected\s+)?(?:static\s+)?(?:async\s+)?(?:function\s+)?(?!(?:if|for|while|switch|catch|else|do|return|with)\b)[A-Za-z_$][\w$]*\s*\([^)]*\)\s*(?::[^;{]*)?\{/g;
  const starts: number[] = [];
  let m: RegExpExecArray | null;
  while ((m = headerRe.exec(text))) starts.push(m.index);
  if (!starts.length) return [{ text, base: 0 }];
  const out: Array<{ text: string; base: number }> = [];
  for (let i = 0; i < starts.length; i++) {
    const end = i + 1 < starts.length ? starts[i + 1]! : text.length;
    out.push({ text: text.slice(starts[i]!, end), base: starts[i]! });
  }
  return out;
}

// --- the reject-cascade logic ----------------------------------------------------------

export interface RejectCascadeScan {
  violations: string[];
  guarded: string[];
  /** A combined approve/reject decision handler that drives a parent transition exists. */
  present: boolean;
}

export function scanRejectCascade(files: Array<{ path: string; text: string }>, cfg: RejectCascadeConfig): RejectCascadeScan {
  const out: RejectCascadeScan = { violations: [], guarded: [], present: false };

  for (const { path, text } of files) {
    for (const region of functionRegions(text)) {
      const rt = region.text;
      // reject-capable: a negative outcome term appears somewhere in the handler
      if (!has(cfg.negativeTerm, rt)) continue;

      // find each positive-outcome test that opens a branch which performs a parent transition
      for (const posIdx of allIdx(rt, cfg.positiveTest)) {
        const posBlock = blockAfter(rt, posIdx);
        if (!posBlock || !has(cfg.transition, posBlock.text)) continue; // approved branch must transition the parent
        out.present = true;

        // is there a reject-branch transition, or an unconditional one, or an else that transitions?
        let rejHandled = false;

        // (a) an `else { … transition … }` immediately after the positive block
        const afterPos = rt.slice(posBlock.end, posBlock.end + 12);
        if (/^\s*else\b/.test(afterPos)) {
          const elseBlock = blockAfter(rt, posBlock.end);
          if (elseBlock && has(cfg.transition, elseBlock.text)) rejHandled = true;
        }
        // (b) an explicit negative-outcome test whose block transitions the parent
        if (!rejHandled) {
          for (const negIdx of allIdx(rt, cfg.negativeTest)) {
            const negBlock = blockAfter(rt, negIdx);
            if (negBlock && has(cfg.transition, negBlock.text)) { rejHandled = true; break; }
          }
        }
        // (c) a parent transition OUTSIDE the positive block (i.e. unconditional, on every path)
        if (!rejHandled) {
          const outside = rt.slice(0, posBlock.start) + rt.slice(posBlock.end);
          // a transition that is a status update to a terminal/other value, not the child decision-record write
          if (has(cfg.transition, outside) && /\.update\s*\(\s*\{[^}]*\bstatus\b\s*:\s*["'`]/.test(outside)) {
            // only count it as the guard if it is a literal terminal status set unconditionally
            rejHandled = true;
          }
        }

        const cite = `${path}:${lineAt(text, region.base + posIdx)}`;
        if (rejHandled) {
          out.guarded.push(`${cite} [reject-cascade] — the handler transitions the parent on BOTH approve and reject (or unconditionally)`);
        } else {
          out.violations.push(
            `${cite} [reject-cascade] — a combined approve/reject decision records the decision and then, ONLY on the ` +
              `approved branch, transitions the parent money object (status update / re-route / release), with NO ` +
              `reject branch and no \`else\`: a rejected / denied decision leaves the parent stuck in its pending / ` +
              `gated state — never cleanly denied, still shown as pending, and re-decidable or treated as open money`,
          );
          break; // one violation per handler is enough
        }
      }
    }
  }
  return out;
}

export function rejectCascadeViolations(files: Array<{ path: string; text: string }>, cfg: RejectCascadeConfig): string[] {
  return scanRejectCascade(files, cfg).violations;
}

// --- file plumbing ---------------------------------------------------------------------

function readFile(path: string, cwd?: string): string {
  return readFileSync(cwd ? `${cwd}/${path}` : path, "utf8");
}

// --- the v4 surface binding ------------------------------------------------------------

export function forSurface(surface: Pick<DerivedSurface, "moneyPaths" | "cwd">): RejectCascadeConfig {
  return { ...REJECT_VOCAB, scanPaths: surface.moneyPaths, cwd: surface.cwd };
}

// --- the verdict -----------------------------------------------------------------------

export function detect(config: RejectCascadeConfig): Verdict {
  const files: Array<{ path: string; text: string }> = [];
  for (const p of config.scanPaths) {
    if (/[*?]/.test(p)) continue;
    try {
      files.push({ path: p, text: readFile(p, config.cwd) });
    } catch {
      /* absent here; skip */
    }
  }

  const scan = scanRejectCascade(files, config);

  if (!scan.present) {
    return notApplicable(
      "no combined approve/reject decision handler that drives a parent transition was found in the derived money " +
        "files — there is no gating decision over a money object whose reject path could be dropped (invariant dormant)",
    );
  }
  if (scan.violations.length) {
    return finding(
      `a rejected decision leaves money stuck pending: ${scan.violations.length} combined approve/reject handler(s) ` +
        `transition the parent only on approval, so a reject/deny leaves the expense/invoice/bill in its pending or ` +
        `gated state — never cleanly denied and re-decidable as still-open money`,
      { violations: scan.violations, guarded: scan.guarded },
    );
  }
  return checked(
    "every combined approve/reject decision transitions the parent money object on BOTH outcomes (or " +
      "unconditionally) — a rejected decision moves the parent to a terminal state, never leaving it pending",
    { guarded: scan.guarded },
  );
}

export function detectRepo(cwd: string): Verdict {
  const surface = deriveMoneySurface(cwd);
  return detect(forSurface({ ...surface, cwd }));
}

export default detect;
