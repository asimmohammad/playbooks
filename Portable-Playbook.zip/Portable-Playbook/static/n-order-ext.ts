// N-ORDER-EXT — portable static detector (static form of the behavioural N-ORDER-01): a money op
// commits its ledger / liability-clearing entry only AFTER the irreversible external call (the payment
// connector / provider) has succeeded durably — never post-the-ledger-then-call-the-provider.
//
// INVARIANT: in a reimbursement / payout flow two things happen — the books record that the obligation
// is settled (a ledger post that DEBITS a liability, clearing Accrued Expenses / Accounts Payable; or a
// status write that marks the item paid / reimbursed / settled), and the money actually leaves the
// building through an irreversible external provider call (connector.createPayment / connector.pay).
// ORDER IS EVERYTHING. The external call is the one step that cannot be rolled back, so it must come
// FIRST and succeed durably; only then may the ledger clear the liability or the row be marked paid.
// The wrong order — post the ledger (clear the liability) and THEN call the provider — is a one-way trap:
// if the provider call throws, times out, or the surrounding transaction is torn down after the ledger
// leg committed, the books now say the liability is settled while the employee / vendor was never paid.
// The accrual is gone, the cash never moved, and nothing reconciles it back: the payee is silently
// stiffed and the trial balance looks clean. (The mirror failure — provider paid, ledger never cleared —
// double-pays on retry; the durable-guard smell below covers the retry face of it.)
//
// SMELL (any one is a FINDING):
//   A. [ledger-before-external] inside one money-movement function, a ledger/journal post (postEntry /
//      accrualLines -> post / journalEntry) OR a mark-paid status write (status := paid/reimbursed/
//      settled) occurs at a SOURCE POSITION BEFORE the irreversible external provider call within the
//      SAME enclosing block — the liability is cleared / the row marked paid before the payment is known
//      to have gone through. A failed provider call then leaves the liability cleared and the payee unpaid.
//   B. [no-durable-guard] the irreversible provider call is made with NO durable payment-state guard in
//      its function (no idempotency runner, no already-paid / status check, no dedup key), so a retry of
//      the same movement re-settles it at the provider — a second real debit.
//
// Like the rest of the family this is a SOURCE scanner (fail-closed, needs no adapter, keys on a stable
// surface — the money-movement / payout functions — not on any behavioural harness). It reads the money
// files with node:fs and matches the smell with regex over the ledger-post / mark-paid / provider-call
// idioms. Every regex is GENERIC money vocabulary; only the PATHS are app-specific, and (v4) those come
// from the DERIVED money surface, not a frozen list — so the scan reaches every money file the repo has
// (src/lib/payments.ts, src/services/expenses.ts, src/services/ap.ts, …) with zero hand-maintenance.
// Dormant (NOT_APPLICABLE) until a function that BOTH clears a liability / marks paid AND makes an
// irreversible external call is actually present — an app with no such ordering surface has nothing here.

import { readFileSync } from "node:fs";
import { checked, finding, notApplicable, type Verdict } from "../money-system.ts";
import { deriveMoneySurface, type DerivedSurface } from "../derive.ts";
import { type MoneySurface } from "../adapters/pmar.ts";

/** How to recognise the order-of-ops-external smell in source. Only `files` is app-specific. */
export interface OrderExtConfig {
  /** The money files to scan (payments + expenses/services). From surface.moneyPaths (v4) or static. */
  files: string[];
  /** A committed ledger / journal post, e.g. /\.postEntry\(/ , /journalEntry\(/ , /accrualLines\(/. */
  ledgerPost: RegExp;
  /** A status write that marks an item PAID / reimbursed / settled (the liability is cleared). */
  markPaid: RegExp;
  /** The irreversible external provider call: a connector/provider payment, e.g. /createPayment\(/. */
  providerCall: RegExp;
  /** A durable payment-state guard around the provider call (idempotency runner, already-paid check). */
  idemGuard: RegExp;
  /** Evidence the ledger post DEBITS a liability (clears Accrued Expenses / AP). Enriches the citation. */
  liabilityDebit: RegExp;
  /** Repo root. Default process.cwd(). */
  cwd?: string;
}

/**
 * The GENERIC order-of-ops vocabulary. These regexes bake in NO app path/table/account — they are money
 * vocabulary only — and are shared by the static PMAR binding and the derived forSurface() binding.
 */
export const ORDER_EXT_REGEXES: Omit<OrderExtConfig, "files" | "cwd"> = {
  // a ledger/journal post that commits an entry (the moment the liability is cleared on the books).
  ledgerPost: /\.postEntry\s*\(|\bpostEntry\s*\(|\bjournalEntr[A-Za-z]*\s*\(|\binsertJournal\s*\(|\bpostLedger\s*\(/i,
  // a status write marking the item PAID — `.update({ status: "paid" })` / SQL `set status = 'reimbursed'`.
  markPaid:
    /\.update\s*\(\s*\{[^}]*\bstatus\b[^}]*\b(?:paid|reimbursed|settled|cleared|disbursed)\b|update\s+[a-z_"'`.]+\s+set\b[^;]*\bstatus\b[^;]*\b(?:paid|reimbursed|settled|cleared|disbursed)\b/i,
  // the irreversible external provider call: a connector method, createPayment, connector.pay*, provider.*.
  // NOTE: deliberately does NOT match the in-process `executeMoneyMovement(...)` wrapper — the ordering
  // bug lives INSIDE that executor; a caller that invokes it and then marks paid is correctly ordered.
  providerCall:
    /\.connectors\.[A-Za-z_$][\w$]*\.[A-Za-z_$][\w$]*\s*\(|\bcreatePayment\s*\(|\bconnector\.pay[A-Za-z]*\s*\(|\bprovider\.[A-Za-z_$][\w$]*\s*\(|\bgateway\.[A-Za-z_$][\w$]*\s*\(/i,
  // a durable payment-state guard: an idempotency runner / key, a dedup key, or an already-paid check.
  idemGuard:
    /\brunIdempotent\b|idempoten|\bidem[_\s]?key\b|\brequest[_\s]?key\b|\bdedup\b|already\s*(?:paid|settled|reimbursed)|\bstatus\b\s*===?\s*["'`](?:paid|settled|reimbursed)["'`]/i,
  // the ledger post debits a liability: a liability account id / an ACCRUED|AP|PAYABLE|LIABILITY account.
  liabilityDebit:
    /debitAccountId\s*:\s*[A-Za-z_.$]*(?:ACCRUED|_AP\b|\bAP\b|PAYABLE|LIAB)|ACCOUNTS\.(?:ACCRUED_EXPENSES|AP|ACCOUNTS_PAYABLE|[A-Z_]*PAYABLE)|accountId\s*:\s*[A-Za-z_.$]*(?:ACCRUED|PAYABLE|LIAB)[A-Za-z_.$]*\s*,\s*side\s*:\s*["'`]debit/i,
};

/** The pmar binding — all pmar specifics (the file list) live here, in config, never in the detector. */
export const PMAR: OrderExtConfig = {
  ...ORDER_EXT_REGEXES,
  files: [
    "src/lib/payments.ts",
    "src/services/expenses.ts",
    "src/services/ap.ts",
    "src/services/travel.ts",
    "src/services/policy.ts",
    "src/lib/gaap.ts",
  ],
};

/**
 * v4 — build the detector config from a DERIVED money surface instead of a frozen path list. Generic
 * money-vocabulary regexes stay in the detector/config; only PATHS come from the surface, so the scan
 * reaches every money file the repo currently has (payments.ts, expenses.ts, ap.ts, travel.ts, …) with
 * zero hand-maintenance. The runner does: `detect(forSurface(deriveMoneySurface(cwd)))`.
 */
export function forSurface(surface: DerivedSurface | MoneySurface): OrderExtConfig {
  return { ...ORDER_EXT_REGEXES, files: surface.moneyPaths, cwd: surface.cwd };
}

// --- pure source-reading primitives (repo-agnostic; mirror the other static detectors) -

/** 1-based line number of the character at `idx`. */
const lineAt = (text: string, idx: number): number => text.slice(0, idx).split("\n").length;

/** `re` as a non-global clone (so a shared /g/ regex's lastIndex can't leak between calls). */
const flat = (re: RegExp): RegExp => new RegExp(re.source, re.flags.replace("g", ""));

/** Does `re` match anywhere in `text`? */
const has = (re: RegExp, text: string): boolean => flat(re).test(text);

/** Every start index of `re` in `text`. */
function allIdx(text: string, re: RegExp): number[] {
  const g = new RegExp(re.source, re.flags.includes("g") ? re.flags : re.flags + "g");
  const out: number[] = [];
  let m: RegExpExecArray | null;
  while ((m = g.exec(text))) {
    out.push(m.index);
    if (m.index === g.lastIndex) g.lastIndex++;
  }
  return out;
}

/** Index of `re`'s first match in `text` at or after `from`, or -1. */
function firstIdxFrom(text: string, re: RegExp, from: number): number {
  const g = new RegExp(re.source, re.flags.includes("g") ? re.flags : re.flags + "g");
  g.lastIndex = from;
  const m = g.exec(text);
  return m ? m.index : -1;
}

/**
 * The INNERMOST brace-balanced `{ ... }` block that encloses character `idx` — i.e. the body of the
 * function / callback that the statement at `idx` lives in. Found by scanning backward from `idx` for
 * the opening `{` at brace-depth 0, then forward for its matching close. Returns the block's open/close
 * absolute indices (null if no enclosing block). Good enough for the controlled fixtures and pmar's TS;
 * like the sibling detectors it does not strip strings/comments.
 */
export function enclosingBlock(text: string, idx: number): { open: number; close: number } | null {
  let depth = 0;
  let open = -1;
  for (let i = idx - 1; i >= 0; i--) {
    const c = text[i];
    if (c === "}") depth++;
    else if (c === "{") {
      if (depth === 0) {
        open = i;
        break;
      }
      depth--;
    }
  }
  if (open < 0) return null;
  depth = 0;
  for (let i = open; i < text.length; i++) {
    const c = text[i];
    if (c === "{") depth++;
    else if (c === "}") {
      depth--;
      if (depth === 0) return { open, close: i };
    }
  }
  return { open, close: text.length };
}

// --- the order-of-ops logic ------------------------------------------------------------

export interface OrderExtScan {
  /** "<file>:<line> [<leg>] — <why>" for each ordering/guard smell found. */
  violations: string[];
  /** "<file> [<leg>] — <why>" for each money-movement function whose ordering is correct. */
  guarded: string[];
  /** At least one function that clears a liability / marks paid AND makes an external call was found. */
  present: boolean;
}

/**
 * Pure core. For every irreversible provider-call site in every money file, find its enclosing function
 * block and ask: does a ledger post / mark-paid occur BEFORE the provider call in that same block? If so
 * the liability is cleared before the money is known to have moved — smell A. A block with both, in the
 * right order (external call first), is guarded. Then, independently, a provider call whose function has
 * no durable payment-state guard is smell B. `files` maps each path to its text (missing files absent).
 */
export function scanOrderExt(files: Map<string, string>, cfg: OrderExtConfig): OrderExtScan {
  const out: OrderExtScan = { violations: [], guarded: [], present: false };
  const seenBlocks = new Set<string>();

  for (const [path, text] of files) {
    const callSites = allIdx(text, cfg.providerCall);
    if (!callSites.length) continue;

    for (const call of callSites) {
      const block = enclosingBlock(text, call);
      if (!block) continue;
      const key = `${path}:${block.open}`;
      if (seenBlocks.has(key)) continue; // one verdict per enclosing function, not per provider call
      seenBlocks.add(key);

      const body = text.slice(block.open, block.close);
      const rel = call - block.open;

      // the earliest ledger-post and mark-paid WITHIN this block, as block-relative indices.
      const ledgerAbs = firstIdxFrom(text, cfg.ledgerPost, block.open);
      const ledgerRel = ledgerAbs >= 0 && ledgerAbs < block.close ? ledgerAbs - block.open : -1;
      const markAbs = firstIdxFrom(text, cfg.markPaid, block.open);
      const markRel = markAbs >= 0 && markAbs < block.close ? markAbs - block.open : -1;

      // this block is an ordering surface only if it BOTH settles the books AND calls the provider.
      const settlesIdx = [ledgerRel, markRel].filter((i) => i >= 0);
      if (!settlesIdx.length) continue; // provider call with no liability-clear / mark-paid here — not ours
      out.present = true;

      const earliestSettle = Math.min(...settlesIdx);
      const clearsLiability = has(cfg.liabilityDebit, body);

      // smell A — the books are settled BEFORE the irreversible external call.
      if (earliestSettle < rel) {
        const which =
          ledgerRel >= 0 && ledgerRel < rel
            ? `a ledger/journal post at line ${lineAt(text, block.open + ledgerRel)}` +
              (clearsLiability ? " that DEBITS a liability (clears Accrued Expenses / AP)" : "")
            : `a mark-paid status write at line ${lineAt(text, block.open + markRel)}`;
        out.violations.push(
          `${path}:${lineAt(text, call)} [ledger-before-external] — ${which} commits BEFORE the irreversible ` +
            `external provider call at line ${lineAt(text, call)}: if that call fails, times out, or the ` +
            `surrounding transaction tears down after the ledger leg committed, the liability is already ` +
            `cleared / the row marked paid while the payee was never paid — the accrual is gone, the cash ` +
            `never moved, and nothing reconciles it back`,
        );
      } else {
        out.guarded.push(
          `${path} [ledger-before-external] — the irreversible external provider call (line ` +
            `${lineAt(text, call)}) precedes the ledger post / mark-paid: the books clear the liability only ` +
            `after the money is known to have moved`,
        );
      }

      // smell B — the provider call has no durable payment-state guard, so a retry re-settles it.
      if (!has(cfg.idemGuard, body)) {
        out.violations.push(
          `${path}:${lineAt(text, call)} [no-durable-guard] — the irreversible external provider call is made ` +
            `with NO durable payment-state guard in its function (no idempotency runner, no already-paid / ` +
            `status check, no dedup key), so a retried movement re-settles at the provider — a second real debit`,
        );
      } else {
        out.guarded.push(
          `${path} [no-durable-guard] — the irreversible external provider call (line ${lineAt(text, call)}) is ` +
            `wrapped by a durable payment-state guard, so a retry does not re-settle`,
        );
      }
    }
  }
  return out;
}

/** Convenience core, matching the other detectors' `<name>Violations(): string[]` shape. */
export function orderExtViolations(files: Map<string, string>, cfg: OrderExtConfig): string[] {
  return scanOrderExt(files, cfg).violations;
}

// --- file plumbing ---------------------------------------------------------------------

function readFile(path: string, cwd?: string): string {
  return readFileSync(cwd ? `${cwd}/${path}` : path, "utf8");
}

// --- the verdict -----------------------------------------------------------------------

/** Run the detector against the live repo. */
export function detect(config: OrderExtConfig): Verdict {
  const files = new Map<string, string>();
  for (const p of config.files) {
    try {
      files.set(p, readFile(p, config.cwd));
    } catch {
      /* absent here (another repo, an empty fixture); skip it. */
    }
  }

  const scan = scanOrderExt(files, config);

  if (!scan.present) {
    return notApplicable(
      "no money-movement function was found that BOTH clears a liability / marks an item paid AND makes an " +
        "irreversible external provider call — there is no commit-vs-external-call ordering surface here to check " +
        "(the invariant is dormant)",
    );
  }
  if (scan.violations.length) {
    return finding(
      `a money op settles its books relative to the irreversible external call in the wrong way: ` +
        `${scan.violations.length} smell(s) across ledger-before-external / no-durable-guard — a failed or ` +
        `retried provider call can leave a liability cleared with the payee unpaid, or re-settle a payment`,
      { violations: scan.violations, guarded: scan.guarded },
    );
  }
  return checked(
    "every money-movement function performs the irreversible external provider call FIRST and clears the " +
      "liability / marks the item paid only after it succeeds, each under a durable payment-state guard — the " +
      "books are never settled ahead of the money actually moving",
    { guarded: scan.guarded },
  );
}

export default detect;
