// N-PASSTHRU-LIAB — portable static detector: tax / collected-on-behalf money is booked to a
// tax-payable LIABILITY account, never recognized as revenue or dropped.
//
// INVARIANT: sales/VAT/withholding tax (and any money an app collects ON BEHALF of a third party) is
// NOT the app's income. When a charge or invoice carries tax, the tax portion is a PASS-THROUGH
// liability: the org owes it onward to the taxing authority. It must land on a tax-payable LIABILITY
// account (e.g. "Sales Tax Payable"), so the trial balance shows the real obligation and remittance
// draws it down. Two classic ways this goes wrong, and both overstate income and understate what is
// owed: (1) the tax leg is credited to REVENUE (the org books someone else's money as its own sales),
// or (2) there is simply NOWHERE to put it — the chart of accounts has a tax engine but no tax-payable
// liability account — so the tax is dropped from the posting entirely and silently recognized as
// margin. A money app that computes tax but cannot book it as a liability is mis-stating its books.
//
// SMELL (any one is a FINDING):
//   A. a tax engine exists (it computes a tax amount) BUT the chart of accounts declares NO
//      tax-payable LIABILITY account — collected tax has no account to be booked to;
//   B. a ledger posting CREDITS a tax amount to a revenue/income account — pass-through money booked
//      as the org's own sales.
//
// Like the rest of the family this is a SOURCE scanner (fail-closed, needs no adapter, keys on stable
// surfaces — the chart of accounts and the ledger-posting idiom — not on a function name). It differs
// from the neobank detectors only in its source-reading MODE: pmar's money logic is TypeScript, not
// SQL migrations (see adapters/pmar.ts), so this reads the chart-of-accounts TS and the service TS
// with node:fs and matches the smell with regex. It is parameterised so nothing app-specific — the
// chart file, the tax-engine files, the account vocabulary, the posting idiom — is baked into the
// detector; only into the config. Dormant (NOT_APPLICABLE) until a tax engine is actually present:
// an app that never computes tax has no pass-through liability to book.

import { readFileSync } from "node:fs";
import { checked, finding, notApplicable, type Verdict } from "../money-system.ts";

export interface PassthruLiabConfig {
  /** Chart-of-accounts source (where account definitions and their `type` live). */
  chartOfAccounts: string;
  /** Files that, if present and matching `taxEngineMarker`, prove a tax engine exists (applicability). */
  taxEngineFiles: string[];
  /** Evidence a tax engine actually COMPUTES a tax amount (e.g. /totalTaxMinor|TaxService/). */
  taxEngineMarker: RegExp;
  /** Recognises a tax-payable account by its name/key, e.g. /sales[_\s-]*tax|tax[_\s-]*payable/i. */
  taxPayableName: RegExp;
  /** Recognises the LIABILITY type inside an account definition, e.g. /type\s*:\s*["']liability["']/i. */
  liabilityMarker?: RegExp;
  /** Service/ledger source files scanned for a tax amount credited to a revenue account (smell B). */
  ledgerSources?: string[];
  /** How a revenue/income account is referenced in a posting line, e.g. /ACCOUNTS\.REVENUE\b/. */
  revenueAccountRef?: RegExp;
  /** A tax-amount token in a posting line, e.g. /\btax\w*\b/i (must NOT match a base/total var). */
  taxAmountRef?: RegExp;
  /** Where to anchor the "missing account" citation in the chart file. Default: the account list. */
  accountListAnchor?: RegExp;
  /** Repo root. Default process.cwd(). */
  cwd?: string;
}

/** The pmar binding — all pmar specifics live here, in config, never in the detector. */
export const PMAR: PassthruLiabConfig = {
  chartOfAccounts: "src/lib/accounts.ts",
  taxEngineFiles: ["src/services/tax.ts"],
  // pmar's tax engine: `class TaxService` whose compute() sums `totalTaxMinor` from per-line `taxMinor`.
  taxEngineMarker: /\bclass\s+TaxService\b|\btotalTaxMinor\b|\btaxMinor\b|\bcomputeTax\b/i,
  // "Sales Tax Payable" / "Tax Payable" / "VAT Payable" / "Sales Tax" / "Withholding Tax" — but NOT
  // plain "Accounts Payable" (no adjacent "tax"), so pmar's existing liabilities don't false-match.
  taxPayableName:
    /tax[_\s-]*(?:payable|liabilit|collected|withheld|withholding|due|owed)|(?:sales|use|vat|gst|withholding|excise)[_\s-]*tax(?:es)?\b/i,
  liabilityMarker: /type\s*:\s*["']liability["']/i,
  ledgerSources: [
    "src/services/ar.ts",
    "src/services/ap.ts",
    "src/services/cards.ts",
    "src/services/expenses.ts",
  ],
  revenueAccountRef: /ACCOUNTS\.(?:REVENUE|SALES(?:_REVENUE)?|INCOME)\b|type\s*:\s*["'](?:revenue|income)["']/i,
  taxAmountRef: /\btax\w*\b/i,
  accountListAnchor: /\bSTANDARD_ACCOUNTS\b|\bACCOUNTS\s*=/,
};

// --- pure source-reading primitives (repo-agnostic; mirror the other static detectors) -

const escapeRe = (s: string): string => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

/** 1-based line number of `re`'s first match in `text` (1 if it does not match). */
function lineOf(text: string, re: RegExp): number {
  const m = new RegExp(re.source, re.flags.replace("g", "")).exec(text);
  return m ? text.slice(0, m.index).split("\n").length : 1;
}

/** Every brace-flat object literal `{ ... }` in the source (account defs / posting lines are these). */
function objectLiterals(text: string): Array<{ body: string; index: number }> {
  const out: Array<{ body: string; index: number }> = [];
  for (const m of text.matchAll(/\{[^{}]*\}/g)) out.push({ body: m[0], index: m.index });
  return out;
}

const LIABILITY = /type\s*:\s*["']liability["']/i;

// --- leg A: the chart must declare a tax-payable LIABILITY account ----------------------

export interface ChartScan {
  /** A tax-payable liability account is declared in the chart. */
  present: boolean;
  /** Liability account names found in the chart (evidence for the verdict). */
  liabilityNames: string[];
}

/**
 * Pure core. A tax-payable liability account is present iff some account-definition object literal is
 * BOTH liability-typed AND named for a tax payable. A liability account named only "Accounts Payable"
 * does not count — pass-through tax needs its own payable account.
 */
export function scanChart(chartText: string, cfg: PassthruLiabConfig): ChartScan {
  const liabilityMarker = cfg.liabilityMarker ?? LIABILITY;
  const defs = objectLiterals(chartText).filter((o) => liabilityMarker.test(o.body));
  const liabilityNames = defs
    .map((o) => /name\s*:\s*["']([^"']+)["']/i.exec(o.body)?.[1])
    .filter((n): n is string => !!n);
  let present = defs.some((o) => cfg.taxPayableName.test(o.body));
  // Fallback for a chart that isn't object-literal shaped: a tax-payable name within 160 chars of a
  // liability marker anywhere in the file.
  if (!present && defs.length === 0) {
    present = new RegExp(
      `(?:${cfg.taxPayableName.source}[\\s\\S]{0,160}?${liabilityMarker.source})|(?:${liabilityMarker.source}[\\s\\S]{0,160}?${cfg.taxPayableName.source})`,
      "i",
    ).test(chartText);
  }
  return { present, liabilityNames };
}

// --- leg B: no ledger posting may credit a tax amount to a revenue account --------------

export interface RevenueScan {
  /** "<file>:<line> — <snippet>" for each posting line crediting a tax amount to a revenue account. */
  violations: string[];
}

/**
 * Pure core. In each ledger source, a posting-line object literal that references a revenue/income
 * account AND is a `credit` AND carries a tax-amount token is booking pass-through tax as the org's
 * own sales. (A revenue credit whose amount is a base/total var — no tax token — is fine.)
 */
export function scanRevenuePostings(files: Array<{ path: string; text: string }>, cfg: PassthruLiabConfig): RevenueScan {
  const out: RevenueScan = { violations: [] };
  const revRef = cfg.revenueAccountRef;
  const taxRef = cfg.taxAmountRef;
  if (!revRef || !taxRef) return out;
  for (const { path, text } of files) {
    for (const { body, index } of objectLiterals(text)) {
      if (!revRef.test(body)) continue;
      if (!/\bcredit\b/i.test(body)) continue;
      if (!taxRef.test(body)) continue;
      const line = text.slice(0, index).split("\n").length;
      out.violations.push(`${path}:${line} — ${body.replace(/\s+/g, " ").trim()}`);
    }
  }
  return out;
}

// --- file plumbing ---------------------------------------------------------------------

function readFile(path: string, cwd?: string): string {
  return readFileSync(cwd ? `${cwd}/${path}` : path, "utf8");
}

/** Concatenate whatever of `paths` exist; a missing file is skipped (another repo may lack it). */
function concat(paths: string[], cwd?: string): string {
  const parts: string[] = [];
  for (const f of paths) {
    try {
      parts.push(readFile(f, cwd));
    } catch {
      /* absent here; skip. */
    }
  }
  return parts.join("\n");
}

/** The tax-engine file (and the line of its marker) that proves an engine is present, if any. */
function taxEngineEvidence(cfg: PassthruLiabConfig): { cite: string } | null {
  for (const f of cfg.taxEngineFiles) {
    let text: string;
    try {
      text = readFile(f, cfg.cwd);
    } catch {
      continue;
    }
    if (cfg.taxEngineMarker.test(text)) return { cite: `${f}:${lineOf(text, cfg.taxEngineMarker)}` };
  }
  return null;
}

// --- the verdict -----------------------------------------------------------------------

/** Run the detector against the live repo. */
export function detect(config: PassthruLiabConfig): Verdict {
  // Applicability: a tax engine must be present. No tax engine => no pass-through tax to book.
  const engine = taxEngineEvidence(config);
  if (!engine) {
    return notApplicable(
      "no tax engine is present — there is no collected/pass-through tax to book, so the tax-payable-liability invariant does not apply",
    );
  }

  const violations: string[] = [];
  const guarded: string[] = [];

  // Leg A — the chart of accounts must declare a tax-payable liability account.
  let chartText = "";
  try {
    chartText = readFile(config.chartOfAccounts, config.cwd);
  } catch {
    /* chart file absent — handled below as "no account to book to". */
  }
  const chart = scanChart(chartText, config);
  const anchor = config.accountListAnchor ?? /\bSTANDARD_ACCOUNTS\b|\bACCOUNTS\s*=/;
  const chartLine = lineOf(chartText, anchor);
  if (chart.present) {
    guarded.push(`${config.chartOfAccounts}: tax-payable liability account declared`);
  } else {
    violations.push(
      `${config.chartOfAccounts}:${chartLine} — a tax engine computes tax (${engine.cite}) but the ` +
        `chart of accounts declares NO tax-payable LIABILITY account` +
        (chart.liabilityNames.length
          ? ` (liability accounts present: ${chart.liabilityNames.join(", ")})`
          : "") +
        `; collected tax has no liability account and is recognized as revenue or dropped`,
    );
  }

  // Leg B — no ledger posting may credit a tax amount to a revenue account.
  const ledgerFiles = (config.ledgerSources ?? [])
    .map((p) => {
      try {
        return { path: p, text: readFile(p, config.cwd) };
      } catch {
        return null;
      }
    })
    .filter((x): x is { path: string; text: string } => x !== null);
  const rev = scanRevenuePostings(ledgerFiles, config);
  for (const v of rev.violations) {
    violations.push(`tax credited to a revenue account: ${v}`);
  }
  if (ledgerFiles.length && rev.violations.length === 0) {
    guarded.push("no ledger posting credits a tax amount to a revenue account");
  }

  if (violations.length) {
    return finding(
      "pass-through / collected tax is not booked to a tax-payable liability account — it is recognized as revenue or dropped",
      { violations, guarded, taxEngine: engine.cite },
    );
  }
  if (guarded.length) {
    return checked(
      "a tax-payable liability account exists for collected tax, and no ledger posting credits tax to a revenue account",
      { guarded, taxEngine: engine.cite },
    );
  }
  return notApplicable(
    "a tax engine is present, but the chart of accounts could not be read and no ledger postings were found — nothing to check",
  );
}

export default detect;
