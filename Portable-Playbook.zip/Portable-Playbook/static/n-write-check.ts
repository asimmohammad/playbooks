// N-WRITE-CHECK — portable static detector: a money/approval DB write CHECKS ITS RESULT before the
// routine reports success, records an approval, moves to the next step, or returns a success response.
//
// INVARIANT: with a supabase-style client, a write (`.from("t").insert/.update/.upsert/.delete(...)`)
// does NOT throw on a database error — it RETURNS `{ error }` (and, for conditional writes, a row
// count). The error is therefore invisible unless the caller destructures and inspects it. A money or
// approval write whose `{ error }` is never checked is a write whose FAILURE is silently swallowed: the
// row was not approved, the status did not flip, the accrual row never landed — yet the very next lines
// record an approval, recognize the expense, emit `expense.approved`, and return `status: "approved"`.
// A failed (or zero-row) write thus APPEARS AS AN APPROVAL. Money is recognized / released against a
// state change that the database rejected. The write must check its result BEFORE the success path:
//   `const { error } = await ctx.sb.from("expense_approvals").update({...}).eq("id", id);`
//   `if (error) throw new AppError("INTERNAL", error.message);`   // only now record the approval
//
// SMELL (any ONE is a FINDING):
//   A. [unchecked-write] a supabase write (`insert`/`update`/`upsert`/`delete`) on a money/approval
//      table is `await`ed with NO `{ error }` destructured and checked (no `if (error) throw/return`),
//      and the routine then runs a SUCCESS PATH after it — another status write, an audit/approval
//      record, a recognition/release call, an event emit, or a success `return`. The failed write is
//      treated as done.
//
// A write whose result is CHECKED — `const { error } = await …; if (error) throw` — before the success
// path is GUARDED. A write whose raw `{ data, error }` result is `return`ed to the caller is neither:
// the caller owns the check, so it is not a self-reported false success.
//
// Like the rest of the family this is a PURE SOURCE scanner (node:fs + regex, fail-closed). Per v4 the
// money surface is DERIVED, not declared: `forSurface(deriveMoneySurface(cwd))` supplies the FILES to
// scan (surface.moneyPaths) and the money TABLE names (surface.moneyTables); the write idioms and the
// generic money/approval table vocabulary live HERE in the detector, so a newly-landed money module
// (policy.ts, expenses.ts, ap.ts, ar.ts …) is scanned the moment it exists. Dormant (NOT_APPLICABLE)
// until an actual money/approval write is present.

import { readFileSync } from "node:fs";
import { checked, finding, notApplicable, type Verdict } from "../money-system.ts";
import { deriveMoneySurface, type DerivedSurface } from "../derive.ts";

export interface WriteCheckConfig {
  /** Money files to scan (v4: surface.moneyPaths, concrete relative paths). */
  scanPaths: string[];
  /** Money/approval table names from the surface (augments the generic name vocabulary below). */
  moneyTables: string[];

  // --- generic write / money-vocabulary idioms (app-agnostic; stay in the detector/config) ---
  /** A supabase write site: `.from("table").insert|update|upsert|delete(` (verb may follow a newline). */
  writeSite: RegExp;
  /** A money/approval TABLE name by vocabulary (expense_approvals, bills, payments, exceptions, …). */
  moneyTableName: RegExp;
  /** A destructure of `error` from the write result: `const { … error … } = …` (captures an alias). */
  errorDestructure: RegExp;
  /** A success path that follows a write: a status write, audit/approval record, release call, emit, return. */
  successPath: RegExp;
  /** Repo root. Default process.cwd(). */
  cwd?: string;
}

/**
 * The generic write-vocabulary. NO paths and NO specific table names here — only the idioms that say
 * "this is a supabase write", "this is a money/approval table name", "this is an error check", "this is
 * a success path". The FILES to scan and the concrete money TABLE names come from the surface.
 */
export const WRITE_CHECK_SMELLS: Omit<WriteCheckConfig, "scanPaths" | "moneyTables" | "cwd"> = {
  // `.from("expense_approvals").update(` / `.from("bills")\n  .insert(` — the write verb may sit on the
  // next line after `.from("t")`. Reads (`.select(`) are NOT writes and are intentionally excluded.
  writeSite: /\.from\s*\(\s*["'`]([a-z0-9_]+)["'`]\s*\)\s*\.\s*(insert|update|upsert|delete)\b/gi,
  // a money/approval table by name — approvals, expenses, exceptions, bills/AP, invoices/AR, payments,
  // reimbursements, payouts, ledger/journal/accruals, settlements, refunds, charges, disputes, …
  moneyTableName:
    /approv|expense|exception|reimburs|payout|payment|\bbill|invoice|ledger|journal|accrual|settle|disburse|refund|charge|dispute|chargeback|remittance|payroll|payable|receivable|\bpay\b|wallet|\bfee|\btax|credit|debit|transfer/i,
  // `const { error } = …` / `const { data, error } = …` / `const { error: insErr } = …`. The braces
  // belong to the destructure, so the enclosing class name is irrelevant.
  errorDestructure:
    /(?:const|let|var)\s*\{[^{}]*\berror\b(?:\s*:\s*([A-Za-z_$][\w$]*))?[^{}]*\}\s*=/,
  // a success path AFTER the write: another status write, an audit/approval record, a recognition /
  // release / finalize call, an event emit, or a success return.
  successPath:
    /\breturn\b|\baudit\s*\(|\b(?:recogni[sz]e|accrue|settle|reimburse|payout|disburse|capture|finali[sz]e|approve)\w*\s*\(|\.emit\s*\(|\.from\s*\(/i,
};

// --- pure source-reading primitives (repo-agnostic; mirror the other static detectors) -

/** 1-based line number of the character at `idx`. */
const lineAt = (text: string, idx: number): number => text.slice(0, idx).split("\n").length;

/**
 * Replace the CONTENTS of `//` and block comments with spaces, preserving every character offset and
 * newline (so line numbers computed on the result still match the original file). String and template
 * literals are skipped, so a `//` inside a quoted string is not mistaken for a comment. This keeps a
 * comment that happens to contain `return`/`error` from steering the scan — only real code is read.
 */
export function blankComments(src: string): string {
  const out = src.split("");
  let i = 0;
  const n = src.length;
  while (i < n) {
    const c = src[i]!;
    if (c === '"' || c === "'" || c === "`") {
      // skip a string/template literal (with backslash escapes); offsets are untouched.
      const quote = c;
      i++;
      while (i < n) {
        if (src[i] === "\\") { i += 2; continue; }
        if (src[i] === quote) { i++; break; }
        i++;
      }
      continue;
    }
    if (c === "/" && src[i + 1] === "/") {
      while (i < n && src[i] !== "\n") { out[i] = " "; i++; }
      continue;
    }
    if (c === "/" && src[i + 1] === "*") {
      out[i] = " "; out[i + 1] = " "; i += 2;
      while (i < n && !(src[i] === "*" && src[i + 1] === "/")) {
        if (src[i] !== "\n") out[i] = " ";
        i++;
      }
      if (i < n) { out[i] = " "; out[i + 1] = " "; i += 2; }
      continue;
    }
    i++;
  }
  return out.join("");
}

/**
 * An `if (error)` / `if (!error)` / `error ? …` / `throw … error` style check of the destructured
 * error alias. Parameterised by the alias name so `const { error: insErr } = …; if (insErr) throw` is
 * recognised as a genuine check.
 */
function errorCheckRe(alias: string): RegExp {
  return new RegExp(
    `\\bif\\s*\\(\\s*!?\\s*${alias}\\b` +
      `|(?:throw|return)[^;]{0,80}\\b${alias}\\b` +
      `|\\b${alias}\\b[^;]{0,24}(?:\\?|&&|\\|\\|)`,
  );
}

/**
 * Split a source file into function / method regions: each region is a `name(...) { … }` header and the
 * body up to the next such header. Works for top-level functions and indented class methods. Inline
 * arrow callbacks are not headers, so a method body is captured whole. A control-flow head (`if (…) {`,
 * `for (…) {`, `while (…) {`, `catch (…) {`, `switch (…) {`) is explicitly NOT a header — otherwise a
 * method body would be split at its first `if`, hiding the success path that follows a write.
 */
export function functionRegions(text: string): Array<{ text: string; base: number }> {
  const headerRe =
    /\n[ \t]*(?:export\s+)?(?:public\s+|private\s+|protected\s+)?(?:static\s+)?(?:async\s+)?(?:function\s+)?(?!(?:if|for|while|switch|catch|return|else|do|with)\b)[A-Za-z_$][\w$]*\s*\([^)]*\)\s*(?::[^;{]*)?\{/g;
  const starts: number[] = [];
  let m: RegExpExecArray | null;
  while ((m = headerRe.exec(text))) starts.push(m.index);
  if (!starts.length) return [{ text, base: 0 }];
  const out: Array<{ text: string; base: number }> = [];
  for (let i = 0; i < starts.length; i++) {
    const end = i + 1 < starts.length ? starts[i + 1]! : text.length;
    out.push({ text: text.slice(starts[i]!, end), base: starts[i]! });
  }
  return out;
}

// --- the write-check logic -------------------------------------------------------------

export interface WriteCheckScan {
  /** "<file>:<line> [<leg>] — <why>" for each unchecked money/approval write found. */
  violations: string[];
  /** "<file>:<line> [<leg>] — <why>" for each money/approval write whose result is checked. */
  guarded: string[];
  /** At least one money/approval write was found (else the invariant is dormant). */
  present: boolean;
}

/**
 * Pure core. For each money file, walk each routine and each supabase write site in order. A write to a
 * money/approval table that is awaited with no `{ error }` check and then followed by a success path is
 * a violation; one whose `{ error }` is destructured and checked before the success path is guarded; a
 * write whose raw result is `return`ed is neither (the caller owns the check). `present` flips true the
 * moment any money/approval write is seen, so an app with none is dormant (NOT_APPLICABLE).
 */
export function scanWriteCheck(
  files: Array<{ path: string; text: string }>,
  cfg: WriteCheckConfig,
): WriteCheckScan {
  const out: WriteCheckScan = { violations: [], guarded: [], present: false };
  const tableSet = new Set(cfg.moneyTables.map((t) => t.toLowerCase()));
  const tableIsMoney = (t: string): boolean => cfg.moneyTableName.test(t) || tableSet.has(t.toLowerCase());

  for (const { path, text: rawText } of files) {
    // Blank comment contents (offsets preserved) so a comment mentioning return/error cannot steer the
    // scan; line numbers below are computed on the same blanked text, so they match the original file.
    const text = blankComments(rawText);
    for (const region of functionRegions(text)) {
      const rt = region.text;

      // every write site in this region, in source order
      const writeRe = new RegExp(cfg.writeSite.source, "gi");
      const sites: Array<{ idx: number; end: number; table: string; verb: string }> = [];
      let m: RegExpExecArray | null;
      while ((m = writeRe.exec(rt))) {
        sites.push({ idx: m.index, end: m.index + m[0].length, table: m[1]!, verb: m[2]! });
        if (m.index === writeRe.lastIndex) writeRe.lastIndex++;
      }

      for (const s of sites) {
        if (!tableIsMoney(s.table)) continue;
        out.present = true;

        // prefix: from the previous statement terminator to the write start. A `;` is the only safe
        // boundary — the destructure `const { error } = …` carries its own braces, so `{`/`}` would
        // truncate it. (A write that is the region's first statement has no prior `;`, so start at 0.)
        const semi = rt.lastIndexOf(";", s.idx);
        const prefix = rt.slice(semi + 1, s.idx);
        const cite = `${path}:${lineAt(text, region.base + s.idx)}`;

        // a `return await ctx.sb.from(...)…` hands the raw `{ error }` up to the caller — not a
        // self-reported false success, so neither a violation nor a guard.
        if (/\breturn\b/.test(prefix)) continue;

        // statement end: the `;` closing the write chain (or region end).
        const stmtEnd = rt.indexOf(";", s.end);
        const stmtEndIdx = stmtEnd < 0 ? rt.length : stmtEnd;
        const after = rt.slice(stmtEndIdx);

        const dm = cfg.errorDestructure.exec(prefix);
        if (dm) {
          const alias = dm[1] || "error";
          const checkWin = rt.slice(s.idx, Math.min(rt.length, stmtEndIdx + 260));
          if (errorCheckRe(alias).test(checkWin)) {
            out.guarded.push(
              `${cite} [write-checked] — the ${s.verb} on \`${s.table}\` destructures \`{ ${alias} }\` and ` +
                `checks it (\`if (${alias}) …\`) before any approval / status change / success return`,
            );
          } else if (cfg.successPath.test(after)) {
            // error was captured but never inspected, then a success path runs — still unchecked.
            out.violations.push(
              `${cite} [unchecked-write] — the ${s.verb} on money/approval table \`${s.table}\` captures ` +
                `\`{ ${alias} }\` but NEVER checks it before the routine records an approval / changes status / ` +
                `returns success: a failed or zero-row write is treated as done, so a DB rejection appears as ` +
                `an approval`,
            );
          }
        } else if (cfg.successPath.test(after)) {
          // bare `await …from(t).update(...)` with no error capture at all, then a success path.
          out.violations.push(
            `${cite} [unchecked-write] — the ${s.verb} on money/approval table \`${s.table}\` is \`await\`ed ` +
              `with NO \`{ error }\` check, then the routine records an approval / changes status / returns ` +
              `success — the write's \`{ error }\` is swallowed, so a failed (or zero-row) write appears as an ` +
              `approval and money is recognized / released against a state change the database rejected [smell A]`,
          );
        }
      }
    }
  }

  return out;
}

/** Convenience core, matching the other detectors' `<name>Violations(): string[]` shape. */
export function writeCheckViolations(
  files: Array<{ path: string; text: string }>,
  cfg: WriteCheckConfig,
): string[] {
  return scanWriteCheck(files, cfg).violations;
}

// --- file plumbing ---------------------------------------------------------------------

function readFile(path: string, cwd?: string): string {
  return readFileSync(cwd ? `${cwd}/${path}` : path, "utf8");
}

// --- the v4 surface binding ------------------------------------------------------------

/**
 * Build the detector config from a DERIVED money surface. Only PATHS (surface.moneyPaths) and the money
 * TABLE names (surface.moneyTables) come from the surface; the write idioms and the generic
 * money/approval table vocabulary are the fixed `WRITE_CHECK_SMELLS`. This is the v4 contract:
 * `detect(forSurface(deriveMoneySurface(cwd)))`.
 */
export function forSurface(surface: Pick<DerivedSurface, "moneyPaths" | "moneyTables" | "cwd">): WriteCheckConfig {
  return {
    ...WRITE_CHECK_SMELLS,
    scanPaths: surface.moneyPaths,
    moneyTables: surface.moneyTables ?? [],
    cwd: surface.cwd,
  };
}

// --- the verdict -----------------------------------------------------------------------

/** Run the detector against the live repo. */
export function detect(config: WriteCheckConfig): Verdict {
  const files: Array<{ path: string; text: string }> = [];
  for (const p of config.scanPaths) {
    if (/[*?]/.test(p)) continue; // a glob (hand-declared surface); v4 derivation yields concrete files
    try {
      files.push({ path: p, text: readFile(p, config.cwd) });
    } catch {
      /* absent here (another repo, an empty fixture); skip it. */
    }
  }

  const scan = scanWriteCheck(files, config);

  if (!scan.present) {
    return notApplicable(
      "no money/approval DB write was found in the derived money files — there is no write whose result " +
        "must be checked here (the invariant is dormant)",
    );
  }
  if (scan.violations.length) {
    return finding(
      `a money/approval DB write does not check its result before reporting success: ${scan.violations.length} ` +
        `unchecked-write smell(s) — a failed or zero-row write is swallowed and appears as an approval, so ` +
        `money is recognized / released against a state change the database rejected`,
      { violations: scan.violations, guarded: scan.guarded },
    );
  }
  return checked(
    "every money/approval write checks its `{ error }` result before recording an approval, changing status, " +
      "or returning success — a failed write can no longer pass for a completed one",
    { guarded: scan.guarded },
  );
}

/** v4 convenience: derive the surface from `cwd` and run. */
export function detectRepo(cwd: string): Verdict {
  const surface = deriveMoneySurface(cwd);
  return detect(forSurface({ ...surface, cwd }));
}

export default detect;
