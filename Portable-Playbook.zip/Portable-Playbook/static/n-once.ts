// N-ONCE — portable static detector: a money movement is EXACTLY-ONCE under failure and
// concurrency. The ledger leg, the domain row and the idempotency marker commit TOGETHER, the
// idempotency key is CLAIMED BEFORE the effect runs, and the external provider call carries its
// own idempotency key.
//
// INVARIANT: moving money is the one operation a system may never do twice. A retried HTTP request,
// a double-click, a provider webhook redelivery, a crash-and-restart mid-flow, or two concurrent
// requests with the same key must all result in AT MOST ONE real movement: one ledger entry, one
// domain (payment) row, one provider debit. Three things together make that true, and ALL three
// must hold:
//   (1) CLAIM-BEFORE. The idempotency key is reserved in durable storage BEFORE the effect runs,
//       not stored after it returns. If the key is only written AFTER the effect, then a crash (or a
//       concurrent second request) between "effect done" and "key stored" re-runs the whole effect:
//       the replay guard never sees the first attempt because it was never recorded in time. A
//       store-AFTER idempotency runner is a replay guard that does not guard the window that matters.
//   (2) ONE COMMIT SCOPE. The ledger leg + the domain row (+ the marker) commit in a SINGLE durable
//       transaction. If the executor instead strings together an inner self-committing ledger post
//       and a separate autocommit INSERT — two independent commit scopes — with an irreversible
//       external call wedged between them, then a failure after the first commit but before the
//       second leaves the movement half-applied (a ledger entry and a real provider debit, but no
//       payment row; or a payment row the ledger never balanced). Nothing reconciles it back.
//   (3) PROVIDER IDEMPOTENCY. The external, irreversible provider call (createPayment) carries an
//       idempotency / request key, so that a retry of the SAME movement is deduplicated BY THE
//       PROVIDER rather than landing as a second real debit. A mutating connector call with no such
//       key cannot be made exactly-once no matter how careful the caller is.
//
// SMELL (any ONE is a FINDING):
//   A. [claim-before] in the idempotency runner the marker is STORED AFTER the effect function
//      returns (store-after) rather than claimed before it;
//   B. [commit-scope] the money-movement executor spans MORE THAN ONE independent commit scope
//      (a self-committing ledger post + a separate autocommit domain INSERT) with an external
//      provider call BETWEEN them, and no single enclosing transaction;
//   C. [connector-idem-key] the mutating connector call (createPayment) is declared and/or invoked
//      with NO idempotency / request-key parameter.
//
// Like the rest of the family this is a SOURCE scanner (fail-closed, needs no adapter, keys on
// stable surfaces — the money-movement executor, the idempotency runner and the connector seam —
// not on any behavioural harness). It shares the TypeScript source-reading MODE of N-OBLIG-DUP and
// N-PASSTHRU-LIAB: pmar's money logic is TS (src/lib/payments.ts, src/lib/idempotency.ts,
// src/connectors/types.ts — see adapters/pmar.ts), so this reads those files with node:fs and
// matches the smell with regex over the executor / runner / connector idioms. It is parameterised so
// nothing app-specific — the executor function, the ledger-post / INSERT / transaction idioms, the
// idempotency runner, the connector method, the idem-key vocabulary — is baked into the detector;
// only into the config. Dormant (NOT_APPLICABLE) until a money-movement executor is actually present.

import { readFileSync } from "node:fs";
import { checked, finding, notApplicable, type Verdict } from "../money-system.ts";
import { deriveMoneySurface, type DerivedSurface } from "../derive.ts";
import { type MoneySurface } from "../adapters/pmar.ts";

// DEEPEN (v4): beyond the money-MOVEMENT executor (payments) this detector also checks the second
// place a value is posted exactly-once — RECOGNITION / ACCRUAL (gaap.recognizeExpense & peers). A
// recognition post is exactly-once only when its idempotency guard is a DURABLE UNIQUE accrual-to-
// source claim, not a MUTABLE lifecycle status, and the status transition is a lock/CAS rather than
// a read-then-write race. Three recognition smells (PR13 recognition-idempotency, 3 High):
//   D. [recognition-mutable-guard] the only replay guard is an equality test on a MUTABLE status
//      (`if (e.status === "approved") return`) with NO durable unique claim — a later status flip
//      (re-open / re-submit) re-runs the accrual, double-counting it;
//   E. [unkeyed-recognition] the recognition/accrual post has NO unique accrual-to-source key, so
//      nothing at the storage layer dedups a second accrual of the same source;
//   F. [recognition-no-cas] status-read -> ledger/accrual post -> status-write with NO lock / CAS,
//      so two concurrent recognitions both pass the read, both post, and both flip the status.
// The recognition legs are GENERIC (vocabulary regexes below); only the FILES to scan are bound —
// statically in PMAR, or (v4) DERIVED from the repo's money surface via forSurface(), so the scan
// reaches every money file (src/lib/gaap.ts, src/services/policy.ts, …) with zero hand-maintenance.

/** One money-movement flow and how to recognise its exactly-once smells in source. */
export interface OnceFlow {
  /** Human label for the flow, e.g. "money-movement executor (payments)". Verdict output only. */
  name: string;

  // --- the executor: legs B (commit scope) and C (connector call site) --------------------
  /** File holding the money-movement executor, e.g. "src/lib/payments.ts". */
  executorFile: string;
  /** Anchors the executor function (also the applicability gate), e.g. /\bexecuteMoneyMovement\b/. */
  executorFn: RegExp;
  /** The self-committing ledger post inside the executor, e.g. /\.postEntry\s*\(/. */
  ledgerPost: RegExp;
  /** The irreversible external provider call, e.g. /\.connectors\.\w+\.\w+\s*\(/. */
  externalCall: RegExp;
  /** The SEPARATE autocommit domain INSERT, e.g. /insert\s+into\s+payments\b/i. */
  domainInsert: RegExp;
  /** A single-transaction wrapper that unifies the commit scope, e.g. /\.transaction\s*\(/. */
  txnWrapper: RegExp;

  // --- the idempotency runner: leg A (claim-before) --------------------------------------
  /** File holding the "run exactly once" runner, e.g. "src/lib/idempotency.ts". */
  idempotencyFile: string;
  /** Anchors the runner function, e.g. /\brunIdempotent\b/. The region runs to the next top-level def. */
  idempotencyRunner: RegExp;
  /** How the runner invokes the effect it wraps, e.g. /\bfn\s*\(/ (must NOT match `fn: () =>`). */
  effectInvoke: RegExp;
  /** How the runner CLAIMS/stores the key, e.g. /\bstoreIdempotent\s*\(|insert\s+into\s+idempotency_keys/i. */
  claimStore: RegExp;

  // --- the mutating connector call: leg C (provider idempotency) -------------------------
  /** File declaring the connector seam, e.g. "src/connectors/types.ts". */
  connectorFile: string;
  /** The mutating connector method, e.g. /\bcreatePayment\s*\(/. */
  mutatingConnectorCall: RegExp;
  /** Recognises an idempotency / request-key field, e.g. /idempoten|request[_\s]?(?:key|id)|dedup/i. */
  idemKeyParam: RegExp;
}

/**
 * The RECOGNITION / ACCRUAL leg (the v4 deepen). A recognition post (debit an expense GL / credit
 * accrued expenses, or any journal post made at approval) must be exactly-once the SAME way a money
 * movement is: guarded by a DURABLE UNIQUE claim keyed to the source, not a mutable status, and with
 * the status transition done as a lock/CAS. Only `files` is app-specific (bound from the surface);
 * every regex below is GENERIC money vocabulary.
 */
export interface RecognitionConfig {
  /** The money files to scan for recognition/accrual posts. From surface.moneyPaths (v4) or static. */
  files: string[];
  /** Anchors a recognition/accrual function, e.g. /recognizeExpense\(/ or /accrue\(/. */
  recognizeFn: RegExp;
  /** The ledger/journal/accrual post inside a recognition region, e.g. /\.postEntry\(/ , /accrualLines\(/. */
  recognitionPost: RegExp;
  /** A replay guard keyed to a MUTABLE lifecycle status, e.g. /if\s*\(\s*e\.status\s*===\s*"approved"/. */
  mutableStatusGuard: RegExp;
  /** A DURABLE unique accrual-to-source claim (unique key / ON CONFLICT / insert into a recognition table). */
  durableClaim: RegExp;
  /** A write of the lifecycle status, e.g. /\.update\(\s*\{\s*status/ or SQL `UPDATE … SET status`. */
  statusWrite: RegExp;
  /** A row lock or compare-and-swap, e.g. /FOR UPDATE/ , /\.forUpdate\(/ , /\.eq\("status",/ , /ON CONFLICT/. */
  lockOrCas: RegExp;
}

/**
 * The GENERIC recognition-leg vocabulary. These regexes bake in NO app path/table — they are money
 * vocabulary only — and are shared by the static PMAR binding and the derived forSurface() binding.
 */
export const RECOGNITION_REGEXES: Omit<RecognitionConfig, "files"> = {
  // recognize / recognise / recognizeExpense / recognizeRevenue / accrue / accrueExpense / recordAccrual.
  // The identifier must be immediately followed by `(` (a def/call), so prose like "recognized (accrued)"
  // in a doc string or rule description is NOT mistaken for a recognition site.
  recognizeFn: /\b(?:recogni[sz]e[A-Za-z]*|accrue[A-Za-z]*|recordAccrual|postRecognition)\(/i,
  recognitionPost: /\.postEntry\s*\(|\bpostEntry\s*\(|\bjournalEntr[A-Za-z]*\s*\(|\baccrualLines\s*\(|\binsertJournal\s*\(/i,
  // an equality (or inequality) test against a `.status` string literal used as the ONLY guard.
  mutableStatusGuard: /\bif\s*\(\s*[^)]*\.\s*status\s*[!=]==?\s*["'`][a-z0-9_]+["'`]/i,
  // a durable unique accrual-to-source key: ON CONFLICT / onConflict / .ignore() / an insert into a
  // recognition|accrual table / a read of one / a recognition_key|accrual_key column / a UNIQUE(...).
  durableClaim:
    /on\s+conflict|\.onConflict\s*\(|\.ignore\s*\(|insert\s+into\s+[a-z_]*(?:recognition|accrual)[a-z_]*|from\(\s*["'`][a-z_]*(?:recognition|accrual)[a-z_]*["'`]|recognition_key|accrual_key|\bunique\s*\(/i,
  statusWrite:
    /\.update\s*\(\s*\{[^}]*\bstatus\b[^}]*\}|update\s+[a-z_"'`.]+\s+set\b[^;]*\bstatus\b/i,
  // a lock or CAS on the status transition.
  lockOrCas:
    /\bfor\s+update\b|\.forUpdate\s*\(|\.eq\s*\(\s*["'`]status["'`]\s*,|\.neq\s*\(\s*["'`]status["'`]\s*,|on\s+conflict|\.onConflict\s*\(|\bwith\s+lock\b/i,
};

export interface OnceConfig {
  /** The money-movement flows to check. */
  flows: OnceFlow[];
  /** The recognition/accrual leg (the v4 deepen). Optional: absent => recognition is not scanned. */
  recognition?: RecognitionConfig;
  /** Repo root. Default process.cwd(). */
  cwd?: string;
}

/** The pmar binding — all pmar specifics live here, in config, never in the detector. */
export const PMAR: OnceConfig = {
  flows: [
    {
      name: "money-movement executor (payments)",
      executorFile: "src/lib/payments.ts",
      executorFn: /\bexecuteMoneyMovement\b/,
      // pmar's ledger post self-commits: `ctx.ledger.postEntry(...)`.
      ledgerPost: /\.postEntry\s*\(|\bpostEntry\s*\(/,
      // the irreversible provider call crosses the connector seam: `ctx.connectors.payments.createPayment(`.
      externalCall: /\.connectors\.[A-Za-z_$][\w$]*\.[A-Za-z_$][\w$]*\s*\(/,
      // the separate autocommit domain write: `INSERT INTO payments (...)`.
      domainInsert: /insert\s+into\s+payments\b/i,
      // a single-transaction wrapper that would unify the two commit scopes (better-sqlite3 style + SQL).
      txnWrapper:
        /\.transaction\s*\(|\bwithTransaction\b|\bbeginTransaction\b|\bBEGIN(?:\s+(?:IMMEDIATE|DEFERRED|EXCLUSIVE|TRANSACTION))?\b/i,
      idempotencyFile: "src/lib/idempotency.ts",
      idempotencyRunner: /\brunIdempotent\b/,
      effectInvoke: /\bfn\s*\(/,
      claimStore: /\bstoreIdempotent\s*\(|insert\s+into\s+idempotency_keys/i,
      connectorFile: "src/connectors/types.ts",
      mutatingConnectorCall: /\bcreatePayment\s*\(/,
      // "idempotencyKey" / "idempotency_key" / "requestKey" / "request_id" / "clientToken" / "dedupKey".
      idemKeyParam: /idempoten|idem[_\s]?key|request[_\s]?(?:key|id|token)|client[_\s]?token|dedup/i,
    },
  ],
  // The recognition/accrual leg — generic vocabulary, a static file list for the non-derived path.
  recognition: {
    ...RECOGNITION_REGEXES,
    files: ["src/lib/gaap.ts", "src/services/policy.ts", "src/services/travel.ts", "src/services/expenses.ts"],
  },
};

/**
 * v4 — build the detector config from a DERIVED money surface instead of a frozen path list. Generic
 * money-vocabulary regexes stay in the detector/config; only PATHS come from the surface, so the
 * recognition scan reaches every money file the repo currently has (gaap.ts, policy.ts, travel.ts, …)
 * with zero hand-maintenance. The runner does: `detect(forSurface(deriveMoneySurface(cwd)))`.
 */
export function forSurface(surface: DerivedSurface | MoneySurface): OnceConfig {
  const mp = surface.moneyPaths;
  const pick = (re: RegExp, fallback: string): string => mp.find((p) => re.test(p)) ?? fallback;
  const base = PMAR.flows[0];
  const flow: OnceFlow = {
    ...base, // every regex (executorFn, ledgerPost, txnWrapper, idemKeyParam, …) is reused verbatim
    executorFile: pick(/(?:^|\/)payments\.ts$/, base.executorFile),
    idempotencyFile: pick(/(?:^|\/)idempotency\.ts$/, base.idempotencyFile),
    connectorFile: pick(/connectors\/types\.ts$/, base.connectorFile),
  };
  return {
    flows: [flow],
    recognition: { ...RECOGNITION_REGEXES, files: mp }, // scan ALL derived money files for recognition
    cwd: surface.cwd,
  };
}

// --- pure source-reading primitives (repo-agnostic; mirror the other static detectors) -

/** 1-based line number of the character at `idx`. */
const lineAt = (text: string, idx: number): number => text.slice(0, idx).split("\n").length;

/** `re` as a non-global clone (so a shared /g/ regex's lastIndex can't leak between calls). */
const flat = (re: RegExp): RegExp => new RegExp(re.source, re.flags.replace("g", ""));

/** Does `re` match anywhere in `text`? */
const has = (re: RegExp, text: string): boolean => flat(re).test(text);

/** Index of `re`'s first match in `text`, or -1. */
function firstIdx(text: string, re: RegExp): number {
  const m = flat(re).exec(text);
  return m ? m.index : -1;
}

/** Every start index of `re` in `text`. */
function allIdx(text: string, re: RegExp): number[] {
  const g = new RegExp(re.source, re.flags.includes("g") ? re.flags : re.flags + "g");
  const out: number[] = [];
  let m: RegExpExecArray | null;
  while ((m = g.exec(text))) {
    out.push(m.index);
    if (m.index === g.lastIndex) g.lastIndex++;
  }
  return out;
}

/**
 * The source region that is one function: from `startRe`'s first match to the NEXT top-level
 * declaration (at column 0) or end of file. Top-level `function`/`const`/`class`/… at column 0 end
 * the region; the function's own indented statements do not, so the body is captured whole. Returns
 * the region text plus its absolute base offset (for line numbers against the full file).
 */
export function sliceRegion(text: string, startRe: RegExp): { text: string; base: number } | null {
  const s = flat(startRe).exec(text);
  if (!s) return null;
  const base = s.index;
  const afterStart = base + s[0].length;
  const rest = text.slice(afterStart);
  const nextDef = /\n(?:export\s+)?(?:async\s+)?(?:function|const|let|var|class|interface|type|enum)\s/.exec(rest);
  const end = nextDef ? afterStart + nextDef.index : text.length;
  return { text: text.slice(base, end), base };
}

/** The brace-balanced `{ ... }` block at or after `fromIdx` (its inner body, open and close index). */
export function balancedBraces(
  text: string,
  fromIdx: number,
): { body: string; open: number; close: number } | null {
  const open = text.indexOf("{", fromIdx);
  if (open < 0) return null;
  let depth = 0;
  for (let i = open; i < text.length; i++) {
    const c = text[i];
    if (c === "{") depth++;
    else if (c === "}") {
      depth--;
      if (depth === 0) return { body: text.slice(open + 1, i), open, close: i };
    }
  }
  return null;
}

/** The object literal / type `{ ... }` that immediately follows the first `callRe` match. */
export function objectAfter(
  text: string,
  callRe: RegExp,
): { body: string; open: number; close: number } | null {
  const m = flat(callRe).exec(text);
  if (!m) return null;
  return balancedBraces(text, m.index + m[0].length);
}

// --- the exactly-once logic ------------------------------------------------------------

export interface OnceScan {
  /** "<flow> [<leg>]: <file>:<line> — <why>" for each exactly-once smell found. */
  violations: string[];
  /** "<flow> [<leg>]: <file> — <why>" for each leg that is guarded. */
  guarded: string[];
  /** At least one money-movement executor was found (else the invariant is dormant). */
  present: boolean;
}

/**
 * Pure core. For each flow whose executor is present, run the three independent legs — claim-before
 * (A), one-commit-scope (B), provider idempotency (C) — over the executor / idempotency-runner /
 * connector sources. Any leg's smell is a violation; a leg whose guard is in place is recorded as
 * guarded. `files` maps a flow's declared paths to their text (a missing file is simply absent).
 */
export function scanOnce(files: Map<string, string>, cfg: OnceConfig): OnceScan {
  const out: OnceScan = { violations: [], guarded: [], present: false };

  for (const flow of cfg.flows) {
    const execText = files.get(flow.executorFile);
    if (execText === undefined || !has(flow.executorFn, execText)) continue; // no executor here
    out.present = true;

    // --- leg B: the ledger leg + domain row must commit in ONE scope ---------------------
    const region = sliceRegion(execText, flow.executorFn);
    if (region) {
      const rt = region.text;
      const lp = firstIdx(rt, flow.ledgerPost);
      const xc = firstIdx(rt, flow.externalCall);
      const di = firstIdx(rt, flow.domainInsert);
      const wrapped = has(flow.txnWrapper, rt);
      const line = (i: number) => lineAt(execText, region.base + i);
      if (lp >= 0 && di >= 0 && xc >= 0 && lp < xc && xc < di && !wrapped) {
        out.violations.push(
          `${flow.name} [commit-scope]: ${flow.executorFile}:${line(xc)} — the executor spans two ` +
            `independent commit scopes (a self-committing ledger post at line ${line(lp)} and a separate ` +
            `autocommit INSERT at line ${line(di)}) with an irreversible external provider call between ` +
            `them and NO single enclosing transaction — a crash or fault between the two commits leaves ` +
            `the money movement half-applied and nothing reconciles it back`,
        );
      } else if (lp >= 0 && di >= 0) {
        out.guarded.push(
          `${flow.name} [commit-scope]: ${flow.executorFile} — ` +
            (wrapped
              ? "the ledger leg and the domain row commit inside a single transaction"
              : "no external provider call sits between the ledger post and the domain-row INSERT"),
        );
      }
    }

    // --- leg A: the idempotency key must be CLAIMED BEFORE the effect runs ----------------
    const idemText = files.get(flow.idempotencyFile);
    if (idemText !== undefined) {
      const reg = sliceRegion(idemText, flow.idempotencyRunner);
      if (reg) {
        const effect = firstIdx(reg.text, flow.effectInvoke);
        const claims = allIdx(reg.text, flow.claimStore);
        if (effect >= 0 && claims.length) {
          const claimBefore = claims.some((c) => c < effect);
          if (!claimBefore) {
            const after = claims.find((c) => c > effect) as number;
            out.violations.push(
              `${flow.name} [claim-before]: ${flow.idempotencyFile}:${lineAt(idemText, reg.base + after)} — ` +
                `the idempotency marker is STORED AFTER the effect (effect invoked at line ` +
                `${lineAt(idemText, reg.base + effect)}, key stored at line ${lineAt(idemText, reg.base + after)}) ` +
                `rather than claimed before it — a crash or a concurrent retry re-runs the whole effect ` +
                `before the key is ever recorded, so the replay guard never guards the window that matters`,
            );
          } else {
            out.guarded.push(
              `${flow.name} [claim-before]: ${flow.idempotencyFile} — the idempotency key is claimed BEFORE the effect runs`,
            );
          }
        }
      }
    }

    // --- leg C: the mutating connector call must carry an idempotency / request key -------
    const connText = files.get(flow.connectorFile);
    if (connText !== undefined) {
      const sig = objectAfter(connText, flow.mutatingConnectorCall);
      if (sig) {
        if (!flow.idemKeyParam.test(sig.body)) {
          out.violations.push(
            `${flow.name} [connector-idem-key]: ${flow.connectorFile}:${lineAt(connText, sig.open)} — the ` +
              `mutating connector method (createPayment) declares NO idempotency / request-key parameter, so a ` +
              `retried movement reaches the provider as a brand-new payment (a second real debit)`,
          );
        } else {
          out.guarded.push(
            `${flow.name} [connector-idem-key]: ${flow.connectorFile} — the mutating connector method accepts an idempotency / request key`,
          );
        }
      }
    }
    const call = objectAfter(execText, flow.mutatingConnectorCall);
    if (call) {
      if (!flow.idemKeyParam.test(call.body)) {
        out.violations.push(
          `${flow.name} [connector-idem-key]: ${flow.executorFile}:${lineAt(execText, call.open)} — the mutating ` +
            `connector call (createPayment) is invoked with NO idempotency / request key — the same movement, ` +
            `retried, is a duplicate payment at the provider`,
        );
      } else {
        out.guarded.push(
          `${flow.name} [connector-idem-key]: ${flow.executorFile} — the mutating connector call passes an idempotency / request key`,
        );
      }
    }
  }

  // --- the RECOGNITION / ACCRUAL leg (v4 deepen) — smells D/E/F over every money file -----
  const rec = cfg.recognition;
  if (rec) {
    for (const path of rec.files) {
      const text = files.get(path);
      if (text === undefined) continue;
      const region = sliceRegion(text, rec.recognizeFn);
      if (!region) continue;
      const rt = region.text;
      const post = firstIdx(rt, rec.recognitionPost);
      if (post < 0) continue; // a recognize*() that posts nothing is not a recognition site to check
      out.present = true;

      const line = (i: number) => lineAt(text, region.base + i);
      const hasDurable = has(rec.durableClaim, rt);
      const guard = firstIdx(rt, rec.mutableStatusGuard);
      const write = firstIdx(rt, rec.statusWrite);
      const hasLock = has(rec.lockOrCas, rt);
      const label = `recognition/accrual post (${path})`;

      // smell D — the only replay guard is a MUTABLE lifecycle status, not a durable unique claim.
      if (guard >= 0 && !hasDurable) {
        out.violations.push(
          `${label} [recognition-mutable-guard]: ${path}:${line(guard)} — the recognition is guarded only by an ` +
            `equality test on a MUTABLE lifecycle status (and there is NO durable unique accrual-to-source claim), ` +
            `so a later status change (re-open, re-submit, a correction that clears the flag) sends the expense back ` +
            `through recognition and the accrual is posted a SECOND time — double-counted`,
        );
      } else if (guard >= 0 || hasDurable) {
        out.guarded.push(
          `${label} [recognition-mutable-guard]: ${path} — ` +
            (hasDurable
              ? "recognition is gated by a durable unique accrual-to-source claim, not a mutable status flag"
              : "no mutable-status-only guard governs the recognition"),
        );
      }

      // smell E — the recognition/accrual post carries NO unique accrual-to-source key.
      if (!hasDurable) {
        out.violations.push(
          `${label} [unkeyed-recognition]: ${path}:${line(post)} — the accrual/journal post has NO unique ` +
            `accrual-to-source key (no ON CONFLICT, no recognition/accrual claim row, no UNIQUE constraint), so ` +
            `nothing at the storage layer dedups a second recognition of the SAME source — a retry or concurrent ` +
            `approval posts the accrual twice`,
        );
      } else {
        out.guarded.push(
          `${label} [unkeyed-recognition]: ${path} — the recognition post is keyed to the source by a durable unique claim`,
        );
      }

      // smell F — status-read -> recognition post -> status-write with no lock/CAS (a TOCTOU race).
      if (write >= 0 && write > post && !hasLock) {
        out.violations.push(
          `${label} [recognition-no-cas]: ${path}:${line(write)} — the flow reads the status, posts the accrual ` +
            `(line ${line(post)}), then writes the status (line ${line(write)}) with NO row lock or compare-and-swap, ` +
            `so two concurrent recognitions both read the pre-approval status, both post the accrual, and both flip ` +
            `the status — the expense is recognised twice`,
        );
      } else if (write >= 0) {
        out.guarded.push(
          `${label} [recognition-no-cas]: ${path} — the status transition around the recognition post is a lock/CAS, not a read-then-write race`,
        );
      }
    }
  }

  return out;
}

/** Convenience core, matching the other detectors' `<name>Violations(): string[]` shape. */
export function onceViolations(files: Map<string, string>, cfg: OnceConfig): string[] {
  return scanOnce(files, cfg).violations;
}

// --- file plumbing ---------------------------------------------------------------------

function readFile(path: string, cwd?: string): string {
  return readFileSync(cwd ? `${cwd}/${path}` : path, "utf8");
}

// --- the verdict -----------------------------------------------------------------------

/** Run the detector against the live repo. */
export function detect(config: OnceConfig): Verdict {
  const files = new Map<string, string>();
  const needed = new Set<string>();
  for (const f of config.flows) {
    needed.add(f.executorFile);
    needed.add(f.idempotencyFile);
    needed.add(f.connectorFile);
  }
  for (const p of config.recognition?.files ?? []) needed.add(p);
  for (const p of needed) {
    try {
      files.set(p, readFile(p, config.cwd));
    } catch {
      /* absent here; skip. */
    }
  }

  const scan = scanOnce(files, config);

  if (!scan.present) {
    return notApplicable(
      "no money-movement executor was found — the exactly-once invariant does not apply here",
    );
  }
  if (scan.violations.length) {
    return finding(
      `a money movement is not exactly-once under failure/concurrency: ${scan.violations.length} ` +
        `smell(s) across claim-before / one-commit-scope / provider-idempotency — a retry, crash or ` +
        `concurrent request can double-move money or leave a movement half-applied`,
      { violations: scan.violations, guarded: scan.guarded },
    );
  }
  if (scan.guarded.length === 0) {
    return notApplicable(
      "a money-movement executor exists, but its idempotency runner, commit structure and connector " +
        "seam could not be read — nothing to check",
    );
  }
  return checked(
    "the money movement is exactly-once: the idempotency key is claimed before the effect, the ledger " +
      "leg and domain row commit in a single scope, and the external provider call carries an idempotency key",
    { guarded: scan.guarded },
  );
}

export default detect;
