// N-STATE-01 — portable static detector: a money op on a member/card re-reads member & card STATE
// from the LOCKED row inside the atomic op, and rejects a removed/invalid subject before any money
// effect.
//
// INVARIANT: once an app can REMOVE an individual family member (while the account stays open), any
// atomic money op that acts on a member or their card — a scheduled allowance run, a card
// authorization, a settle-back, a hold release — must re-read the member AND card state from the
// LOCKED row inside the op and reject if the member is removed (or the card canceled/frozen/inactive)
// BEFORE moving money. Relying on a pre-lock read or the request payload loses a removal/freeze that
// commits between the check and the money effect: the run debits the owner and credits a removed
// member's pocket (funds stranded — nothing ever recovers them), or an authorization places a live
// hold on a canceled card.
//
// This is a TOCTOU/atomicity sibling of N-CAP-01 (which covers aggregate caps and per-member spend
// LIMITS under the lock); member/card STATE is a distinct invariant, so it is its own detector. Like
// the others it is a SOURCE scanner over the migration SQL, fails CLOSED on a match, and needs no
// adapter — so it fires on a surface a blind behavioural run never drives.
//
// GENERALITY: it keys on the STABLE surfaces the repo conventions mandate — the `harbor_*` atomic
// functions, the `family_members`/`card_authorizations` tables, `for update` row locks, and the
// spec's member-state vocabulary (removed / member_inactive / card_canceled) — not on any single
// function name. Dormant (NOT_APPLICABLE) until the repo has a PER-MEMBER removal op (the race
// precondition): a repo that only tears members down in bulk at account closure is never faulted.

import { readdirSync, readFileSync } from "node:fs";
import { checked, finding, notApplicable, type Verdict } from "../money-system.ts";

export interface StateConfig {
  /** Directory of *.sql migrations that define the atomic ops. Default "supabase/migrations". */
  migrationsDir?: string;
  /** Prefix marking this app's own atomic SQL ops, e.g. "harbor_". Helpers use the doubled prefix. Default "harbor_". */
  sqlFnPrefix?: string;
  /**
   * Applicability gate: evidence a PER-MEMBER removal op exists (a single-member status→removed,
   * which is what makes a concurrent money-op-vs-removal race possible). A bulk teardown at account
   * closure (`where id = any(...)`) does NOT count. Default matches a single-member removal.
   */
  removalMarker?: RegExp;
  /** An op authorizes a member card when its body inserts an authorization row AND references a member. */
  cardAuthMarker?: RegExp;
  /**
   * An op is a recurring/scheduled money-move for a member when its body is period-idempotent.
   * Two equivalent dedup idioms count: an `on conflict (… period …) do nothing` upsert, OR an
   * `if exists (select … from <x>_runs … period …) … return` early-return guard (same semantics,
   * different spelling — a repo that writes the second form must still re-check member state).
   */
  recurringMoveMarker?: RegExp;
  /** Evidence an op references a member (so a member-state recheck is owed). */
  memberRef?: RegExp;
  /** Evidence an op actually moves money / posts a ledger (so the recheck must precede a money effect). */
  moneyEffect?: RegExp;
  /** The member table whose row the op must lock. Default "family_members". */
  memberTable?: string;
  /** Evidence the op rejects a removed/invalid member or card state under the lock. */
  stateReject?: RegExp;
  /** Repo root. Default process.cwd(). */
  cwd?: string;
}

/** The neobank binding — all neobank specifics live here, in config, never in the detector. */
export const NEOBANK: StateConfig = {
  migrationsDir: "supabase/migrations",
  sqlFnPrefix: "harbor_",
  removalMarker:
    /update\s+(?:public\.)?family_members\s+set\s+status\s*=\s*'removed'\s+where\s+id\s*=\s*(?!\s*any\b)/i,
  cardAuthMarker: /insert\s+into\s+(?:public\.)?card_authorizations\b/i,
  recurringMoveMarker:
    /on\s+conflict\s*\([^)]*\bperiod\b[^)]*\)\s*do\s+nothing|if\s+exists\s*\([\s\S]{0,200}?\b\w*_runs\b[\s\S]{0,120}?\bperiod\b[\s\S]{0,40}?\)[\s\S]{0,60}?\breturn\b/i,
  memberRef: /family_member|family_allowance/i,
  moneyEffect: /insert\s+into\s+(?:public\.)?(?:holds|transfers)\b|post_ledger\s*\(/i,
  memberTable: "family_members",
  stateReject:
    /member_inactive|member_state_changed|card_canceled|card_inactive|\.status\s*(?:<>|!=|=|\sin\s|\snot\s+in\s)\s*\(?\s*'(?:active|removed|canceled|frozen|inactive)'/i,
};

// --- pure source-reading primitives (repo-agnostic; mirror the other static detectors) -

const stripSqlComments = (sql: string): string => sql.replace(/--[^\n]*/g, "");
const escapeRe = (s: string): string => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

/** name (lowercased) -> body of every SQL function. A later `create or replace` wins, as applied. */
function sqlFunctions(sql: string): Map<string, string> {
  const out = new Map<string, string>();
  const re =
    /create\s+(?:or\s+replace\s+)?function\s+(?:public\.)?(\w+)\s*\([\s\S]*?\$(\w*)\$([\s\S]*?)\$\2\$/gi;
  for (const m of stripSqlComments(sql).matchAll(re)) out.set(m[1].toLowerCase(), m[3]);
  return out;
}

// --- the member/card-state logic -------------------------------------------------------

export interface StateScan {
  /** "<fn>: <why>" for each in-scope op missing a member/card-state recheck under its lock. */
  violations: string[];
  /** In-scope ops that DO lock + re-check member/card state. */
  guarded: string[];
  /** A per-member removal op exists, so the member-state race is possible (else dormant). */
  applicable: boolean;
}

/**
 * Pure core. Dormant unless a per-member removal op exists. Then every atomic op that either
 * authorizes a member card OR is a recurring money-move for a member MUST take a `for update` lock on
 * the member table AND reject a removed/invalid member or card state; an op that does neither is a
 * violation (the removal/freeze race strands money or holds a canceled card).
 */
export function scanState(sqlText: string, cfg: StateConfig): StateScan {
  const prefix = (cfg.sqlFnPrefix ?? "harbor_").toLowerCase();
  const removalMarker =
    cfg.removalMarker ??
    /update\s+(?:public\.)?family_members\s+set\s+status\s*=\s*'removed'\s+where\s+id\s*=\s*(?!\s*any\b)/i;
  const cardAuthMarker =
    cfg.cardAuthMarker ?? /insert\s+into\s+(?:public\.)?card_authorizations\b/i;
  const recurringMoveMarker =
    cfg.recurringMoveMarker ??
    /on\s+conflict\s*\([^)]*\bperiod\b[^)]*\)\s*do\s+nothing|if\s+exists\s*\([\s\S]{0,200}?\b\w*_runs\b[\s\S]{0,120}?\bperiod\b[\s\S]{0,40}?\)[\s\S]{0,60}?\breturn\b/i;
  const memberRef = cfg.memberRef ?? /family_member|family_allowance/i;
  const moneyEffect =
    cfg.moneyEffect ?? /insert\s+into\s+(?:public\.)?(?:holds|transfers)\b|post_ledger\s*\(/i;
  const memberTable = cfg.memberTable ?? "family_members";
  const stateReject = cfg.stateReject ?? /member_inactive|member_state_changed|card_canceled/i;
  const memberLock = new RegExp(
    `from\\s+(?:public\\.)?${escapeRe(memberTable)}\\b[\\s\\S]{0,240}?for\\s+update`,
    "i",
  );

  const out: StateScan = { violations: [], guarded: [], applicable: false };
  const fns = sqlFunctions(sqlText);
  out.applicable = [...fns.values()].some((b) => removalMarker.test(b));
  if (!out.applicable) return out;

  for (const [name, body] of fns) {
    // Only this app's top-level ops; skip the doubled-prefix helpers.
    if (!name.startsWith(prefix) || name.startsWith(prefix + "_")) continue;
    const authorizesMember = cardAuthMarker.test(body) && memberRef.test(body);
    const recurringMemberMove =
      recurringMoveMarker.test(body) && moneyEffect.test(body) && memberRef.test(body);
    if (!authorizesMember && !recurringMemberMove) continue; // not a member-state money op → skip

    const locked = memberLock.test(body);
    const rejects = stateReject.test(body);
    if (locked && rejects) {
      out.guarded.push(`${name}: locks ${memberTable} and re-checks member/card state`);
    } else {
      const why = !locked
        ? `never locks the ${memberTable} row (no FOR UPDATE) before moving money`
        : `locks ${memberTable} but never rejects a removed/invalid member or card state`;
      out.violations.push(
        `${name} acts on a member's money but ${why} — a run/auth racing a removal or freeze ` +
          `strands funds or holds a canceled card`,
      );
    }
  }
  return out;
}

/** Convenience core, matching the other detectors' `<name>Violations(): string[]` shape. */
export function stateViolations(sqlText: string, cfg: StateConfig): string[] {
  return scanState(sqlText, cfg).violations;
}

function migrationSql(cfg: StateConfig): string {
  const dir = cfg.migrationsDir ?? "supabase/migrations";
  const base = cfg.cwd ? `${cfg.cwd}/${dir}` : dir;
  return readdirSync(base)
    .filter((f) => f.endsWith(".sql"))
    .sort()
    .map((f) => readFileSync(`${base}/${f}`, "utf8"))
    .join("\n");
}

/** Run the detector against the live repo. */
export function detect(config: StateConfig): Verdict {
  let sqlText: string;
  try {
    sqlText = migrationSql(config);
  } catch {
    return notApplicable(
      `migrations dir not found: ${config.migrationsDir ?? "supabase/migrations"}`,
    );
  }
  const scan = scanState(sqlText, config);
  if (!scan.applicable) {
    return notApplicable(
      "no per-member removal op is present — the member-state money-op race cannot arise here",
    );
  }
  if (scan.violations.length) {
    return finding(
      `${scan.violations.length} money op(s) act on a member/card without re-reading its state from the locked row`,
      { violations: scan.violations, guarded: scan.guarded },
    );
  }
  if (scan.guarded.length === 0) {
    return notApplicable(
      "a per-member removal op exists, but no atomic op authorizes a member card or moves a recurring allowance yet — nothing to re-check",
    );
  }
  return checked(
    "every atomic money op on a member/card locks the member row and re-checks member/card state before moving money",
    { guarded: scan.guarded },
  );
}

export default detect;
