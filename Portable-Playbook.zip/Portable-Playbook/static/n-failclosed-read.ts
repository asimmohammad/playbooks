// N-FAILCLOSED-READ — portable static detector: a money READ that computes a variance /
// reconciliation / assurance result FAILS CLOSED.
//
// INVARIANT: a reconciliation / variance / assurance computation is only trustworthy if a FAILED or
// EMPTY read makes it LOUD, not clean. A supabase read returns `{ data, error }`; a missing trip, a
// DB error, or an empty table all come back as `data: null | []`. If the computation destructures
// only `{ data }` and swallows `error`, then an error is indistinguishable from "nothing to reconcile"
// — and the arithmetic then helpfully produces a BENIGN value: `(data ?? []).reduce(...)` → zero
// variance, `feedRows.length === 0 ? 1` → 100% matched, a score of 100, a clean grade. The result LOOKS
// reconciled precisely because the lookup broke. The same hazard hides in an assurance/golden RUN whose
// setup/cleanup writes swallow their `error`: a failed insert or a failed cleanup never fails the run,
// so the harness reports ALL PASS over state it never actually established. Either way a broken or
// unreconciled money state is masked as healthy — the exact PR5/10 error-swallow / recon-status smell.
//
// The property is simply: EVERY supabase money op whose outcome feeds a variance/reconciliation/
// assurance verdict must CAPTURE and SURFACE its `error` (destructure `error` and raise on it, or
// `.throwOnError()`), never destructure `{ data }` alone and treat an empty/failed read as a benign
// zero/clean/pass.
//
// SMELL (any ONE is a FINDING):
//   A. [swallowed-variance-read] inside a variance / reconciliation / assurance region, a supabase
//      `.select()` money read destructures `{ data }` WITHOUT `error` (and has no `.throwOnError()` /
//      no follow-up error check): a DB error or missing row returns empty and the variance / matched-
//      rate / score silently computes a benign value that hides the unreconciled state.
//   B. [swallowed-run-op] inside an assurance / golden / backtest RUN region, a supabase mutating op
//      (insert / update / upsert / delete) whose `error` is neither captured nor checked: a failed
//      setup or cleanup leaves the run reporting a clean pass over state it never actually established.
//
// Like the rest of the family this is a PURE SOURCE scanner (node:fs + regex, fail-closed). Per v4 the
// money surface is DERIVED, not declared: `forSurface(deriveMoneySurface(cwd))` builds the config from
// the repo's own money files (surface.moneyPaths — travel.ts, validation/assurance.ts, recon.ts,
// services …), so a newly-landed reconciliation module is scanned the moment it exists. Only PATHS come
// from the surface; the fail-closed / supabase / error-capture vocabulary stays GENERIC in the config.
// Dormant (NOT_APPLICABLE) until an actual money variance / reconciliation / assurance read site exists.

import { readFileSync } from "node:fs";
import { checked, finding, notApplicable, type Verdict } from "../money-system.ts";
import { deriveMoneySurface, type DerivedSurface } from "../derive.ts";

export interface FailClosedConfig {
  /** Money files to scan (v4: surface.moneyPaths, concrete relative paths). */
  scanPaths: string[];

  // --- generic fail-closed / supabase vocabulary (app-agnostic; stays in the detector/config) ---
  /** A region whose money READ must fail closed: a variance / reconciliation / assurance computation. */
  readContext: RegExp;
  /** A region that RUNS an assurance / golden / backtest set and must fail closed on setup/cleanup. */
  runContext: RegExp;
  /** A supabase table op anchor: `.from("<table>")`. */
  fromCall: RegExp;
  /** A READ terminal in the op chain: `.select(`. */
  readVerb: RegExp;
  /** A mutating terminal in the op chain: `.insert( / .update( / .upsert( / .delete(`. */
  writeVerb: RegExp;
  /** The op's `error` is captured in the destructure (`{ data, error }` / `{ error }` / `error: e`). */
  errorInDestructure: RegExp;
  /** The destructuring assignment head of a supabase statement: `{ … } = await`. */
  destructureHead: RegExp;
  /** A fail-closed chain terminal: `.throwOnError(`. */
  throwOnError: RegExp;
  /** A benign-on-empty default that masks a failed read (corroborating evidence only). */
  benignDefault: RegExp;
  /** Repo root. Default process.cwd(). */
  cwd?: string;
}

/**
 * The generic fail-closed vocabulary. NO paths and NO table names here — only the idioms that say
 * "this is a reconciliation/variance/assurance read" and "this supabase op does / does not surface its
 * error". Paths come from the surface.
 */
export const FAILCLOSED_SMELLS: Omit<FailClosedConfig, "scanPaths" | "cwd"> = {
  // a variance / reconciliation / assurance / matched-rate / drift computation.
  readContext: /\bvariance|reconcil|unreconcil|assurance|matched[_ ]?rate|booked[_ ]?vs|\bdrift\b|\brecon/i,
  // an assurance / golden-set / backtest run harness.
  runContext: /\bassurance|\bgolden|\bbacktest|goldenset|golden[_ ]?set/i,
  // `.from("bank_feed")`, `.from('expenses')`, `.from(`bookings`)`, `.from(t)` (a variable table too).
  fromCall: /\.from\s*\(\s*(?:['"\x60][^'"\x60]+['"\x60]|[A-Za-z_$][\w$]*)\s*\)/,
  readVerb: /\.select\s*\(/,
  writeVerb: /\.(?:insert|update|upsert|delete)\s*\(/,
  // `error` as a captured destructure field: `, error`, `{ error`, `error:` , `error }`.
  errorInDestructure: /\berror\b/,
  // `const { … } = await` (handles multi-line chains; `[^}]` crosses newlines, stops at the first `}`).
  destructureHead: /\{([^}]*)\}\s*=\s*await\b/,
  throwOnError: /\.throwOnError\s*\(/,
  // `?? []` / `?? 0` / `.length === 0 ? 1` / `=== 0 ? 1 :` / `?? 1` — an empty read coalesced to benign.
  benignDefault: /\?\?\s*\[\s*\]|\?\?\s*0\b|\?\?\s*1\b|\.length\s*===?\s*0\s*\?|===?\s*0\s*\?\s*1\b/,
};

// --- pure source-reading primitives (repo-agnostic; mirror the other static detectors) -

/** 1-based line number of the character at `idx`. */
const lineAt = (text: string, idx: number): number => text.slice(0, idx).split("\n").length;

/** `re` as a non-global clone (so a shared /g/ regex's lastIndex can't leak between calls). */
const flat = (re: RegExp): RegExp => new RegExp(re.source, re.flags.replace("g", ""));

/** Does `re` match anywhere in `text`? */
const has = (re: RegExp, text: string): boolean => flat(re).test(text);

/** Every start index of `re` in `text`. */
function allIdx(text: string, re: RegExp): number[] {
  const g = new RegExp(re.source, re.flags.includes("g") ? re.flags : re.flags + "g");
  const out: number[] = [];
  let m: RegExpExecArray | null;
  while ((m = g.exec(text))) {
    out.push(m.index);
    if (m.index === g.lastIndex) g.lastIndex++;
  }
  return out;
}

/**
 * Bounds of the statement containing the op at `opIdx`: back to the nearest preceding `;` (so the
 * whole `const { … } = await …` destructure head is included — a `{ data, error }` destructure's own
 * `}` must NOT end the scan), forward to the next `;` (so a multi-line supabase chain is captured
 * whole). Returns [start, end) indices into `text`.
 */
function statementBounds(text: string, opIdx: number): { start: number; end: number } {
  const prevSemi = text.lastIndexOf(";", opIdx);
  const start = prevSemi >= 0 ? prevSemi + 1 : 0;
  const semi = text.indexOf(";", opIdx);
  const end = semi >= 0 ? semi : Math.min(text.length, opIdx + 400);
  return { start, end };
}

/**
 * Split a source file into function / method regions (header + body to the next header). Mirrors the
 * other v4 detectors so a method's whole body is one region.
 */
export function functionRegions(text: string): Array<{ text: string; base: number }> {
  const headerRe =
    /\n[ \t]*(?:export\s+)?(?:public\s+|private\s+|protected\s+)?(?:static\s+)?(?:async\s+)?(?:function\s+)?[A-Za-z_$][\w$]*\s*\([^)]*\)\s*(?::[^;{]*)?\{/g;
  const starts: number[] = [];
  let m: RegExpExecArray | null;
  while ((m = headerRe.exec(text))) starts.push(m.index);
  if (!starts.length) return [{ text, base: 0 }];
  const out: Array<{ text: string; base: number }> = [];
  for (let i = 0; i < starts.length; i++) {
    const end = i + 1 < starts.length ? starts[i + 1]! : text.length;
    out.push({ text: text.slice(starts[i]!, end), base: starts[i]! });
  }
  return out;
}

// --- the fail-closed logic -------------------------------------------------------------

/**
 * Is the supabase op in statement `stmt` (followed by `lookahead` — the region text after it)
 * FAIL-CLOSED on error? True iff the chain `.throwOnError()`s, OR the destructure captures `error`
 * AND that error alias is actually referenced afterwards (a check / raise, not a dead capture).
 */
function errorIsSurfaced(stmt: string, lookahead: string, cfg: FailClosedConfig): boolean {
  if (cfg.throwOnError.test(stmt)) return true;
  const head = flat(cfg.destructureHead).exec(stmt);
  if (!head) return false; // a bare `await …from(…).delete()` with no `{ … } = await` — error swallowed
  const inner = head[1] ?? "";
  if (!cfg.errorInDestructure.test(inner)) return false; // `{ data }` alone — error swallowed
  // Extract the error alias (`error` or `error: e`) and require it be used afterwards.
  const am = /\berror\b(?:\s*:\s*([A-Za-z_$][\w$]*))?/.exec(inner);
  const alias = am?.[1] ?? "error";
  return new RegExp(`\\b${alias}\\b`).test(lookahead);
}

export interface FailClosedScan {
  /** "<file>:<line> [<leg>] — <why>" for each swallowed-error money op found. */
  violations: string[];
  /** "<file>:<line> [<leg>] — <why>" for each money op found to surface its error. */
  guarded: string[];
  /** At least one variance/reconciliation/assurance read (or assurance-run) op site was found. */
  present: boolean;
}

/**
 * Pure core. For every money file, walk each function region. A region that reads money for a variance/
 * reconciliation/assurance verdict (readContext) must surface the `error` of each `.select()` in it; a
 * region that runs an assurance/golden set (runContext) must surface the `error` of each mutating op in
 * it. A swallowed op is a violation; a surfaced one is guarded. `present` is true once any such op site
 * is seen, so an app with no reconciliation/assurance read is dormant (NOT_APPLICABLE).
 */
export function scanFailClosed(files: Array<{ path: string; text: string }>, cfg: FailClosedConfig): FailClosedScan {
  const out: FailClosedScan = { violations: [], guarded: [], present: false };

  for (const { path, text } of files) {
    for (const region of functionRegions(text)) {
      const rt = region.text;
      const readCtx = has(cfg.readContext, rt);
      const runCtx = has(cfg.runContext, rt);
      if (!readCtx && !runCtx) continue;

      for (const opIdx of allIdx(rt, cfg.fromCall)) {
        const { start, end } = statementBounds(rt, opIdx);
        const stmt = rt.slice(start, end);
        const isRead = cfg.readVerb.test(stmt);
        const isWrite = !isRead && cfg.writeVerb.test(stmt);
        // reads matter in a variance/recon/assurance region; writes matter in an assurance/golden run.
        const leg = isRead && readCtx ? "swallowed-variance-read" : isWrite && runCtx ? "swallowed-run-op" : null;
        if (!leg) continue;

        out.present = true;
        const lookahead = rt.slice(end, end + 320);
        const cite = `${path}:${lineAt(text, region.base + opIdx)}`;
        if (errorIsSurfaced(stmt, lookahead, cfg)) {
          out.guarded.push(
            `${cite} [${leg}] — the supabase money op captures and raises on its \`error\` (fails closed)`,
          );
          continue;
        }
        const benign = has(cfg.benignDefault, rt);
        if (leg === "swallowed-variance-read") {
          out.violations.push(
            `${cite} [swallowed-variance-read] — a money read in a variance/reconciliation/assurance ` +
              `computation destructures \`{ data }\` and SWALLOWS \`error\`: a DB error or missing row ` +
              `returns empty and the result${benign ? " is then coalesced to a benign default (`?? []`/`" +
                "`=== 0 ? 1`) and" : ""} silently computes a zero variance / 100% matched / clean score — ` +
              `an unreconciled or broken state is masked as healthy [smell A]`,
          );
        } else {
          out.violations.push(
            `${cite} [swallowed-run-op] — an assurance/golden RUN performs a supabase mutating op whose ` +
              `\`error\` is neither captured nor checked: a failed setup or cleanup never fails the run, so ` +
              `the harness reports a clean pass over state it never actually established [smell B]`,
          );
        }
      }
    }
  }

  return out;
}

/** Convenience core, matching the other detectors' `<name>Violations(): string[]` shape. */
export function failClosedViolations(files: Array<{ path: string; text: string }>, cfg: FailClosedConfig): string[] {
  return scanFailClosed(files, cfg).violations;
}

// --- file plumbing ---------------------------------------------------------------------

function readFile(path: string, cwd?: string): string {
  return readFileSync(cwd ? `${cwd}/${path}` : path, "utf8");
}

// --- the v4 surface binding ------------------------------------------------------------

/**
 * Build the detector config from a DERIVED money surface. Only the PATHS come from the surface
 * (surface.moneyPaths — the repo's own money files, recomputed every run); the fail-closed vocabulary
 * is the fixed `FAILCLOSED_SMELLS`. v4 contract: `detect(forSurface(deriveMoneySurface(cwd)))`.
 */
export function forSurface(surface: Pick<DerivedSurface, "moneyPaths" | "cwd">): FailClosedConfig {
  return { ...FAILCLOSED_SMELLS, scanPaths: surface.moneyPaths, cwd: surface.cwd };
}

// --- the verdict -----------------------------------------------------------------------

/** Run the detector against the live repo. */
export function detect(config: FailClosedConfig): Verdict {
  const files: Array<{ path: string; text: string }> = [];
  for (const p of config.scanPaths) {
    if (/[*?]/.test(p)) continue; // a glob (hand-declared surface); v4 derivation yields concrete files
    try {
      files.push({ path: p, text: readFile(p, config.cwd) });
    } catch {
      /* absent here (another repo, an empty fixture); skip it. */
    }
  }

  const scan = scanFailClosed(files, config);

  if (!scan.present) {
    return notApplicable(
      "no money variance / reconciliation / assurance read site was found in the derived money files — " +
        "there is no fail-closed read boundary here to check (the invariant is dormant)",
    );
  }
  if (scan.violations.length) {
    return finding(
      `a money read that computes a variance / reconciliation / assurance result does NOT fail closed: ` +
        `${scan.violations.length} swallowed-error op(s) — a DB error, a missing row, an empty result, or a ` +
        `failed setup/cleanup is masked as a zero variance / 100% matched / clean pass, hiding an unreconciled ` +
        `or broken money state`,
      { violations: scan.violations, guarded: scan.guarded },
    );
  }
  return checked(
    "every money read that feeds a variance / reconciliation / assurance verdict captures and surfaces its " +
      "error (and every assurance-run setup/cleanup op does too) — a failed or empty read is raised, never " +
      "silently turned into a benign zero / 100% matched / clean pass",
    { guarded: scan.guarded },
  );
}

/** v4 convenience: derive the surface from `cwd` and run. */
export function detectRepo(cwd: string): Verdict {
  const surface = deriveMoneySurface(cwd);
  return detect(forSurface({ ...surface, cwd }));
}

export default detect;
