// N-ACCOUNT-VALID — portable static detector: an account CODE that money is posted to is validated by
// EXISTENCE in the organization's chart of accounts (a lookup), never merely by its SHAPE (a regex).
//
// INVARIANT: every journal / ledger line names an account code, and that code is the address money is
// posted to. Balance and trial-balance reports are built by JOINING posted lines against the SEEDED
// chart of accounts (the org's `ledger_accounts` / STANDARD_ACCOUNTS). So a line posted to a code that
// does NOT exist in the chart is money sent to an address that no report reads back: the debit/credit
// is real in the journal but vanishes from every balance that joins the chart — the books silently
// stop tying out. Therefore an account code must be validated by LOOKING IT UP in the chart (and
// checking its type/currency are right for this posting) BEFORE money is posted to it. Validating the
// code by its SHAPE — a regex like `/^6\d{3}$/` that merely asserts "four digits starting with 6" —
// is not validation: `6999` passes the regex, is never a seeded account, and the accrual posted to it
// disappears from the expense balance. Shape is a type, not an existence proof; only a chart lookup is.
//
// SMELL (an account-coded posting with no chart-existence lookup is a FINDING):
//   A. [shape-not-chart] the account code is validated by a REGEX on its SHAPE (`/^6\d{3}$/`, `/^\d{4}$/`,
//      a digit-count pattern) and the posting file has NO lookup against the chart (no STANDARD_ACCOUNTS
//      lookup, no getAccount(), no read of a `ledger_accounts`/`accounts` row): a well-shaped but
//      unseeded code is accepted and money is posted to an account that balance reports never read; OR
//   B. [no-existence-check] a journal/ledger line is posted to an account code read from a record/input
//      with NO existence check AT ALL (neither shape nor chart) — the code is trusted blindly.
//
// GUARD (CHECKED): the account code is looked up in the chart — STANDARD_ACCOUNTS / getAccount() / a
// `ledger_accounts` row read — (and its type/currency checked) before the line is posted.
//
// Like the rest of the family this is a PURE SOURCE scanner (node:fs + regex, fail-closed). Per v4 the
// money surface is DERIVED, not declared: `forSurface(deriveMoneySurface(cwd))` builds the config from
// the repo's own money files plus its chart-of-accounts file, so a newly-landed accounting module
// (gaap.ts, ledger, accounts.ts …) is scanned the moment it exists. Only PATHS come from the surface;
// the account-code / posting / shape-regex / chart-lookup vocabulary lives here in the config. Dormant
// (NOT_APPLICABLE) until an actual account-coded journal/ledger posting site is present.

import { readFileSync } from "node:fs";
import { checked, finding, notApplicable, type Verdict } from "../money-system.ts";
import { deriveMoneySurface, type DerivedSurface } from "../derive.ts";
import { type MoneySurface } from "../adapters/pmar.ts";

export interface AccountValidConfig {
  /** Money files to scan, plus the chart-of-accounts file (v4: derived; concrete relative paths). */
  scanPaths: string[];

  // --- generic account-posting vocabulary (app-agnostic; stays in the detector/config) ----
  /** A journal / ledger / accrual posting idiom, e.g. `.postEntry(`, `accrualLines(`, `journalEntry(`. */
  accountPostIdiom: RegExp;
  /** A reference to an account-CODE field on a record/line, e.g. `gl_account`, `accountId`, `account_code`. */
  accountCodeField: RegExp;
  /** A SHAPE regex literal used as account-code validation, e.g. `/^6\d{3}$/`, `/^\d{4}$/`. */
  shapeRegex: RegExp;
  /** A chart-of-accounts EXISTENCE lookup: STANDARD_ACCOUNTS / getAccount() / a `ledger_accounts` row read. */
  chartLookup: RegExp;
  /** Repo root. Default process.cwd(). */
  cwd?: string;
}

/**
 * The generic account-validity vocabulary. NO paths and NO app table names here — only the idioms that
 * say "this posts to an account code / validates one by shape / looks one up in the chart". Paths come
 * from the derived surface.
 */
export const ACCOUNT_VALID_SMELLS: Omit<AccountValidConfig, "scanPaths" | "cwd"> = {
  // the account-coded posting: a ledger post / accrual / journal-entry builder, or an insert into the
  // journal-line table. These are where a code becomes the address money lands on.
  accountPostIdiom:
    /\.postEntry\s*\(|\bpostEntry\s*\(|\baccrualLines\s*\(|\bjournalEntr[A-Za-z]*\s*\(|\bpostJournal\s*\(|\binsertJournal\s*\(|\bledgerLines?\s*\(|\bjournal_entry_lines\b/i,
  // an account-code field carried on a record/line: gl_account / glAccount / accountId / account_code /
  // accountCode / ledger_account. (NOT a bare `account` — too broad.)
  accountCodeField:
    /\bgl_account\b|\bglAccount\b|\baccountId\b|\baccount_code\b|\baccountCode\b|\bledger_account\b|\baccount_id\b/i,
  // a regex literal asserting the SHAPE of a code: `/^6\d{3}$/`, `/^\d{4}$/`, `/^\d{3,4}$/`.
  shapeRegex: /\/\^?\d*\\d\{\d+(?:,\s*\d*)?\}\$?\//,
  // a chart-of-accounts EXISTENCE lookup. STANDARD_ACCOUNTS (the seeded chart array), getAccount() /
  // findAccount() / lookupAccount() / accountExists(), or a read of a `ledger_accounts`/`accounts` row.
  chartLookup:
    /\bSTANDARD_ACCOUNTS\b|\b(?:get|find|lookup|resolve)Account\s*\(|\baccountExists\s*\(|\bchartOfAccounts\b|\.from\s*\(\s*['"`](?:ledger_)?accounts['"`]|Object\.(?:values|keys|entries)\s*\(\s*ACCOUNTS\b/i,
};

// --- pure source-reading primitives (repo-agnostic; mirror the other static detectors) -

/** 1-based line number of the character at `idx`. */
const lineAt = (text: string, idx: number): number => text.slice(0, idx).split("\n").length;

/** `re` as a non-global clone (so a shared /g/ regex's lastIndex can't leak between calls). */
const flat = (re: RegExp): RegExp => new RegExp(re.source, re.flags.replace("g", ""));

/** Does `re` match anywhere in `text`? */
const has = (re: RegExp, text: string): boolean => flat(re).test(text);

/** Index of `re`'s first match in `text`, or -1. */
function firstIdx(text: string, re: RegExp): number {
  const m = flat(re).exec(text);
  return m ? m.index : -1;
}

// --- the account-validity logic --------------------------------------------------------

export interface AccountValidScan {
  /** "<file>:<line> [<leg>] — <why>" for each account-validity smell found. */
  violations: string[];
  /** "<file>:<line> — <why>" for each account-coded posting found to be chart-validated. */
  guarded: string[];
  /** At least one account-coded posting site was found (else the invariant is dormant). */
  present: boolean;
}

/**
 * Pure core. For each file that posts to an account code (an account-posting idiom AND an account-code
 * field), decide whether the code is validated by a chart-existence lookup. A posting with a chart
 * lookup is guarded; a posting with only a SHAPE regex (smell A) or with no check at all (smell B) is a
 * violation. `present` becomes true as soon as ANY account-coded posting site is seen, so an app that
 * posts no account codes is dormant (NOT_APPLICABLE). Analysis is per-file: the lookup must live in the
 * same file that posts, which is where account-code validation belongs.
 */
export function scanAccountValid(files: Array<{ path: string; text: string }>, cfg: AccountValidConfig): AccountValidScan {
  const out: AccountValidScan = { violations: [], guarded: [], present: false };

  for (const { path, text } of files) {
    const postIdx = firstIdx(text, cfg.accountPostIdiom);
    const hasCodeField = has(cfg.accountCodeField, text);
    // an account-coded posting needs BOTH a posting idiom and an account-code field; the chart file
    // (which only lists codes, never posts) and a money file that moves amounts but posts no coded
    // journal line both fall out here → dormant.
    if (postIdx < 0 || !hasCodeField) continue;
    out.present = true;

    const postLine = lineAt(text, postIdx);
    const hasChart = has(cfg.chartLookup, text);
    if (hasChart) {
      out.guarded.push(
        `${path}:${postLine} — the account code is validated by a chart-of-accounts existence lookup ` +
          `(STANDARD_ACCOUNTS / getAccount / a ledger_accounts row) before the line is posted`,
      );
      continue;
    }

    const shapeIdx = firstIdx(text, cfg.shapeRegex);
    if (shapeIdx >= 0) {
      out.violations.push(
        `${path}:${lineAt(text, shapeIdx)} [shape-not-chart] — the account code is validated only by a ` +
          `regex on its SHAPE (a digit-count pattern) and ${path} has NO chart-of-accounts existence ` +
          `lookup: a well-shaped but UNSEEDED code (e.g. 6999) passes the regex, money is posted to it ` +
          `at line ${postLine}, and the debit/credit then vanishes from every balance that joins the ` +
          `seeded chart — the books silently stop tying out [smell A]`,
      );
    } else {
      out.violations.push(
        `${path}:${postLine} [no-existence-check] — a journal/ledger line is posted to an account code ` +
          `with NO existence check at all (neither a shape regex nor a chart lookup) in ${path}: the code ` +
          `is trusted blindly, so a posting to an account that is not seeded in the chart disappears from ` +
          `balance reports [smell B]`,
      );
    }
  }

  return out;
}

/** Convenience core, matching the other detectors' `<name>Violations(): string[]` shape. */
export function accountValidViolations(files: Array<{ path: string; text: string }>, cfg: AccountValidConfig): string[] {
  return scanAccountValid(files, cfg).violations;
}

// --- file plumbing ---------------------------------------------------------------------

function readFile(path: string, cwd?: string): string {
  return readFileSync(cwd ? `${cwd}/${path}` : path, "utf8");
}

// --- the v4 surface binding ------------------------------------------------------------

/**
 * Build the detector config from a DERIVED money surface. Only the PATHS come from the surface —
 * `surface.moneyPaths` (the repo's own money files: gaap.ts, the ledger, …) PLUS
 * `surface.chartOfAccounts` (so the chart file is in scope should a posting ever live there) — and the
 * account-validity vocabulary is the fixed `ACCOUNT_VALID_SMELLS`. This is the v4 contract:
 * `detect(forSurface(deriveMoneySurface(cwd)))`.
 */
export function forSurface(surface: Pick<DerivedSurface | MoneySurface, "moneyPaths" | "chartOfAccounts" | "cwd">): AccountValidConfig {
  const scanPaths = Array.from(new Set([...surface.moneyPaths, surface.chartOfAccounts].filter(Boolean)));
  return { ...ACCOUNT_VALID_SMELLS, scanPaths, cwd: surface.cwd };
}

// --- the verdict -----------------------------------------------------------------------

/** Run the detector against the live repo. */
export function detect(config: AccountValidConfig): Verdict {
  const files: Array<{ path: string; text: string }> = [];
  for (const p of config.scanPaths) {
    if (/[*?]/.test(p)) continue; // a glob (hand-declared surface); v4 derivation yields concrete files
    try {
      files.push({ path: p, text: readFile(p, config.cwd) });
    } catch {
      /* absent here (another repo, an empty fixture); skip it. */
    }
  }

  const scan = scanAccountValid(files, config);

  if (!scan.present) {
    return notApplicable(
      "no account-coded journal/ledger posting site was found in the derived money files — there is no " +
        "account-validity boundary here to check (the invariant is dormant)",
    );
  }
  if (scan.violations.length) {
    return finding(
      `an account code money is posted to is validated by shape (or not at all), not by existence in the ` +
        `chart of accounts: ${scan.violations.length} posting site(s) accept a well-shaped but unseeded ` +
        `code, so the debit/credit posted to it vanishes from balance reports and the books stop tying out`,
      { violations: scan.violations, guarded: scan.guarded },
    );
  }
  return checked(
    "every account-coded posting validates the account code by looking it up in the chart of accounts " +
      "(STANDARD_ACCOUNTS / getAccount / a ledger_accounts row) before money is posted to it — a posting " +
      "can only name a real, seeded account",
    { guarded: scan.guarded },
  );
}

/** v4 convenience: derive the surface from `cwd` and run. */
export function detectRepo(cwd: string): Verdict {
  const surface = deriveMoneySurface(cwd);
  return detect(forSurface({ ...surface, cwd }));
}

export default detect;
