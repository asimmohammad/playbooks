// N-CAP-01 — portable static detector: aggregate-cap guards are enforced INSIDE the atomic op.
//
// INVARIANT: every aggregate cap a money app declares — a per-owner / per-scope limit on a COUNT
// or SUM of rows (e.g. "at most N family members", "at most N active cards") — must be re-checked
// INSIDE the atomic SQL function that commits a new unit of that aggregate: the aggregate is read
// under a row / advisory lock, and the cap is enforced, before the insert. A cap enforced ONLY in
// an app-layer pre-check (the service reads the count, compares it to the policy, then calls the
// atomic op) is bypassed under concurrency: two requests each pass the stale pre-check and each
// commit inside its own transaction, so the owner overshoots the cap (a TOCTOU aggregate bypass).
//
// This is the STRUCTURAL leg of the N-ATOMIC family (see FAMILIES.md §1). The behavioural N-ATOMIC
// rule competes two debits against ONE shared balance; it cannot reach a COUNT cap on issuance. The
// sealed N-ATOMIC detector only checks that a CLOSED, hard-coded set of balance/limit aggregates and
// guard codes sit under a lock — so a cap that is ENTIRELY ABSENT from the SQL op is invisible to it
// (you cannot catch a missing check by scanning for a misplaced one). N-PARITY-01 only checks the two
// stores AGREE, so a cap missing from BOTH passes. N-CAP-01 closes that gap from the other side: for
// each declared cap it finds every atomic op that commits the capped aggregate and FAILS when that op
// does not re-read and re-cap it under a lock.
//
// EXTENSION — per-member spend LIMITS under the lock. The same TOCTOU danger applies to a per-row
// limit THRESHOLD, not just a count/sum: when an atomic op enforces a per-member spending limit at
// authorization, the limit VALUES (daily / monthly / per-transaction cents) must be read from the
// LOCKED member row INSIDE the op — never trusted from the request payload. A request that carries
// its own `member_limit` and is believed lets a caller raise their own cap; and a limit-update path
// that recomputes the per-transaction cap from the daily/monthly figures, without reading the stored
// value, silently loosens a tighter control the owner already set. `lockedLimits` (SQL) and
// `preservedLimits` (app) below catch exactly these, alongside the aggregate-cap scan.
//
// This is a SOURCE scanner over pure text: the app/domain sources (where the pre-check is declared)
// and the migration SQL (the atomic ops). It is parameterised so nothing app-specific — table names,
// scope columns, the policy key that names the cap, the SQL-fn prefix, file paths — is baked into the
// detector; only into the config.

import { readdirSync, readFileSync } from "node:fs";
import { checked, finding, notApplicable, type Verdict } from "../money-system.ts";

/** One declared aggregate cap the app enforces, and how to recognise it in app code and in SQL. */
export interface AggregateCap {
  /** Human label for the invariant, e.g. "family-member cap". Used in verdict output only. */
  name: string;
  /** The table an atomic op inserts a new unit of the capped aggregate into, e.g. "family_members". */
  cappedTable: string;
  /** The column the cap is keyed by (the per-owner / per-scope grouping), e.g. "owner_user_id". */
  scopeColumn: string;
  /**
   * Proof the app DECLARES & enforces this cap in its pre-check layer (any `appSources` file). When
   * this matches nowhere the cap is dormant and the entry is skipped — the detector never invents a
   * cap the app does not have. e.g. /\bmaxMembers\b/.
   */
  appCheck: RegExp;
  /**
   * What the under-lock re-check looks like INSIDE the atomic SQL function body. Optional: by default
   * the detector requires a COUNT/SUM aggregate selected `from <cappedTable>` with `<scopeColumn>`
   * mentioned in the body (a scoped aggregate read). Override to match a cap enforced some other way
   * (e.g. a specific raised guard code).
   */
  sqlRecheck?: RegExp;
  /** Atomic ops (prefix-stripped or full name) that legitimately skip this cap (e.g. an admin path). */
  exemptFns?: string[];
}

/**
 * A per-member spend LIMIT enforced inside an atomic SQL op at authorization. Its threshold columns
 * must be read from the LOCKED subject row, not trusted from the request payload. Dormant unless the
 * op actually references the limit (so an op without this feature is never faulted for it).
 */
export interface LockedLimit {
  /** Human label, e.g. "member card-spend limit". Verdict output only. */
  name: string;
  /** The atomic SQL op that enforces the limit (prefix-stripped or full name), e.g. "card_authorize". */
  fn: string;
  /** The subject table whose LOCKED row holds the authoritative limit, e.g. "family_members". */
  subjectTable: string;
  /** The authoritative limit columns that MUST be read from the locked row, e.g. ["daily_cents","monthly_cents"]. */
  limitColumns: string[];
  /**
   * Applicability: the per-member spend-limit FEATURE is present in this op. Keyed on the spec's
   * STABLE decline vocabulary / payload token so it fires on an independent rebuild and stays dormant
   * on an op that only checks an owner-tier limit. e.g. /member_limit|member_daily_limit|member_monthly_limit/.
   */
  appliesWhen: RegExp;
  /** Evidence the op pulls the limit from the REQUEST PAYLOAD (enriches the verdict), e.g. /member_limit/. */
  payloadToken?: RegExp;
}

/**
 * A stored limit field that an app-layer limit-UPDATE must preserve (read back), not silently derive
 * away. e.g. recomputing the per-transaction cap as min(daily, monthly) drops a tighter stored cap.
 * Dormant unless the update method exists and (re)assigns the field.
 */
export interface PreservedLimit {
  /** Human label, e.g. "per-transaction cap". Verdict output only. */
  name: string;
  /**
   * The DERIVED field-assignment pattern, with capture group 1 = the derivation expression that must
   * read the stored value. Method-agnostic (keyed on the stable field + derivation shape, not a method
   * name), e.g. /perTxnCents\s*:\s*Math\.min\s*\(([^)]*)\)/. Dormant when it matches nowhere.
   */
  derivePattern: RegExp;
  /** The stored value the derivation must reference, e.g. /per_txn_cents/. */
  mustReference: RegExp;
}

export interface CapLockConfig {
  /** App/domain/service source files where the cap pre-checks are declared (`appCheck` is tested here). */
  appSources: string[];
  /** Directory of *.sql migrations that define the atomic ops. Default "supabase/migrations". */
  migrationsDir?: string;
  /** Prefix marking this app's own atomic SQL ops, e.g. "harbor_". Default "harbor_". */
  sqlFnPrefix?: string;
  /** The declared aggregate caps to enforce inside the atomic ops. */
  caps: AggregateCap[];
  /** Per-member spend limits whose values must be read from the locked row inside the atomic op. */
  lockedLimits?: LockedLimit[];
  /** Stored limit fields an app-layer limit-update must preserve, not silently derive away. */
  preservedLimits?: PreservedLimit[];
  /** Repo root. Default process.cwd(). */
  cwd?: string;
}

/** The neobank binding — all neobank specifics live here, in config, never in the detector. */
export const NEOBANK: CapLockConfig = {
  appSources: [
    "supabase/functions/_shared/app/service.ts",
    "supabase/functions/_shared/domain/family.ts",
    "supabase/functions/_shared/domain/config.ts",
  ],
  migrationsDir: "supabase/migrations",
  sqlFnPrefix: "harbor_",
  caps: [
    {
      name: "family-member cap",
      cappedTable: "family_members",
      scopeColumn: "owner_user_id",
      appCheck: /\bmaxMembers\b/,
    },
  ],
  lockedLimits: [
    {
      name: "member card-spend limit",
      fn: "card_authorize",
      subjectTable: "family_members",
      limitColumns: ["daily_cents", "monthly_cents"],
      appliesWhen: /member_limit|member_daily_limit|member_monthly_limit/,
      payloadToken: /member_limit/,
    },
  ],
  preservedLimits: [
    {
      name: "per-transaction cap",
      derivePattern: /perTxnCents\s*:\s*Math\.min\s*\(([^)]*)\)/,
      mustReference: /per_txn_cents/,
    },
  ],
};

// --- pure source-reading primitives (repo-agnostic; mirror static/n-parity-01.ts) ------

const stripSqlComments = (sql: string): string => sql.replace(/--[^\n]*/g, "");

/** name (lowercased) -> body of every SQL function. A later `create or replace` wins, as applied. */
function sqlFunctions(sql: string): Map<string, string> {
  const out = new Map<string, string>();
  const re =
    /create\s+(?:or\s+replace\s+)?function\s+(?:public\.)?(\w+)\s*\([\s\S]*?\$(\w*)\$([\s\S]*?)\$\2\$/gi;
  for (const m of stripSqlComments(sql).matchAll(re)) out.set(m[1].toLowerCase(), m[3]);
  return out;
}

const escapeRe = (s: string): string => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

/** A row/advisory lock token: `... for update` or `pg_advisory[_xact]_lock(`. */
const LOCK = /\bfor\s+update\b|\bpg_advisory(?:_xact)?_lock\s*\(/i;

// --- the cap-under-lock logic ----------------------------------------------------------

/** Default under-lock re-check: a COUNT/SUM aggregate selected from the capped table. */
function defaultRecheck(cap: AggregateCap): RegExp {
  return new RegExp(
    `(?:count|sum)\\s*\\([^)]*\\)[\\s\\S]{0,80}?\\bfrom\\s+(?:public\\.)?${escapeRe(cap.cappedTable)}\\b`,
    "i",
  );
}

/** Atomic ops (prefixed SQL fns) whose body inserts a new unit of the capped aggregate. */
function committingOps(fns: Map<string, string>, cap: AggregateCap, prefix: string): string[] {
  const p = prefix.toLowerCase();
  const insertRe = new RegExp(
    `insert\\s+into\\s+(?:public\\.)?${escapeRe(cap.cappedTable)}\\b`,
    "i",
  );
  const exempt = new Set((cap.exemptFns ?? []).map((f) => f.toLowerCase().replace(p, "")));
  return [...fns]
    .filter(([name, body]) => name.startsWith(p) && insertRe.test(body))
    .filter(([name]) => !exempt.has(name.replace(p, "")))
    .map(([name]) => name);
}

export interface CapScan {
  /** Capped-insert ops that are missing the under-lock re-check (each one is a violation). */
  violations: string[];
  /** "<fn>: <cap>" for each atomic op that DOES re-read and re-cap the aggregate under a lock. */
  guarded: string[];
  /** Cap names the app does not declare anywhere in `appSources` (dormant — skipped). */
  dormant: string[];
}

/**
 * Pure core: given the concatenated app sources and the concatenated migration SQL, classify every
 * declared cap. A cap not present in the app is dormant. For a declared cap, every atomic op that
 * inserts a new unit of the capped aggregate MUST re-read it (aggregate over the capped table) under
 * a lock taken first; an op that inserts but never re-reads — or reads the aggregate before any lock
 * — is a violation.
 */
export function scanCaps(appText: string, sqlText: string, cfg: CapLockConfig): CapScan {
  const prefix = cfg.sqlFnPrefix ?? "harbor_";
  const fns = sqlFunctions(sqlText);
  const scan: CapScan = { violations: [], guarded: [], dormant: [] };

  for (const cap of cfg.caps) {
    if (!cap.appCheck.test(appText)) {
      scan.dormant.push(cap.name);
      continue;
    }
    const recheck = cap.sqlRecheck ?? defaultRecheck(cap);
    const scopeRe = new RegExp(`\\b${escapeRe(cap.scopeColumn)}\\b`);
    for (const fn of committingOps(fns, cap, prefix)) {
      const body = fns.get(fn) ?? "";
      const agg = recheck.exec(body);
      const scoped = cap.sqlRecheck ? true : scopeRe.test(body);
      if (!agg || !scoped) {
        scan.violations.push(
          `${cap.name}: ${fn} inserts into ${cap.cappedTable} but never re-checks the cap ` +
            `under its lock — enforced only in an app-layer pre-check (concurrent bypass)`,
        );
        continue;
      }
      const lock = LOCK.exec(body);
      if (!lock || lock.index > agg.index) {
        scan.violations.push(
          `${cap.name}: ${fn} reads the ${cap.cappedTable} cap aggregate before taking a lock (TOCTOU)`,
        );
        continue;
      }
      scan.guarded.push(`${fn}: ${cap.name}`);
    }
  }
  return scan;
}

/** Convenience core, matching the other static detectors' `<name>Violations(): string[]` shape. */
export function capViolations(appText: string, sqlText: string, cfg: CapLockConfig): string[] {
  return scanCaps(appText, sqlText, cfg).violations;
}

// --- per-member spend-LIMIT-under-lock logic (the extension) ---------------------------

export interface LockedLimitScan {
  violations: string[];
  guarded: string[];
  /** A configured limit feature is actually present in the SQL (else the leg is dormant). */
  applicable: boolean;
}

/**
 * Pure core: for each configured per-member limit, if the atomic op enforces it, every limit column
 * MUST be read as a real column from the LOCKED subject row (a bareword read, under a FOR UPDATE on
 * that table) — not pulled from a jsonb payload. A column that only ever appears as a payload key
 * (e.g. `member_limit->>'daily_cents'`) is a violation: the caller supplied their own cap.
 */
export function scanLockedLimits(sqlText: string, cfg: CapLockConfig): LockedLimitScan {
  const out: LockedLimitScan = { violations: [], guarded: [], applicable: false };
  const prefix = (cfg.sqlFnPrefix ?? "harbor_").toLowerCase();
  const fns = sqlFunctions(sqlText);
  for (const lim of cfg.lockedLimits ?? []) {
    const key = lim.fn.toLowerCase().replace(prefix, "");
    const body = fns.get(prefix + key) ?? fns.get(key);
    if (body === undefined) continue; // op not defined here → dormant
    // The PER-MEMBER limit feature is present only when the op's body matches `appliesWhen` (the
    // spec's stable member-limit vocabulary) — NOT merely because a limit column name appears as
    // some other payload's jsonb key (e.g. the owner-tier p_limit, which is policy-derived).
    if (!lim.appliesWhen.test(body)) continue; // op does not enforce this per-member limit → dormant
    out.applicable = true;
    // A real column read of `c` from the locked row — a bareword, never a jsonb key ('...c...').
    const barewordRead = (c: string) => new RegExp(`(?<!['\\w])${escapeRe(c)}\\b`).test(body);
    const fromPayload = lim.payloadToken ? lim.payloadToken.test(body) : false;
    const lock = new RegExp(
      `from\\s+(?:public\\.)?${escapeRe(lim.subjectTable)}\\b[\\s\\S]{0,240}?for\\s+update`,
      "i",
    );
    const locked = lock.test(body);
    const notLockedRead = lim.limitColumns.filter((c) => !(barewordRead(c) && locked));
    if (notLockedRead.length) {
      out.violations.push(
        `${lim.name}: ${lim.fn} compares the limit (${notLockedRead.join(", ")}) ` +
          `${fromPayload ? "taken from the request payload" : "not read from the locked row"} ` +
          `instead of from the locked ${lim.subjectTable} row under its lock — a caller can raise their own cap`,
      );
    } else {
      out.guarded.push(`${lim.fn}: ${lim.name} (read from the locked ${lim.subjectTable} row)`);
    }
  }
  return out;
}

export interface PreservedLimitScan {
  violations: string[];
  guarded: string[];
  /** A configured limit-update method is present and (re)assigns the field (else the leg is dormant). */
  applicable: boolean;
}

/**
 * Pure core: an app-layer limit-UPDATE that DERIVES a stored limit field MUST read the stored value
 * back, not derive the field purely from the other limits. Recomputing the per-transaction cap as
 * min(daily, monthly) without reading the stored per-transaction value silently loosens it. Keyed on
 * the derivation shape + stable column, so it is method-name-agnostic.
 */
export function scanPreservedLimits(appText: string, cfg: CapLockConfig): PreservedLimitScan {
  const out: PreservedLimitScan = { violations: [], guarded: [], applicable: false };
  for (const p of cfg.preservedLimits ?? []) {
    const re = new RegExp(p.derivePattern.source, p.derivePattern.flags.replace("g", "") + "g");
    for (const m of appText.matchAll(re)) {
      out.applicable = true;
      const derivation = m[1] ?? m[0];
      if (p.mustReference.test(derivation)) {
        out.guarded.push(`${p.name}: derived with the stored value read back`);
      } else {
        out.violations.push(
          `${p.name}: recomputed from the other limits without reading the stored value ` +
            `(${m[0].trim()}) — a tighter ${p.name} the owner already set is silently dropped`,
        );
      }
    }
  }
  return out;
}

function readFile(path: string, cwd?: string): string {
  return readFileSync(cwd ? `${cwd}/${path}` : path, "utf8");
}

/** Concatenate whatever `appSources` exist; a missing file is skipped (another repo may lack it). */
function appSourcesText(cfg: CapLockConfig): string {
  const parts: string[] = [];
  for (const f of cfg.appSources) {
    try {
      parts.push(readFile(f, cfg.cwd));
    } catch {
      // a source this binding names is absent here; skip it.
    }
  }
  return parts.join("\n");
}

function migrationSql(cfg: CapLockConfig): string {
  const dir = cfg.migrationsDir ?? "supabase/migrations";
  const base = cfg.cwd ? `${cfg.cwd}/${dir}` : dir;
  return readdirSync(base)
    .filter((f) => f.endsWith(".sql"))
    .sort()
    .map((f) => readFileSync(`${base}/${f}`, "utf8"))
    .join("\n");
}

/** Run the detector against the live repo. */
export function detect(config: CapLockConfig): Verdict {
  const appText = appSourcesText(config);
  if (!appText) return notApplicable("none of the configured app sources were found");

  let sqlText = "";
  try {
    sqlText = migrationSql(config);
  } catch {
    // No migrations dir here: the SQL-based legs (aggregate caps, locked limits) stay dormant, but
    // the app-based leg (preserved limits) can still apply, so this is not on its own NOT_APPLICABLE.
  }

  const capScan = scanCaps(appText, sqlText, config);
  const lockScan = scanLockedLimits(sqlText, config);
  const presScan = scanPreservedLimits(appText, config);

  const applicableCaps = config.caps.filter((c) => c.appCheck.test(appText));
  const violations = [...capScan.violations, ...lockScan.violations, ...presScan.violations];
  const guarded = [...capScan.guarded, ...lockScan.guarded, ...presScan.guarded];

  if (applicableCaps.length === 0 && !lockScan.applicable && !presScan.applicable) {
    return notApplicable(
      "no declared aggregate cap or per-member spend limit is present in the sources",
    );
  }
  if (violations.length) {
    return finding(
      `${violations.length} cap/limit violation(s): a cap or per-member limit is enforced from the request payload, or outside the atomic op's lock`,
      { violations, guarded },
    );
  }
  if (guarded.length === 0) {
    return notApplicable(
      "declared cap/limit(s) exist, but no atomic op commits or enforces them yet — nothing to re-check under a lock",
      { caps: applicableCaps.map((c) => c.name) },
    );
  }
  return checked(
    "every declared aggregate cap and per-member spend limit is read and enforced inside the atomic op under a lock",
    { guarded },
  );
}

export default detect;
