// N-SCOPE-01 — portable static detector: a bulk state-RESTORE honours provenance, not just the
// shared state.
//
// INVARIANT: a bulk restore (unfreeze / resume) that lifts rows out of a shared state <S> back to
// active, filtered by a parent key, must restore ONLY what its pairing op put into <S> — not every
// row in <S> under that parent. When <S> is ALSO set by another path (e.g. an individual card freeze
// alongside the member-level freeze), a restore that filters on `<S>` + parent alone reactivates
// rows a different path froze for a different reason. The restore must either carry a provenance
// predicate, or touch only the entity it actually changed (e.g. flip the member's own status and
// leave individually-frozen cards alone).
//
// This is a SOURCE scanner over the service: it follows the restore ROUTE (a stable spec path) to
// whatever handler it dispatches to and reads that handler's body — so it survives a rebuild that
// renames the handler. Fails CLOSED when the restore bulk-lifts the entity by the shared state with
// no provenance AND another site sets that same state. NOT_APPLICABLE when the restore route is absent.

import { readFileSync } from "node:fs";
import { checked, finding, notApplicable, type Verdict } from "../money-system.ts";

export interface ScopeConfig {
  /** Source file that registers routes (the router). */
  routerSource: string;
  /** App/service source files where the handlers are defined. */
  appSources: string[];
  /** The stable route path of the bulk RESTORE op, e.g. /\/members\/[^/]+\/unfreeze\b/. */
  restoreRoute: RegExp;
  /** The entity whose rows the restore lifts, e.g. "cards". */
  entity: string;
  /** The shared state the restore lifts out of, e.g. "frozen". */
  sharedState: string;
  /** The state the restore lifts rows back to, e.g. "active". */
  activeState: string;
  /** A DIFFERENT route that also sets the entity to `sharedState` (so the state is not unique provenance). */
  otherSetterRoute: RegExp;
  /** Optional: a provenance predicate that would make a bulk restore safe (a reason/source marker). */
  provenanceMarker?: RegExp;
  /** Repo root. Default process.cwd(). */
  cwd?: string;
}

/** The neobank binding — all neobank specifics live here, in config, never in the detector. */
export const NEOBANK: ScopeConfig = {
  routerSource: "supabase/functions/_shared/app/router.ts",
  appSources: ["supabase/functions/_shared/app/service.ts"],
  restoreRoute: /\/members\/[^/"'`]+\/unfreeze\b/,
  entity: "cards",
  sharedState: "frozen",
  activeState: "active",
  // An individual card can be frozen on its own — so `frozen` is set by more than the member freeze.
  otherSetterRoute: /\/cards\/[^/"'`]+\/freeze\b/,
};

// --- pure source-reading primitives (repo-agnostic) -----------------------------------

const escapeRe = (s: string): string => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

/** The handler method a route dispatches to (keyed on the stable path, not the method name). */
export function routeHandler(routerText: string, routeRe: RegExp): string | null {
  const lit = /["'`](\/[^"'`]+)["'`]/g;
  for (const m of routerText.matchAll(lit)) {
    if (!routeRe.test(m[1])) continue;
    const win = routerText.slice(m.index, m.index + 300);
    const hm = /\b(?:s|this)\.(\w+)\s*\(/.exec(win);
    if (hm) return hm[1];
  }
  return null;
}

/** The body (including braces) of a method DEFINITION named `fn`, brace-matched; null if absent. */
export function methodBody(src: string, fn: string): string | null {
  const re = new RegExp(`(?:async\\s+)?\\b${escapeRe(fn)}\\s*\\(`, "g");
  for (const m of src.matchAll(re)) {
    if (src[m.index - 1] === ".") continue;
    let i = m.index + m[0].length - 1;
    let depth = 0;
    for (; i < src.length; i++) {
      if (src[i] === "(") depth++;
      else if (src[i] === ")") {
        depth--;
        if (depth === 0) {
          i++;
          break;
        }
      }
    }
    while (i < src.length && src[i] !== "{" && src[i] !== ";") i++;
    if (src[i] !== "{") continue;
    const bodyStart = i;
    let d = 1;
    i = bodyStart + 1;
    for (; i < src.length && d > 0; i++) {
      if (src[i] === "{") d++;
      else if (src[i] === "}") d--;
    }
    return src.slice(bodyStart, i);
  }
  return null;
}

// --- the restore-scope logic -----------------------------------------------------------

export interface ScopeScan {
  violation: string | null;
  /** The restore route is registered (else dormant). */
  applicable: boolean;
}

/**
 * Pure core. The restore handler bulk-lifts `entity` to `activeState` filtered by `sharedState`
 * (and the parent) with no provenance predicate, AND another route also sets `sharedState` — so the
 * restore reactivates rows it never froze.
 */
export function scanScope(routerText: string, appText: string, cfg: ScopeConfig): ScopeScan {
  const out: ScopeScan = { violation: null, applicable: false };
  const handler = routeHandler(routerText, cfg.restoreRoute);
  const body = handler ? methodBody(appText, handler) : null;
  if (!handler || body === null) return out;
  out.applicable = true;

  const sharedFilter = new RegExp(`status\\b[^;\\n]{0,8}?['"]${escapeRe(cfg.sharedState)}['"]`);
  const entityRestore = new RegExp(
    `update\\s*\\(\\s*["'\`]${escapeRe(cfg.entity)}["'\`][\\s\\S]{0,160}?status["']?\\s*:\\s*["'\`]${escapeRe(cfg.activeState)}["'\`]`,
    "i",
  );
  const bulkRestore = sharedFilter.test(body) && entityRestore.test(body);
  const hasProvenance = cfg.provenanceMarker ? cfg.provenanceMarker.test(body) : false;
  const otherSetter = cfg.otherSetterRoute.test(routerText);

  if (bulkRestore && !hasProvenance && otherSetter) {
    out.violation =
      `${handler} bulk-restores ${cfg.entity} filtered only on status='${cfg.sharedState}' (+ parent) ` +
      `with no provenance predicate, while a separate path also sets '${cfg.sharedState}' — it ` +
      `reactivates ${cfg.entity} it never froze`;
  }
  return out;
}

/** Convenience core, matching the other detectors' `<name>Violations(): string[]` shape. */
export function scopeViolations(routerText: string, appText: string, cfg: ScopeConfig): string[] {
  const v = scanScope(routerText, appText, cfg).violation;
  return v ? [v] : [];
}

function readFile(path: string, cwd?: string): string {
  return readFileSync(cwd ? `${cwd}/${path}` : path, "utf8");
}

function concatSources(paths: string[], cwd?: string): string {
  const parts: string[] = [];
  for (const f of paths) {
    try {
      parts.push(readFile(f, cwd));
    } catch {
      // absent here; skip.
    }
  }
  return parts.join("\n");
}

/** Run the detector against the live repo. */
export function detect(config: ScopeConfig): Verdict {
  let routerText: string;
  try {
    routerText = readFile(config.routerSource, config.cwd);
  } catch {
    return notApplicable(`router source not found: ${config.routerSource}`);
  }
  const appText = concatSources(config.appSources, config.cwd);
  const scan = scanScope(routerText, appText, config);
  if (!scan.applicable) {
    return notApplicable("no bulk state-restore route is registered in this repo");
  }
  if (scan.violation) {
    return finding("a bulk state-restore reactivates rows another path set to the same state", {
      violations: [scan.violation],
    });
  }
  return checked(
    "the restore touches only what it changed (or filters by provenance) — it never reactivates rows another path set",
  );
}

export default detect;
