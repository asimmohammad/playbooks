// N-UNWIND-01 — portable static detector: a terminal unwind first asserts no unresolved money state.
//
// INVARIANT: a terminal lifecycle op that settles an entity's balance to zero AND marks it
// terminal (removed/closed) must FIRST assert there is no UNRESOLVED money attached to it — no open
// dispute, no provisional credit, no pending inbound. Settling to zero and marking the entity gone
// while a dispute could still reverse (a chargeback / provisional-credit reversal) strands money:
// the later reversal has nowhere to land and no path back to the owner.
//
// This is a SOURCE scanner over the migration SQL, fails CLOSED when a terminal-unwind op has no
// guard against the app's unresolved-money set, and needs no adapter. The unresolved-money surfaces
// (the disputes table and its live statuses, pending transfers) live in the NEOBANK config, not in
// the detector. Scoped to a SINGLE-subject removal (the removal-race unwind), so a repo that only
// tears down in bulk at account closure — which guards disputes already — is NOT_APPLICABLE here.

import { readdirSync, readFileSync } from "node:fs";
import { checked, finding, notApplicable, type Verdict } from "../money-system.ts";

export interface UnwindConfig {
  /** Directory of *.sql migrations that define the atomic ops. Default "supabase/migrations". */
  migrationsDir?: string;
  /** Prefix marking this app's own atomic SQL ops, e.g. "harbor_". Default "harbor_". */
  sqlFnPrefix?: string;
  /** Marks a terminal-unwind op: a single-subject removal (not a bulk `any(...)` closure teardown). */
  terminalMarker: RegExp;
  /** Evidence the op settles a balance to zero (a settle-back ledger post / pocket-to-zero). */
  settleMarker: RegExp;
  /** The unresolved-money guard that must be present first — disputes {open, provisional_credited}, pending inbound. */
  unresolvedGuard: RegExp;
  /** Repo root. Default process.cwd(). */
  cwd?: string;
}

/** The neobank binding — all neobank specifics (the unresolved-money set) live here, not in the detector. */
export const NEOBANK: UnwindConfig = {
  migrationsDir: "supabase/migrations",
  sqlFnPrefix: "harbor_",
  terminalMarker:
    /update\s+(?:public\.)?family_members\s+set\s+status\s*=\s*'removed'\s+where\s+id\s*=\s*(?!\s*any\b)/i,
  settleMarker:
    /allowance[\s\S]{0,60}?zero|settle[\s_-]?back|settled_back|harbor__post_ledger\s*\(/i,
  unresolvedGuard: /disputes\b[\s\S]{0,200}?(?:'open'|provisional_credited)|open_disputes/i,
};

// --- pure source-reading primitives (repo-agnostic) -----------------------------------

const stripSqlComments = (sql: string): string => sql.replace(/--[^\n]*/g, "");

function sqlFunctions(sql: string): Map<string, string> {
  const out = new Map<string, string>();
  const re =
    /create\s+(?:or\s+replace\s+)?function\s+(?:public\.)?(\w+)\s*\([\s\S]*?\$(\w*)\$([\s\S]*?)\$\2\$/gi;
  for (const m of stripSqlComments(sql).matchAll(re)) out.set(m[1].toLowerCase(), m[3]);
  return out;
}

// --- the terminal-unwind logic ---------------------------------------------------------

export interface UnwindScan {
  /** "<fn>: …" for each terminal-unwind op with no unresolved-money guard. */
  violations: string[];
  /** A terminal-unwind op (settle-to-zero + mark terminal) is present (else dormant). */
  applicable: boolean;
}

/**
 * Pure core: an op that both settles a balance to zero and marks its subject terminal MUST guard
 * against the unresolved-money set first; one that does not is a violation.
 */
export function scanUnwind(sqlText: string, cfg: UnwindConfig): UnwindScan {
  const prefix = (cfg.sqlFnPrefix ?? "harbor_").toLowerCase();
  const out: UnwindScan = { violations: [], applicable: false };
  for (const [name, body] of sqlFunctions(sqlText)) {
    if (!name.startsWith(prefix) || name.startsWith(prefix + "_")) continue; // top-level ops only
    const isTerminalUnwind = cfg.terminalMarker.test(body) && cfg.settleMarker.test(body);
    if (!isTerminalUnwind) continue;
    out.applicable = true;
    if (!cfg.unresolvedGuard.test(body)) {
      out.violations.push(
        `${name}: settles the balance to zero and marks the subject terminal without first ` +
          `asserting no unresolved money (open dispute / provisional credit / pending inbound) — ` +
          `a later reversal would strand funds`,
      );
    }
  }
  return out;
}

/** Convenience core, matching the other detectors' `<name>Violations(): string[]` shape. */
export function unwindViolations(sqlText: string, cfg: UnwindConfig): string[] {
  return scanUnwind(sqlText, cfg).violations;
}

function migrationSql(cfg: UnwindConfig): string {
  const dir = cfg.migrationsDir ?? "supabase/migrations";
  const base = cfg.cwd ? `${cfg.cwd}/${dir}` : dir;
  return readdirSync(base)
    .filter((f) => f.endsWith(".sql"))
    .sort()
    .map((f) => readFileSync(`${base}/${f}`, "utf8"))
    .join("\n");
}

/** Run the detector against the live repo. */
export function detect(config: UnwindConfig): Verdict {
  let sqlText: string;
  try {
    sqlText = migrationSql(config);
  } catch {
    return notApplicable(
      `migrations dir not found: ${config.migrationsDir ?? "supabase/migrations"}`,
    );
  }
  const scan = scanUnwind(sqlText, config);
  if (!scan.applicable) {
    return notApplicable("no terminal-unwind op (settle-to-zero + mark-terminal) is present");
  }
  if (scan.violations.length) {
    return finding(
      `${scan.violations.length} terminal-unwind op(s) settle & mark terminal with no unresolved-money guard`,
      { violations: scan.violations },
    );
  }
  return checked(
    "every terminal-unwind op asserts no open dispute / provisional credit before settling to zero and marking terminal",
  );
}

export default detect;
