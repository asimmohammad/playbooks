// N-GL-TIE — portable static detector: every payable/receivable is FULLY BOOKED across its
// lifecycle. An obligation and its General-Ledger recognition entry are TIED together — you cannot
// have one without the other.
//
// INVARIANT: when a money app records an obligation (a payable/bill it owes, a receivable/invoice it
// is owed), that obligation must be RECOGNIZED in the double-entry ledger at the same moment it is
// created — DR expense / CR Accounts-Payable for a bill, DR Accounts-Receivable / CR Revenue for an
// invoice. The AP/AR line is a CONTROL ACCOUNT: it is the ledger's running tally of everything owed.
// A control account must therefore be touched on BOTH sides over the obligation's life — CREDITed
// when the obligation is recognized (money becomes owed) and DEBITed when it is settled (money is
// paid). If recognition is skipped, the obligation exists in its own table but is INVISIBLE to the
// GL: the trial balance understates liabilities (or assets), the AP/AR control account is one-sided,
// and the sub-ledger (bills/invoices) silently diverges from the ledger it is supposed to tie out to.
// That is a direct mis-statement of the books, and nothing downstream ever reconciles the two back.
//
// SMELL (any one is a FINDING):
//   A. an OBLIGATION-CREATING method inserts the obligation (INSERT INTO bills / invoices / their
//      lines) but issues NO recognition ledger post (no postEntry / ledger.post / post_ledger) in its
//      body — the payable/receivable is booked to its own table with no journal entry; OR
//   B. a GL CONTROL ACCOUNT (the AP / AR account code) is only ever DEBITed, or only ever CREDITed,
//      across its service — one leg of the obligation (recognition or settlement) is never booked, so
//      the control account can never tie out to its sub-ledger.
//
// Like the rest of the family this is a SOURCE scanner (fail-closed, needs no adapter, keys on stable
// surfaces — the obligation-INSERT idiom, the ledger-post idiom, and the control-account reference —
// NOT on a function name). It reads the money service TS with node:fs and matches the smell with regex.
// It is parameterised so nothing app-specific — the obligation tables, their service files, the
// ledger-post idiom, the posting-line debit/credit idioms, the control-account vocabulary — is baked
// into the detector; only into the config. Dormant (NOT_APPLICABLE) until an obligation-creating insert
// is actually present: an app that records no payables/receivables has no recognition entry to tie.
//
// v4 DEEPEN — SUPABASE-CLIENT inserts. The obligation-INSERT idiom used to be raw SQL only
// (`insert into bills`). pmar records money through the SUPABASE client — `ctx.sb.from("bills").insert({…})`
// and recognizes through `ctx.ledger.postEntry(…)` / `.from("journal_entry_lines").insert(…)`, NOT raw
// SQL — so on feat/gaap this detector found no obligation insert, set `present=false`, and went
// NOT_APPLICABLE, MASKING a real bug (createBill inserts the bill + lines but posts NO recognition entry,
// so AP is only ever DEBITed at settlement and never CREDITed at recognition — the sub-ledger diverges
// from the GL). The obligation-INSERT and recognition-post idioms are widened below to recognise BOTH
// raw SQL AND the supabase-client shape, so the bug is caught on either. The money-vocabulary stays in the
// detector; only PATHS come from the DERIVED surface via `forSurface(deriveMoneySurface(cwd))` (v4).

import { readFileSync } from "node:fs";
import { checked, finding, notApplicable, type Verdict } from "../money-system.ts";
import { deriveMoneySurface, type DerivedSurface } from "../derive.ts";

/** A GL control account whose two-sidedness is audited, e.g. AP (code 2000) or AR (code 2100). */
export interface ControlAccount {
  /** Human label for verdict output, e.g. "AP (Accounts Payable, code 2000)". */
  name: string;
  /** How the account is referenced in a posting line, e.g. /ACCOUNTS\.AP\b/ . */
  ref: RegExp;
}

/** One obligation flow (a payable or a receivable) and how to recognise its smell in the service code. */
export interface GlTieFlow {
  /** Human label for the invariant leg, e.g. "payable (bills)". Verdict output only. */
  name: string;
  /** Service file(s) that create and settle this obligation (where the INSERT + postings live). */
  serviceFiles: string[];
  /**
   * The obligation-creating INSERT idiom. A method whose body contains this is an obligation-creating
   * method and MUST post a recognition entry. e.g. /insert\s+into\s+(?:bills|bill_lines)\b/i .
   * Must match ONLY the obligation + its lines, never a settlement/payment table.
   */
  obligationInsert: RegExp;
  /** How a recognition ledger post is written, e.g. /\bpostEntry\b|ledger\.post|post_ledger/i . */
  recognitionPost: RegExp;
  /** The GL control account this flow recognizes/settles against (audited for one-sidedness). */
  controlAccount: ControlAccount;
}

export interface GlTieConfig {
  /** The obligation flows to check (bills, invoices, ...). */
  flows: GlTieFlow[];
  /**
   * How a posting line (or a money-executor parameter) expresses a DEBIT of an account. Each regex is
   * GLOBAL and captures the ACCOUNT reference in group 1, e.g. /debitAccountId\s*:\s*([\w$.]+)/g and
   * /accountId\s*:\s*([\w$.]+)\s*,\s*side\s*:\s*["']debit["']/g . App-wide idiom, not per-flow.
   */
  debitForms: RegExp[];
  /** How a posting line / executor param expresses a CREDIT of an account (group 1 = account ref). */
  creditForms: RegExp[];
  /** Repo root. Default process.cwd(). */
  cwd?: string;
}

/**
 * How a RECOGNITION ledger post is written. Widened in v4 to recognise BOTH the idioms pmar uses:
 *   - a ledger executor call — `ctx.ledger.postEntry(…)`, `ledger.post(…)`, `postJournal(…)`, `post_ledger`; AND
 *   - a direct supabase insert of posting lines — `.from("journal_entry_lines").insert(…)` (or `ledger_lines`).
 * A method that creates an obligation MUST contain one of these in its body, else recognition is skipped.
 */
const RECOGNITION_POST =
  /\bpostEntry\b|ledger\.post\b|\bpost_ledger\b|\bpostJournal\b|\.from\s*\(\s*["'`](?:journal_entry_lines|ledger_lines|journal_lines)["'`]\s*\)\s*\.insert\b/i;

/** An obligation-creating INSERT of `table` (+ its `_lines`), matching BOTH raw SQL and the supabase client. */
const obligationInsertFor = (table: string, lines: string): RegExp =>
  new RegExp(
    // raw SQL: `insert into (public.)?bills|bill_lines`
    `insert\\s+into\\s+(?:public\\.)?(?:${table}|${lines})\\b` +
      // OR supabase client: `.from("bills"|"bill_lines").insert` — ctx.sb / ctx.db / any receiver.
      `|\\.from\\s*\\(\\s*["'\`](?:${table}|${lines})["'\`]\\s*\\)\\s*\\.insert\\b`,
    "i",
  );

/**
 * The GENERIC obligation flows — money vocabulary only, NO paths. Each flow knows how to recognise its
 * obligation-creating insert (raw SQL or supabase), its recognition post, and its GL control account.
 * Paths are supplied per binding: concrete defaults in `PMAR`, or the DERIVED surface in `forSurface`.
 */
export const GL_TIE_FLOWS: Array<Omit<GlTieFlow, "serviceFiles">> = [
  {
    name: "payable (bills)",
    // bills + bill_lines, but NOT a settlement table (there is no ap payment table; payBill posts).
    obligationInsert: obligationInsertFor("bills", "bill_lines"),
    recognitionPost: RECOGNITION_POST,
    controlAccount: { name: "AP (Accounts Payable, code 2000)", ref: /ACCOUNTS\.AP\b/ },
  },
  {
    name: "receivable (invoices)",
    // invoices + invoice_lines, but NOT invoice_payments (that is settlement, not recognition).
    obligationInsert: obligationInsertFor("invoices", "invoice_lines"),
    recognitionPost: RECOGNITION_POST,
    controlAccount: { name: "AR (Accounts Receivable, code 2100)", ref: /ACCOUNTS\.AR\b/ },
  },
];

// pmar books money two ways: inline posting-line object literals ({ accountId, side }) in a service,
// and named parameters on executeMoneyMovement ({ debitAccountId, creditAccountId }). Both idioms,
// in either field order, resolve an account to a side here. App-wide idiom, not per-flow.
const DEBIT_FORMS: RegExp[] = [
  /debitAccountId\s*:\s*([A-Za-z_$][\w$.]*)/g,
  /accountId\s*:\s*([A-Za-z_$][\w$.]*)\s*,\s*side\s*:\s*["']debit["']/g,
  /side\s*:\s*["']debit["']\s*,\s*accountId\s*:\s*([A-Za-z_$][\w$.]*)/g,
];
const CREDIT_FORMS: RegExp[] = [
  /creditAccountId\s*:\s*([A-Za-z_$][\w$.]*)/g,
  /accountId\s*:\s*([A-Za-z_$][\w$.]*)\s*,\s*side\s*:\s*["']credit["']/g,
  /side\s*:\s*["']credit["']\s*,\s*accountId\s*:\s*([A-Za-z_$][\w$.]*)/g,
];

/** The pmar binding with concrete default service files (used by the earlier `detect(PMAR)` call path). */
export const PMAR: GlTieConfig = {
  flows: [
    { ...GL_TIE_FLOWS[0]!, serviceFiles: ["src/services/ap.ts", "src/services/gaap.ts", "src/lib/gaap.ts"] },
    { ...GL_TIE_FLOWS[1]!, serviceFiles: ["src/services/ar.ts", "src/services/gaap.ts", "src/lib/gaap.ts"] },
  ],
  debitForms: DEBIT_FORMS,
  creditForms: CREDIT_FORMS,
};

/**
 * v4 surface binding: `detect(forSurface(deriveMoneySurface(cwd)))`. Only the PATHS come from the
 * derived surface — each flow scans the repo's own money files (surface.moneyPaths, which reach
 * ap.ts / ar.ts / gaap.ts and any new money module the moment it lands). The obligation-insert,
 * recognition-post and control-account vocabulary stay fixed in `GL_TIE_FLOWS` above. A flow's
 * obligation regex only matches its own tables, so handing every money file to both flows is safe.
 */
export function forSurface(surface: Pick<DerivedSurface, "moneyPaths" | "cwd">): GlTieConfig {
  return {
    flows: GL_TIE_FLOWS.map((f) => ({ ...f, serviceFiles: surface.moneyPaths })),
    debitForms: DEBIT_FORMS,
    creditForms: CREDIT_FORMS,
    cwd: surface.cwd,
  };
}

// --- pure source-reading primitives (repo-agnostic; mirror the other static detectors) -

/** 1-based line number of the character at `idx`. */
const lineAt = (text: string, idx: number): number => text.slice(0, idx).split("\n").length;

/** A fresh GLOBAL clone of `re` (so matchAll / repeated use never trip over a shared lastIndex). */
const global = (re: RegExp): RegExp =>
  new RegExp(re.source, re.flags.includes("g") ? re.flags : re.flags + "g");

/**
 * Does the `{` at `openBraceIdx` open a FUNCTION/METHOD body (vs. a control block like for/if/while)?
 * True iff, ignoring whitespace, it is preceded by `) ` whose matching `(` is preceded by an
 * identifier that is NOT a control keyword, or by an arrow `=>`.
 */
function opensFunctionBody(text: string, openBraceIdx: number): boolean {
  let k = openBraceIdx - 1;
  while (k >= 0 && /\s/.test(text[k])) k--;
  if (k < 0) return false;
  if (text[k] === ">") return text[k - 1] === "="; // arrow `=> {`
  if (text[k] !== ")") return false; // not a `(...) {` signature
  // walk back over the balanced parameter list to the identifier before `(`
  let depth = 1;
  let p = k - 1;
  for (; p >= 0 && depth > 0; p--) {
    if (text[p] === ")") depth++;
    else if (text[p] === "(") depth--;
  }
  let q = p;
  while (q >= 0 && /\s/.test(text[q])) q--;
  const end = q;
  while (q >= 0 && /[\w$]/.test(text[q])) q--;
  const ident = text.slice(q + 1, end + 1);
  if (!ident) return false; // `(...) {` with no name before it — e.g. an inline control block
  return !/^(?:for|while|if|switch|catch|do)$/.test(ident);
}

/**
 * The smallest FUNCTION/METHOD body that encloses `idx`, as {start,end} (start = its `{`, end = just
 * past its matching `}`), or null if none. Walks outward through every enclosing brace block (skipping
 * inner for/if/while bodies) until it reaches one whose opener is a function signature.
 */
export function enclosingMethodBody(text: string, idx: number): { start: number; end: number } | null {
  // collect enclosing openers, innermost first
  const openers: number[] = [];
  let depth = 0;
  for (let i = idx - 1; i >= 0; i--) {
    const c = text[i];
    if (c === "}") depth++;
    else if (c === "{") {
      if (depth === 0) openers.push(i);
      else depth--;
    }
  }
  for (const op of openers) {
    if (!opensFunctionBody(text, op)) continue;
    let d = 1;
    let j = op + 1;
    for (; j < text.length && d > 0; j++) {
      if (text[j] === "{") d++;
      else if (text[j] === "}") d--;
    }
    return { start: op, end: j };
  }
  return null;
}

// --- the GL-tie logic ------------------------------------------------------------------

/** One place an account is booked, with the side it was booked on. */
interface SideHit {
  file: string;
  line: number;
  side: "debit" | "credit";
  /** The captured account reference, e.g. "ACCOUNTS.AP". */
  token: string;
}

/** Every (account, side) booking across the given service files, from both posting idioms. */
export function accountSides(
  files: Array<{ path: string; text: string }>,
  cfg: GlTieConfig,
): SideHit[] {
  const out: SideHit[] = [];
  const collect = (forms: RegExp[], side: "debit" | "credit") => {
    for (const form of forms) {
      for (const { path, text } of files) {
        for (const m of text.matchAll(global(form))) {
          const token = m[1];
          if (!token) continue;
          out.push({ file: path, line: lineAt(text, m.index ?? 0), side, token });
        }
      }
    }
  };
  collect(cfg.debitForms, "debit");
  collect(cfg.creditForms, "credit");
  return out;
}

export interface GlTieScan {
  /** "<flow>: <file>:<line> — <why>" for each un-tied obligation / one-sided control account. */
  violations: string[];
  /** "<flow>: <file>:<line> — <why>" for each obligation that is fully booked. */
  guarded: string[];
  /** At least one obligation-creating insert was found (else the invariant is dormant). */
  present: boolean;
}

/**
 * Pure core. For each flow: (A) every obligation-creating method (a method whose body contains an
 * obligation INSERT) must contain a recognition ledger post; (B) its control account must be booked
 * on BOTH sides across the flow's service files. A method that inserts without posting, or a control
 * account used on only one side, is a violation.
 */
export function scanGlTie(serviceTexts: Map<string, string>, cfg: GlTieConfig): GlTieScan {
  const out: GlTieScan = { violations: [], guarded: [], present: false };

  for (const flow of cfg.flows) {
    const files = flow.serviceFiles
      .map((p) => {
        const text = serviceTexts.get(p);
        return text === undefined ? null : { path: p, text };
      })
      .filter((x): x is { path: string; text: string } => x !== null);

    // --- leg A: obligation-creating methods must post a recognition entry ---------------
    const seenMethods = new Set<string>();
    for (const { path, text } of files) {
      for (const m of text.matchAll(global(flow.obligationInsert))) {
        out.present = true;
        const idx = m.index ?? 0;
        const body = enclosingMethodBody(text, idx);
        if (!body) continue; // could not scope the enclosing method; nothing to assert on
        const key = `${path}:${body.start}`;
        if (seenMethods.has(key)) continue; // several inserts in one method — check it once
        seenMethods.add(key);
        const bodyText = text.slice(body.start, body.end);
        const cite = `${path}:${lineAt(text, body.start)}`;
        const inserted = m[0].replace(/\s+/g, " ").trim();
        if (flow.recognitionPost.test(bodyText)) {
          out.guarded.push(
            `${flow.name}: ${cite} — the obligation-creating method (${inserted}) posts a recognition ledger entry`,
          );
        } else {
          out.violations.push(
            `${flow.name}: ${cite} — the obligation-creating method (${inserted}) inserts the ` +
              `obligation but posts NO recognition ledger entry (no postEntry / ledger.post) in its ` +
              `body — the payable/receivable is recorded with no journal entry, so the GL never ` +
              `reflects it and the ${flow.controlAccount.name} control account is never credited at ` +
              `recognition time`,
          );
        }
      }
    }

    // --- leg B: the control account must be booked on BOTH sides ------------------------
    const sides = accountSides(files, cfg);
    const debits = sides.filter((h) => h.side === "debit" && flow.controlAccount.ref.test(h.token));
    const credits = sides.filter((h) => h.side === "credit" && flow.controlAccount.ref.test(h.token));
    if (debits.length && !credits.length) {
      const h = debits[0];
      out.violations.push(
        `${flow.name}: ${h.file}:${h.line} — the ${flow.controlAccount.name} control account is only ` +
          `ever DEBITed across ${flow.serviceFiles.join(", ")} (${debits.length} debit(s), 0 credits) — ` +
          `the recognition leg that CREDITs it is never booked, so it can never tie out to its sub-ledger`,
      );
    } else if (credits.length && !debits.length) {
      const h = credits[0];
      out.violations.push(
        `${flow.name}: ${h.file}:${h.line} — the ${flow.controlAccount.name} control account is only ` +
          `ever CREDITed across ${flow.serviceFiles.join(", ")} (0 debits, ${credits.length} credit(s)) — ` +
          `the settlement leg that DEBITs it is never booked, so it can never tie out to its sub-ledger`,
      );
    } else if (debits.length && credits.length) {
      out.guarded.push(
        `${flow.name}: the ${flow.controlAccount.name} control account is booked on both sides ` +
          `(${debits.length} debit(s), ${credits.length} credit(s))`,
      );
    }
  }

  return out;
}

/** Convenience core, matching the other detectors' `<name>Violations(): string[]` shape. */
export function glTieViolations(serviceTexts: Map<string, string>, cfg: GlTieConfig): string[] {
  return scanGlTie(serviceTexts, cfg).violations;
}

// --- file plumbing ---------------------------------------------------------------------

function readFile(path: string, cwd?: string): string {
  return readFileSync(cwd ? `${cwd}/${path}` : path, "utf8");
}

// --- the verdict -----------------------------------------------------------------------

/** Run the detector against the live repo. */
export function detect(config: GlTieConfig): Verdict {
  const serviceTexts = new Map<string, string>();
  for (const flow of config.flows) {
    for (const sf of flow.serviceFiles) {
      if (serviceTexts.has(sf)) continue;
      try {
        serviceTexts.set(sf, readFile(sf, config.cwd));
      } catch {
        /* this flow's service file is absent here; skip it. */
      }
    }
  }

  const scan = scanGlTie(serviceTexts, config);

  if (!scan.present) {
    return notApplicable(
      "no obligation-creating insert (bills/invoices) was found — the GL-tie invariant (every payable/" +
        "receivable is recognized in the ledger) does not apply here",
    );
  }
  if (scan.violations.length) {
    return finding(
      `${scan.violations.length} GL-tie violation(s): a payable/receivable is recorded without its ` +
        `recognition ledger entry, or an AP/AR control account is booked on only one side — the ` +
        `sub-ledger diverges from the GL and the trial balance mis-states what is owed`,
      { violations: scan.violations, guarded: scan.guarded },
    );
  }
  if (scan.guarded.length === 0) {
    return notApplicable(
      "obligation tables exist, but no obligation-creating method or control-account booking was " +
        "matched — nothing to check",
    );
  }
  return checked(
    "every obligation-creating method posts its recognition ledger entry, and each AP/AR control " +
      "account is booked on both sides — the sub-ledger ties out to the GL",
    { guarded: scan.guarded },
  );
}

/** v4 convenience: derive the surface from `cwd` and run. */
export function detectRepo(cwd: string): Verdict {
  const surface = deriveMoneySurface(cwd);
  return detect(forSurface({ ...surface, cwd }));
}

export default detect;
