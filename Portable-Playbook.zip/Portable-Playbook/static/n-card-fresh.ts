// N-CARD-FRESH — portable static detector: an app's money-surface CARD stays in sync with its repo.
//
// INVARIANT: the "card" — the MoneySurface manifest in adapters/<app>.ts that every other check reads
// (the money-touch skip-gate keys on `moneyTables`/`moneyColumns`/`moneyPaths`; each static detector
// is pointed at `schemaFiles`/`httpEntry`/paths through its binding) — must not drift out of sync with
// the repo it describes. Two drifts break the whole playbook silently:
//
//   (1) MISSING TABLE. The schema defines a money-bearing table (a `create table` whose body has a
//       column matching `moneyColumns` — an `_minor`/`amount`/`balance`/… field) that the card does
//       NOT list in `moneyTables`. The skip-gate then cannot name that table in a diff's SQL, so a PR
//       that only touches the new table can fail-closed-less and skip the PAID LLM money pass, and the
//       table-keyed detectors never look at it. A new `escrow`/`settlements` table silently escapes.
//
//   (2) DEAD PATH. The card names a `schemaFiles`, `moneyPaths` (a glob — its `/**` tail stripped to the
//       directory root) or `httpEntry` entry that no longer exists under the repo root (renamed, moved,
//       deleted). A detector pointed at a dead path reads an empty source and returns a vacuous pass —
//       a FALSE GREEN. Worst case the skip-gate's own money-path set rots and it skips real money code.
//
//   (3) PHANTOM TABLE (the reverse of #1). The card LISTS a table in `moneyTables` that the schema no
//       longer defines at all — a table that was renamed, dropped or mistyped, so no `create table`
//       exists for it. A table-keyed detector then scopes itself to a table that is not there and reads
//       nothing, and the skip-gate's `moneyTables` match on that name can never fire — both pass
//       vacuously on a name that describes no real surface. A stale `transfers`/`holds` entry (tables
//       pmar never had) is exactly this drift; it masks the fact that the card was copied, not derived.
//
// This is a META-check: it does not reason about money logic at all, it reasons about the MANIFEST the
// other checks trust. It fails CLOSED on any of these drifts and is NOT_APPLICABLE only when the card
// points at no schema file that exists (nothing to check for drift — we cannot tell phantom from unread).
//
// Like its siblings it is a pure SOURCE reader (node:fs text + path existence), repo-agnostic: every
// app specific — which files are the schema, which tables are money, which paths to trust — comes from
// the passed MoneySurface (the card), never from the detector. It works for both schema shapes: neobank's
// `.sql` migrations and pmar's `create table` template strings embedded in a `.ts` db module, because it
// scans the raw text of whatever `schemaFiles` names, independent of `schemaMode`.

import { existsSync, readFileSync } from "node:fs";
import { join } from "node:path";
import { checked, finding, notApplicable, type Verdict } from "../money-system.ts";
import { type MoneySurface } from "../adapters/pmar.ts";

// --- pure source-reading primitives (repo-agnostic; mirror the other static detectors) -

/** Drop SQL line comments so a stray `(` / `amount` in a comment can't skew paren depth or the money test. */
const stripSqlComments = (sql: string): string => sql.replace(/--[^\n]*/g, "");

/** A non-global copy of a regex, so repeated `.test()` is stateless even when the card's regex has /g. */
const stateless = (re: RegExp): RegExp => new RegExp(re.source, re.flags.replace("g", ""));

/**
 * table name (lowercased) -> the text INSIDE its outer parens, for every `create table <name> (...)`.
 * Balanced-paren scan (nested `check (...)` constraints are common) that skips single-quoted SQL string
 * literals, so a `'...)...'` default can't unbalance the count. Schema-shape agnostic: the same SQL text
 * is matched whether it sits in a `.sql` migration or inside a `.ts` template string.
 */
export function createTables(text: string): Map<string, string> {
  const src = stripSqlComments(text);
  const head =
    /create\s+(?:(?:global|local)\s+)?(?:unlogged\s+|temp(?:orary)?\s+)?table\s+(?:if\s+not\s+exists\s+)?(?:public\.)?["`']?(\w+)["`']?\s*\(/gi;
  const out = new Map<string, string>();
  let m: RegExpExecArray | null;
  while ((m = head.exec(src)) !== null) {
    const name = m[1].toLowerCase();
    const start = head.lastIndex; // first char inside the opening paren
    let depth = 1;
    let i = start;
    while (i < src.length && depth > 0) {
      const ch = src[i];
      if (ch === "'") {
        i++;
        while (i < src.length) {
          if (src[i] === "'") {
            if (src[i + 1] === "'") { i += 2; continue; } // doubled '' escape inside the literal
            i++;
            break;
          }
          i++;
        }
        continue;
      }
      if (ch === "(") depth++;
      else if (ch === ")") depth--;
      i++;
    }
    // slice up to (but not including) the closing paren we just consumed.
    out.set(name, src.slice(start, depth === 0 ? i - 1 : i));
    head.lastIndex = i; // resume scanning after this table's body
  }
  return out;
}

/** Money-bearing tables the schema defines: a `create table` whose body has a `moneyColumns`-matching column. */
export function moneyBearingTables(schemaText: string, moneyColumns: RegExp): string[] {
  const col = stateless(moneyColumns);
  const out: string[] = [];
  for (const [name, body] of createTables(schemaText)) {
    if (col.test(body)) out.push(name);
  }
  return out;
}

/** Strip a single trailing `/**` glob tail from a card path, leaving the directory root to existence-check. */
const stripGlob = (p: string): string => (p.endsWith("/**") ? p.slice(0, -3) : p);

const uniq = (xs: string[]): string[] => [...new Set(xs)];

// --- the card-freshness logic ----------------------------------------------------------

export interface CardScan {
  /** `schemaFiles` entries that actually exist and were read (the drift target). */
  schemaFilesFound: string[];
  /** Money-bearing tables the schema defines (a `create table` with a `moneyColumns` column). */
  moneyBearing: string[];
  /** Money-bearing tables the schema has but the card's `moneyTables` does NOT list (drift #1). */
  missingTables: string[];
  /** Card paths (schemaFiles / moneyPaths sans `/**` / httpEntry) that do not exist under cwd (drift #2). */
  deadPaths: string[];
  /** Card `moneyTables` entries the schema does NOT define with any `create table` (drift #3, reverse of #1). */
  phantomTables: string[];
}

/**
 * Read the card's schema file(s) under cwd, extract the money-bearing tables, and check every card path
 * exists. Pure w.r.t. the card: all table names / column shapes / paths come from the MoneySurface.
 * A `schemaFiles` entry that cannot be read is simply absent from `schemaFilesFound` (and, being a named
 * card path, is also reported as a dead path).
 */
export function cardScan(surface: MoneySurface, cwd: string): CardScan {
  const parts: string[] = [];
  const schemaFilesFound: string[] = [];
  for (const f of surface.schemaFiles) {
    try {
      parts.push(readFileSync(join(cwd, f), "utf8"));
      schemaFilesFound.push(f);
    } catch {
      // schema file this card names is absent here; recorded as a dead path below.
    }
  }

  const schemaText = parts.join("\n");
  const moneyBearing = moneyBearingTables(schemaText, surface.moneyColumns);
  const declared = new Set(surface.moneyTables.map((t) => t.toLowerCase()));
  const missingTables = moneyBearing.filter((t) => !declared.has(t));

  // drift #3 (phantom): a card money table the schema defines no `create table` for. Only meaningful
  // once we actually read a schema — with no schema read we cannot tell a phantom from an unread table
  // (the NOT_APPLICABLE path below handles that), so phantom stays empty in that case.
  const definedTables = new Set([...createTables(schemaText).keys()]); // createTables lowercases names
  const phantomTables = schemaFilesFound.length
    ? surface.moneyTables.filter((t) => !definedTables.has(t.toLowerCase()))
    : [];

  const cardPaths = uniq(
    [
      ...surface.schemaFiles,
      ...surface.moneyPaths.map(stripGlob),
      surface.httpEntry,
    ].filter((p): p is string => Boolean(p)),
  );
  const deadPaths = cardPaths.filter((p) => !existsSync(join(cwd, p)));

  return { schemaFilesFound, moneyBearing, missingTables, deadPaths, phantomTables };
}

/** Run the detector against a repo. `surface` IS the card; cwd (the repo root) resolves its paths. */
export function detect(surface: MoneySurface, opts: { cwd?: string } = {}): Verdict {
  const cwd = opts.cwd ?? surface.cwd ?? process.cwd();
  const scan = cardScan(surface, cwd);

  if (scan.schemaFilesFound.length === 0) {
    return notApplicable(
      "the card names no schema file that exists under cwd — there is no schema to check it against",
      { schemaFiles: surface.schemaFiles, cwd },
    );
  }

  const problems: string[] = [];
  if (scan.missingTables.length) {
    problems.push(
      `card omits ${scan.missingTables.length} money-bearing table(s) the schema defines ` +
        `(${scan.missingTables.join(", ")}) from moneyTables — the skip-gate and table-keyed detectors miss them`,
    );
  }
  if (scan.phantomTables.length) {
    problems.push(
      `card lists ${scan.phantomTables.length} table(s) in moneyTables the schema defines no create-table for ` +
        `(${scan.phantomTables.join(", ")}) — a table-keyed detector / the skip-gate scopes to a table that does ` +
        `not exist, so it reads nothing, never matches, and passes vacuously on a name describing no real surface`,
    );
  }
  if (scan.deadPaths.length) {
    problems.push(
      `card names ${scan.deadPaths.length} path(s) that no longer exist under cwd ` +
        `(${scan.deadPaths.join(", ")}) — a detector pointed at a dead path reads nothing and passes vacuously`,
    );
  }

  if (problems.length) {
    return finding(
      `the money-surface card has drifted from the repo: ${scan.missingTables.length} missing money table(s), ` +
        `${scan.phantomTables.length} phantom table(s), ${scan.deadPaths.length} dead path(s)`,
      {
        missingTables: scan.missingTables,
        phantomTables: scan.phantomTables,
        deadPaths: scan.deadPaths,
        problems,
        moneyBearingTables: scan.moneyBearing,
        schemaFilesRead: scan.schemaFilesFound,
      },
    );
  }

  return checked(
    "the money-surface card is in sync: every money-bearing table the schema defines is listed in moneyTables, " +
      "every listed money table is defined in the schema, and every card path still exists",
    { moneyBearingTables: scan.moneyBearing, schemaFilesRead: scan.schemaFilesFound },
  );
}

export default detect;
