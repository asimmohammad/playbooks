// N-PARITY-01 — portable static detector: multi-backend guard parity.
//
// INVARIANT: an app that keeps two (or more) implementations of its money operations — a
// fast in-memory store for tests and a real SQL-backed store for production — must keep
// them in LOCKSTEP. Every operation of the canonical ops interface is implemented by every
// store; every SQL-backed operation names a database function that a migration actually
// defines; and every business guard (a refusal code) is enforced on BOTH sides. A guard
// that exists only in memory passes the test suite but lets prod through; one only in SQL
// fails prod in a way the tests never saw.
//
// This is a SOURCE scanner over pure text: the store source, the migration SQL, and
// optional CI-evidence files. It is parameterised so nothing neobank-specific (class
// names, the `harbor_` function prefix, the `harbor:` guard prefix, file paths) is baked
// into the detector — only into the config.

import { readdirSync, readFileSync } from "node:fs";
import { checked, finding, notApplicable, type Verdict } from "../money-system.ts";

export interface CiEvidence {
  /** A file that must demonstrate both backends are exercised in CI. */
  file: string;
  /** Substrings/patterns that must all be present in `file`. */
  mustContain: (string | RegExp)[];
}

export interface ParityConfig {
  /** Source file declaring the ops interface and all store classes. */
  storeSource: string;
  /** Interface every store must fully implement, e.g. "MoneyOps". */
  opsInterface: string;
  /** Store classes that must each implement every op, e.g. ["MemoryStore", "SupabaseStore"]. */
  stores: string[];
  /** Store(s) backed by SQL: each op must name a SQL function (by prefix) a migration defines. */
  sqlBackedStores?: string[];
  /** Prefix marking this app's own SQL functions, referenced as quoted strings. Default "harbor_". */
  sqlFnPrefix?: string;
  /** Guards raised as '<guardPrefix><code>' in SQL and fail("<code>") in the guard store. Default "harbor:". */
  guardPrefix?: string;
  /** The in-memory store whose fail("code") guards must match the SQL guard codes. */
  guardStore?: string;
  /** Directory of *.sql migrations that define the functions and raise the guards. Default "supabase/migrations". */
  migrationsDir?: string;
  /** Optional: files that must prove both backends run in CI. Omit to skip the CI-parity leg. */
  ciEvidence?: CiEvidence[];
  /** Repo root. Default process.cwd(). */
  cwd?: string;
}

/** The neobank binding — all neobank specifics live here, not in the detector. */
export const NEOBANK: ParityConfig = {
  storeSource: "supabase/functions/_shared/app/store.ts",
  opsInterface: "MoneyOps",
  stores: ["MemoryStore", "SupabaseStore"],
  sqlBackedStores: ["SupabaseStore"],
  sqlFnPrefix: "harbor_",
  guardPrefix: "harbor:",
  guardStore: "MemoryStore",
  migrationsDir: "supabase/migrations",
  ciEvidence: [
    { file: ".github/workflows/ci.yml", mustContain: ["npm run test:integration:pg"] },
    { file: ".github/workflows/helix.yml", mustContain: [/with_pg\.sh/] },
    {
      file: "tests/integration/support/harness.ts",
      mustContain: ['name: "memory"', 'name: "postgres"'],
    },
  ],
};

// --- pure source-reading primitives (repo-agnostic) -----------------------------------

const stripSqlComments = (sql: string): string => sql.replace(/--[^\n]*/g, "");

/** name -> body of every SQL function. A later `create or replace` wins, as when applied. */
function sqlFunctions(sql: string): Map<string, string> {
  const out = new Map<string, string>();
  const re =
    /create\s+(?:or\s+replace\s+)?function\s+(?:public\.)?(\w+)\s*\([\s\S]*?\$(\w*)\$([\s\S]*?)\$\2\$/gi;
  for (const m of stripSqlComments(sql).matchAll(re)) out.set(m[1].toLowerCase(), m[3]);
  return out;
}

/** Body of `export class <name>` or `export interface <name>`, brace-matched. Throws if absent. */
function block(src: string, kind: "class" | "interface", name: string): string {
  const m = new RegExp(`export ${kind} ${name}\\b[^{]*\\{`).exec(src);
  if (!m) throw new Error(`${kind} ${name} not found`);
  const start = m.index + m[0].length;
  let i = start;
  for (let depth = 1; depth > 0; i++) {
    if (i >= src.length) throw new Error(`${kind} ${name}: unbalanced braces`);
    if (src[i] === "{") depth++;
    else if (src[i] === "}") depth--;
  }
  return src.slice(start, i - 1);
}

/** Members declared at two-space indent -> their source text, up to the next member. */
function members(body: string): Map<string, string> {
  const out = new Map<string, string>();
  const head = /^ {2}(?:(?:private|protected|public|static|readonly|async)\s+)*(\w+)\s*[(<]/;
  let name: string | null = null;
  let lines: string[] = [];
  const flush = () => {
    if (name) out.set(name, (out.get(name) ?? "") + lines.join("\n"));
  };
  for (const line of body.split("\n")) {
    const m = head.exec(line);
    if (m) {
      flush();
      name = m[1];
      lines = [line];
    } else lines.push(line);
  }
  flush();
  return out;
}

const escapeRe = (s: string): string => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

// --- the parity logic ------------------------------------------------------------------

/** Pure core: all parity violations given the store source and the concatenated migration SQL. */
export function parityViolations(src: string, sql: string, cfg: ParityConfig): string[] {
  const out: string[] = [];
  const sqlFnPrefix = cfg.sqlFnPrefix ?? "harbor_";
  const guardPrefix = cfg.guardPrefix ?? "harbor:";
  const ops = [...members(block(src, "interface", cfg.opsInterface)).keys()];
  const fns = sqlFunctions(sql);

  // 1. every op implemented by every store; 2. SQL-backed stores name defined SQL functions.
  const sqlBacked = new Set(cfg.sqlBackedStores ?? []);
  const fnRef = new RegExp(`["'\`](${escapeRe(sqlFnPrefix)}\\w+)["'\`]`, "g");
  for (const store of cfg.stores) {
    const impl = members(block(src, "class", store));
    for (const op of ops) {
      const body = impl.get(op);
      if (!body) {
        out.push(`${op}: not implemented by ${store}`);
        continue;
      }
      if (!sqlBacked.has(store)) continue;
      const called = [...body.matchAll(fnRef)].map((m) => m[1]);
      if (called.length === 0) out.push(`${op}: ${store} names no ${sqlFnPrefix}* SQL function`);
      for (const f of called)
        if (!fns.has(f.toLowerCase())) out.push(`${op}: ${f} is not defined by any migration`);
    }
  }

  // 3. guard-code parity between the SQL and the guard store (both directions).
  if (cfg.guardStore) {
    const guardText = block(src, "class", cfg.guardStore);
    const guardRe = new RegExp(`'${escapeRe(guardPrefix)}(\\w+)'`, "g");
    const sqlCodes = new Set([...sql.matchAll(guardRe)].map((m) => m[1]));
    const memCodes = new Set([...guardText.matchAll(/fail\(\s*"(\w+)"/g)].map((m) => m[1]));
    for (const c of [...sqlCodes].sort())
      if (!guardText.includes(`"${c}"`))
        out.push(`guard ${c}: raised in SQL, never in ${cfg.guardStore}`);
    for (const c of [...memCodes].sort())
      if (!sqlCodes.has(c)) out.push(`guard ${c}: raised in ${cfg.guardStore}, never in SQL`);
  }
  return out;
}

function readFile(path: string, cwd?: string): string {
  return readFileSync(cwd ? `${cwd}/${path}` : path, "utf8");
}

function migrationSql(cfg: ParityConfig): string {
  const dir = cfg.migrationsDir ?? "supabase/migrations";
  const base = cfg.cwd ? `${cfg.cwd}/${dir}` : dir;
  return readdirSync(base)
    .filter((f) => f.endsWith(".sql"))
    .sort()
    .map((f) => readFileSync(`${base}/${f}`, "utf8"))
    .join("\n");
}

/** Run the detector against the live repo. */
export function detect(config: ParityConfig): Verdict {
  let src: string;
  try {
    src = readFile(config.storeSource, config.cwd);
  } catch {
    return notApplicable(`store source not found: ${config.storeSource}`);
  }
  let violations: string[];
  try {
    const sql = migrationSql(config);
    violations = parityViolations(src, sql, config);
  } catch (e) {
    // The configured interface/store/migrations are absent: the rule does not apply here.
    return notApplicable(`parity structure not present: ${(e as Error).message}`);
  }

  // CI-parity evidence (optional leg).
  for (const ev of config.ciEvidence ?? []) {
    let text: string;
    try {
      text = readFile(ev.file, config.cwd);
    } catch {
      violations.push(`CI evidence file missing: ${ev.file}`);
      continue;
    }
    for (const want of ev.mustContain) {
      const present = typeof want === "string" ? text.includes(want) : want.test(text);
      if (!present) violations.push(`${ev.file}: missing CI parity evidence ${want}`);
    }
  }

  if (violations.length) {
    return finding(`${violations.length} store/guard parity violation(s)`, { violations });
  }
  return checked("every op and guard is present on all backends; CI exercises both", {
    stores: config.stores,
  });
}

export default detect;
