// N-FX-COMPARE — portable static detector: money is only COMPARED, AGGREGATED, MATCHED or
// LIMIT-CHECKED after currencies are NORMALIZED, and FX conversion uses the per-currency minor-unit
// scale with INTEGER math — never a hardcoded /100 or *100, never Math.round(minor * floatRate), and
// never a float rate stored as money.
//
// INVARIANT: in a multi-currency money app two amounts are only commensurable once they are in the
// SAME currency. Three things therefore must hold wherever amounts meet:
//   (1) FX SCALE. A currency conversion must respect each currency's own minor-unit scale — JPY and
//       KRW have ZERO decimal places, most currencies have two — and must be done with integer math.
//       `Math.round(amountMinor * rate)` with a float rate silently assumes every currency has the
//       SAME scale (so ¥1000, stored as 1000 minor units, is treated as $10.00 worth of minor units)
//       and rounds a binary-float product of money — both lose or invent cents at scale. A float rate
//       written into a money column is the same error frozen into the books.
//   (2) COMPARE-NORMALIZE. A threshold / limit / duplicate / match comparison (<, >, ===,
//       Math.abs(diff)) between two amounts is only meaningful if their currencies are first checked
//       EQUAL or one side is CONVERTED. Comparing a foreign expense's `amount_minor` straight against
//       a policy limit, a card limit or a charge — without converting — approves or blocks the wrong
//       spend: ¥50000 (50000 minor) trivially "exceeds" a $500 (50000 minor) cap that it is actually
//       under, or slips under one it is actually over.
//   (3) AGGREGATE-SPLIT. A SUM / reduce / total of `amount_minor` over rows that each carry their own
//       currency must convert per row (or GROUP BY currency); adding raw minor units across currencies
//       produces a number that is in no currency at all.
//
// SMELL (any ONE is a FINDING):
//   A. [fx-scale] a conversion site uses a hardcoded scale (`/ 100`, `* 100`, `.toFixed(2)`) or
//      `Math.round(<minor> * <rate>)` / a float `rate` multiplied into minor units, with NO
//      per-currency minor-unit scale table in the file.
//   B. [compare-norm] a money comparison whose operands carry a DYNAMIC currency field (`x.currency`,
//      `*_currency`, a selected `currency` column) is made WITHOUT first converting or asserting the
//      currencies equal.
//   C. [aggregate-split] a `reduce` / SUM of `amount_minor` over rows that carry a currency, with NO
//      per-row conversion and no per-currency split.
//
// Like the rest of the family this is a PURE SOURCE scanner (node:fs + regex, fail-closed). Per v4 the
// money surface is DERIVED, not declared: `forSurface(deriveMoneySurface(cwd))` builds the config from
// the repo's own money files (fx.ts, services, policy.ts, expenses.ts, …), so a newly-landed money
// module is scanned the moment it exists. Only PATHS come from the surface; the FX / currency
// vocabulary lives here in the config. Dormant (NOT_APPLICABLE) when the app is single-currency: no
// currency field is read anywhere and no FX conversion is performed, so there is nothing to normalize.

import { readFileSync } from "node:fs";
import { checked, finding, notApplicable, type Verdict } from "../money-system.ts";
import { deriveMoneySurface, type DerivedSurface } from "../derive.ts";

export interface FxCompareConfig {
  /** Money files to scan (v4: surface.moneyPaths, concrete relative paths). */
  scanPaths: string[];

  // --- generic FX / currency vocabulary (app-agnostic; stays in the detector/config) ------
  /** Marks a file/region that performs a currency CONVERSION (anchors leg A and applicability). */
  fxContext: RegExp;
  /** An FX-scale smell: hardcoded /100, *100, .toFixed(2), or Math.round(minor * floatRate). */
  fxScaleSmell: RegExp;
  /** A per-currency minor-unit SCALE table / lookup (the leg-A guard). */
  scaleTable: RegExp;
  /** A money comparison: an amount/limit/threshold operand next to a relational/equality operator. */
  moneyCompare: RegExp;
  /** A DYNAMIC currency field being read (`x.currency`, `*_currency`, a selected `currency` column). */
  currencyFieldRead: RegExp;
  /** Currencies normalized before use: a conversion call, or a currency-equality assertion. */
  currencyNormalized: RegExp;
  /** A SUM / reduce of a minor-unit amount (anchors leg C). */
  sumMinorReduce: RegExp;
  /** Repo root. Default process.cwd(). */
  cwd?: string;
}

/**
 * The generic FX / currency vocabulary. NO paths and NO table names here — only the idioms that say
 * "this converts a currency / compares amounts / sums minor units / reads a currency field". Paths
 * come from the surface.
 */
export const FX_SMELLS: Omit<FxCompareConfig, "scanPaths" | "cwd"> = {
  // a conversion is happening: convertMinor( / fxRate( / fxConvert( / toBase( / toUsd( / an exchange_rate
  // / original_currency column / a from===to currency short-circuit / a RATES rate table.
  fxContext:
    /\bconvert(?:Minor|Currency|Amount|Money)?\s*\(|\bfx(?:Rate|Convert)\s*\(|\bto(?:Base|Usd|USD)Minor?\s*\(|\bexchange_?rate\b|\boriginal_currency\b|\bRATES\b/i,
  // hardcoded scale or float-rate money math. `Math.round( … * …rate )`, `.toFixed(2)`, or a minor-unit
  // value multiplied/divided by a literal 100 (the "every currency has 2 decimals" assumption).
  fxScaleSmell:
    /Math\.round\s*\([^;{}]*\*[^;{}]*\brate\b[^;{}]*\)|\.toFixed\s*\(\s*2\s*\)|(?:[A-Za-z_$][\w$.]*)?(?:[Mm]inor|[Cc]ents)\s*[*/]\s*100\b|\b100\s*[*/]\s*(?:[A-Za-z_$][\w$.]*)?(?:[Mm]inor|[Cc]ents)\b/,
  // a per-currency minor-unit scale table / lookup: MINOR_UNITS / CURRENCY_SCALE / minorUnits /
  // decimalsFor / scaleFor / a `minor_units` column — the thing that encodes "JPY has 0 decimals".
  scaleTable:
    /\b(?:MINOR_UNITS|CURRENCY_SCALE|minorUnits|minorUnitScale|currencyScale|decimalsFor|scaleFor|DECIMALS|minor_units)\b/,
  // an amount/limit/threshold identifier adjacent to a relational/equality operator (either side).
  moneyCompare: new RegExp(
    "(?:[A-Za-z_$][\\w$.]*)?(?:[Mm]inor|[Cc]ents|amount_minor|[Aa]mountMinor|\\bcap\\b|\\blimit\\b|limit_minor|max_amount_minor|\\bthreshold\\b|minMinor)\\s*(?:<=?|>=?|===|!==|==|!=)" +
      "|(?:<=?|>=?|===|!==|==|!=)\\s*(?:[A-Za-z_$][\\w$.]*)?(?:[Mm]inor|[Cc]ents|amount_minor|[Aa]mountMinor|\\bcap\\b|\\blimit\\b|max_amount_minor|\\bthreshold\\b|minMinor)",
  ),
  // a DYNAMIC currency field read: `x.currency`, `foo_currency`, or a `currency` column in a select.
  // A literal `currency: "USD"` assignment is NOT a dynamic read, so single-currency code is not flagged.
  currencyFieldRead:
    /\b[A-Za-z_$][\w$]*\.currency\b|\b[A-Za-z_$][\w$]*_currency\b|select\s*\(\s*["'][^"']*\bcurrency\b/i,
  // currencies made commensurable first: a conversion call, or a currency-equality assertion.
  currencyNormalized:
    /\bconvert(?:Minor|Currency|Amount|Money)?\s*\(|\bfx(?:Rate|Convert)\s*\(|\bto(?:Base|Usd|USD)Minor?\s*\(|\bnormaliz|\bassertSameCurrency\b|\bsameCurrency\b|[A-Za-z_$][\w$]*\.currency\s*(?:===|!==|==|!=)|(?:===|!==|==|!=)\s*[A-Za-z_$][\w$]*\.currency/i,
  // a reduce/SUM that adds a minor-unit amount.
  sumMinorReduce:
    /\.reduce\s*\(\s*\([^)]*\)\s*=>[\s\S]{0,120}?\+[\s\S]{0,80}?(?:amount_minor|[Aa]mountMinor|[A-Za-z_$][\w$.]*_minor\b|[A-Za-z_$][\w$.]*[Mm]inor\b)|\bSUM\s*\(\s*[a-z_]*amount[a-z_]*_?minor/i,
};

// --- pure source-reading primitives (repo-agnostic; mirror the other static detectors) -

/** 1-based line number of the character at `idx`. */
const lineAt = (text: string, idx: number): number => text.slice(0, idx).split("\n").length;

/** `re` as a non-global clone (so a shared /g/ regex's lastIndex can't leak between calls). */
const flat = (re: RegExp): RegExp => new RegExp(re.source, re.flags.replace("g", ""));

/** Does `re` match anywhere in `text`? */
const has = (re: RegExp, text: string): boolean => flat(re).test(text);

/** Every start index of `re` in `text`. */
function allIdx(text: string, re: RegExp): number[] {
  const g = new RegExp(re.source, re.flags.includes("g") ? re.flags : re.flags + "g");
  const out: number[] = [];
  let m: RegExpExecArray | null;
  while ((m = g.exec(text))) {
    out.push(m.index);
    if (m.index === g.lastIndex) g.lastIndex++;
  }
  return out;
}

/**
 * Split a source file into function / method regions: each region is a `name(...) { … }` header and
 * the body up to the next such header. Works for top-level functions and indented class methods.
 * Inline arrow callbacks are not headers, so a method's body (its reduces, comparisons) is captured
 * whole. Mirrors n-lifecycle's functionRegions.
 */
export function functionRegions(text: string): Array<{ text: string; base: number }> {
  const headerRe =
    /\n[ \t]*(?:export\s+)?(?:public\s+|private\s+|protected\s+)?(?:static\s+)?(?:async\s+)?(?:function\s+)?[A-Za-z_$][\w$]*\s*\([^)]*\)\s*(?::[^;{]*)?\{/g;
  const starts: number[] = [];
  let m: RegExpExecArray | null;
  while ((m = headerRe.exec(text))) starts.push(m.index);
  if (!starts.length) return [{ text, base: 0 }];
  const out: Array<{ text: string; base: number }> = [];
  for (let i = 0; i < starts.length; i++) {
    const end = i + 1 < starts.length ? starts[i + 1]! : text.length;
    out.push({ text: text.slice(starts[i]!, end), base: starts[i]! });
  }
  return out;
}

// --- the FX / currency logic -----------------------------------------------------------

export interface FxCompareScan {
  /** "<file>:<line> [<leg>] — <why>" for each FX / currency smell found. */
  violations: string[];
  /** "<file>:<line> [<leg>] — <why>" for each site found to be safe. */
  guarded: string[];
  /** The invariant is live here: a conversion is performed OR a dynamic currency field is read. */
  present: boolean;
}

/**
 * Pure core. For each money file, run the three independent legs — fx-scale (A), compare-normalize
 * (B), aggregate-split (C). Any leg's smell is a violation; a site whose guard holds is recorded as
 * guarded. `present` is true once ANY currency conversion or dynamic-currency read is seen, so a
 * single-currency app is dormant (NOT_APPLICABLE).
 */
export function scanFxCompare(files: Array<{ path: string; text: string }>, cfg: FxCompareConfig): FxCompareScan {
  const out: FxCompareScan = { violations: [], guarded: [], present: false };

  for (const { path, text } of files) {
    const fileDoesFx = has(cfg.fxContext, text);
    const hasScaleTable = has(cfg.scaleTable, text);
    if (fileDoesFx || has(cfg.currencyFieldRead, text)) out.present = true;

    // --- leg A: a conversion site must use a per-currency scale table + integer math --------
    if (fileDoesFx && !hasScaleTable) {
      for (const idx of allIdx(text, cfg.fxScaleSmell)) {
        out.violations.push(
          `${path}:${lineAt(text, idx)} [fx-scale] — a currency conversion uses a hardcoded scale ` +
            `(\`/ 100\`, \`* 100\`, \`.toFixed(2)\`) or \`Math.round(<minor> * <rate>)\` with a float rate, and ` +
            `the file has NO per-currency minor-unit scale table: this assumes every currency has the same ` +
            `number of decimals (JPY/KRW have ZERO), so ¥-denominated minor units are scaled as if they were ` +
            `cents and the converted amount is wrong [smell A: fx scale]`,
        );
      }
    } else if (fileDoesFx && hasScaleTable) {
      out.guarded.push(
        `${path} [fx-scale] — currency conversion is backed by a per-currency minor-unit scale table ` +
          `(JPY/KRW = 0 decimals) and integer math, not a hardcoded /100 or a float-rate product`,
      );
    }

    // --- legs B & C operate per routine -----------------------------------------------------
    for (const region of functionRegions(text)) {
      const rt = region.text;
      const dynamicCurrency = has(cfg.currencyFieldRead, rt);
      const normalized = has(cfg.currencyNormalized, rt);

      // --- leg B: a money comparison over dynamic-currency operands must normalize first -----
      const cmpIdxs = allIdx(rt, cfg.moneyCompare);
      if (cmpIdxs.length && dynamicCurrency) {
        const cite = `${path}:${lineAt(text, region.base + cmpIdxs[0]!)}`;
        if (!normalized) {
          out.violations.push(
            `${cite} [compare-norm] — a threshold / limit / match comparison is made between amounts that ` +
              `carry a DYNAMIC currency field, with NO conversion and no currency-equality check first: a ` +
              `foreign amount is compared raw against a limit/charge, so the wrong spend is approved or blocked ` +
              `(¥50000 and $500 are both "50000 minor") [smell B: compare without normalize]`,
          );
        } else {
          out.guarded.push(
            `${cite} [compare-norm] — amounts are converted (or their currencies asserted equal) before the comparison`,
          );
        }
      }

      // --- leg C: a SUM / reduce of minor units over currency-bearing rows must convert ------
      const sumIdxs = allIdx(rt, cfg.sumMinorReduce);
      if (sumIdxs.length && dynamicCurrency) {
        const cite = `${path}:${lineAt(text, region.base + sumIdxs[0]!)}`;
        if (!normalized) {
          out.violations.push(
            `${cite} [aggregate-split] — a SUM/reduce of \`amount_minor\` runs over rows that each carry their ` +
              `own currency, with NO per-row conversion and no per-currency split: raw minor units are added ` +
              `across currencies, so the total is in no currency at all [smell C: aggregate across currencies]`,
          );
        } else {
          out.guarded.push(
            `${cite} [aggregate-split] — the minor-unit total converts each row to a base currency before summing`,
          );
        }
      }
    }
  }

  return out;
}

/** Convenience core, matching the other detectors' `<name>Violations(): string[]` shape. */
export function fxCompareViolations(files: Array<{ path: string; text: string }>, cfg: FxCompareConfig): string[] {
  return scanFxCompare(files, cfg).violations;
}

// --- file plumbing ---------------------------------------------------------------------

function readFile(path: string, cwd?: string): string {
  return readFileSync(cwd ? `${cwd}/${path}` : path, "utf8");
}

// --- the v4 surface binding ------------------------------------------------------------

/**
 * Build the detector config from a DERIVED money surface. Only the PATHS come from the surface
 * (surface.moneyPaths — the repo's own money files, recomputed every run); the FX / currency
 * vocabulary is the fixed `FX_SMELLS`. This is the v4 contract: `detect(forSurface(deriveMoneySurface(cwd)))`.
 */
export function forSurface(surface: Pick<DerivedSurface, "moneyPaths" | "cwd">): FxCompareConfig {
  return { ...FX_SMELLS, scanPaths: surface.moneyPaths, cwd: surface.cwd };
}

// --- the verdict -----------------------------------------------------------------------

/** Run the detector against the live repo. */
export function detect(config: FxCompareConfig): Verdict {
  const files: Array<{ path: string; text: string }> = [];
  for (const p of config.scanPaths) {
    if (/[*?]/.test(p)) continue; // a glob (hand-declared surface); v4 derivation yields concrete files
    try {
      files.push({ path: p, text: readFile(p, config.cwd) });
    } catch {
      /* absent here (another repo, an empty fixture); skip it. */
    }
  }

  const scan = scanFxCompare(files, config);

  if (!scan.present) {
    return notApplicable(
      "no currency conversion and no dynamic currency field was found in the derived money files — the app is " +
        "single-currency here, so there is nothing to normalize before comparing or aggregating (invariant dormant)",
    );
  }
  if (scan.violations.length) {
    return finding(
      `money is compared / aggregated / converted without a consistent currency scale: ${scan.violations.length} ` +
        `smell(s) across fx-scale / compare-normalize / aggregate-split — a foreign amount can be mis-scaled on ` +
        `conversion or compared raw against a limit, approving or blocking the wrong spend`,
      { violations: scan.violations, guarded: scan.guarded },
    );
  }
  return checked(
    "every currency conversion uses a per-currency minor-unit scale with integer math, and every money " +
      "comparison / aggregation normalizes currency first — amounts are only ever compared when commensurable",
    { guarded: scan.guarded },
  );
}

/** v4 convenience: derive the surface from `cwd` and run. */
export function detectRepo(cwd: string): Verdict {
  const surface = deriveMoneySurface(cwd);
  return detect(forSurface({ ...surface, cwd }));
}

export default detect;
