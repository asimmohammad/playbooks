// N-ORPHAN-01 — portable static detector: the issuer card is cancelled ONLY when the durable write
// fails, never because a post-commit step throws.
//
// INVARIANT: a path that mints an issuer card and then durably writes the local card row must cancel
// the issuer card ONLY if that durable write fails. A post-commit step — an `audit(...)` log, a
// notification — that runs AFTER the row is committed-active must NOT sit inside the same try whose
// catch cancels the issuer card. If it does, a throw from that post-commit step cancels a live,
// committed card at the issuer: the local row says `active`, the issuer says `canceled`, every
// authorization then fails at the network, and support has no record of why (an "anti-orphan": the
// mirror of the classic orphan, caused by over-broad cleanup rather than missing cleanup).
//
// This converts the behavioural NO-ORPHAN rule (which injected a post-create fault through the
// adapter) into an adapter-free SOURCE scan, because the #28 defect lives in a path the hand-written
// adapter never drove (familyInviteAccept) — so a behavioural run reported a false pass. A source
// scan reads the try/catch shape directly.
//
// GENERALITY: it keys on the STABLE surfaces — the issuer mint call, the issuer-cancel call, and the
// `audit(...)` post-commit step — not on a method name, so it fires on any accept/replace/remove
// path an independent rebuild writes. Fails CLOSED on the audit-in-cancel-try shape. NOT_APPLICABLE
// when the app has no issuer-mint path at all.

import { readFileSync } from "node:fs";
import { checked, finding, notApplicable, type Verdict } from "../money-system.ts";

export interface OrphanConfig {
  /** App/service source files where issuer mint + durable-write paths live. */
  appSources: string[];
  /** The issuer-mint call (its presence makes the invariant applicable), e.g. /\bcreateCard\s*\(/. */
  mintMarker: RegExp;
  /** The issuer-cancel call that must fire ONLY on a durable-write failure. */
  cancelMarker: RegExp;
  /** A post-commit step (e.g. an audit log) that must NOT sit inside the cancel-guarded try. */
  postCommitMarker: RegExp;
  /** How far back (chars) to look for the guarded mint before a try — the same function. Default 900. */
  mintWindow?: number;
  /** Repo root. Default process.cwd(). */
  cwd?: string;
}

/** The neobank binding — all neobank specifics live here, in config, never in the detector. */
export const NEOBANK: OrphanConfig = {
  appSources: ["supabase/functions/_shared/app/service.ts"],
  mintMarker: /\bcreateCard\s*\(/,
  cancelMarker:
    /cancelIssuerCard\s*\(|cancelCard\s*\(|setStatus\s*\([^)]*,\s*["']canceled["']\s*\)/,
  postCommitMarker: /\baudit\s*\(/,
  mintWindow: 900,
};

// --- pure source-reading primitives (repo-agnostic) -----------------------------------

/** Every `try { ... } catch (...) { ... }` pair, brace-matched. */
export function tryCatchBlocks(
  src: string,
): { tryStart: number; tryBody: string; catchBody: string }[] {
  const out: { tryStart: number; tryBody: string; catchBody: string }[] = [];
  const tryRe = /\btry\s*\{/g;
  for (const m of src.matchAll(tryRe)) {
    const tryOpen = m.index + m[0].length - 1; // the "{"
    let d = 1;
    let i = tryOpen + 1;
    for (; i < src.length && d > 0; i++) {
      if (src[i] === "{") d++;
      else if (src[i] === "}") d--;
    }
    const tryBody = src.slice(tryOpen, i);
    const cm = /^\s*catch\s*(?:\([^)]*\))?\s*\{/.exec(src.slice(i));
    if (!cm) continue;
    const catchOpen = i + cm[0].length - 1;
    let d2 = 1;
    let j = catchOpen + 1;
    for (; j < src.length && d2 > 0; j++) {
      if (src[j] === "{") d2++;
      else if (src[j] === "}") d2--;
    }
    out.push({ tryStart: m.index, tryBody, catchBody: src.slice(catchOpen, j) });
  }
  return out;
}

/** The name of the nearest enclosing function/method header before `idx` (for verdict labels). */
const KEYWORD = new Set(["if", "for", "while", "switch", "catch", "return", "await", "function"]);
function enclosingFn(src: string, idx: number): string {
  const head = /(?:async\s+)?(\w+)\s*\([^)]*\)\s*(?::[^{;]+)?\{/g;
  let name = "?";
  for (const m of src.slice(0, idx).matchAll(head)) if (!KEYWORD.has(m[1])) name = m[1];
  return name;
}

// --- the anti-orphan logic -------------------------------------------------------------

export interface OrphanScan {
  /** "<fn>: <why>" for each cancel-guarded try that also holds a post-commit step. */
  violations: string[];
  /** The app has an issuer-mint path (else the detector is dormant). */
  applicable: boolean;
}

/**
 * Pure core: a try whose CATCH cancels the issuer card, whose TRY body also contains a post-commit
 * step, and that is reached from an issuer mint (the mint appears shortly before the try, i.e. the
 * same function), is a violation — the cancel can fire for a post-commit throw on a committed card.
 */
export function scanOrphan(appText: string, cfg: OrphanConfig): OrphanScan {
  const out: OrphanScan = { violations: [], applicable: cfg.mintMarker.test(appText) };
  if (!out.applicable) return out;
  const window = cfg.mintWindow ?? 900;
  for (const b of tryCatchBlocks(appText)) {
    const cancelsInCatch = cfg.cancelMarker.test(b.catchBody);
    const postCommitInTry = cfg.postCommitMarker.test(b.tryBody);
    const mintBefore = cfg.mintMarker.test(
      appText.slice(Math.max(0, b.tryStart - window), b.tryStart),
    );
    if (cancelsInCatch && postCommitInTry && mintBefore) {
      out.violations.push(
        `${enclosingFn(appText, b.tryStart)}: a post-commit step runs inside the try whose catch ` +
          `cancels the issuer card — a throw after the durable write cancels a committed-active card ` +
          `(local row active, issuer canceled)`,
      );
    }
  }
  return out;
}

/** Convenience core, matching the other detectors' `<name>Violations(): string[]` shape. */
export function orphanViolations(appText: string, cfg: OrphanConfig): string[] {
  return scanOrphan(appText, cfg).violations;
}

function readFile(path: string, cwd?: string): string {
  return readFileSync(cwd ? `${cwd}/${path}` : path, "utf8");
}

function appSourcesText(cfg: OrphanConfig): string {
  const parts: string[] = [];
  for (const f of cfg.appSources) {
    try {
      parts.push(readFile(f, cfg.cwd));
    } catch {
      // a source this binding names is absent here; skip it.
    }
  }
  return parts.join("\n");
}

/** Run the detector against the live repo. */
export function detect(config: OrphanConfig): Verdict {
  const appText = appSourcesText(config);
  if (!appText) return notApplicable("none of the configured app sources were found");
  const scan = scanOrphan(appText, config);
  if (!scan.applicable) {
    return notApplicable("no issuer-mint path is present in this repo");
  }
  if (scan.violations.length) {
    return finding(
      `${scan.violations.length} mint path(s) cancel the issuer card for a post-commit failure, not only a durable-write failure`,
      { violations: scan.violations },
    );
  }
  return checked(
    "the issuer-cancel cleanup guards only the durable write; no post-commit step sits inside it",
  );
}

export default detect;
