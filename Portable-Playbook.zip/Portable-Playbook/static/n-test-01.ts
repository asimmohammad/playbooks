// N-TEST-01 — portable static detector: test integrity (no silently-weakened money assertions).
//
// INVARIANT: a branch may not make the pipeline green by LOOSENING a money assertion. If a
// test that exists on the base branch asserts an exact money value and the branch removes
// or weakens that assertion (e.g. `toBe(250_000)` -> `toBeGreaterThan(0)`) without also
// recording the behaviour change in a spec-of-record file, that is a FINDING — a passing
// suite then proves less than it did. A genuine MOVE of the same assertion (removed here,
// re-added verbatim elsewhere) is fine; a new test file is fine.
//
// This is a git-DIFF scanner over pure text. It is parameterised by the money-assertion
// pattern, the guarded test paths and the spec-of-record paths, so it carries no
// neobank-specific knowledge — only the config does.

import { execFileSync } from "node:child_process";
import { checked, finding, notApplicable, type Verdict } from "../money-system.ts";

export interface TestIntegrityConfig {
  /** Path specs whose test files are guarded, e.g. ["tests", "e2e"]. */
  testPaths: string[];
  /** Pattern identifying a money assertion whose weakening is a finding. */
  moneyAssertion: RegExp;
  /** Paths whose change in the same branch justifies an assertion change (the spec of record). */
  justificationPaths?: string[];
  /** Env var naming the base ref (CI: the PR base). Default "HELIX_BASE_REF". */
  baseRefEnv?: string;
  /** Fallback base ref. Default "origin/main". */
  defaultBaseRef?: string;
  /** Repo root. Default process.cwd(). */
  cwd?: string;
}

/**
 * A money assertion: `expectCents(...)`, or an `expect(...)` naming a cents value before the
 * statement ends. Exported so the config and other rules share one definition.
 */
export const MONEY_ASSERTION = /\bexpectCents\s*\(|\bexpect\s*\([^;]*cents/i;

/** The neobank binding — all neobank specifics live here, in config. */
export const NEOBANK: TestIntegrityConfig = {
  testPaths: ["tests", "e2e"],
  moneyAssertion: MONEY_ASSERTION,
  justificationPaths: ["docs/SPEC.md"],
};

/**
 * Pure core: given a unified diff (`git diff -U0`) over the test paths and whether a
 * spec-of-record file changed, list the money assertions this branch removed or changed
 * on PRE-EXISTING files without re-adding them verbatim (a move) and without a spec change.
 */
export function weakenedAssertions(
  unifiedDiff: string,
  specChanged: boolean,
  moneyAssertion: RegExp,
): string[] {
  if (specChanged) return [];
  const isMoney = (code: string) => moneyAssertion.test(code);
  const removed: { file: string; code: string }[] = [];
  const added = new Set<string>();
  let file = "";
  let existed = true;
  for (const l of unifiedDiff.split("\n")) {
    if (l.startsWith("diff --git ")) {
      file = l.slice(l.indexOf(" b/") + 3);
      existed = true;
    } else if (l.startsWith("new file mode")) existed = false;
    else if (l.startsWith("--- ") || l.startsWith("+++ ")) continue;
    else if (l.startsWith("-") && existed && isMoney(l.slice(1)))
      removed.push({ file, code: l.slice(1).trim() });
    else if (l.startsWith("+") && isMoney(l.slice(1))) added.add(l.slice(1).trim());
  }
  return removed
    .filter((r) => !added.has(r.code))
    .map((r) => `${r.file}: money assertion removed or changed: ${r.code}`);
}

function resolveBaseRef(cfg: TestIntegrityConfig): string | null {
  const ref =
    process.env[cfg.baseRefEnv ?? "HELIX_BASE_REF"] || cfg.defaultBaseRef || "origin/main";
  try {
    execFileSync("git", ["rev-parse", "--verify", "--quiet", `${ref}^{commit}`], {
      stdio: "pipe",
      cwd: cfg.cwd,
    });
    return ref;
  } catch {
    return null;
  }
}

const gitDiff = (base: string, args: string[], cwd?: string): string =>
  execFileSync("git", ["diff", "--no-color", `${base}...HEAD`, ...args], {
    encoding: "utf8",
    maxBuffer: 64 * 1024 * 1024,
    cwd,
  });

/** Run the detector against the live repo. */
export function detect(config: TestIntegrityConfig): Verdict {
  const base = resolveBaseRef(config);
  if (base === null) {
    return notApplicable(
      "base ref not resolvable — set HELIX_BASE_REF or fetch origin/main (the diff could not run)",
    );
  }
  const diff = gitDiff(base, ["-U0", "--", ...config.testPaths], config.cwd);
  const specChanged =
    (config.justificationPaths?.length ?? 0) > 0 &&
    gitDiff(base, ["--name-only", "--", ...config.justificationPaths!], config.cwd).trim() !== "";
  const violations = weakenedAssertions(diff, specChanged, config.moneyAssertion);
  if (violations.length) {
    return finding(`${violations.length} money assertion(s) weakened without a spec change`, {
      base,
      violations,
    });
  }
  return checked("no pre-existing money assertion was weakened since base", { base, specChanged });
}

export default detect;
