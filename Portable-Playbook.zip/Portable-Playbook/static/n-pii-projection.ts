// N-PII-PROJECTION — portable static detector: a client-facing list/read of a money entity does NOT
// project SENSITIVE identity / bank fields (tax id, bank account, full card number) to the client.
//
// INVARIANT: a money app's entity tables carry sensitive identity and banking fields — a vendor's tax
// id (TIN / EIN), an employee's SSN, a card's full PAN, a bank account / routing / IBAN. Those columns
// exist so the server can file a 1099, screen a payee, or push a payout; they are NEVER meant to reach
// a browser. The one thing standing between "stored for the server" and "leaked to every list consumer"
// is the PROJECTION of a client-facing read: a list/get endpoint must name an EXPLICIT column set that
// excludes the sensitive fields. The moment such a read is a `select("*")` (or otherwise returns the
// raw row), every sensitive column on that table rides out to the client — a vendor directory that
// hands back TINs, a card list that hands back the full PAN. The leak is silent: the endpoint "works",
// the UI shows what it needs, and the extra columns sit in the JSON payload for anyone who looks. (This
// is pmar PR12: GET /v1/vendors -> listVendors did `.from("vendors").select("*")`, projecting the
// `tin` column of every vendor to the client.)
//
// SMELL (any ONE client-facing read of a sensitive-column table in this state is a FINDING):
//   A. [wildcard-projection] a supabase `.from(<table>).select("*")` where <table> is defined with a
//      SENSITIVE column (tin / tax_id / ssn / ein / bank_account / account_number / routing / iban /
//      pan_token / card_number) — the wildcard projects that column to the client.
//   B. [explicit-sensitive] a `.from(<table>).select("... <sensitive col> ...")` that NAMES a sensitive
//      column of such a table in the client projection — the leak is explicit rather than wildcard.
// A read is CHECKED when its projection of a sensitive-column table is an explicit column set that
// EXCLUDES every sensitive column (a `tin_status` flag may ship; the raw `tin` may not).
//
// Like the rest of the family this is a PURE SOURCE scanner (node:fs + regex, fail-closed). Per v4 the
// money surface is DERIVED, not declared: `forSurface(deriveMoneySurface(cwd))` builds the config from
// the repo's own schema + money files, so a newly-landed sensitive column or a new list endpoint is in
// scope the moment it exists. Only PATHS/TABLES come from the surface — surface.schemaFiles says which
// tables carry a sensitive column, surface.moneyPaths + surface.httpEntry are the reads to scan; the
// sensitive-field vocabulary and the supabase read idioms live here in the config. Dormant
// (NOT_APPLICABLE) until a client-facing read of a sensitive-column table is actually present.

import { readFileSync } from "node:fs";
import { checked, finding, notApplicable, type Verdict } from "../money-system.ts";
import { deriveMoneySurface, type DerivedSurface } from "../derive.ts";
import { type MoneySurface } from "../adapters/pmar.ts";

export interface PiiProjectionConfig {
  /** Files to scan for client-facing reads (v4: surface.moneyPaths + surface.httpEntry, concrete paths). */
  scanPaths: string[];
  /** Schema file(s) defining the entity tables and their columns (v4: surface.schemaFiles). */
  schemaFiles: string[];
  /** The surface's money tables — supplementary context for the verdict (v4: surface.moneyTables). */
  knownMoneyTables: string[];

  // --- generic sensitive-projection vocabulary (app-agnostic; stays in the detector/config) ---
  /** A column name that is SENSITIVE identity / bank data — must never ride out to the client. */
  sensitiveColumn: RegExp;
  /** A supabase table read: `.from("<table>").select(<arg>)`. Capture 1 = table, capture 2 = select arg. */
  tableSelect: RegExp;
  /** A wildcard projection argument: `"*"`. */
  wildcardArg: RegExp;
  /** Repo root. Default process.cwd(). */
  cwd?: string;
}

/**
 * The GENERIC sensitive-projection vocabulary. NO table names and NO paths here — only the idioms that
 * say "this column is sensitive" and "this is a supabase row read". Paths/tables come from the surface.
 */
export const PII_SMELLS: Omit<PiiProjectionConfig, "scanPaths" | "schemaFiles" | "knownMoneyTables" | "cwd"> = {
  // tax id / SSN / EIN / bank account / routing / IBAN / full card number columns. Word-bounded so a
  // benign `tin_status` flag column does NOT match the raw `tin`, and `pan_token` is named explicitly
  // rather than via a bare `pan` that could catch unrelated identifiers.
  sensitiveColumn:
    /\b(?:tin|tax_?id|taxpayer_?id|ssn|social_security|ein|bank_account(?:_number)?|account_number|acct_number|routing(?:_number)?|aba|iban|swift|pan_token|full_pan|card_number)\b/i,
  // `.from("vendors").select("*")` / `.from('cards').select("id, ...")`. The select must follow the from
  // (optional whitespace/newline between), so an insert/update/delete chain is NOT matched as a read.
  tableSelect: /\.from\s*\(\s*["'`](\w+)["'`]\s*\)\s*\.select\s*\(\s*(["'`][^"'`]*["'`])/,
  wildcardArg: /^\*$/,
};

/** The pmar binding — pmar specifics via the derived surface; vocabulary is the fixed PII_SMELLS. */
export const PMAR = (surface: MoneySurface): PiiProjectionConfig => forSurface(surface);

// --- pure source-reading primitives (repo-agnostic; mirror the other static detectors) -

/** 1-based line number of the character at `idx`. */
const lineAt = (text: string, idx: number): number => text.slice(0, idx).split("\n").length;

/** `re` as a non-global clone (so a shared regex's lastIndex can't leak between calls). */
const flat = (re: RegExp): RegExp => new RegExp(re.source, re.flags.replace("g", ""));

/** Strip SQL `--` line comments (so a column word inside a comment is not read as a real column). */
const stripSqlComments = (text: string): string => text.replace(/--[^\n]*/g, "");

/**
 * Extract `create table <name> ( <body> )` blocks from a schema text (SQL or a TS template string),
 * paren-balanced so a column's own `(...)` does not end the body early. Returns table name -> body.
 * Comment-stripped so a word inside a `-- ...` comment is not mistaken for a column.
 */
export function createTables(text: string): Map<string, string> {
  const src = stripSqlComments(text);
  const head =
    /create\s+(?:(?:global|local)\s+)?(?:unlogged\s+|temp(?:orary)?\s+)?table\s+(?:if\s+not\s+exists\s+)?(?:public\.)?["`']?(\w+)["`']?\s*\(/gi;
  const out = new Map<string, string>();
  let m: RegExpExecArray | null;
  while ((m = head.exec(src)) !== null) {
    const name = m[1]!.toLowerCase();
    const start = head.lastIndex; // first char inside the opening paren
    let depth = 1;
    let i = start;
    for (; i < src.length && depth > 0; i++) {
      const ch = src[i];
      if (ch === "(") depth++;
      else if (ch === ")") depth--;
    }
    out.set(name, src.slice(start, i - 1));
  }
  return out;
}

// --- the sensitive-projection logic ----------------------------------------------------

/** Which tables carry a sensitive column, and the sensitive column names each has. */
export function sensitiveTablesOf(schemaText: string, sensitiveColumn: RegExp): Map<string, string[]> {
  const re = new RegExp(sensitiveColumn.source, sensitiveColumn.flags.includes("g") ? sensitiveColumn.flags : sensitiveColumn.flags + "g");
  const out = new Map<string, string[]>();
  for (const [name, body] of createTables(schemaText)) {
    const cols: string[] = [];
    re.lastIndex = 0;
    let m: RegExpExecArray | null;
    while ((m = re.exec(body)) !== null) {
      cols.push(m[0].toLowerCase());
      if (m.index === re.lastIndex) re.lastIndex++;
    }
    if (cols.length) out.set(name.toLowerCase(), [...new Set(cols)]);
  }
  return out;
}

export interface PiiScan {
  /** "<file>:<line> [<leg>] — <why>" for each client-facing read that leaks a sensitive column. */
  violations: string[];
  /** "<file>:<line> — <why>" for each client-facing read of a sensitive table that is safely projected. */
  guarded: string[];
  /** At least one client-facing read of a sensitive-column table was found (else dormant). */
  present: boolean;
  /** The sensitive tables derived from the schema (for the verdict detail). */
  sensitiveTables: Record<string, string[]>;
}

/**
 * Pure core. From the schema, learn which tables carry a sensitive column. Then over every scan file
 * find each supabase row read (`.from(<table>).select(<arg>)`); for a read of a sensitive table,
 * classify its projection: a `"*"` wildcard (leg A) or an explicit set that NAMES a sensitive column
 * (leg B) is a violation; an explicit set that excludes every sensitive column is guarded.
 */
export function scanPiiProjection(
  schemaText: string,
  files: Array<{ path: string; text: string }>,
  cfg: PiiProjectionConfig,
): PiiScan {
  const sens = sensitiveTablesOf(schemaText, cfg.sensitiveColumn);
  const out: PiiScan = { violations: [], guarded: [], present: false, sensitiveTables: Object.fromEntries(sens) };
  const readRe = new RegExp(cfg.tableSelect.source, cfg.tableSelect.flags.includes("g") ? cfg.tableSelect.flags : cfg.tableSelect.flags + "g");
  const colSens = flat(cfg.sensitiveColumn);

  for (const { path, text } of files) {
    readRe.lastIndex = 0;
    let m: RegExpExecArray | null;
    while ((m = readRe.exec(text)) !== null) {
      const table = (m[1] ?? "").toLowerCase();
      const sensCols = sens.get(table);
      if (!sensCols) continue; // a read of a non-sensitive table is not this invariant's concern
      out.present = true;

      const rawArg = (m[2] ?? "").replace(/^["'`]|["'`]$/g, "").trim();
      const cite = `${path}:${lineAt(text, m.index)}`;

      if (cfg.wildcardArg.test(rawArg)) {
        out.violations.push(
          `${cite} [wildcard-projection] — a client-facing read of \`${table}\` uses \`select("*")\`, ` +
            `projecting its sensitive column(s) (${sensCols.join(", ")}) straight to the client: every ` +
            `row's ${sensCols.join("/")} rides out in the response payload — a sensitive-field leak [smell A]`,
        );
        continue;
      }

      // explicit projection: does it name any sensitive column of this table?
      const named = rawArg
        .split(",")
        .map((c) => c.trim())
        .filter((c) => c && colSens.test(c));
      if (named.length) {
        out.violations.push(
          `${cite} [explicit-sensitive] — a client-facing read of \`${table}\` explicitly projects a ` +
            `sensitive column (${named.join(", ")}) in its client column set (\`${rawArg.slice(0, 80)}\`): ` +
            `the sensitive field is handed to the client [smell B]`,
        );
      } else {
        out.guarded.push(
          `${cite} — the read of \`${table}\` projects an explicit column set that EXCLUDES its sensitive ` +
            `column(s) (${sensCols.join(", ")}) — no sensitive field reaches the client`,
        );
      }
    }
  }
  return out;
}

/** Convenience core, matching the other detectors' `<name>Violations(): string[]` shape. */
export function piiProjectionViolations(
  schemaText: string,
  files: Array<{ path: string; text: string }>,
  cfg: PiiProjectionConfig,
): string[] {
  return scanPiiProjection(schemaText, files, cfg).violations;
}

// --- file plumbing ---------------------------------------------------------------------

function readFile(path: string, cwd?: string): string {
  return readFileSync(cwd ? `${cwd}/${path}` : path, "utf8");
}

/** Read each path that exists; a glob or an absent file is simply skipped. */
function readAll(paths: string[], cwd?: string): Array<{ path: string; text: string }> {
  const seen = new Set<string>();
  const out: Array<{ path: string; text: string }> = [];
  for (const p of paths) {
    if (/[*?]/.test(p) || seen.has(p)) continue; // a glob (hand-declared surface); v4 derivation is concrete
    seen.add(p);
    try {
      out.push({ path: p, text: readFile(p, cwd) });
    } catch {
      /* absent here (another repo, an empty fixture); skip it. */
    }
  }
  return out;
}

// --- the v4 surface binding ------------------------------------------------------------

/**
 * Build the detector config from a DERIVED money surface. Only PATHS/TABLES come from the surface:
 * surface.schemaFiles (which tables carry a sensitive column), surface.moneyPaths + surface.httpEntry
 * (the reads to scan), surface.moneyTables (verdict context). The sensitive-field vocabulary and the
 * supabase read idioms are the fixed PII_SMELLS. This is the v4 contract:
 * `detect(forSurface(deriveMoneySurface(cwd)))`.
 */
export function forSurface(
  surface: Pick<DerivedSurface, "moneyPaths" | "httpEntry" | "schemaFiles" | "moneyTables" | "cwd">,
): PiiProjectionConfig {
  return {
    ...PII_SMELLS,
    scanPaths: [...surface.moneyPaths, surface.httpEntry],
    schemaFiles: surface.schemaFiles,
    knownMoneyTables: surface.moneyTables,
    cwd: surface.cwd,
  };
}

// --- the verdict -----------------------------------------------------------------------

/** Run the detector against the live repo. */
export function detect(config: PiiProjectionConfig): Verdict {
  const schemaText = readAll(config.schemaFiles, config.cwd)
    .map((f) => f.text)
    .join("\n");
  const files = readAll(config.scanPaths, config.cwd);

  const scan = scanPiiProjection(schemaText, files, config);

  if (!scan.present) {
    return notApplicable(
      "no client-facing read of a sensitive-column table was found — either the schema defines no " +
        "sensitive identity/bank column, or nothing reads such a table; there is no projection boundary " +
        "here to check (the invariant is dormant)",
      { sensitiveTables: scan.sensitiveTables },
    );
  }
  if (scan.violations.length) {
    return finding(
      `a client-facing read projects sensitive identity/bank fields to the client: ${scan.violations.length} ` +
        `read(s) over a sensitive-column table use \`select("*")\` or name a sensitive column — a vendor TIN, ` +
        `employee SSN, bank account or full card number leaks out in the response`,
      { violations: scan.violations, guarded: scan.guarded, sensitiveTables: scan.sensitiveTables },
    );
  }
  return checked(
    "every client-facing read of a sensitive-column table projects an explicit column set that excludes its " +
      "sensitive identity/bank fields — no TIN / SSN / bank account / full card number reaches the client",
    { guarded: scan.guarded, sensitiveTables: scan.sensitiveTables },
  );
}

/** v4 convenience: derive the surface from `cwd` and run. */
export function detectRepo(cwd: string): Verdict {
  const surface = deriveMoneySurface(cwd);
  return detect(forSurface({ ...surface, cwd }));
}

export default detect;
