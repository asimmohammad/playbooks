// N-AUDIT — portable static detector: every money-mutating service path leaves an ATTRIBUTED,
// non-forgeable audit trail, in the same path, written from an AUTHENTICATED principal.
//
// INVARIANT: in a money app the ledger is the money and the audit log is the ANSWER to "who moved
// it, when, and from what to what". An approval that posts an accrual, a reimbursement that moves
// cash, a status flip that recognises an expense — each is a state change on money, and each MUST
// record an audit row (actor + reason + before/after) in the SAME path that made the change. Two
// ways that trail fails, and both are a real breach:
//   (1) MISSING. A money-mutating path posts the ledger / moves money / writes a money table but
//       records NO audit row in that path. The books moved and nothing says who did it or why;
//       the movement is unattributable, and a later dispute, clawback or SOX review has nothing to
//       stand on. An unaudited money mutation is money moved in the dark.
//   (2) FORGEABLE / UNATTRIBUTED actor. An audit row — or a decision/approval record — stamps an
//       actor that the server did not authenticate: a hard-coded constant, `null`, or (worse) a
//       value lifted straight off the request body. A caller who can set `actorId` in the JSON body
//       can approve their own spend as "the CFO": the audit trail now LIES, which is worse than no
//       trail, because it manufactures false attribution for a real money movement.
//
// SMELL (any one is a FINDING):
//   A. [unaudited-mutation] a money-mutating action inside a service function — a ledger/accrual
//      post, a money-movement executor call, or an insert/update on a money table — with NO reachable
//      audit write in the SAME function region.
//   B. [constant-actor] an audit / decision / approval write whose actor field is a CONSTANT or
//      `null` literal (`actorId: null`, `decided_by: "approver"`) — the movement is unattributed.
//   C. [forgeable-actor] an actor fed into a decision / approval / audit write is read from a
//      CALLER-SUPPLIED request value (`req.body.actorId`, a `const b = c.body` alias then `b.actorId`)
//      — request-supplied attribution the server never authenticated.
//
// Like the rest of the family this is a SOURCE scanner (fail-closed, needs no adapter, keys on a
// stable surface — the money-mutating service paths and the HTTP entry where a per-request actor is
// built — not on a function name). It shares the TypeScript source-reading MODE of N-ONCE /
// N-OBLIG-DUP: pmar's money logic is TS (src/lib/gaap.ts, src/services/*.ts, src/http/server.ts),
// so this reads those files with node:fs and matches the smell with regex. Only the FILES to scan and
// the money-TABLE names are app-specific: bound statically in PMAR, or (v4) DERIVED from the repo's
// money surface via forSurface(), so the scan reaches every money file the repo currently has with
// zero hand-maintenance. Every other regex is GENERIC audit / actor / money-action vocabulary.
// Dormant (NOT_APPLICABLE) until a money-mutating action or an audit/decision write is actually found.

import { readFileSync } from "node:fs";
import { checked, finding, notApplicable, type Verdict } from "../money-system.ts";
import { deriveMoneySurface, type DerivedSurface } from "../derive.ts";
import { type MoneySurface } from "../adapters/pmar.ts";

/** The GENERIC audit-trail vocabulary. Bakes in NO app path/table — money/audit/actor idioms only. */
export interface AuditVocab {
  /** A ledger / accrual / journal POST — a money-state change. */
  ledgerPost: RegExp;
  /** A money-movement executor / disbursement call. */
  moneyMove: RegExp;
  /** A reachable audit WRITE (the guard that discharges smell A). */
  auditCall: RegExp;
  /**
   * An actor field stamped with a CONSTANT or `null` RHS (smell B). Matches `actorId: null` /
   * `decided_by: "approver"` but NOT an identifier RHS (`decided_by: actorId`) or a member read
   * (`actorId: principal.sub`) — those are not constant/null.
   */
  constActor: RegExp;
  /** An actor/approver/decider name vocabulary, for the forgeable-actor (request-sourced) scan. */
  actorName: string;
}

/** The pmar-shaped (and portable) audit vocabulary — generic money/audit idioms, no app specifics. */
export const AUDIT_VOCAB: AuditVocab = {
  // an actual ledger/accrual/journal POST (NOT accrualLines(), which only builds the line objects).
  ledgerPost:
    /\.postEntry\s*\(|\bpostEntry\s*\(|\.post\s*\(\s*["'`]?(?:entry|journal|ledger)|\bjournalEntr[A-Za-z]*\s*\(|\binsertJournal\s*\(|\bpostJournal\s*\(/i,
  // executeMoneyMovement / payout / disburse / settle / reimburse-the-money / capture / refund calls.
  moneyMove:
    /\bexecuteMoneyMovement\s*\(|\bpayout\s*\(|\bdisburse\s*\(|\bsettlePayment\s*\(|\bcapture\s*\(|\brefund\s*\(|\bmakePayment\s*\(|\brecordPayment\s*\(/i,
  // audit( / auditLog( / recordAudit( / writeAudit( / logAudit( / insert into audit_log / .from("audit_log").insert
  auditCall:
    /\baudit\s*\(|\bauditLog\s*\(|\brecordAudit\s*\(|\bwriteAudit\s*\(|\blogAudit\s*\(|insert\s+into\s+audit_log\b|\.from\(\s*["'`]audit_log["'`]\s*\)\s*\.\s*insert\b/i,
  // actorId / actor_id / actor / decidedBy / decided_by / approverId / approver_id / performedBy
  // : null  OR  : "literal"  OR  : 'literal'  OR  : `literal`.
  constActor:
    /\b(?:actorId|actor_id|actor|decidedBy|decided_by|approverId|approver_id|approvedBy|approved_by|performedBy|performed_by|changedBy|changed_by)\s*:\s*(null\b|["'`][^"'`]*["'`])/i,
  actorName:
    "actorId|actor_id|actor|approverId|approver_id|approver|decidedBy|decided_by|decider|approvedBy|approved_by|performedBy|performed_by|userId|user_id",
};

export interface AuditConfig extends AuditVocab {
  /** The money files to scan (surface.moneyPaths ∪ httpEntry, v4) or a static list. */
  files: string[];
  /** An insert/update/upsert/delete on a MONEY table (built from the money-table names). */
  moneyTableWrite: RegExp;
  /** Repo root. Default process.cwd(). */
  cwd?: string;
}

/** The money-table names pmar's schema defines (fallback when a surface carries none). */
const DEFAULT_MONEY_TABLES = [
  "expenses",
  "ledger_entries",
  "ledger_accounts",
  "ledger_lines",
  "payments",
  "reimbursements",
  "bookings",
  "trips",
  "expense_approvals",
  "expense_exceptions",
  "per_diem_rates",
  "card_transactions",
];

/** Build the money-table insert/update/upsert/delete regex from a list of table names. */
export function buildTableWrite(tables: string[]): RegExp {
  const names = (tables.length ? tables : DEFAULT_MONEY_TABLES)
    .map((t) => t.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"))
    .join("|");
  return new RegExp(`\\.from\\(\\s*["'\`](?:${names})["'\`]\\s*\\)\\s*\\.\\s*(?:insert|update|upsert|delete)\\b`, "i");
}

/** The pmar binding — all pmar specifics live here, in config, never in the detector. */
export const PMAR: AuditConfig = {
  ...AUDIT_VOCAB,
  files: [
    "src/lib/gaap.ts",
    "src/services/expenses.ts",
    "src/services/policy.ts",
    "src/services/travel.ts",
    "src/http/server.ts",
  ],
  moneyTableWrite: buildTableWrite(DEFAULT_MONEY_TABLES),
};

/**
 * v4 — build the detector config from a DERIVED money surface instead of a frozen path list. Generic
 * audit/actor/money-action regexes stay in the vocab; only PATHS (surface.moneyPaths ∪ the HTTP
 * entry) and the money-TABLE names (surface.moneyTables) come from the surface, so the scan reaches
 * every money file the repo currently has (gaap.ts, policy.ts, travel.ts, server.ts, …) with zero
 * hand-maintenance. The runner does: `detect(forSurface(deriveMoneySurface(cwd)))`.
 */
export function forSurface(surface: DerivedSurface | MoneySurface): AuditConfig {
  const files = [...new Set([...(surface.moneyPaths ?? []), surface.httpEntry].filter(Boolean) as string[])];
  return {
    ...AUDIT_VOCAB,
    files,
    moneyTableWrite: buildTableWrite(surface.moneyTables ?? []),
    cwd: surface.cwd,
  };
}

// --- pure source-reading primitives (repo-agnostic; mirror the other static detectors) -

/** 1-based line number of the character at `idx`. */
const lineAt = (text: string, idx: number): number => text.slice(0, idx).split("\n").length;

/**
 * Blank out comments so a comment that merely NAMES a smell ("stamps `actorId: null`") is never
 * mistaken for the smell itself — while preserving every newline (and thus every line number).
 * Block comments and line comments are replaced char-for-char with spaces; a `//` preceded by `:`
 * (e.g. `https://`) is left intact so a URL in a string is not swallowed.
 */
export function stripComments(text: string): string {
  // block comments first.
  let out = text.replace(/\/\*[\s\S]*?\*\//g, (m) => m.replace(/[^\n]/g, " "));
  // line comments, but not `://` (URLs).
  out = out.replace(/(^|[^:])\/\/[^\n]*/g, (_m, p1: string) => p1 + " ".repeat(_m.length - p1.length));
  return out;
}

/** `re` as a non-global clone (so a shared /g/ regex's lastIndex can't leak between calls). */
const flat = (re: RegExp): RegExp => new RegExp(re.source, re.flags.replace("g", ""));

/** Does `re` match anywhere in `text`? */
const has = (re: RegExp, text: string): boolean => flat(re).test(text);

/** The brace-balanced `{ ... }` block whose opening brace is at (or at/after) `openIdx`. */
function balancedFrom(text: string, openIdx: number): { body: string; open: number; close: number } | null {
  const open = text.indexOf("{", openIdx);
  if (open < 0) return null;
  let depth = 0;
  for (let i = open; i < text.length; i++) {
    const c = text[i];
    if (c === "{") depth++;
    else if (c === "}") {
      depth--;
      if (depth === 0) return { body: text.slice(open + 1, i), open, close: i };
    }
  }
  return null;
}

/** JS keywords whose `kw (...) {` shape must NOT be mistaken for a function/method region. */
const CONTROL = new Set([
  "if", "for", "while", "switch", "catch", "do", "else", "return", "with", "function", "typeof", "await", "yield",
]);

export interface Region {
  /** The function / method name (for citations). */
  name: string;
  /** The region body (between its braces). */
  body: string;
  /** Absolute offset of the first body character (for line numbers against the full file). */
  base: number;
  /** Absolute offset of the header (name) start. */
  headerIdx: number;
}

/**
 * Segment a source file into function / method regions by brace balancing. A region is a named
 * function or class method header — `<prefixes> <name>(<params>) <ret?> {` — balanced to its closing
 * brace. Control statements (`if (...) {`) are excluded by name. Class methods (indented) and
 * top-level functions both match; arrow route handlers (`(c) => {`, no name before `(`) do not, so
 * their bodies are not treated as money-mutating "service paths" (the forgeable-actor scan reads the
 * whole file instead, so request-sourced actors in route handlers are still caught).
 */
export function collectRegions(text: string): Region[] {
  const headerRe =
    /(?:^|\n)[ \t]*(?:export\s+)?(?:default\s+)?(?:public\s+|private\s+|protected\s+|static\s+|readonly\s+|async\s+|function\s+|get\s+|set\s+)*([A-Za-z_$][\w$]*)\s*\([^{}]*\)\s*(?::\s*[^{};=]+?)?\s*\{/g;
  const out: Region[] = [];
  let m: RegExpExecArray | null;
  while ((m = headerRe.exec(text))) {
    const name = m[1];
    if (CONTROL.has(name)) continue;
    const braceIdx = m.index + m[0].length - 1; // position of the trailing `{`
    const bal = balancedFrom(text, braceIdx);
    if (!bal) continue;
    out.push({ name, body: bal.body, base: bal.open + 1, headerIdx: text.indexOf(name, m.index) });
    headerRe.lastIndex = bal.close; // do not descend into the body for more headers
  }
  return out;
}

// --- the audit-trail logic -------------------------------------------------------------

export interface AuditScan {
  /** "<file>:<line> [<smell>] — <why>" for each breach found. */
  violations: string[];
  /** "<file>:<line> [<smell>] — <why>" for each money path / actor write that is in order. */
  guarded: string[];
  /** At least one money-mutating action OR audit/decision write was found (else dormant). */
  present: boolean;
}

/** A money-mutating action anchor inside a region, and where (region-relative index). */
function mutationAnchor(body: string, cfg: AuditConfig): { kind: string; idx: number } | null {
  const lp = flat(cfg.ledgerPost).exec(body);
  const mm = flat(cfg.moneyMove).exec(body);
  const tw = flat(cfg.moneyTableWrite).exec(body);
  const cand = [
    lp ? { kind: "ledger/accrual post", idx: lp.index } : null,
    mm ? { kind: "money-movement call", idx: mm.index } : null,
    tw ? { kind: "money-table insert/update", idx: tw.index } : null,
  ].filter(Boolean) as Array<{ kind: string; idx: number }>;
  if (!cand.length) return null;
  return cand.sort((a, b) => a.idx - b.idx)[0];
}

/**
 * Collect the forgeable (request-sourced) actor sites in one file: an actor/approver/decider value
 * read off a request body — `req.body.actorId`, `c.body["actorId"]`, or a `const b = c.body` alias
 * then `b.actorId`. Returns "<file>:<line>" cites.
 */
export function forgeableActorSites(text: string, file: string, cfg: AuditConfig): string[] {
  // body aliases: `const b = c.body as ...` / `let x = req.body`.
  const aliases = new Set<string>();
  const aliasRe = /\b(?:const|let|var)\s+([A-Za-z_$][\w$]*)\s*=\s*[^;\n]*\b(?:req|request|c|ctx)\.body\b/g;
  let am: RegExpExecArray | null;
  while ((am = aliasRe.exec(text))) aliases.add(am[1]);

  const esc = (s: string) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const sources = ["(?:req|request|c|ctx)\\.body", ...[...aliases].map(esc)];
  const re = new RegExp(
    `(?:${sources.join("|")})\\s*(?:\\.\\s*(?:${cfg.actorName})\\b|\\[\\s*["'\`](?:${cfg.actorName})["'\`]\\s*\\])`,
    "g",
  );
  const out: string[] = [];
  let m: RegExpExecArray | null;
  while ((m = re.exec(text))) out.push(`${file}:${lineAt(text, m.index)}`);
  return out;
}

/**
 * Pure core. Over each scanned file: (A) every function/method region whose body performs a money
 * mutation but contains no reachable audit write is a violation; (B) every audit/decision write with
 * a constant/null actor is a violation; (C) every request-sourced actor read is a violation.
 */
export function scanAudit(files: Map<string, string>, cfg: AuditConfig): AuditScan {
  const out: AuditScan = { violations: [], guarded: [], present: false };

  for (const [file, raw] of files) {
    const text = stripComments(raw); // a comment naming a smell is not the smell
    // --- smell A: unaudited money-mutating service path ---------------------------------
    for (const region of collectRegions(text)) {
      const anchor = mutationAnchor(region.body, cfg);
      if (!anchor) continue;
      out.present = true;
      const line = lineAt(text, region.base + anchor.idx);
      if (!has(cfg.auditCall, region.body)) {
        out.violations.push(
          `${file}:${line} [unaudited-mutation] — \`${region.name}()\` performs a money mutation (${anchor.kind}) ` +
            `but writes NO audit row in this path: the books moved with nothing recording who did it, why, or the ` +
            `before/after — the movement is unattributable`,
        );
      } else {
        out.guarded.push(
          `${file} [unaudited-mutation] — \`${region.name}()\` performs a money mutation and writes an audit row in the same path`,
        );
      }
    }

    // --- smell B: constant / null actor on an audit or decision write -------------------
    const constRe = new RegExp(cfg.constActor.source, cfg.constActor.flags.includes("g") ? cfg.constActor.flags : cfg.constActor.flags + "g");
    let cm: RegExpExecArray | null;
    while ((cm = constRe.exec(text))) {
      out.present = true;
      out.violations.push(
        `${file}:${lineAt(text, cm.index)} [constant-actor] — an audit/decision actor is stamped with a constant/null ` +
          `literal (\`${cm[0].trim()}\`): the money movement is recorded with no authenticated principal behind it — ` +
          `unattributed attribution`,
      );
    }

    // --- smell C: request-supplied (forgeable) actor ------------------------------------
    for (const cite of forgeableActorSites(text, file, cfg)) {
      out.present = true;
      out.violations.push(
        `${cite} [forgeable-actor] — a decision/audit actor is read straight off the request body: any caller can set ` +
          `the actor field in the JSON body and stamp the audit trail as someone they are not — the trail lies`,
      );
    }
  }

  return out;
}

/** Convenience core, matching the other detectors' `<name>Violations(): string[]` shape. */
export function auditViolations(files: Map<string, string>, cfg: AuditConfig): string[] {
  return scanAudit(files, cfg).violations;
}

// --- file plumbing ---------------------------------------------------------------------

function readFile(path: string, cwd?: string): string {
  return readFileSync(cwd ? `${cwd}/${path}` : path, "utf8");
}

// --- the verdict -----------------------------------------------------------------------

/** Run the detector against the live repo. */
export function detect(config: AuditConfig): Verdict {
  const files = new Map<string, string>();
  for (const p of config.files) {
    try {
      files.set(p, readFile(p, config.cwd));
    } catch {
      /* absent here (another repo, an empty fixture); skip. */
    }
  }

  const scan = scanAudit(files, config);

  if (!scan.present) {
    return notApplicable(
      "no money-mutating action and no audit/decision write was found in the scanned money paths — there is no " +
        "audit-trail boundary here to check (the invariant is dormant)",
    );
  }
  if (scan.violations.length) {
    return finding(
      `${scan.violations.length} audit-trail breach(es): a money-mutating path records no audit row, and/or an ` +
        `audit/decision actor is a constant/null or is read from the request body — money moved unattributed or ` +
        `with forged attribution`,
      { violations: scan.violations, guarded: scan.guarded },
    );
  }
  return checked(
    "every money-mutating service path writes an attributed audit row in the same path, and every audit/decision " +
      "actor is a server-authenticated principal — never a constant, null, or a request-supplied value",
    { guarded: scan.guarded },
  );
}

export default detect;
