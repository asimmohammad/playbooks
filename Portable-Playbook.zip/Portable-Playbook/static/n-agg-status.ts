// N-AGG-STATUS — portable static detector: a money TOTAL / VARIANCE / RECONCILIATION aggregate over a
// STATUS-BEARING money table must restrict to economically-final rows — it must not sum draft, pending,
// rejected, void or cancelled rows as if they were real money.
//
// INVARIANT: not every row in a money table is money that counts. An expense can be a draft or rejected;
// an invoice can be void; a bill can be pending. A table that carries a `status` / `state` lifecycle
// column has rows in non-final states that are NOT yet (or never will be) real value. A SUM / reduce of
// an `amount_minor` column that reads such a table with NO status predicate silently folds those
// non-final rows into the total — so a "booked vs actual" variance, a recognized-revenue total, an
// outstanding-AR figure or an assurance number is overstated or structurally wrong, and the error is
// invisible because the number still looks plausible. (pmar: TravelService.bookedVsActual sums
// `expenses.amount_minor` with no status filter, folding drafts and rejected expenses into "actual" —
// Qodo flagged the variance as structurally wrong and v4 previously missed it.)
//
// SMELL (a FINDING): a `.from("<T>").select("…_minor…")` read of a money table T that the schema shows
// HAS a status/state column, where the from-chain applies NO status predicate, and the bound result is
// then SUMMED with a `.reduce(… + …_minor)` in the same routine. The aggregate counts non-final rows.
//
// GUARD (CHECKED): the same read constrains status (`.eq("status", …)`, `.in("status", […])`,
// `.neq("status","rejected")`, `.not("status", …)`, a `.match({status})`, or a `where … status …`).
//
// DORMANT (NOT_APPLICABLE): no status-bearing money table is aggregated (summed) anywhere in the money
// files — there is no total that could fold non-final rows (invariant dormant).
//
// PURE SOURCE scanner (node:fs + regex, fail-closed). v4 surface-derived: PATHS + schemaFiles come from
// the surface; the aggregation / status vocabulary lives here. `detect(forSurface(deriveMoneySurface(cwd)))`.

import { readFileSync } from "node:fs";
import { checked, finding, notApplicable, type Verdict } from "../money-system.ts";
import { deriveMoneySurface, type DerivedSurface } from "../derive.ts";
import { createTables } from "./n-card-fresh.ts";

export interface AggStatusConfig {
  scanPaths: string[];
  schemaFiles: string[];
  /** A lifecycle status/state column name (marks a table whose rows can be non-final). */
  statusColumn: RegExp;
  /** A status PREDICATE on a query chain (the guard). */
  statusPredicate: RegExp;
  /** A select() projection that pulls a minor-unit amount (so the read feeds a money total). */
  minorSelect: RegExp;
  cwd?: string;
}

export const AGG_VOCAB: Omit<AggStatusConfig, "scanPaths" | "schemaFiles" | "cwd"> = {
  statusColumn: /\b(status|state|lifecycle_state|lifecycle|phase|stage|approval_state)\b/i,
  statusPredicate:
    /\.(?:eq|neq|in|not|is|gte?|lte?|filter|match|or|contains)\s*\(\s*(?:\{[^}]*)?["'`]?(?:status|state|lifecycle_state|lifecycle|phase|stage|approval_state)\b|where[^;]*\b(?:status|state)\b/i,
  minorSelect: /_minor\b|amount|\*/i,
};

// --- pure source-reading primitives ------------------------------------------------------

const lineAt = (text: string, idx: number): number => text.slice(0, idx).split("\n").length;
const flat = (re: RegExp): RegExp => new RegExp(re.source, re.flags.replace("g", ""));
const has = (re: RegExp, text: string): boolean => flat(re).test(text);

function allIdx(text: string, re: RegExp): number[] {
  const g = new RegExp(re.source, re.flags.includes("g") ? re.flags : re.flags + "g");
  const out: number[] = [];
  let m: RegExpExecArray | null;
  while ((m = g.exec(text))) {
    out.push(m.index);
    if (m.index === g.lastIndex) g.lastIndex++;
  }
  return out;
}

/** Split a file into function/method regions (mirror n-fx-compare's functionRegions). */
export function functionRegions(text: string): Array<{ text: string; base: number }> {
  const headerRe =
    /\n[ \t]*(?:export\s+)?(?:public\s+|private\s+|protected\s+)?(?:static\s+)?(?:async\s+)?(?:function\s+)?[A-Za-z_$][\w$]*\s*\([^)]*\)\s*(?::[^;{]*)?\{/g;
  const starts: number[] = [];
  let m: RegExpExecArray | null;
  while ((m = headerRe.exec(text))) starts.push(m.index);
  if (!starts.length) return [{ text, base: 0 }];
  const out: Array<{ text: string; base: number }> = [];
  for (let i = 0; i < starts.length; i++) {
    const end = i + 1 < starts.length ? starts[i + 1]! : text.length;
    out.push({ text: text.slice(starts[i]!, end), base: starts[i]! });
  }
  return out;
}

// --- schema: tables that carry a status/state column -----------------------------------

export function statusTables(schemaText: string, cfg: Pick<AggStatusConfig, "statusColumn">): Set<string> {
  const out = new Set<string>();
  const col = flat(cfg.statusColumn);
  for (const [name, body] of createTables(schemaText)) {
    // a column whose NAME is status-like (first token of a comma-separated column def)
    const cols = body.split(/,(?![^(]*\))/).map((l) => l.trim().split(/\s+/)[0] ?? "");
    if (cols.some((c) => col.test(c))) out.add(name);
  }
  return out;
}

// --- the aggregation logic -------------------------------------------------------------

export interface AggScan {
  violations: string[];
  guarded: string[];
  present: boolean;
}

export function scanAggStatus(
  files: Array<{ path: string; text: string }>,
  schemaText: string,
  cfg: AggStatusConfig,
): AggScan {
  const out: AggScan = { violations: [], guarded: [], present: false };
  const st = statusTables(schemaText, cfg);
  if (!st.size) return out; // no status-bearing table anywhere — dormant

  const fromRe = /\.from\(\s*["'`]([a-z_][\w]*)["'`]\s*\)/gi;

  for (const { path, text } of files) {
    for (const region of functionRegions(text)) {
      const rt = region.text;
      let m: RegExpExecArray | null;
      fromRe.lastIndex = 0;
      while ((m = fromRe.exec(rt))) {
        const table = m[1]!.toLowerCase();
        if (!st.has(table)) continue;

        // statement window: from the start of this `.from(` back to the binding, forward to `;`/newline
        const stmtStart = Math.max(
          rt.lastIndexOf("\n", m.index),
          rt.lastIndexOf(";", m.index),
          rt.lastIndexOf("const", m.index) >= 0 ? rt.lastIndexOf("const", m.index) : -1,
        );
        let end = m.index;
        while (end < rt.length && rt[end] !== ";" && rt[end] !== "\n") end++;
        const stmt = rt.slice(Math.max(0, stmtStart), end);

        // must select a minor amount (so the read feeds a money total), and bind a variable
        const selMatch = stmt.match(/\.select\(\s*["'`]([^"'`]*)["'`]/);
        if (!selMatch || !flat(cfg.minorSelect).test(selMatch[1]!)) continue;
        const varMatch = stmt.match(/\bdata\s*:\s*([A-Za-z_$][\w$]*)/) || stmt.match(/const\s+([A-Za-z_$][\w$]*)\s*=/);
        if (!varMatch) continue;
        const v = varMatch[1]!;

        // is this result then SUMMED with a reduce of a minor amount, in this region?
        const reduceRe = new RegExp(`\\b${v}\\b[\\s\\S]{0,16}?\\.reduce\\s*\\(`);
        const rm = reduceRe.exec(rt);
        if (!rm) continue; // bound but not aggregated — not a total we care about
        const reduceBody = rt.slice(rm.index, rm.index + 200);
        if (!/_minor\b|\bamount\b|\+/i.test(reduceBody)) continue;

        out.present = true;
        const cite = `${path}:${lineAt(text, region.base + m.index)}`;
        if (has(cfg.statusPredicate, stmt)) {
          out.guarded.push(`${cite} [agg-status] — the money total over \`${table}\` constrains status before summing`);
        } else {
          out.violations.push(
            `${cite} [agg-status] — a money total (\`${v}.reduce(… + …_minor)\`) is computed over \`${table}\`, a ` +
              `status-bearing money table, with NO status predicate on the read: draft / pending / rejected / void ` +
              `rows are summed as if they were real money, so the total (a variance, recognized-revenue, ` +
              `outstanding-AR or assurance figure) is overstated or structurally wrong while still looking plausible`,
          );
        }
      }
    }
  }
  return out;
}

export function aggStatusViolations(
  files: Array<{ path: string; text: string }>,
  schemaText: string,
  cfg: AggStatusConfig,
): string[] {
  return scanAggStatus(files, schemaText, cfg).violations;
}

// --- file plumbing ---------------------------------------------------------------------

function readFile(path: string, cwd?: string): string {
  return readFileSync(cwd ? `${cwd}/${path}` : path, "utf8");
}

// --- the v4 surface binding ------------------------------------------------------------

export function forSurface(surface: Pick<DerivedSurface, "moneyPaths" | "schemaFiles" | "cwd">): AggStatusConfig {
  return { ...AGG_VOCAB, scanPaths: surface.moneyPaths, schemaFiles: surface.schemaFiles, cwd: surface.cwd };
}

// --- the verdict -----------------------------------------------------------------------

export function detect(config: AggStatusConfig): Verdict {
  const files: Array<{ path: string; text: string }> = [];
  for (const p of config.scanPaths) {
    if (/[*?]/.test(p)) continue;
    try {
      files.push({ path: p, text: readFile(p, config.cwd) });
    } catch {
      /* absent here; skip */
    }
  }
  const schemaText = config.schemaFiles.map((p) => { try { return readFile(p, config.cwd); } catch { return ""; } }).join("\n");

  const scan = scanAggStatus(files, schemaText, config);

  if (!scan.present) {
    return notApplicable(
      "no money total/variance aggregate over a status-bearing money table was found in the derived money files — " +
        "there is no SUM that could fold draft/rejected/void rows into a real-money figure (invariant dormant)",
    );
  }
  if (scan.violations.length) {
    return finding(
      `a money total counts non-final rows: ${scan.violations.length} aggregate(s) SUM an amount_minor column over ` +
        `a status-bearing money table with no status predicate, so draft / pending / rejected / void rows are ` +
        `folded into a variance, recognized-revenue, outstanding-AR or assurance figure — the number is wrong but ` +
        `still looks plausible`,
      { violations: scan.violations, guarded: scan.guarded },
    );
  }
  return checked(
    "every money total/variance aggregate over a status-bearing money table constrains status first — draft, " +
      "pending, rejected and void rows are excluded, so the figure reflects only real money",
    { guarded: scan.guarded },
  );
}

export function detectRepo(cwd: string): Verdict {
  const surface = deriveMoneySurface(cwd);
  return detect(forSurface({ ...surface, cwd }));
}

export default detect;
