// N-IDEMP-01 — portable static detector: exactly-once money + observable conditional state changes.
//
// Two invariants, both about never acting (or reporting success) more than the real state supports:
//   (a) EVERY mutating money endpoint gates on an Idempotency-Key before any money effect — the
//       dispatcher rejects a money mutation that carries no key and wraps the handler in a
//       read-first/replay, so a retried POST moves money at most once.
//   (b) A conditional state update whose OUTCOME THE CODE CANNOT OBSERVE (e.g. a compare-and-set
//       `store.update(table, { …status:'pending'… }, …)` that returns void) must NOT report success
//       or write an audit row without confirming a row actually changed. If an accept races between
//       the pre-read and the update, the update matches zero rows, yet the endpoint still returns
//       `declined`/`revoked` and audits it — the API response and audit log then contradict the
//       persisted state (#28 decline/revoke 0-row success).
//
// This converts the behavioural N-IDEMP rule into an adapter-free SOURCE scan: (b) lives on a path
// (consumeInvite) the hand-written adapter never drove, so the behavioural run reported a false
// pass. A source scan reads the compare-and-set + audit shape directly, and fails CLOSED.
//
// GENERALITY: (a) keys on the router's stable `money: true` flag and the dispatcher's key-required /
// replay enforcement; (b) keys on the stable compare-and-set-on-status shape and the audit step —
// not on a method name — so both fire on an independent rebuild. NOT_APPLICABLE when neither surface
// exists.

import { readFileSync } from "node:fs";
import { checked, finding, notApplicable, type Verdict } from "../money-system.ts";

export interface IdempConfig {
  /** Source file that registers routes (the router). */
  routerSource: string;
  /** App/service source files where conditional state updates live. */
  appSources: string[];
  /** Router: a money route is flagged with this, e.g. /\bmoney\s*:\s*true\b/. */
  moneyRouteMarker: RegExp;
  /** Router: the dispatcher rejects a money mutation that carries no idempotency key. */
  keyRequiredMarker: RegExp;
  /** Router: the dispatcher wraps the handler in a read-first/replay. */
  replayMarker: RegExp;
  /** Service: a compare-and-set update whose result is unobservable (status literal in the match). */
  conditionalUpdateMarker: RegExp;
  /** Service: the success/audit step that must not run without a confirmed row change. */
  successMarker: RegExp;
  /** How far after a conditional update (chars) to look for an unguarded success/audit. Default 600. */
  successWindow?: number;
  /** Repo root. Default process.cwd(). */
  cwd?: string;
}

/** The neobank binding — all neobank specifics live here, in config, never in the detector. */
export const NEOBANK: IdempConfig = {
  routerSource: "supabase/functions/_shared/app/router.ts",
  appSources: ["supabase/functions/_shared/app/service.ts"],
  moneyRouteMarker: /\bmoney\s*:\s*true\b/,
  keyRequiredMarker: /idempotency_key_required|!\s*\w+\.idempotencyKey/,
  replayMarker: /\bidempotent\s*\(/,
  // A store.update whose MATCH object (2nd arg) carries a status literal: a compare-and-set whose
  // void return the code cannot observe. (A normal update keeps status in the PATCH, not the match.)
  conditionalUpdateMarker:
    /\.update\s*\(\s*["'][^"']+["']\s*,\s*\{[^}]*\bstatus\s*:\s*["'][^"']+["'][^}]*\}/g,
  successMarker: /\baudit\s*\(/,
  successWindow: 600,
};

// --- pure core -------------------------------------------------------------------------

export interface IdempScan {
  violations: string[];
  /** Either leg's surface is present (else the detector is dormant). */
  applicable: boolean;
}

/**
 * Pure core. Leg (a): if the router declares money routes, the dispatcher must enforce both the
 * key-required reject and the replay wrap. Leg (b): a conditional compare-and-set update followed
 * (same function) by a success/audit step, with no confirmed row change, is a violation.
 */
export function scanIdemp(routerText: string, appText: string, cfg: IdempConfig): IdempScan {
  const out: IdempScan = { violations: [], applicable: false };

  // Leg (a): money-route idempotency enforcement.
  const hasMoneyRoutes = cfg.moneyRouteMarker.test(routerText);
  if (hasMoneyRoutes) {
    out.applicable = true;
    if (!cfg.keyRequiredMarker.test(routerText))
      out.violations.push(
        "money routes are declared, but the dispatcher never rejects a money mutation that carries no Idempotency-Key",
      );
    if (!cfg.replayMarker.test(routerText))
      out.violations.push(
        "money routes are declared, but the dispatcher never wraps the handler in a read-first/replay",
      );
  }

  // Leg (b): conditional state update whose outcome is unobserved, then a success/audit.
  const window = cfg.successWindow ?? 600;
  const re = new RegExp(
    cfg.conditionalUpdateMarker.source,
    cfg.conditionalUpdateMarker.flags.includes("g")
      ? cfg.conditionalUpdateMarker.flags
      : cfg.conditionalUpdateMarker.flags + "g",
  );
  for (const m of appText.matchAll(re)) {
    out.applicable = true;
    const after = appText.slice(m.index, m.index + window);
    if (cfg.successMarker.test(after)) {
      out.violations.push(
        "a conditional compare-and-set update (status in the match) reports success / writes an " +
          "audit row without confirming a row changed — a racing consume reports a false outcome",
      );
    }
  }
  return out;
}

/** Convenience core, matching the other detectors' `<name>Violations(): string[]` shape. */
export function idempViolations(routerText: string, appText: string, cfg: IdempConfig): string[] {
  return scanIdemp(routerText, appText, cfg).violations;
}

function readFile(path: string, cwd?: string): string {
  return readFileSync(cwd ? `${cwd}/${path}` : path, "utf8");
}

function concatSources(paths: string[], cwd?: string): string {
  const parts: string[] = [];
  for (const f of paths) {
    try {
      parts.push(readFile(f, cwd));
    } catch {
      // a source this binding names is absent here; skip it.
    }
  }
  return parts.join("\n");
}

/** Run the detector against the live repo. */
export function detect(config: IdempConfig): Verdict {
  let routerText = "";
  try {
    routerText = readFile(config.routerSource, config.cwd);
  } catch {
    // no router here; leg (a) is dormant, leg (b) can still apply.
  }
  const appText = concatSources(config.appSources, config.cwd);
  if (!routerText && !appText) {
    return notApplicable("none of the configured sources were found");
  }
  const scan = scanIdemp(routerText, appText, config);
  if (!scan.applicable) {
    return notApplicable(
      "no money route or conditional state-update surface is present in this repo",
    );
  }
  if (scan.violations.length) {
    return finding(`${scan.violations.length} exactly-once / observable-outcome violation(s)`, {
      violations: scan.violations,
    });
  }
  return checked(
    "money routes gate on an Idempotency-Key with replay; conditional state updates confirm a row changed before reporting success",
  );
}

export default detect;
