// N-TENANT-ISO — portable static detector: the tenant/org a request operates on comes from an
// AUTHENTICATED principal, never from a value the caller supplies, and there is no default tenant.
//
// INVARIANT: in a multi-tenant money app every request carries an org/tenant key, and EVERY money
// read and write is scoped to it. That key is the single thing standing between one customer's money
// and another's, so its PROVENANCE is the whole ballgame: it must be derived from an AUTHENTICATED
// principal (a verified token / session / signed claim the server itself checks), NOT from a value the
// caller hands in (a request header, body field or query param the client fully controls), and there
// must be NO default/fallback tenant the request silently drops into. If the org key is read straight
// off a request header with no authentication, any caller sets `X-Org-Id: org_of_their_victim` and
// reads or moves another tenant's money — a total cross-tenant breach. If instead the key is MISSING
// and the code falls back to a hard-coded default tenant (`?? "org_01"`), unauthenticated or
// mis-targeted traffic lands in — and mutates the books of — one unlucky real org. Either way the
// isolation boundary is not an authenticated fact; it is a client-supplied suggestion.
//
// SMELL (any one request-tenant-resolution site in this state is a FINDING):
//   A. the org/tenant key is resolved from a CALLER-SUPPLIED value (a raw request header / body /
//      query, e.g. `req.headers["x-org-id"]`, or a bracketed key named org/tenant) AND the file
//      doing so has NO authentication/principal parsing at all (no Authorization-header read, no
//      token/JWT/session verification, no principal/claims parse) — so nothing authenticates the
//      tenant the request claims; OR
//   B. the resolution DEFAULTS to a hard-coded tenant literal (`?? "org_01"`, `|| "tenant_default"`)
//      — a request with no (or a bad) tenant silently operates on a real org's books.
//
// Like the rest of the family this is a SOURCE scanner (fail-closed, needs no adapter, keys on a
// stable surface — the HTTP entrypoint where a request's per-call tenant context is built — not on a
// function name). It shares the source-reading MODE of N-PASSTHRU-LIAB / N-OBLIG-DUP: pmar's transport
// is a node:http router in TypeScript (see adapters/pmar.ts `httpEntry`), so this reads the HTTP entry
// TS with node:fs and matches the smell with regex. It is parameterised so nothing app-specific — the
// entry file(s), the tenant-key vocabulary, the caller-supplied-source idiom, the default-tenant
// idiom, the auth/principal vocabulary — is baked into the detector; only into the config. Dormant
// (NOT_APPLICABLE) until a per-request tenant-resolution site is actually present: an app whose entry
// never resolves a tenant from the transport has no isolation boundary here to check.

import { readFileSync } from "node:fs";
import { checked, finding, notApplicable, type Verdict } from "../money-system.ts";
import { PMAR_SURFACE } from "../adapters/pmar.ts";

export interface TenantIsoConfig {
  /** HTTP entrypoint file(s) where a request's per-call tenant/org context is built. pmar: server.ts. */
  httpEntryFiles: string[];
  /**
   * The tenant/org KEY vocabulary — the variable/field a request's tenant context is assigned to,
   * e.g. /orgId|org_id|tenantId|tenant_id/ . A resolution site is `<tenantKey> [:=] <rhs>`.
   */
  tenantKey: RegExp;
  /**
   * A CALLER-SUPPLIED source on the RHS: the RAW request's header/body/query, or a bracketed string
   * key named org/tenant. MUST match `req.headers[...]` but NOT a downstream read of the already
   * resolved context (`c.orgId`) — that is correct scoping, not resolution.
   */
  requestSource: RegExp;
  /** A principal/session/claims reference on the RHS — an AUTHENTICATED tenant source. */
  principalSource: RegExp;
  /** A hard-coded default-tenant literal on the RHS, e.g. /\?\?\s*["']org_\w+["']/ . */
  defaultTenant: RegExp;
  /**
   * Genuine authentication / principal PARSING anywhere in the entry file: an Authorization-header
   * read, a token/JWT/session verification, a principal/claims parse. Must NOT match a mere auth-named
   * route string or an "authorization" event-type literal — only real verification idioms.
   */
  authMarker: RegExp;
  /** Optional: a dev/stub-auth tell (for the citation that the only "auth" is a stub). */
  authStubMarker?: RegExp;
  /** Repo root. Default process.cwd(). */
  cwd?: string;
}

/** The pmar binding — all pmar specifics live here, in config, never in the detector. */
export const PMAR: TenantIsoConfig = {
  httpEntryFiles: [PMAR_SURFACE.httpEntry], // ["src/http/server.ts"]
  tenantKey: /orgId|org_id|orgKey|tenantId|tenant_id|tenantKey|accountId|workspaceId/,
  // RAW request only (so pmar's correct `c.orgId` downstream scoping is NOT a resolution site), plus a
  // bracketed key named org/tenant (e.g. headers["x-org-id"], body["orgId"]).
  requestSource:
    /\breq\.(?:headers|body|query|params)\b|\brequest\.(?:headers|body|query|params)\b|\[\s*['"\x60][a-z0-9_.-]*(?:org|tenant|workspace)[a-z0-9_.-]*['"\x60]\s*\]/i,
  principalSource: /\bprincipal\b|\bclaims\b|\bsession\b|\bauthContext\b|\bauthUser\b|\bactor\b/i,
  // `?? "org_01"` / `|| "tenant_default"` / `?? "acct_…"` — a quoted tenant-ish literal as a fallback.
  defaultTenant:
    /(?:\?\?|\|\|)\s*['"\x60](?:org|tenant|acct|account|company|workspace|ws|default)[a-z0-9_-]*['"\x60]/i,
  // Real verification idioms ONLY: verify*( / jwt.verify( / jsonwebtoken / authenticate( /
  // get|parse|requirePrincipal( / getSession( / req.session / an Authorization-HEADER read. This does
  // NOT match pmar's `/v1/auth/token` route string, its "dev auth stub" note, or line 98's
  // `as "authorization"` webhook event-type literal (none of which is a header read or a verify call).
  authMarker:
    /\bverify(?:Token|Jwt|Session|Auth|Bearer|Signature)?\s*\(|\bjwt\.verify\s*\(|\bjsonwebtoken\b|\bauthenticate\s*\(|\b(?:get|parse|require)Principal\s*\(|\bgetSession\s*\(|\breq\.session\b|headers\s*\[\s*['"\x60]authorization['"\x60]/i,
  authStubMarker: /dev[ _-]?auth[ _-]?stub|auth[ _-]?stub|stub[ _-]?auth/i,
};

// --- pure source-reading primitives (repo-agnostic; mirror the other static detectors) -

/** 1-based line number of the character at `idx`. */
const lineAt = (text: string, idx: number): number => text.slice(0, idx).split("\n").length;

/** 1-based line number of `re`'s first match in `text` (null if it does not match). */
function lineOf(text: string, re: RegExp): number | null {
  const m = new RegExp(re.source, re.flags.replace("g", "")).exec(text);
  return m ? text.slice(0, m.index).split("\n").length : null;
}

// --- the tenant-isolation logic --------------------------------------------------------

/** One per-request tenant-resolution site: where `<tenantKey>` is assigned and what from. */
export interface ResolutionSite {
  /** "<file>:<line>". */
  cite: string;
  /** The RHS text the tenant key is assigned from (up to end of statement). */
  rhs: string;
  /** The RHS reads a raw caller-supplied value (header/body/query / bracketed org key). */
  requestSupplied: boolean;
  /** The RHS defaults to a hard-coded tenant literal. */
  hasDefault: boolean;
}

/**
 * Collect the per-request tenant-RESOLUTION sites in one entry file. A site is a `<tenantKey> [:=] rhs`
 * whose RHS actually RESOLVES the tenant from the transport — it reads a raw caller-supplied value, OR
 * derives it from an authenticated principal, OR defaults to a tenant literal. A `<tenantKey>` that is
 * merely READ from the already-built context (`c.orgId`, `orgId: c.orgId`) or is a type declaration
 * (`orgId: string`) is NOT a resolution site: that is correct downstream scoping, and the detector must
 * not flag it.
 */
export function collectResolutionSites(text: string, file: string, cfg: TenantIsoConfig): ResolutionSite[] {
  const sites: ResolutionSite[] = [];
  const assignRe = new RegExp(`\\b(?:${cfg.tenantKey.source})\\s*[:=]\\s*([^\\n;]*)`, "gi");
  for (const m of text.matchAll(assignRe)) {
    const rhs = m[1] ?? "";
    const requestSupplied = cfg.requestSource.test(rhs);
    const principalDerived = cfg.principalSource.test(rhs);
    const hasDefault = cfg.defaultTenant.test(rhs);
    // Only a real resolution site — one of the three transport-provenance shapes.
    if (!requestSupplied && !principalDerived && !hasDefault) continue;
    sites.push({ cite: `${file}:${lineAt(text, m.index ?? 0)}`, rhs: rhs.trim(), requestSupplied, hasDefault });
  }
  return sites;
}

export interface TenantIsoScan {
  /** "<cite> — <why>" for each resolution site that breaches isolation. */
  violations: string[];
  /** "<cite> — <why>" for each resolution site that is authenticated and defaultless. */
  guarded: string[];
  /** At least one per-request tenant-resolution site was found (else the invariant is dormant here). */
  present: boolean;
  /** Per entry file: whether it carries genuine auth/principal parsing. For verdict detail. */
  authByFile: Record<string, boolean>;
}

/**
 * Pure core. For each entry file, decide whether it authenticates at all (authMarker), then classify
 * every tenant-resolution site: a site that DEFAULTS to a tenant literal (smell B), or that is resolved
 * from a caller-supplied value in a file with NO authentication (smell A), is a violation. A site
 * resolved from an authenticated principal with no default is guarded.
 */
export function scanTenantIso(files: Array<{ path: string; text: string }>, cfg: TenantIsoConfig): TenantIsoScan {
  const out: TenantIsoScan = { violations: [], guarded: [], present: false, authByFile: {} };
  for (const { path, text } of files) {
    const fileHasAuth = cfg.authMarker.test(text);
    out.authByFile[path] = fileHasAuth;
    for (const site of collectResolutionSites(text, path, cfg)) {
      out.present = true;
      if (site.hasDefault) {
        out.violations.push(
          `${site.cite} — tenant/org key defaults to a hard-coded tenant literal (\`${site.rhs}\`): a request ` +
            `with no/invalid tenant silently operates on a real org's books [smell B: default tenant]`,
        );
      } else if (site.requestSupplied && !fileHasAuth) {
        out.violations.push(
          `${site.cite} — tenant/org key resolved from a caller-supplied value (\`${site.rhs}\`) with NO ` +
            `authentication/principal parsing in ${path}: any caller can set the header to another org and ` +
            `read/write that org's money [smell A: unauthenticated request-supplied tenant]`,
        );
      } else {
        const why = site.requestSupplied
          ? "tenant read from the request, but the file authenticates a principal"
          : "tenant derived from an authenticated principal, with no default-tenant fallback";
        out.guarded.push(`${site.cite} — ${why} (\`${site.rhs}\`)`);
      }
    }
  }
  return out;
}

// --- file plumbing ---------------------------------------------------------------------

function readFile(path: string, cwd?: string): string {
  return readFileSync(cwd ? `${cwd}/${path}` : path, "utf8");
}

// --- the verdict -----------------------------------------------------------------------

/** Run the detector against the live repo. */
export function detect(config: TenantIsoConfig): Verdict {
  const files: Array<{ path: string; text: string }> = [];
  for (const p of config.httpEntryFiles) {
    try {
      files.push({ path: p, text: readFile(p, config.cwd) });
    } catch {
      /* this entry file is absent here (another repo, an empty fixture); skip it. */
    }
  }

  const scan = scanTenantIso(files, config);

  if (!scan.present) {
    return notApplicable(
      "no per-request tenant/org resolution site found in the HTTP entrypoint(s) — there is no tenant-isolation " +
        "boundary here to check (the invariant is dormant)",
    );
  }

  if (scan.violations.length) {
    // Soft evidence: if the file has no real auth, point at the stub-auth tell, if any.
    const stub: string[] = [];
    if (config.authStubMarker) {
      for (const { path, text } of files) {
        if (scan.authByFile[path]) continue;
        const ln = lineOf(text, config.authStubMarker);
        if (ln != null) stub.push(`${path}:${ln} — the only auth surface is a dev/stub endpoint, not real authentication`);
      }
    }
    return finding(
      `${scan.violations.length} request tenant-resolution site(s) breach tenant isolation: the org/tenant key ` +
        `is caller-supplied without authentication and/or defaults to a hard-coded tenant — a cross-tenant money breach`,
      { violations: scan.violations, guarded: scan.guarded, authStub: stub, authByFile: scan.authByFile },
    );
  }

  return checked(
    "every per-request tenant/org resolution derives the key from an authenticated principal with no default-tenant " +
      "fallback — the tenant-isolation boundary is an authenticated fact, not a client-supplied suggestion",
    { guarded: scan.guarded, authByFile: scan.authByFile },
  );
}

export default detect;
