// N-LIFECYCLE — portable static detector: a money-releasing / recognition status transition is
// GUARDED BY PRIOR STATUS, TERMINAL-SAFE, and AGGREGATE-CLEARANCE SAFE.
//
// INVARIANT: in an expense/AP/accrual system, money leaves (reimburse, pay, payout) and value is
// recognized (accrue, recognize) ONLY on a status transition — draft→approved→reimbursed,
// submitted→approved, exception→cleared. Each such transition is the gate that must hold money
// exactly once, so three things must be true of it:
//   (a) GUARDED BY PRIOR STATUS. The write that flips the status is itself conditioned on the
//       source status — a status-filtered UPDATE (`set status=X where id=? AND status=<expected>`)
//       whose affected-row count proves this caller won the transition. A blind `update set
//       status=X where id=?` (no `and status=`) lets two concurrent callers both "win": both read
//       `approved`, both flip to `reimbursed`, both release money. The predicate IS the lock.
//   (b) TERMINAL-SAFE. A terminal state (reimbursed / paid / closed / settled) never transitions
//       back to an active/payable one, and a money op is not reachable from a terminal or non-source
//       status. When the ONLY thing standing between the money op and a double-release is a status
//       value READ earlier into a variable (`if (e.status !== "approved") throw; …; move money`),
//       that read is stale the instant it is taken: nothing claims the transition, so a retry or a
//       concurrent request sails through the same check and releases again.
//   (c) AGGREGATE-CLEARANCE SAFE. A transition gated on "all required clearances / approval levels /
//       exceptions are approved" must use EVERY / ALL (or a count-of-required), never `.some(` /
//       `.find(` / a single `=== "approved"`: first-match clearance lets ONE sign-off release money
//       that required N.
//
// SMELL (any ONE is a FINDING):
//   A. [prior-status] a status-setting UPDATE (`.update({ status … })`, `UPDATE … SET status`, or a
//      direct `.status = <literal>`) with NO prior-status predicate in the write itself.
//   B. [terminal-safe] a money-release / recognition call whose only guard is a mutable status field
//      read earlier (a `x.status ===/!== …` read-check) with NO status-filtered claim-update in the
//      same routine — the stale read is the whole lock.
//   C. [aggregate-clearance] a clearance / approval-level / exception gate that drives a release via
//      `.some(` / `.find(` / a single `=== "approved"` where EVERY / ALL / a count is required.
//
// Like the rest of the family this is a PURE SOURCE scanner (node:fs + regex, fail-closed). Per v4
// the money surface is DERIVED, not declared: `forSurface(deriveMoneySurface(cwd))` builds the config
// from the repo's own money files, so a newly-landed money module (gaap.ts, policy.ts, travel.ts …)
// is scanned the moment it exists. Only PATHS come from the surface; the money-lifecycle vocabulary
// (the status/release/aggregate idioms) lives here in the config. Dormant (NOT_APPLICABLE) until an
// actual money-releasing / recognition transition site is present.

import { readFileSync } from "node:fs";
import { checked, finding, notApplicable, type Verdict } from "../money-system.ts";
import { deriveMoneySurface, type DerivedSurface } from "../derive.ts";

export interface LifecycleConfig {
  /** Money files to scan (v4: surface.moneyPaths, concrete relative paths). */
  scanPaths: string[];

  // --- generic money-lifecycle vocabulary (app-agnostic; stays in the detector/config) ---
  /** A status-setting UPDATE: a supabase `.update({ … status … })`. */
  statusUpdate: RegExp;
  /** A status-setting SQL write: `UPDATE … SET status = …`. */
  sqlStatusUpdate: RegExp;
  /** A direct status assignment to a literal: `x.status = "approved"`. */
  directStatusAssign: RegExp;
  /** A prior-status predicate inside the write (so the UPDATE is status-filtered). */
  statusPredicate: RegExp;
  /** A SQL prior-status predicate in the WHERE (`… and status = …`, `where status = …`). */
  sqlStatusPredicate: RegExp;
  /** A money-release / recognition call (reimburse, pay, payout, recognize, accrue, settle, post). */
  moneyRelease: RegExp;
  /** A read-check of a mutable status field (`x.status === …` / `!== …`). */
  readStatusGuard: RegExp;
  /** A status-filtered claim UPDATE in a routine (an `.update({status})` carrying a status predicate). */
  claimUpdate: RegExp;
  /** Clearance / approval-level / exception context words. */
  clearanceContext: RegExp;
  /** A WEAK aggregator used to clear: `.some(` / `.find(`. */
  weakAggregator: RegExp;
  /** A STRONG aggregator: `.every(` / a count-of-required. */
  strongAggregator: RegExp;
  /** A single-equality clearance: a lone `status === "approved"` driving a boolean clearance flag. */
  singleEqClearance: RegExp;
  /** Repo root. Default process.cwd(). */
  cwd?: string;
}

/**
 * The generic money-lifecycle vocabulary. NO paths and NO table names here — only the idioms that
 * say "this flips a status / releases money / clears an aggregate". Paths come from the surface.
 */
export const LIFECYCLE_SMELLS: Omit<LifecycleConfig, "scanPaths" | "cwd"> = {
  // `.update({ status: "…" })` / `.update({ status })` — a status-setting supabase write (NOT insert).
  statusUpdate: /\.update\s*\(\s*\{[^{}]*\bstatus\b[^{}]*\}/,
  // `UPDATE <table> SET … status = …`.
  sqlStatusUpdate: /\bupdate\s+[\w."]+\s+set\b[^;]*\bstatus\s*=/i,
  // `foo.status = "approved"` (assignment to a status literal; not a comparison ===/!==).
  directStatusAssign: /\b[A-Za-z_$][\w$]*\.status\s*=\s*['"][a-z_]+['"]/,
  // a status predicate in the same chain: `.eq("status", …)`, `.in("status", …)`, `.match({ status … })`.
  statusPredicate: /\.(?:eq|in|neq|is)\s*\(\s*['"]status['"]|\.match\s*\(\s*\{[^{}]*\bstatus\b/,
  // SQL where/and status predicate.
  sqlStatusPredicate: /\b(?:where|and)\b[^;]*\bstatus\s*=/i,
  // money leaves / value is recognized. `createPayment` is the connector debit.
  moneyRelease:
    /\b(?:reimburse|reimbursed|payBill|payout|recordPayment|createPayment|executeMoneyMovement|recognizeExpense|recognize|accrue|settle|disburse|capture)\s*\(|\.postEntry\s*\(/i,
  // a read-check of a status value held in a variable.
  readStatusGuard: /\b[A-Za-z_$][\w$.]*\.status\s*(?:===|!==|==|!=)\s*['"][a-z_]+['"]/,
  // a status-filtered claim update (an `.update({...status...})` whose chain carries a status predicate).
  claimUpdate:
    /\.update\s*\(\s*\{[^{}]*\bstatus\b[^{}]*\}\s*\)[\s\S]{0,160}?\.(?:eq|in)\s*\(\s*['"]status['"]/,
  clearanceContext: /\b(?:exception|clearance|approval|approvals|level|levels|sign[- ]?off|signoff|gate)s?\b/i,
  weakAggregator: /\.(?:some|find)\s*\(/,
  strongAggregator: /\.every\s*\(|\.filter\s*\([\s\S]{0,80}?\)\s*\.length|\bcount\b/i,
  // a boolean clearance flag set from a single status equality.
  singleEqClearance:
    /\b(?:cleared|approved|allApproved|canRelease|ready)\b\s*=\s*[^;=]*\.status\s*(?:===|==)\s*['"]approved['"]/,
};

// --- pure source-reading primitives (repo-agnostic; mirror the other static detectors) -

/** 1-based line number of the character at `idx`. */
const lineAt = (text: string, idx: number): number => text.slice(0, idx).split("\n").length;

/** `re` as a non-global clone (so a shared /g/ regex's lastIndex can't leak between calls). */
const flat = (re: RegExp): RegExp => new RegExp(re.source, re.flags.replace("g", ""));

/** Does `re` match anywhere in `text`? */
const has = (re: RegExp, text: string): boolean => flat(re).test(text);

/** Every start index of `re` in `text`. */
function allIdx(text: string, re: RegExp): number[] {
  const g = new RegExp(re.source, re.flags.includes("g") ? re.flags : re.flags + "g");
  const out: number[] = [];
  let m: RegExpExecArray | null;
  while ((m = g.exec(text))) {
    out.push(m.index);
    if (m.index === g.lastIndex) g.lastIndex++;
  }
  return out;
}

/** The statement text starting at `idx`, up to the next `;` (capped) — captures a whole chained call. */
function statementAt(text: string, idx: number, cap = 400): string {
  const slice = text.slice(idx, idx + cap);
  const semi = slice.indexOf(";");
  return semi >= 0 ? slice.slice(0, semi) : slice;
}

/**
 * Split a source file into function / method regions: each region is a `name(...) { … }` header and
 * the body up to the next such header. Works for both top-level functions and indented class methods.
 * Inline arrow callbacks (`(a,b) => …`) are not headers (no `name(` anchor), so a method's body is
 * captured whole.
 */
export function functionRegions(text: string): Array<{ text: string; base: number }> {
  const headerRe =
    /\n[ \t]*(?:export\s+)?(?:public\s+|private\s+|protected\s+)?(?:static\s+)?(?:async\s+)?(?:function\s+)?[A-Za-z_$][\w$]*\s*\([^)]*\)\s*(?::[^;{]*)?\{/g;
  const starts: number[] = [];
  let m: RegExpExecArray | null;
  while ((m = headerRe.exec(text))) starts.push(m.index);
  if (!starts.length) return [{ text, base: 0 }];
  const out: Array<{ text: string; base: number }> = [];
  for (let i = 0; i < starts.length; i++) {
    const end = i + 1 < starts.length ? starts[i + 1]! : text.length;
    out.push({ text: text.slice(starts[i]!, end), base: starts[i]! });
  }
  return out;
}

// --- the lifecycle logic ---------------------------------------------------------------

export interface LifecycleScan {
  /** "<file>:<line> [<leg>] — <why>" for each lifecycle smell found. */
  violations: string[];
  /** "<file>:<line> [<leg>] — <why>" for each transition site found to be guarded. */
  guarded: string[];
  /** At least one money-releasing / recognition transition site was found (else dormant). */
  present: boolean;
}

/**
 * Pure core. For each money file, run the three independent legs — prior-status (A), terminal-safe
 * (B), aggregate-clearance (C). Any leg's smell is a violation; a transition site whose guard holds
 * is recorded as guarded. `present` is true once ANY transition site (status write, release call, or
 * clearance gate) is seen, so an app with no money-releasing transition is dormant (NOT_APPLICABLE).
 */
export function scanLifecycle(files: Array<{ path: string; text: string }>, cfg: LifecycleConfig): LifecycleScan {
  const out: LifecycleScan = { violations: [], guarded: [], present: false };

  for (const { path, text } of files) {
    // --- leg A: every status-setting UPDATE must carry a prior-status predicate -----------
    const updateIdxs = [
      ...allIdx(text, cfg.statusUpdate),
      ...allIdx(text, cfg.sqlStatusUpdate),
      ...allIdx(text, cfg.directStatusAssign),
    ].sort((a, b) => a - b);
    for (const idx of updateIdxs) {
      out.present = true;
      const stmt = statementAt(text, idx);
      const guardedWrite =
        cfg.statusPredicate.test(stmt) || cfg.sqlStatusPredicate.test(stmt);
      const cite = `${path}:${lineAt(text, idx)}`;
      if (!guardedWrite) {
        out.violations.push(
          `${cite} [prior-status] — a status-setting write flips the status with NO prior-status ` +
            `predicate (\`${stmt.trim().slice(0, 90)}\`): two concurrent callers both read the old status ` +
            `and both win the transition, so a money-releasing transition fires twice [smell A]`,
        );
      } else {
        out.guarded.push(`${cite} [prior-status] — the status write is status-filtered (predicate present)`);
      }
    }

    // --- legs B & C operate per routine ---------------------------------------------------
    for (const region of functionRegions(text)) {
      const rt = region.text;

      // --- leg B: a money-release guarded only by a stale status read -----------------------
      const releaseIdxs = allIdx(rt, cfg.moneyRelease);
      if (releaseIdxs.length) {
        out.present = true;
        const readGuard = has(cfg.readStatusGuard, rt);
        const claim = has(cfg.claimUpdate, rt);
        const cite = `${path}:${lineAt(text, region.base + releaseIdxs[0]!)}`;
        if (readGuard && !claim) {
          out.violations.push(
            `${cite} [terminal-safe] — a money-release / recognition call is gated ONLY by a status ` +
              `value read into a variable (an \`x.status ===/!== …\` check) with NO status-filtered ` +
              `claim-update in the routine: the read is stale the instant it is taken, so a retry or a ` +
              `concurrent request passes the same check and releases money again — and a terminal row ` +
              `can be re-released [smell B]`,
          );
        } else if (claim) {
          out.guarded.push(
            `${cite} [terminal-safe] — the release is preceded by a status-filtered claim-update that ` +
              `atomically wins the transition before money moves`,
          );
        }
      }

      // --- leg C: an aggregate clearance must be EVERY / count, never some/find/single-eq ---
      const inClearance = has(cfg.clearanceContext, rt);
      const drivesRelease = releaseIdxs.length > 0 || /\b(?:recogniz|approv|finaliz|clear|release)/i.test(rt);
      if (inClearance && drivesRelease) {
        const weak = has(cfg.weakAggregator, rt) || has(cfg.singleEqClearance, rt);
        const strong = has(cfg.strongAggregator, rt);
        if (weak && !strong) {
          const wIdx = allIdx(rt, cfg.weakAggregator)[0];
          const cite = `${path}:${lineAt(text, region.base + (wIdx ?? 0))}`;
          out.violations.push(
            `${cite} [aggregate-clearance] — a clearance / approval-level / exception gate drives a ` +
              `money-releasing transition via a first-match aggregator (\`.some(\`/\`.find(\`/a single ` +
              `\`=== "approved"\`) where EVERY / ALL / a count-of-required is needed: ONE sign-off ` +
              `releases money that required all of them [smell C]`,
          );
        } else if (strong) {
          const sIdx = allIdx(rt, cfg.strongAggregator)[0];
          out.guarded.push(
            `${path}:${lineAt(text, region.base + (sIdx ?? 0))} [aggregate-clearance] — clearance uses ` +
              `EVERY / ALL (every required sign-off must approve before release)`,
          );
        }
      }
    }
  }

  return out;
}

/** Convenience core, matching the other detectors' `<name>Violations(): string[]` shape. */
export function lifecycleViolations(files: Array<{ path: string; text: string }>, cfg: LifecycleConfig): string[] {
  return scanLifecycle(files, cfg).violations;
}

// --- file plumbing ---------------------------------------------------------------------

function readFile(path: string, cwd?: string): string {
  return readFileSync(cwd ? `${cwd}/${path}` : path, "utf8");
}

// --- the v4 surface binding ------------------------------------------------------------

/**
 * Build the detector config from a DERIVED money surface. Only the PATHS come from the surface
 * (surface.moneyPaths — the repo's own money files, recomputed every run); the lifecycle vocabulary
 * is the fixed `LIFECYCLE_SMELLS`. This is the v4 contract: `detect(forSurface(deriveMoneySurface(cwd)))`.
 */
export function forSurface(surface: Pick<DerivedSurface, "moneyPaths" | "cwd">): LifecycleConfig {
  return { ...LIFECYCLE_SMELLS, scanPaths: surface.moneyPaths, cwd: surface.cwd };
}

// --- the verdict -----------------------------------------------------------------------

/** Run the detector against the live repo. */
export function detect(config: LifecycleConfig): Verdict {
  const files: Array<{ path: string; text: string }> = [];
  for (const p of config.scanPaths) {
    if (/[*?]/.test(p)) continue; // a glob (hand-declared surface); v4 derivation yields concrete files
    try {
      files.push({ path: p, text: readFile(p, config.cwd) });
    } catch {
      /* absent here (another repo, an empty fixture); skip it. */
    }
  }

  const scan = scanLifecycle(files, config);

  if (!scan.present) {
    return notApplicable(
      "no money-releasing / recognition status-transition site was found in the derived money files — " +
        "there is no lifecycle gate here to check (the invariant is dormant)",
    );
  }
  if (scan.violations.length) {
    return finding(
      `a money-releasing / recognition status transition is not lifecycle-safe: ${scan.violations.length} ` +
        `smell(s) across prior-status / terminal-safe / aggregate-clearance — a retry, a concurrent ` +
        `request, or a single sign-off can release or recognize money more than once`,
      { violations: scan.violations, guarded: scan.guarded },
    );
  }
  return checked(
    "every money-releasing / recognition transition is guarded by prior status (status-filtered writes), " +
      "is terminal-safe (claimed atomically, not via a stale status read), and clears aggregates with " +
      "EVERY / ALL — a transition fires at most once",
    { guarded: scan.guarded },
  );
}

/** v4 convenience: derive the surface from `cwd` and run. */
export function detectRepo(cwd: string): Verdict {
  const surface = deriveMoneySurface(cwd);
  return detect(forSurface({ ...surface, cwd }));
}

export default detect;
