// N-CAS-01 — portable static detector: a status transition is a locked compare-and-set, not a
// read-then-blind-write.
//
// INVARIANT: when an atomic op reads rows of a table BY a status (`… WHERE status = <S>`) and then
// transitions each to another status, the transition must be safe against a concurrent change of
// that row between the read and the write. It is safe iff EITHER the read took a row lock
// (`FOR UPDATE`) OR the write is itself conditional on the status (`UPDATE … SET status = <X> WHERE
// id = <row> AND status = <S>`). A read with no `FOR UPDATE` followed by an UNCONDITIONAL
// `UPDATE … WHERE id = <row>` (status dropped from the WHERE) is a TOCTOU race: a capture (or any
// transition) that commits between the read and the write is silently clobbered.
//
// This REFINES the atomicity-under-lock family: N-STATE-01 checks the OUTER subject lock (the member
// row); this checks the INNER compare-and-set loop over a related table (e.g. reversing a member's
// authorizations on removal). They are distinct, so this is its own detector. It is a SOURCE scanner
// over the migration SQL functions, fails CLOSED on the read-then-blind-write shape, needs no
// adapter, and keys on the stable SQL shape — not on a function name.

import { readdirSync, readFileSync } from "node:fs";
import { checked, finding, notApplicable, type Verdict } from "../money-system.ts";

export interface CasConfig {
  /** Directory of *.sql migrations that define the atomic ops. Default "supabase/migrations". */
  migrationsDir?: string;
  /** Prefix marking this app's own atomic SQL ops, e.g. "harbor_". Default "harbor_". */
  sqlFnPrefix?: string;
  /** Repo root. Default process.cwd(). */
  cwd?: string;
}

/** The neobank binding. The CAS shape is detected generically; nothing app-specific is needed. */
export const NEOBANK: CasConfig = {
  migrationsDir: "supabase/migrations",
  sqlFnPrefix: "harbor_",
};

// --- pure source-reading primitives (repo-agnostic; mirror the other static detectors) -

const stripSqlComments = (sql: string): string => sql.replace(/--[^\n]*/g, "");
const escapeRe = (s: string): string => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

/** name (lowercased) -> body of every SQL function. */
function sqlFunctions(sql: string): Map<string, string> {
  const out = new Map<string, string>();
  const re =
    /create\s+(?:or\s+replace\s+)?function\s+(?:public\.)?(\w+)\s*\([\s\S]*?\$(\w*)\$([\s\S]*?)\$\2\$/gi;
  for (const m of stripSqlComments(sql).matchAll(re)) out.set(m[1].toLowerCase(), m[3]);
  return out;
}

// --- the compare-and-set logic ---------------------------------------------------------

/**
 * Scan each `FROM/JOIN <table>` select statement (up to the next `loop` or `;`): does it filter on a
 * status, and does that read take a row lock (`FOR UPDATE`)? Returns whether any status-filtered read
 * of the table exists, and whether any such read is UNLOCKED.
 */
function statusReads(body: string, table: string): { any: boolean; unlocked: boolean } {
  const fromRe = new RegExp(`\\b(?:from|join)\\s+(?:public\\.)?${escapeRe(table)}\\b`, "gi");
  let any = false;
  let unlocked = false;
  for (const m of body.matchAll(fromRe)) {
    const rest = body.slice(m.index);
    const loopAt = rest.search(/\bloop\b/i);
    const semiAt = rest.indexOf(";");
    const ends = [loopAt, semiAt].filter((n) => n >= 0);
    const end = ends.length ? Math.min(...ends) : Math.min(rest.length, 400);
    const span = rest.slice(0, end);
    if (/\bstatus\b\s*=\s*'[^']+'/i.test(span)) {
      any = true;
      if (!/\bfor\s+update\b/i.test(span)) unlocked = true;
    }
  }
  return { any, unlocked };
}

export interface CasScan {
  /** "<fn>: <table> …" for each read-then-blind-write status transition (each a race). */
  violations: string[];
  /** A compare-and-set status transition (status read + status update of the same table) is present. */
  applicable: boolean;
}

/**
 * Pure core. For every atomic op, every `UPDATE <t> SET … status = '<X>' … WHERE <clause>` whose
 * WHERE drops the status predicate (an unconditional by-id write) is a race when the op also read
 * `<t>` by status without a row lock. Safe iff the read is `FOR UPDATE` or the write keeps the status
 * in its WHERE.
 */
export function scanCas(sqlText: string, cfg: CasConfig): CasScan {
  const prefix = (cfg.sqlFnPrefix ?? "harbor_").toLowerCase();
  const out: CasScan = { violations: [], applicable: false };
  const fns = sqlFunctions(sqlText);
  const updateRe =
    /update\s+(?:public\.)?(\w+)\s+set\b[\s\S]*?\bstatus\s*=\s*'[^']+'[\s\S]*?\bwhere\s+([^;]+);/gi;
  for (const [name, body] of fns) {
    if (!name.startsWith(prefix) || name.startsWith(prefix + "_")) continue; // top-level ops only
    for (const m of body.matchAll(updateRe)) {
      const table = m[1];
      const whereClause = m[2];
      const byId = /\bid\s*=/.test(whereClause); // keyed by a (row) id
      const conditional = /\bstatus\b/i.test(whereClause); // re-checks status in the write
      if (!byId) continue; // not an id-keyed status transition
      const reads = statusReads(body, table);
      if (!reads.any) continue; // no paired status read → not a read-then-write CAS transition
      out.applicable = true; // the CAS pattern is present (safe or not)
      if (!conditional && reads.unlocked) {
        out.violations.push(
          `${name}: reads ${table} by status without FOR UPDATE, then does an UNCONDITIONAL ` +
            `\`update ${table} set status … where ${whereClause.trim()}\` — a concurrent transition ` +
            `between the read and this write is silently clobbered (TOCTOU)`,
        );
      }
    }
  }
  return out;
}

/** Convenience core, matching the other detectors' `<name>Violations(): string[]` shape. */
export function casViolations(sqlText: string, cfg: CasConfig): string[] {
  return scanCas(sqlText, cfg).violations;
}

function migrationSql(cfg: CasConfig): string {
  const dir = cfg.migrationsDir ?? "supabase/migrations";
  const base = cfg.cwd ? `${cfg.cwd}/${dir}` : dir;
  return readdirSync(base)
    .filter((f) => f.endsWith(".sql"))
    .sort()
    .map((f) => readFileSync(`${base}/${f}`, "utf8"))
    .join("\n");
}

/** Run the detector against the live repo. */
export function detect(config: CasConfig): Verdict {
  let sqlText: string;
  try {
    sqlText = migrationSql(config);
  } catch {
    return notApplicable(
      `migrations dir not found: ${config.migrationsDir ?? "supabase/migrations"}`,
    );
  }
  const scan = scanCas(sqlText, config);
  if (!scan.applicable) {
    return notApplicable(
      "no status compare-and-set (a status-filtered read + a status update of the same table) is present",
    );
  }
  if (scan.violations.length) {
    return finding(
      `${scan.violations.length} status transition(s) read without FOR UPDATE then blind-write by id (TOCTOU)`,
      { violations: scan.violations },
    );
  }
  return checked(
    "every status transition either locks the read (FOR UPDATE) or re-checks the status in the write",
  );
}

export default detect;
