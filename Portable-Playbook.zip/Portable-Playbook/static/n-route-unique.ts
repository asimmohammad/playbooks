// N-ROUTE-UNIQUE — portable static detector: the HTTP entry registers each (method, path) exactly
// ONCE, and a money/approval route is never SHADOWED by an earlier/looser registration that bypasses
// the guard the workflow-aware route enforces.
//
// INVARIANT: a first-match router (push a route, then serve the FIRST entry whose method+path match —
// the node:http idiom pmar and its peers use) is order-sensitive. If the SAME (method, path) is
// registered twice, one of the two handlers is dead: the later one is unreachable, or — worse — the
// EARLIER, less-guarded one wins. For a money/approval route that is a correctness breach, not a lint
// nit: pmar registers `POST /v1/expenses/:id/approve` first as `expenses.approve` (a single-step
// approve that recognizes the expense straight onto the P&L) and AGAIN, later, as
// `policy.approveLevel` (the multi-level BR-018 workflow that walks the pending `expense_approvals`
// steps). Because the router serves the first match, every approval silently takes the single-step
// path and the entire multi-level approval chain — the pending-level steps, the per-level approver of
// record, the "not approved until the last level clears" guard — is never consulted. The money moves
// (the expense is recognized / reimbursed) having skipped the control that was supposed to gate it.
//
// SMELL (any one is a FINDING):
//   A. [duplicate-route] two route registrations share the same method + (parameter-normalized) path
//      on a MONEY/APPROVAL path — one of them is unreachable under a first-match router; and
//   B. [approval-bypass-shadow] in such a duplicate the WINNING (first) handler recognizes/moves money
//      directly WITHOUT consulting the workflow/pending-steps, while a SHADOWED (later) registration of
//      the same route is the workflow-aware approval handler — the money route bypasses its approval chain.
//
// Like the rest of the family this is a SOURCE scanner (fail-closed, needs no adapter, keys on a stable
// surface — the HTTP entrypoint where routes are registered — not on a function name). It shares the
// TypeScript source-reading MODE of N-TENANT-ISO / N-ONCE: it reads the HTTP entry with node:fs, matches
// route registrations with regex, groups them by method+path, and — for a shadowed approval route —
// classifies the winning vs shadowed handlers by their money/workflow vocabulary, following a handler
// that merely dispatches `app.services.X.method(...)` INTO the money files (surface.moneyPaths) to read
// that method's body (so policy.ts's `approveLevel` reads as workflow-aware, gaap.ts/expenses.ts's
// `recognizeExpense`/`approve` as a direct money move). Only PATHS come from the surface; all the
// money/approval/workflow vocabulary is generic and lives in the config. Dormant (NOT_APPLICABLE) until
// at least one money/approval route is actually registered — an app with no approval route has no
// approval chain to shadow here.

import { readFileSync } from "node:fs";
import { checked, finding, notApplicable, type Verdict } from "../money-system.ts";
import { deriveMoneySurface, type DerivedSurface } from "../derive.ts";
import { PMAR_SURFACE, type MoneySurface } from "../adapters/pmar.ts";

export interface RouteUniqueConfig {
  /** HTTP entrypoint file(s) where routes are registered. From surface.httpEntry (v4) or static. */
  httpEntryFiles: string[];
  /**
   * A method-as-STRING registration — `add("POST", "/path", handler)` / `addRoute("POST", "/path", …)`.
   * Capture group [1] = HTTP method, [2] = path. Global.
   */
  methodStringRoute: RegExp;
  /**
   * A method-as-CALL-NAME registration — `.post("/path", handler)` / `.get("/path", …)`.
   * Capture group [1] = HTTP method (the call name), [2] = path. Global.
   */
  methodCallRoute: RegExp;
  /** A MONEY/APPROVAL path — recognises an approval/money-movement route by its path vocabulary. */
  approvalPath: RegExp;
  /** A handler that CONSULTS the workflow / pending-approval steps (the guarded, workflow-aware path). */
  workflowAware: RegExp;
  /** A handler that RECOGNISES/MOVES money directly (recognize, reimburse, pay, post an entry, …). */
  directMove: RegExp;
  /**
   * Money files a dispatching handler may reach into — to read the body of the service method it calls
   * (`app.services.X.method(...)`) and classify it. From surface.moneyPaths (v4). Glob entries (with a
   * `*`) are skipped (unreadable); the derived surface supplies concrete file paths.
   */
  handlerTargets?: string[];
  /** Repo root. Default process.cwd(). */
  cwd?: string;
}

/**
 * The GENERIC route/money/approval/workflow vocabulary — bakes in NO app path. Shared by the static
 * PMAR binding and the derived forSurface() binding; only the FILE LIST differs between them.
 */
export const ROUTE_REGEXES: Omit<RouteUniqueConfig, "httpEntryFiles" | "handlerTargets" | "cwd"> = {
  // add("POST", "/v1/…", …) / addRoute("POST", "/v1/…", …). First arg is a quoted HTTP method.
  methodStringRoute:
    /\b(?:add|addRoute)\s*\(\s*["'`](GET|POST|PUT|PATCH|DELETE|HEAD|OPTIONS)["'`]\s*,\s*["'`]([^"'`]+)["'`]/gi,
  // .post("/v1/…", …) / .get("/v1/…", …) — the method is the call name.
  methodCallRoute: /\.(get|post|put|patch|delete|head|options)\s*\(\s*["'`]([^"'`]+)["'`]/gi,
  // a path that moves money / drives an approval: /approve, /reject, /reimburse…, /pay, /decide, …
  approvalPath:
    /approve|reject|reimburse|\bpay\b|decide|settle|capture|refund|payout|disburse|chargeback/i,
  // the workflow-aware path: the multi-level approval machinery and the pending-step bookkeeping.
  workflowAware:
    /approveLevel|rejectLevel|routeForApproval|currentLevel|listApprovals|nextLevel|pending[_\s]?approval|pendingSteps|expense_approvals|approval[_\s]?workflow|\bworkflow\b|requiresApproval|approvalChain/i,
  // a direct money recognition / movement: recognize(Expense), reimburse, payBill, postEntry, a plain
  // single-step `.approve(` (NOT `.approveLevel(` — the trailing `(` must be immediate).
  directMove:
    /recogni[sz]e|reimburse|payBill|recordPayment|createPayment|postEntry|\bsettle\b|\bcapture\b|expenses?\.approve|\.approve\s*\(/i,
};

/** The pmar binding — all pmar specifics live here, in config, never in the detector. */
export const PMAR: RouteUniqueConfig = {
  httpEntryFiles: [PMAR_SURFACE.httpEntry], // ["src/http/server.ts"]
  ...ROUTE_REGEXES,
};

/**
 * v4 — build the detector config from a DERIVED money surface. The HTTP entry and the money files to
 * follow dispatching handlers into are DERIVED from the repo; every route/money/approval/workflow regex
 * is reused verbatim from ROUTE_REGEXES. The runner does: `detect(forSurface(deriveMoneySurface(cwd)))`.
 */
export function forSurface(surface: DerivedSurface | MoneySurface): RouteUniqueConfig {
  return {
    httpEntryFiles: [surface.httpEntry],
    handlerTargets: surface.moneyPaths,
    ...ROUTE_REGEXES,
    cwd: surface.cwd,
  };
}

// --- pure source-reading primitives (repo-agnostic; mirror the other static detectors) -

/** 1-based line number of the character at `idx`. */
const lineAt = (text: string, idx: number): number => text.slice(0, idx).split("\n").length;

/** `re` as a non-global clone (so a shared /g/ regex's lastIndex can't leak between calls). */
const flat = (re: RegExp): RegExp => new RegExp(re.source, re.flags.replace("g", ""));

/** `re` as a global clone (for matchAll). */
const glob = (re: RegExp): RegExp => new RegExp(re.source, re.flags.includes("g") ? re.flags : re.flags + "g");

/** The paren-balanced argument region of the call whose `(` is at/after `openIdx`; its inner text. */
function balancedParens(text: string, openIdx: number): string | null {
  const open = text.indexOf("(", openIdx);
  if (open < 0) return null;
  let depth = 0;
  for (let i = open; i < text.length; i++) {
    const c = text[i];
    if (c === "(") depth++;
    else if (c === ")") {
      depth--;
      if (depth === 0) return text.slice(open + 1, i);
    }
  }
  return null;
}

/** Parameter-normalize a route path so `:id` and `:cardId` collapse (duplicate detection by shape). */
const normPath = (p: string): string => p.replace(/:[^/]+/g, ":param").replace(/\/+$/, "") || "/";

// --- route collection ------------------------------------------------------------------

/** One route registration: where it is, its method+path, and the handler/arg text that follows. */
export interface RouteSite {
  cite: string;
  method: string;
  path: string;
  norm: string;
  /** The registration call's argument text (method, path and the inline handler). */
  handler: string;
  line: number;
  isMoney: boolean;
}

/** Collect every route-registration site in one entry file (both registration idioms), deduped. */
export function collectRoutes(text: string, file: string, cfg: RouteUniqueConfig): RouteSite[] {
  const sites: RouteSite[] = [];
  const seen = new Set<string>();
  for (const re of [cfg.methodStringRoute, cfg.methodCallRoute]) {
    for (const m of text.matchAll(glob(re))) {
      const method = (m[1] ?? "").toUpperCase();
      const path = m[2] ?? "";
      if (!method || !path) continue;
      const idx = m.index ?? 0;
      const line = lineAt(text, idx);
      const norm = normPath(path);
      const key = `${method} ${norm} @${line}`;
      if (seen.has(key)) continue; // one registration matched by both idioms -> count once
      seen.add(key);
      sites.push({
        cite: `${file}:${line}`,
        method,
        path,
        norm,
        handler: balancedParens(text, idx) ?? "",
        line,
        isMoney: flat(cfg.approvalPath).test(path),
      });
    }
  }
  return sites;
}

// --- handler classification ------------------------------------------------------------

/** Whether a handler (or the service method it dispatches to) consults the workflow / moves money. */
export interface HandlerClass {
  workflow: boolean;
  direct: boolean;
}

/**
 * Classify a handler. First by its inline text; then, for a handler that only dispatches
 * `app.services.X.method(...)`, by following each dispatched method NAME into the money files and
 * reading its definition body — so `policy.approveLevel` reads as workflow-aware and
 * `expenses.approve`/`recognizeExpense` as a direct money move even when the entry one-liner is terse.
 */
export function classifyHandler(handler: string, moneyFiles: Map<string, string>, cfg: RouteUniqueConfig): HandlerClass {
  let workflow = flat(cfg.workflowAware).test(handler);
  let direct = flat(cfg.directMove).test(handler);
  // The method NAMES this handler dispatches to (`.approveLevel(`, `.approve(`, `.reimburse(`, …).
  const names = new Set<string>();
  for (const m of handler.matchAll(/\.([A-Za-z_$][\w$]*)\s*\(/g)) names.add(m[1]!);
  if (names.size && moneyFiles.size) {
    for (const name of names) {
      const defRe = new RegExp(`\\b(?:async\\s+)?${name}\\s*\\(`);
      for (const text of moneyFiles.values()) {
        const m = defRe.exec(text);
        if (!m) continue;
        const region = text.slice(m.index, m.index + 1500); // the method body window
        if (flat(cfg.workflowAware).test(region)) workflow = true;
        if (flat(cfg.directMove).test(region)) direct = true;
      }
    }
  }
  return { workflow, direct };
}

// --- the route-uniqueness logic --------------------------------------------------------

export interface RouteScan {
  /** "<cite> — <why>" for each money/approval route-uniqueness breach. */
  violations: string[];
  /** "<cite> — <why>" for each money/approval route that is registered exactly once. */
  guarded: string[];
  /** At least one money/approval route was registered (else the invariant is dormant). */
  present: boolean;
}

/**
 * Pure core. Collect all route sites across the entry files, group them by method + normalized path,
 * and for every MONEY/APPROVAL group with more than one registration raise a finding — classifying the
 * winning (first, served) handler against the shadowed (later, unreachable) ones to say whether the
 * winner skips the approval chain the shadowed workflow-aware route enforces.
 */
export function scanRoutes(
  entries: Array<{ path: string; text: string }>,
  moneyFiles: Map<string, string>,
  cfg: RouteUniqueConfig,
): RouteScan {
  const out: RouteScan = { violations: [], guarded: [], present: false };
  const groups = new Map<string, RouteSite[]>();
  for (const { path, text } of entries) {
    for (const site of collectRoutes(text, path, cfg)) {
      if (site.isMoney) out.present = true;
      const key = `${site.method} ${site.norm}`;
      (groups.get(key) ?? groups.set(key, []).get(key)!).push(site);
    }
  }

  for (const [key, group] of groups) {
    const money = group.some((s) => s.isMoney);
    if (!money) continue; // this detector's invariant is money/approval route uniqueness only
    if (group.length === 1) {
      out.guarded.push(`${group[0]!.cite} — money/approval route \`${key}\` is registered exactly once`);
      continue;
    }
    // A duplicate money/approval route — under a first-match router one registration is unreachable.
    const winner = group[0]!;
    const shadowed = group.slice(1);
    const wc = classifyHandler(winner.handler, moneyFiles, cfg);
    const shadowWorkflow = shadowed.find((s) => classifyHandler(s.handler, moneyFiles, cfg).workflow);
    if (shadowWorkflow && !wc.workflow) {
      out.violations.push(
        `${winner.cite} — money/approval route \`${key}\` is registered more than once; under a first-match ` +
          `router the FIRST registration (here, at ${winner.cite}) wins and ` +
          (wc.direct ? "recognizes/moves money directly" : "runs") +
          ` WITHOUT consulting the workflow/pending-approval steps, while the workflow-aware registration ` +
          `(${shadowWorkflow.cite}) that enforces the multi-level approval chain is SHADOWED and never reached ` +
          `[smell B: approval-bypass-shadow] — every approval silently skips its approval chain`,
      );
    } else {
      out.violations.push(
        `${winner.cite} — money/approval route \`${key}\` is registered ${group.length} times (${group
          .map((s) => s.cite)
          .join(", ")}); under a first-match router only the first is reachable and the rest are dead — one of ` +
          `two money handlers for the same route is silently unreachable [smell A: duplicate money/approval route]`,
      );
    }
  }
  return out;
}

// --- file plumbing ---------------------------------------------------------------------

function readFile(path: string, cwd?: string): string {
  return readFileSync(cwd ? `${cwd}/${path}` : path, "utf8");
}

// --- the verdict -----------------------------------------------------------------------

/** Run the detector against the live repo. */
export function detect(config: RouteUniqueConfig): Verdict {
  const entries: Array<{ path: string; text: string }> = [];
  for (const p of config.httpEntryFiles) {
    try {
      entries.push({ path: p, text: readFile(p, config.cwd) });
    } catch {
      /* this entry file is absent here (another repo, an empty fixture); skip it. */
    }
  }
  // The money files a dispatching handler may be followed into (skip unreadable glob entries, and the
  // HTTP entry itself — a handler dispatches INTO the services, and re-reading the router would let one
  // route's region bleed into a sibling route's handler classification).
  const moneyFiles = new Map<string, string>();
  const entryPaths = new Set(config.httpEntryFiles);
  for (const p of config.handlerTargets ?? []) {
    if (p.includes("*") || entryPaths.has(p)) continue;
    try {
      moneyFiles.set(p, readFile(p, config.cwd));
    } catch {
      /* absent here; skip. */
    }
  }

  const scan = scanRoutes(entries, moneyFiles, config);

  if (!scan.present) {
    return notApplicable(
      "no money/approval route is registered in the HTTP entrypoint(s) — there is no approval chain to be " +
        "shadowed here (the invariant is dormant)",
    );
  }
  if (scan.violations.length) {
    return finding(
      `${scan.violations.length} money/approval route(s) are registered more than once: under a first-match ` +
        `router a duplicate (method, path) makes one handler unreachable, and where the winning handler moves ` +
        `money without the workflow while the shadowed one is the workflow-aware approver, every approval ` +
        `bypasses its approval chain`,
      { violations: scan.violations, guarded: scan.guarded },
    );
  }
  return checked(
    "every money/approval (method, path) is registered exactly once — no route shadows a workflow-aware " +
      "approval handler, so no approval can silently skip its approval chain",
    { guarded: scan.guarded },
  );
}

export default detect;
