// N-SCHED-01 — portable static detector: a scheduled-start card is gated, and the start SURVIVES
// replacement/reissue.
//
// INVARIANT: when a money app lets a card carry a FUTURE activation instant (a "scheduled start":
// the card exists but must not authorize until that moment), two things must hold:
//   1. the authorization path GATES on the activation instant — a card whose start is in the future
//      is declined, never approved; and
//   2. that start instant SURVIVES card replacement and reissue — any code path that builds a
//      replacement/reissued card row from a prior card MUST carry the scheduled-start field over.
//      Dropping it silently re-mints the replacement as spendable-now, so a card the owner scheduled
//      for the future becomes live immediately the instant it is replaced.
//
// Leg 2 is the subtle one and is exactly the defect a blind behavioural run misses: the adapter
// issues a card and authorizes it, but never REPLACES a *scheduled* card, so "no violation seen"
// reads as a false pass. A source scan has no such blind spot — it reads every replacement builder.
//
// GENERALITY: this keys on the STABLE surfaces the spec + repo conventions mandate — the card row's
// `replaces_card_id` / scheduled-start columns and the activation-instant time-gate — NOT on any
// method name (replaceCard, reissue, …), so it still fires on an independently-written build that
// names things differently. It is a SOURCE scanner over pure text (the app/service sources where
// card rows are built, and the domain source where authorization gates on the start), parameterised
// so nothing app-specific is baked into the detector; only into the config. Dormant
// (NOT_APPLICABLE) when the app has no scheduled-start feature at all. Fails CLOSED on a match.

import { readdirSync, readFileSync } from "node:fs";
import { checked, finding, notApplicable, type Verdict } from "../money-system.ts";

export interface SchedConfig {
  /** App/service source files where card rows (fresh + replacement) are built. */
  appSources: string[];
  /** Source files where the authorization decision is made (it must gate on the activation instant). */
  authSources: string[];
  /** The scheduled-start column a card row carries, e.g. "activates_at". */
  scheduleField: string;
  /** The key marking a card-row object a replacement/reissue (non-null => built from a prior card), e.g. "replaces_card_id". */
  replacesField: string;
  /**
   * Evidence the authorization path gates on the activation instant: the start field used in a time
   * comparison. Defaults to the start field (snake or camel) within reach of a clock / `now` / `<`.
   */
  authGate?: RegExp;
  /**
   * Proof the scheduled-start FEATURE exists in this repo (tested across all sources + SQL). When it
   * matches nowhere the feature is absent and the detector is dormant. Defaults to a snake/camel
   * match on `scheduleField`.
   */
  featureMarker?: RegExp;
  /** Directory of *.sql migrations (only read to detect feature presence of the start column). */
  migrationsDir?: string;
  /** Repo root. Default process.cwd(). */
  cwd?: string;
}

/** The neobank binding — all neobank specifics live here, in config, never in the detector. */
export const NEOBANK: SchedConfig = {
  appSources: ["supabase/functions/_shared/app/service.ts"],
  authSources: ["supabase/functions/_shared/domain/cards.ts"],
  scheduleField: "activates_at",
  replacesField: "replaces_card_id",
  featureMarker: /activates_?at/i,
  migrationsDir: "supabase/migrations",
};

// --- pure source-reading primitives (repo-agnostic) -----------------------------------

const escapeRe = (s: string): string => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

/** Camel form of a snake_case identifier, e.g. activates_at -> activatesAt. */
const toCamel = (s: string): string => s.replace(/_([a-z])/g, (_, c: string) => c.toUpperCase());

/** The innermost object literal `{ ... }` that encloses `idx`, brace-matched; null if none. */
export function enclosingObject(src: string, idx: number): { obj: string; open: number } | null {
  let depth = 0;
  let open = -1;
  for (let i = idx; i >= 0; i--) {
    const ch = src[i];
    if (ch === "}") depth++;
    else if (ch === "{") {
      if (depth === 0) {
        open = i;
        break;
      }
      depth--;
    }
  }
  if (open < 0) return null;
  let d = 1;
  let j = open + 1;
  for (; j < src.length && d > 0; j++) {
    if (src[j] === "{") d++;
    else if (src[j] === "}") d--;
  }
  return { obj: src.slice(open, j), open };
}

/** The name of the nearest enclosing function/method header before `idx` (for verdict labels). */
const KEYWORD = new Set(["if", "for", "while", "switch", "catch", "return", "await", "function"]);
function enclosingFn(src: string, idx: number): string {
  const head = /(?:async\s+)?(\w+)\s*\([^)]*\)\s*(?::[^{;]+)?\{/g;
  let name = "?";
  for (const m of src.slice(0, idx).matchAll(head)) if (!KEYWORD.has(m[1])) name = m[1];
  return name;
}

// --- the scheduled-start logic ---------------------------------------------------------

export interface SchedScan {
  /** Replacement/reissue card-row builders that DROP the scheduled-start field (each a violation). */
  droppedOnReplace: string[];
  /** Replacement builders that correctly carry the scheduled-start field over. */
  carried: string[];
  /** The authorization path gates on the activation instant. */
  authGated: boolean;
  /** The scheduled-start feature is present at all (else the detector is dormant). */
  featurePresent: boolean;
}

function defaultAuthGate(scheduleField: string): RegExp {
  const camel = toCamel(scheduleField);
  return new RegExp(
    `(?:${escapeRe(scheduleField)}|${escapeRe(camel)})[\\s\\S]{0,160}?(?:getTime|Date\\.now|\\bnow\\b|<=?)`,
    "i",
  );
}

/**
 * Pure core: classify the scheduled-start feature. Every replacement/reissue card row (an object
 * literal that sets `replacesField` to a NON-null value — a card built from a prior card) MUST carry
 * the scheduled-start field, and the authorization path MUST gate on the instant.
 */
export function scanSchedule(
  appText: string,
  authText: string,
  sqlText: string,
  cfg: SchedConfig,
): SchedScan {
  const featureMarker = cfg.featureMarker ?? new RegExp(escapeRe(cfg.scheduleField), "i");
  const authGate = cfg.authGate ?? defaultAuthGate(cfg.scheduleField);
  const scan: SchedScan = {
    droppedOnReplace: [],
    carried: [],
    authGated: authGate.test(authText),
    featurePresent:
      featureMarker.test(appText) || featureMarker.test(authText) || featureMarker.test(sqlText),
  };
  if (!scan.featurePresent) return scan;

  const carriesField = new RegExp(`\\b${escapeRe(cfg.scheduleField)}\\s*:`);
  const replacesVal = new RegExp(`\\b${escapeRe(cfg.replacesField)}\\s*:\\s*([^,\\n}]+)`, "g");
  const seen = new Set<number>();
  for (const m of appText.matchAll(replacesVal)) {
    if (m[1].trim() === "null") continue; // a fresh card is not built from a prior card's schedule
    const enc = enclosingObject(appText, m.index);
    if (!enc || seen.has(enc.open)) continue;
    seen.add(enc.open);
    const where = `${enclosingFn(appText, m.index)}: card replacement/reissue row`;
    if (carriesField.test(enc.obj)) scan.carried.push(where);
    else
      scan.droppedOnReplace.push(
        `${where} drops the scheduled-start field '${cfg.scheduleField}' — a replaced/reissued ` +
          `scheduled card becomes spendable immediately (the future start is lost)`,
      );
  }
  return scan;
}

/** Convenience core, matching the other detectors' `<name>Violations(): string[]` shape. */
export function schedViolations(
  appText: string,
  authText: string,
  sqlText: string,
  cfg: SchedConfig,
): string[] {
  const scan = scanSchedule(appText, authText, sqlText, cfg);
  if (!scan.featurePresent) return [];
  const out = [...scan.droppedOnReplace];
  if (!scan.authGated)
    out.push(
      `the authorization path does not gate on the scheduled-start instant — a card whose ` +
        `'${cfg.scheduleField}' is still in the future can authorize early`,
    );
  return out;
}

function readFile(path: string, cwd?: string): string {
  return readFileSync(cwd ? `${cwd}/${path}` : path, "utf8");
}

/** Concatenate whatever files in `paths` exist; a missing file is skipped (another repo may lack it). */
function concatSources(paths: string[], cwd?: string): string {
  const parts: string[] = [];
  for (const f of paths) {
    try {
      parts.push(readFile(f, cwd));
    } catch {
      // a source this binding names is absent here; skip it.
    }
  }
  return parts.join("\n");
}

function migrationSql(cfg: SchedConfig): string {
  const dir = cfg.migrationsDir ?? "supabase/migrations";
  const base = cfg.cwd ? `${cfg.cwd}/${dir}` : dir;
  try {
    return readdirSync(base)
      .filter((f) => f.endsWith(".sql"))
      .sort()
      .map((f) => readFileSync(`${base}/${f}`, "utf8"))
      .join("\n");
  } catch {
    return "";
  }
}

/** Run the detector against the live repo. */
export function detect(config: SchedConfig): Verdict {
  const appText = concatSources(config.appSources, config.cwd);
  const authText = concatSources(config.authSources, config.cwd);
  if (!appText && !authText) {
    return notApplicable("none of the configured sources were found");
  }
  const sqlText = migrationSql(config);
  const scan = scanSchedule(appText, authText, sqlText, config);
  if (!scan.featurePresent) {
    return notApplicable("no scheduled-start card feature is present in this repo");
  }
  const violations = schedViolations(appText, authText, sqlText, config);
  if (violations.length) {
    return finding(
      `${violations.length} scheduled-start violation(s): the future activation is dropped on ` +
        `replacement/reissue, or the authorization path does not gate on it`,
      { violations, carried: scan.carried, authGated: scan.authGated },
    );
  }
  return checked(
    "the scheduled start survives replacement/reissue and the authorization path gates on it",
    { carried: scan.carried, authGated: scan.authGated },
  );
}

export default detect;
