// N-DEPLOY-BACKFILL — portable static detector: when a change adds a money-bearing account / table /
// column that EXISTING rows must have, it ships BOTH an applied migration AND a backfill for the records
// and orgs that already exist. A new money path must never assume pre-existing records already carry the
// new data.
//
// INVARIANT: a deploy is not a reset — on the day a money feature lands, the database is already full of
// orgs, expenses, bills and ledger rows created under the OLD schema. If the feature introduces a new
// account (a new chart-of-accounts entry), a new money table, or a new money column that recognition or
// settlement then READS, correctness requires two things to ship together:
//   (1) the schema change is APPLIED — the migration that creates the table/column/account actually runs
//       as part of the deploy (it is REGISTERED in the migrate runner, not merely documented as a .sql
//       file nobody applies); and
//   (2) the pre-existing data is BACKFILLED — every org that already exists is given the new account, and
//       every already-posted record that the new path depends on is reconciled, so the new money path
//       does not read a row/account/balance that was never created for the pre-deploy world.
// When a new account is seeded ONLY on the new-org path (seedOrg / seedStandardAccounts, which runs at org
// creation) with no backfill for existing orgs, every org that predates the deploy is missing the account.
// When a settlement path DEBITS an accrual/liability that a brand-new recognition step is supposed to have
// credited, every record approved BEFORE the deploy was never run through recognition, so the accrual it
// clears was never posted — the debit has no matching credit and the books go out of balance. And when the
// migrations that create all of this are documented as .sql files but the migrate runner is a no-op
// placeholder, none of it is applied at all.
//
// SMELL (any ONE is a FINDING):
//   A. [new-account-no-backfill] a new money account is defined in the chart of accounts and is posted to
//      by a recognition/settlement path, but NOTHING backfills it into existing orgs — the only seeding is
//      the new-org seedOrg/seedStandardAccounts path, so every pre-deploy org lacks the account.
//   B. [settlement-reads-unbackfilled-accrual] a settlement/reimbursement path DEBITS an accrual/liability
//      account (it assumes a pre-existing accrual balance) while nothing backfills the accrual for records
//      approved before the deploy — the debit clears an accrual that pre-deploy approvals never posted.
//   C. [migration-not-registered] documented .sql migrations exist under the migrations directory but the
//      migrate runner does not apply them (a no-op placeholder: it never reads the migrations dir, applies
//      a migration, or executes their SQL) — the schema change ships unapplied.
//
// Like the rest of the family this is a SOURCE scanner (fail-closed, needs no adapter, keys on stable
// surfaces — the chart of accounts, the schema/migrations, the seed path, the migrate runner and the money
// paths — not on any function name). It reads those files with node:fs and matches the smell with regex. It
// is DERIVED (v4): the FILES to scan come from the repo's money surface via forSurface(), so a new money
// module is in scope the moment it lands; every account/accrual/backfill/runner regex is GENERIC money
// vocabulary and lives in the config. Dormant (NOT_APPLICABLE) until a backfill-bearing surface is actually
// present — an app with no accrual-reading money path and no documented migrations has nothing to check.

import { readFileSync } from "node:fs";
import { checked, finding, notApplicable, type Verdict } from "../money-system.ts";
import { deriveMoneySurface, type DerivedSurface } from "../derive.ts";
import { type MoneySurface } from "../adapters/pmar.ts";

export interface DeployBackfillConfig {
  /** The schema file(s) — SQL migrations and/or schema.sql. From surface.schemaFiles. */
  schemaFiles: string[];
  /** Chart-of-accounts source (where new accounts are declared). From surface.chartOfAccounts. */
  chartOfAccounts: string;
  /** Money/ledger paths — recognition & settlement posts live here. From surface.moneyPaths (globs skipped). */
  moneyPaths: string[];
  /** Seed path candidates (the NEW-ORG seeding surface, excluded from moneyPaths). Derived next to the chart. */
  seedFiles: string[];
  /** Migrate-runner candidates — the command that APPLIES migrations. Derived by convention. */
  migrateRunnerFiles: string[];
  /** Path prefix identifying a documented migration file, e.g. "supabase/migrations/". */
  migrationsDir: string;

  // --- GENERIC money vocabulary (no app path/table baked in) -----------------------------
  /** A reference to an accrual / liability account the ledger posts against. */
  accrualAccountRef: RegExp;
  /** A recognition/accrual post (the leg that is supposed to CREDIT the accrual at approval). */
  recognitionPost: RegExp;
  /** A settlement/reimbursement function (the leg that DEBITS the accrual at pay-time). */
  settlementFn: RegExp;
  /** A DEBIT directed at an accrual/liability account inside a settlement region. */
  settlementDebit: RegExp;
  /** A new-account declaration in the chart of accounts (an accrual/liability entry). */
  newAccountEntry: RegExp;
  /** A backfill for EXISTING orgs/records — seed-for-existing, not the new-org seed path. */
  backfillSignal: RegExp;
  /** The NEW-ORG-only seeding path (seedOrg / seedStandardAccounts) — seeds new orgs, not existing ones. */
  newOrgSeed: RegExp;
  /** The migrate runner actually APPLIES migrations (reads the dir, applies/executes a migration). */
  runnerApplies: RegExp;
  /** Repo root. Default process.cwd(). */
  cwd?: string;
}

/**
 * The GENERIC deploy-backfill vocabulary. These regexes bake in NO app path/table — money vocabulary
 * only — and are shared by the static PMAR binding and the derived forSurface() binding; only the FILE
 * LISTS differ between them.
 */
export const DEPLOY_BACKFILL_REGEXES: Omit<
  DeployBackfillConfig,
  "schemaFiles" | "chartOfAccounts" | "moneyPaths" | "seedFiles" | "migrateRunnerFiles" | "migrationsDir" | "cwd"
> = {
  // an accrual / liability account: ACCRUED_EXPENSES, ACCOUNTS.ACCRUED_*, "accrued expenses", a LIABILITY
  // entry named accrued/accrual. NOT the recognition function `accrualLines(` (that is a post, matched below).
  accrualAccountRef: /\bACCRUED_[A-Z0-9]+\b|ACCOUNTS\.ACCRUED[A-Za-z0-9_]*|accrued[_\s-]?expenses?\b/i,
  // recognize / recognise / recognizeExpense / accrualLines / postEntry — a recognition/accrual post. The
  // identifier is immediately followed by `(`, so prose ("recognized (accrued)") is not a post site.
  recognitionPost: /\brecogni[sz]e[A-Za-z]*\s*\(|\baccrualLines\s*\(|\bpostEntry\s*\(/i,
  // a settlement / reimbursement function: reimburse( / settle*( / clearAccrual( / payReimbursement(.
  settlementFn: /\b(?:reimburse[A-Za-z]*|settle[A-Za-z]*|clearAccrual|payReimbursement)\s*\(/i,
  // a DEBIT directed at an accrual/liability account: `debitAccountId: ACCOUNTS.ACCRUED…`, a debit side on
  // an accrued account, `direction: "debit"` alongside an accrual ref.
  settlementDebit:
    /debit[A-Za-z]*\s*[:=]\s*[A-Za-z_.$]*ACCRUED[A-Za-z0-9_]*|debit[A-Za-z]*\s*[:=]\s*[A-Za-z_.$]*accrued|ACCRUED_[A-Z0-9]+[\s\S]{0,60}?["']debit["']|["']debit["'][\s\S]{0,60}?ACCRUED_[A-Z0-9]+/i,
  // a new chart-of-accounts entry for an accrual/liability: `ACCRUED_EXPENSES: "2500"` or a
  // STANDARD_ACCOUNTS row `{ code: "2500", name: "Accrued Expenses", type: "liability", … }`.
  newAccountEntry:
    /\bACCRUED_[A-Z0-9]+\s*[:=]\s*["'`][^"'`]+["'`]|\{[^}]*\bcode\s*:\s*["'`][^"'`]+["'`][^}]*(?:accru|liabilit)[^}]*\}/i,
  // a backfill for EXISTING data: the word backfill; a seed-for-existing path; an INSERT … SELECT … FROM
  // orgs into the accounts/ledger table (give every existing org the new account); an UPDATE touching an
  // accrual for existing records.
  backfillSignal:
    /\bback[_\s-]?fill\b|seed[_A-Za-z]*[Ee]xisting|[Ee]xisting[_\s]?orgs?|for\s+(?:all\s+)?existing\b|insert\s+into\s+[^;]{0,80}?(?:ledger[_\s]?account|accounts?)\b[^;]{0,200}?\bselect\b[^;]{0,220}?\borgs?\b|update\s+[^;]{0,140}?\bset\b[^;]{0,220}?accru/i,
  // the new-org-only seeding path.
  newOrgSeed: /\bseedOrg\b|\bseedStandardAccounts\b|\bseedAccounts\b/i,
  // the runner APPLIES migrations: reads the migrations dir, applies/executes a migration, loops the files.
  runnerApplies:
    /readdir(?:Sync)?\s*\(|read[_\s]?migrations|\bapply[_A-Za-z]*Migration[A-Za-z]*\s*\(|\bapplyMigration\b|migrations\.(?:forEach|map|sort)\b|for\s*\([^)]*\bmigrations\b|\bexec(?:ute)?(?:Sql)?\s*\([^)]*sql|\brunMigration[A-Za-z]*\s*\(/i,
};

/** The pmar binding — pmar specifics (paths) live here; the derived path is forSurface(). */
export const PMAR: DeployBackfillConfig = {
  schemaFiles: ["supabase/migrations/002_travel_expense.sql", "supabase/migrations/003_policy_engine.sql", "supabase/migrations/004_approval_workflows.sql"],
  chartOfAccounts: "src/lib/accounts.ts",
  moneyPaths: ["src/lib/gaap.ts", "src/services/expenses.ts", "src/services/policy.ts", "src/services/travel.ts"],
  seedFiles: ["src/lib/seed.ts"],
  migrateRunnerFiles: ["src/migrate.ts", "src/lib/migrate.ts", "scripts/migrate.ts"],
  migrationsDir: "supabase/migrations/",
  ...DEPLOY_BACKFILL_REGEXES,
};

/**
 * v4 — build the detector config from a DERIVED money surface instead of a frozen path list. The schema
 * files, chart of accounts and money paths come from the repo's surface; the seed path and migrate runner
 * are derived by convention (both are deliberately OUTSIDE moneyPaths — derive excludes seed.ts/migrate.ts
 * as plumbing — so the backfill/registration surface is reached without hand-maintenance). Every regex is
 * reused verbatim. The runner does: `detect(forSurface(deriveMoneySurface(cwd)))`.
 */
export function forSurface(surface: DerivedSurface | MoneySurface): DeployBackfillConfig {
  // migrations directory: the prefix up to and including ".../migrations/" of any migration schema file.
  const migFile = surface.schemaFiles.find((p) => /\/migrations\//.test(p) || /migrations\//.test(p));
  const migrationsDir = migFile ? migFile.replace(/(migrations\/).*$/i, "$1") : "supabase/migrations/";
  // seed candidates: next to the chart of accounts, plus the conventional spots.
  const chartDir = surface.chartOfAccounts.replace(/[^/]+$/, ""); // "src/lib/"
  const seedFiles = Array.from(
    new Set([`${chartDir}seed.ts`, "src/lib/seed.ts", "src/seed.ts", "src/lib/seedOrg.ts"]),
  );
  // migrate-runner candidates by convention (derive drops migrate.ts from moneyPaths as plumbing).
  const migrateRunnerFiles = ["src/migrate.ts", "src/lib/migrate.ts", "scripts/migrate.ts", "src/db/migrate.ts"];
  return {
    schemaFiles: surface.schemaFiles,
    chartOfAccounts: surface.chartOfAccounts,
    moneyPaths: surface.moneyPaths,
    seedFiles,
    migrateRunnerFiles,
    migrationsDir,
    ...DEPLOY_BACKFILL_REGEXES,
    cwd: surface.cwd,
  };
}

// --- pure source-reading primitives (repo-agnostic; mirror the other static detectors) -

/** 1-based line number of the character at `idx`. */
const lineAt = (text: string, idx: number): number => text.slice(0, idx).split("\n").length;

/** `re` as a non-global clone (so a shared /g/ regex's lastIndex can't leak between calls). */
const flat = (re: RegExp): RegExp => new RegExp(re.source, re.flags.replace("g", ""));

/** Does `re` match anywhere in `text`? */
const has = (re: RegExp, text: string): boolean => flat(re).test(text);

/** Index of `re`'s first match in `text`, or -1. */
function firstIdx(text: string, re: RegExp): number {
  const m = flat(re).exec(text);
  return m ? m.index : -1;
}

// --- the deploy-backfill logic ---------------------------------------------------------

export interface DeployBackfillScan {
  /** "[<leg>] <cite> — <why>" for each deploy-backfill smell found. */
  violations: string[];
  /** "[<leg>] <file> — <why>" for each leg that is guarded. */
  guarded: string[];
  /** At least one backfill-bearing surface (accrual-reading money path, or documented migrations+runner). */
  present: boolean;
}

/**
 * Pure core. Three independent legs over the gathered files:
 *   A — a new accrual account read by a recognition/settlement post, with NO backfill for existing orgs;
 *   B — a settlement path that debits an accrual, with NO backfill of the accrual for pre-deploy records;
 *   C — documented .sql migrations that the migrate runner does not apply.
 * `files` maps every declared path to its text (a missing file is simply absent).
 */
export function scanDeployBackfill(files: Map<string, string>, cfg: DeployBackfillConfig): DeployBackfillScan {
  const out: DeployBackfillScan = { violations: [], guarded: [], present: false };

  const chartText = files.get(cfg.chartOfAccounts) ?? "";
  // The money-path texts actually present (skip glob entries, which are unreadable).
  const moneyTexts: Array<{ path: string; text: string }> = [];
  for (const p of cfg.moneyPaths) {
    if (p.includes("*")) continue;
    const t = files.get(p);
    if (t !== undefined) moneyTexts.push({ path: p, text: t });
  }

  // Files the backfill may live in: schema (migrations) + seed (seed-for-existing) + money paths.
  const backfillHaystack: string[] = [];
  for (const p of cfg.schemaFiles) { const t = files.get(p); if (t !== undefined) backfillHaystack.push(t); }
  for (const p of cfg.seedFiles) { const t = files.get(p); if (t !== undefined) backfillHaystack.push(t); }
  for (const { text } of moneyTexts) backfillHaystack.push(text);
  const backfillPresent = backfillHaystack.some((t) => has(cfg.backfillSignal, t));

  // The new-org-only seeding path (for the citation that the ONLY seeding is at org creation).
  const seedOnlyNew = [...cfg.seedFiles, cfg.chartOfAccounts]
    .map((p) => ({ p, t: files.get(p) }))
    .find(({ t }) => t !== undefined && has(cfg.newOrgSeed, t));

  // Is an accrual account posted to by a recognition/settlement path? (leg A/B applicability)
  const accrualPost = moneyTexts.find(
    ({ text }) => has(cfg.accrualAccountRef, text) && (has(cfg.recognitionPost, text) || has(cfg.settlementFn, text)),
  );

  // ---- Leg A: a new accrual account, read by recognition, with no backfill for existing orgs ----
  const acctIdx = firstIdx(chartText, cfg.newAccountEntry);
  if (acctIdx >= 0 && accrualPost) {
    out.present = true;
    if (!backfillPresent) {
      const seedNote = seedOnlyNew ? ` — the only seeding is the new-org path (\`${seedOnlyNew.p}\`)` : "";
      out.violations.push(
        `[new-account-no-backfill] ${cfg.chartOfAccounts}:${lineAt(chartText, acctIdx)} — a new accrual/` +
          `liability account is declared in the chart of accounts and is posted to by the recognition/` +
          `settlement path in ${accrualPost.path}, but NOTHING backfills it into existing orgs${seedNote}; ` +
          `every org that predates this deploy is missing the account, so the new money path posts against ` +
          `an account that does not exist for the pre-deploy world`,
      );
    } else {
      out.guarded.push(
        `[new-account-no-backfill] ${cfg.chartOfAccounts} — the new accrual account ships a backfill that ` +
          `seeds it into existing orgs, not only the new-org seed path`,
      );
    }
  }

  // ---- Leg B: a settlement path that debits an accrual the pre-deploy world never posted ----
  // A settlement function AND a debit directed at an accrual/liability account in the same money file is
  // the smell — the settlementDebit idiom (`debitAccountId: …ACCRUED…`) is itself specific, so this is
  // keyed at file scope (a settlement anchor in a header comment must not hide the method body below it).
  for (const { path, text } of moneyTexts) {
    if (!has(cfg.settlementFn, text) || !has(cfg.settlementDebit, text)) continue;
    out.present = true;
    const dIdx = firstIdx(text, cfg.settlementDebit);
    if (!backfillPresent) {
      out.violations.push(
        `[settlement-reads-unbackfilled-accrual] ${path}:${lineAt(text, dIdx)} — the settlement/reimbursement ` +
          `path DEBITS an accrual/liability account (it assumes a pre-existing accrual balance) while nothing ` +
          `backfills the accrual for records approved before this deploy; every expense approved pre-deploy ` +
          `never ran through the new recognition step, so the accrual it clears was never posted — the debit ` +
          `has no matching credit and the books go out of balance`,
      );
    } else {
      out.guarded.push(
        `[settlement-reads-unbackfilled-accrual] ${path} — the settlement debits an accrual, and a backfill ` +
          `posts the missing accrual for pre-deploy records`,
      );
    }
  }

  // ---- Leg C: documented migrations the migrate runner does not apply ----
  const migrationFiles = cfg.schemaFiles.filter((p) => p.includes(cfg.migrationsDir) || /\/migrations\//.test(p));
  const runner = cfg.migrateRunnerFiles.map((p) => ({ p, t: files.get(p) })).find(({ t }) => t !== undefined);
  if (migrationFiles.length && runner) {
    out.present = true;
    if (!has(cfg.runnerApplies, runner.t!)) {
      out.violations.push(
        `[migration-not-registered] ${runner.p} — ${migrationFiles.length} documented migration(s) exist under ` +
          `${cfg.migrationsDir} (${migrationFiles.map((p) => p.slice(cfg.migrationsDir.length) || p).join(", ")}) ` +
          `but the migrate runner never reads the migrations directory, applies a migration, or executes their ` +
          `SQL — it is a no-op placeholder, so the schema change ships UNAPPLIED and the new tables/columns/` +
          `accounts do not exist in the deployed database`,
      );
    } else {
      out.guarded.push(
        `[migration-not-registered] ${runner.p} — the migrate runner reads and applies the documented migrations`,
      );
    }
  }

  return out;
}

/** Convenience core, matching the other detectors' `<name>Violations(): string[]` shape. */
export function deployBackfillViolations(files: Map<string, string>, cfg: DeployBackfillConfig): string[] {
  return scanDeployBackfill(files, cfg).violations;
}

// --- file plumbing ---------------------------------------------------------------------

function readFile(path: string, cwd?: string): string {
  return readFileSync(cwd ? `${cwd}/${path}` : path, "utf8");
}

// --- the verdict -----------------------------------------------------------------------

/** Run the detector against the live repo. */
export function detect(config: DeployBackfillConfig): Verdict {
  const files = new Map<string, string>();
  const needed = new Set<string>([config.chartOfAccounts]);
  for (const p of config.schemaFiles) needed.add(p);
  for (const p of config.moneyPaths) if (!p.includes("*")) needed.add(p);
  for (const p of config.seedFiles) needed.add(p);
  for (const p of config.migrateRunnerFiles) needed.add(p);
  for (const p of needed) {
    try {
      files.set(p, readFile(p, config.cwd));
    } catch {
      /* absent here (another repo, an empty fixture); skip. */
    }
  }

  const scan = scanDeployBackfill(files, config);

  if (!scan.present) {
    return notApplicable(
      "no backfill-bearing surface found — there is no accrual-reading recognition/settlement path and no " +
        "documented migration + runner to check, so the deploy-backfill invariant is dormant here",
    );
  }
  if (scan.violations.length) {
    return finding(
      `a money change does not ship a backfill / applied migration for the data that already exists: ` +
        `${scan.violations.length} smell(s) across new-account-no-backfill / settlement-reads-unbackfilled-` +
        `accrual / migration-not-registered — a new money path assumes pre-existing orgs and records already ` +
        `carry data that was never created for the pre-deploy world`,
      { violations: scan.violations, guarded: scan.guarded },
    );
  }
  return checked(
    "every new money account/table ships both an applied (registered) migration and a backfill for existing " +
      "orgs and records — no new money path reads a row, account or accrual that the pre-deploy world lacks",
    { guarded: scan.guarded },
  );
}

export default detect;
