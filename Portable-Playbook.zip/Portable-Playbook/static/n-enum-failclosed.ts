// N-ENUM-FAILCLOSED — portable static detector: a money-GATING enum / action / decision value is
// validated against a CLOSED set and FAILS CLOSED on an unknown value.
//
// INVARIANT: in a money system the value that decides whether a control FIRES — a policy rule's
// action (block / flag / allow), an approval decision, an exception disposition, a rule type — is an
// enum with a KNOWN, closed domain. The moment code treats that value as an open string it must ask
// one question: what happens to a value that is NOT in the known set? The only safe answer for a
// money control is FAIL CLOSED — reject, throw, or treat the unknown as the BLOCKING case. If instead
// an unrecognised value silently falls through to allow / flag / skip / no-op, then a typo in a rule
// ("blokc"), a value from an older/newer schema ("escalate"), a null, or a deliberately malformed
// rule row SILENTLY STOPS the control: out-of-policy spend that a "block" rule should have halted
// sails straight through because `action === "block"` is false and nothing else blocks. The enum was
// a suggestion, not a gate. (This is PR6 enum-validity: `(r.action as "flag" | "block") ?? "flag"`
// defaults an unknown DB action to the PERMISSIVE value, and `violations.some(v => v.action ===
// "block")` then blocks nothing — an invalid action silently stops blocking spend. One High.)
//
// SMELL (any ONE is a FINDING, in a file that has NO closed-set / fail-closed validation):
//   A. [switch-default-allow] a `switch` on a money-gating action/decision/type whose `default:`
//      branch ALLOWS / returns / no-ops (does not throw / reject / block), OR that has NO default and
//      NO exhaustiveness check — an unhandled value falls through to the permissive path;
//   B. [unvalidated-default-allow] a money-gating action is read (from a DB row / config) and cast to
//      a CLOSED string-union with a PERMISSIVE `??` / `||` fallback (`… as "flag"|"block") ?? "flag"`)
//      and nothing validates the raw value against the set — an unknown value becomes the allow case;
//   C. [implicit-allow-eq] the gating decision is a bare `=== "<blocking>"` compare on the action
//      (`v.action === "block"`) with an implicit allow for everything else — an unknown action that
//      was meant to block is treated as not-block, so the control does not fire.
//
// CHECKED when the money-gating value is validated against a closed set and fails closed: a membership
// check against a KNOWN/VALID/ALLOWED set, a schema enum parse (z.enum / safeParse), an exhaustiveness
// assert (assertNever / : never), a `throw` on an unknown/invalid action, a `switch` default that
// throws/blocks, or a fail-closed `?? "block"` default. NOT_APPLICABLE when the file has no
// money-gating enum / action / decision dispatch at all (the invariant is dormant here).
//
// Like the rest of the family this is a PURE SOURCE scanner (node:fs + regex, fail-closed). Per v4 the
// money surface is DERIVED, not declared: `forSurface(deriveMoneySurface(cwd))` builds the config from
// the repo's own money files, so a newly-landed policy / rule-dispatch module is scanned the moment it
// exists. Only PATHS come from the surface; the money-gating enum vocabulary (action/decision words,
// blocking vs allowing literals, closed-union cast, fail-closed markers) lives here in the config.

import { readFileSync } from "node:fs";
import { checked, finding, notApplicable, type Verdict } from "../money-system.ts";
import { deriveMoneySurface, type DerivedSurface } from "../derive.ts";

export interface EnumFailClosedConfig {
  /** Money files to scan (v4: surface.moneyPaths, concrete relative paths). */
  scanPaths: string[];

  // --- generic money-gating enum vocabulary (app-agnostic; stays in the detector/config) ---
  /** A money-gating action/decision/type field or variable (action, decision, verdict, ruleType …). */
  actionField: RegExp;
  /** A BLOCKING action literal — a value that STOPS money (block, deny, reject, hold, freeze …). */
  blockingLiteral: RegExp;
  /** An ALLOWING action literal — a value that LETS money through (flag, allow, permit, skip, warn …). */
  allowingLiteral: RegExp;
  /** A cast to a CLOSED string-union of 2+ literals: `as "flag" | "block"`. */
  closedUnionCast: RegExp;
  /** A PERMISSIVE `??` / `||` fallback to an allowing literal: `?? "flag"`. */
  permissiveDefault: RegExp;
  /** A `switch` whose discriminant is a money-gating action/decision. */
  switchOnAction: RegExp;
  /** Markers that validate the value against a closed set and FAIL CLOSED (make a file safe). */
  failClosedMarker: RegExp;
  /** Fail-closed tokens inside a `switch`'s `default:` branch (throw / block / reject / return false). */
  failClosedBranch: RegExp;
  /** An exhaustiveness check (assertNever / `: never`). */
  exhaustiveMarker: RegExp;
  /** Repo root. Default process.cwd(). */
  cwd?: string;
}

/**
 * The generic money-gating enum vocabulary. NO paths and NO table names here — only the idioms that
 * say "this value GATES money and is treated as an open string". Paths come from the surface.
 */
export const ENUM_SMELLS: Omit<EnumFailClosedConfig, "scanPaths" | "cwd"> = {
  // a money-gating action/decision/type field or variable. Scoped to money files + a gating-literal
  // comparison, so a generic `action`/`type` word is not flagged on its own.
  actionField: /\b(?:action|decision|disposition|verdict|rule_?type|policy_?action|effect|outcome)\b/i,
  // values that STOP money.
  blockingLiteral: /["'`](?:block|blocked|deny|denied|reject|rejected|hold|freeze|frozen|stop|decline|declined)["'`]/i,
  // values that LET money through.
  allowingLiteral: /["'`](?:flag|flagged|allow|allowed|permit|permitted|pass|passed|skip|skipped|warn|none|noop|ok|approve|approved)["'`]/i,
  // `as "x" | "y"` — a cast of an open value to a closed string-union of two or more literals.
  closedUnionCast: /\bas\s+["'`][a-z0-9_]+["'`](?:\s*\|\s*["'`][a-z0-9_]+["'`])+/i,
  // `?? "flag"` / `|| "allow"` — defaulting an unknown value to a PERMISSIVE (allowing) literal.
  permissiveDefault:
    /(?:\?\?|\|\|)\s*["'`](?:flag|flagged|allow|allowed|permit|permitted|pass|passed|skip|skipped|warn|none|noop|ok|approve|approved)["'`]/i,
  // `switch (x.action)` / `switch (decision)` — dispatch on a money-gating value.
  switchOnAction:
    /\bswitch\s*\(\s*[^)]*\b(?:action|decision|disposition|verdict|rule_?type|policy_?action|effect|outcome)\b[^)]*\)/i,
  // a closed-set membership check, a schema enum parse, an exhaustiveness assert, a throw-on-unknown,
  // or a fail-closed `?? "block"` default. Any ONE present means the file validates & fails closed.
  failClosedMarker:
    /\b(?:KNOWN|VALID|ALLOWED|PERMITTED|RECOGNI[SZ]ED)_?(?:ACTIONS?|DECISIONS?|TYPES?|VALUES?|SET)\b|\bnew\s+Set\s*\(|\bz\.enum\s*\(|\.safeParse\s*\(|\bassertNever\s*\(|\bthrow\b[^;\n]*\b(?:unknown|unrecogni[sz]ed|invalid|unexpected|unsupported|illegal)\b[^;\n]*\b(?:action|decision|type|rule|enum|value|status|disposition)\b|\bdefault\s*:\s*(?:throw\b|return\s+false\b)|(?:\?\?|\|\|)\s*["'`](?:block|deny|reject|hold|freeze|stop|decline)["'`]/i,
  // inside a switch default branch: a token that fails CLOSED.
  failClosedBranch:
    /\bthrow\b|\breturn\s+false\b|["'`](?:block|deny|reject|hold|freeze|stop|decline)["'`]|\b(?:block|deny|reject|decline)\w*\s*\(/i,
  exhaustiveMarker: /\bassertNever\s*\(|:\s*never\b/,
};

/** The pmar binding — generic vocabulary, a static file list for the non-derived path. */
export const PMAR: EnumFailClosedConfig = {
  ...ENUM_SMELLS,
  scanPaths: ["src/services/policy.ts", "src/services/ap.ts", "src/services/ar.ts", "src/services/travel.ts"],
};

// --- pure source-reading primitives (repo-agnostic; mirror the other static detectors) -

/** 1-based line number of the character at `idx`. */
const lineAt = (text: string, idx: number): number => text.slice(0, idx).split("\n").length;

/** `re` as a non-global clone (so a shared /g/ regex's lastIndex can't leak between calls). */
const flat = (re: RegExp): RegExp => new RegExp(re.source, re.flags.replace("g", ""));

/** Does `re` match anywhere in `text`? */
const has = (re: RegExp, text: string): boolean => flat(re).test(text);

/** Every match of `re` in `text` (index + matched text). */
function allMatches(text: string, re: RegExp): Array<{ index: number; text: string }> {
  const g = new RegExp(re.source, re.flags.includes("g") ? re.flags : re.flags + "g");
  const out: Array<{ index: number; text: string }> = [];
  let m: RegExpExecArray | null;
  while ((m = g.exec(text))) {
    out.push({ index: m.index, text: m[0] });
    if (m.index === g.lastIndex) g.lastIndex++;
  }
  return out;
}

/** The brace-balanced `{ … }` block at or after `fromIdx` (inner body + open/close indices). */
function balancedBraces(text: string, fromIdx: number): { body: string; open: number; close: number } | null {
  const open = text.indexOf("{", fromIdx);
  if (open < 0) return null;
  let depth = 0;
  for (let i = open; i < text.length; i++) {
    const c = text[i];
    if (c === "{") depth++;
    else if (c === "}") {
      depth--;
      if (depth === 0) return { body: text.slice(open + 1, i), open, close: i };
    }
  }
  return null;
}

// --- the enum-fail-closed logic --------------------------------------------------------

export interface EnumScan {
  /** "<file>:<line> [<leg>] — <why>" for each fail-open smell found. */
  violations: string[];
  /** "<file>:<line> [<leg>] — <why>" for each site found to validate & fail closed. */
  guarded: string[];
  /** At least one money-gating enum / action / decision dispatch was found (else dormant). */
  present: boolean;
}

/**
 * Does this file carry a money-gating enum / action / decision dispatch at all? Signals: a comparison
 * of an action field to a gating literal, a cast of a value to a closed union whose members are gating
 * literals, or a `switch` on a money-gating action. Without any of these the invariant is dormant.
 */
function hasGatingDispatch(text: string, cfg: EnumFailClosedConfig): boolean {
  // action === "<blocking|allowing>" (either side of the ==/===).
  const eqGate = new RegExp(
    `${cfg.actionField.source}\\s*(?:===|==|!==|!=)\\s*(?:${cfg.blockingLiteral.source}|${cfg.allowingLiteral.source})`,
    "i",
  );
  if (has(eqGate, text)) return true;
  if (has(cfg.switchOnAction, text)) return true;
  for (const c of allMatches(text, cfg.closedUnionCast)) {
    if (cfg.blockingLiteral.test(c.text) || cfg.allowingLiteral.test(c.text)) return true;
  }
  return false;
}

/**
 * Pure core. For each money file that both (a) carries a money-gating enum dispatch and (b) has NO
 * closed-set / fail-closed validation, report the fail-open smells A / B / C. A file that validates &
 * fails closed is recorded as guarded (and its smells are suppressed — the enum domain is closed).
 */
export function scanEnumFailClosed(
  files: Array<{ path: string; text: string }>,
  cfg: EnumFailClosedConfig,
): EnumScan {
  const out: EnumScan = { violations: [], guarded: [], present: false };

  for (const { path, text } of files) {
    if (!hasGatingDispatch(text, cfg)) continue; // no money-gating dispatch here — dormant for this file
    out.present = true;
    const fileFailsClosed = has(cfg.failClosedMarker, text) || has(cfg.exhaustiveMarker, text);

    if (fileFailsClosed) {
      out.guarded.push(
        `${path} — the money-gating action/decision is validated against a closed set and FAILS CLOSED on an ` +
          `unknown value (membership check / schema enum / exhaustiveness assert / throw-on-unknown / ` +
          `fail-closed default), so an unrecognised value cannot silently stop the control`,
      );
      continue; // closed domain — the compares/casts below are safe
    }

    // --- smell A: a switch on a money-gating action whose default allows (or is missing) ----
    for (const sw of allMatches(text, cfg.switchOnAction)) {
      const block = balancedBraces(text, sw.index);
      if (!block) continue;
      const defM = /\bdefault\s*:/.exec(block.body);
      if (!defM) {
        if (!has(cfg.exhaustiveMarker, block.body)) {
          out.violations.push(
            `${path}:${lineAt(text, sw.index)} [switch-default-allow] — a \`switch\` on a money-gating ` +
              `action/decision has NO \`default:\` branch and NO exhaustiveness check: an unrecognised value ` +
              `falls through the switch entirely and the money control silently does not fire [smell A]`,
          );
        }
        continue;
      }
      // default branch body: from `default:` to the next `case ` or the end of the switch body.
      const defStart = defM.index + defM[0].length;
      const nextCase = /\bcase\b/.exec(block.body.slice(defStart));
      const defBody = block.body.slice(defStart, nextCase ? defStart + nextCase.index : undefined);
      if (!cfg.failClosedBranch.test(defBody)) {
        out.violations.push(
          `${path}:${lineAt(text, block.open + 1 + defStart)} [switch-default-allow] — the \`default:\` branch ` +
            `of a \`switch\` on a money-gating action/decision ALLOWS / returns / no-ops (it does not throw, ` +
            `reject or block): an unknown action silently takes the permissive path and the control does not ` +
            `fire [smell A]`,
        );
      } else {
        out.guarded.push(`${path}:${lineAt(text, block.open)} [switch-default-allow] — the switch default fails closed`);
      }
    }

    // --- smell B: an action cast to a closed union with a PERMISSIVE default, unvalidated ----
    for (const c of allMatches(text, cfg.closedUnionCast)) {
      const unionIsGating = cfg.blockingLiteral.test(c.text) || cfg.allowingLiteral.test(c.text);
      if (!unionIsGating) continue; // a non-money union cast — not our concern
      const after = text.slice(c.index + c.text.length, c.index + c.text.length + 48);
      if (cfg.permissiveDefault.test(after)) {
        out.violations.push(
          `${path}:${lineAt(text, c.index)} [unvalidated-default-allow] — a money-gating action is cast to a ` +
            `closed union (\`${c.text}\`) with a PERMISSIVE fallback (\`${after.trim().slice(0, 24)}…\`) and ` +
            `nothing validates the raw value against the set: an unknown/typo'd/null action silently becomes the ` +
            `ALLOW case, so a rule meant to block out-of-policy spend stops blocking it [smell B]`,
        );
      }
    }

    // --- smell C: the gating decision is a bare `=== "<blocking>"` with an implicit allow -----
    const eqBlock = new RegExp(`${cfg.actionField.source}\\s*(?:===|==)\\s*(${cfg.blockingLiteral.source})`, "gi");
    for (const m of allMatches(text, eqBlock)) {
      out.violations.push(
        `${path}:${lineAt(text, m.index)} [implicit-allow-eq] — the money-gating decision is a bare equality ` +
          `compare to a single blocking literal (\`${m.text.trim()}\`) with an IMPLICIT allow for every other ` +
          `value, and the file never validates the action against a closed set: an unknown action that should ` +
          `have blocked is treated as not-block, so the control silently does not fire [smell C]`,
      );
    }
  }

  return out;
}

/** Convenience core, matching the other detectors' `<name>Violations(): string[]` shape. */
export function enumFailClosedViolations(
  files: Array<{ path: string; text: string }>,
  cfg: EnumFailClosedConfig,
): string[] {
  return scanEnumFailClosed(files, cfg).violations;
}

// --- file plumbing ---------------------------------------------------------------------

function readFile(path: string, cwd?: string): string {
  return readFileSync(cwd ? `${cwd}/${path}` : path, "utf8");
}

// --- the v4 surface binding ------------------------------------------------------------

/**
 * Build the detector config from a DERIVED money surface. Only the PATHS come from the surface
 * (surface.moneyPaths — the repo's own money files); the money-gating enum vocabulary is the fixed
 * `ENUM_SMELLS`. This is the v4 contract: `detect(forSurface(deriveMoneySurface(cwd)))`.
 */
export function forSurface(surface: Pick<DerivedSurface, "moneyPaths" | "cwd">): EnumFailClosedConfig {
  return { ...ENUM_SMELLS, scanPaths: surface.moneyPaths, cwd: surface.cwd };
}

// --- the verdict -----------------------------------------------------------------------

/** Run the detector against the live repo. */
export function detect(config: EnumFailClosedConfig): Verdict {
  const files: Array<{ path: string; text: string }> = [];
  for (const p of config.scanPaths) {
    if (/[*?]/.test(p)) continue; // a glob (hand-declared surface); v4 derivation yields concrete files
    try {
      files.push({ path: p, text: readFile(p, config.cwd) });
    } catch {
      /* absent here (another repo, an empty fixture); skip it. */
    }
  }

  const scan = scanEnumFailClosed(files, config);

  if (!scan.present) {
    return notApplicable(
      "no money-gating enum / action / decision dispatch was found in the derived money files — there is no " +
        "closed-set fail-closed boundary here to check (the invariant is dormant)",
    );
  }
  if (scan.violations.length) {
    return finding(
      `a money-gating enum / action is treated as an open string and FAILS OPEN: ${scan.violations.length} ` +
        `smell(s) across switch-default-allow / unvalidated-default-allow / implicit-allow-eq — an invalid or ` +
        `unknown action silently stops the money control (e.g. out-of-policy spend is no longer blocked)`,
      { violations: scan.violations, guarded: scan.guarded },
    );
  }
  return checked(
    "every money-gating action/decision is validated against a closed set and fails closed on an unknown value — " +
      "an unrecognised action is rejected or treated as blocking, so the control cannot be silently disabled",
    { guarded: scan.guarded },
  );
}

/** v4 convenience: derive the surface from `cwd` and run. */
export function detectRepo(cwd: string): Verdict {
  const surface = deriveMoneySurface(cwd);
  return detect(forSurface({ ...surface, cwd }));
}

export default detect;
