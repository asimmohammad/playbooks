// N-AGING — portable static detector: a receivable / payable / obligation stored in a table that has
// an AGING / MATURITY date column must have that date POPULATED at creation, never null-defaulted.
//
// INVARIANT: money that is owed has a clock. A `due_date` / `due_at` / `maturity_date` / `payable_on`
// column is what the aging report, the overdue/dunning logic, late-fee accrual and recognition-timing
// read to decide whether a receivable is current, due or overdue. If a row is inserted with that column
// set to NULL (or left out so the DB stores NULL), the obligation has no clock: it sits in the "current"
// bucket forever, never ages, never becomes overdue, never gets dunned — the money is owed but the books
// never say it is late. (pmar: ArService.createInvoice inserts `due_date: input.dueDate ?? null`, so a
// web-created invoice with no due date silently never becomes overdue — Qodo flagged exactly this.)
//
// SMELL (any ONE is a FINDING):
//   A. [null-default] an INSERT into a money table that HAS an aging-date column sets that column to a
//      null-ish value: `due_date: null`, `due_date: x ?? null`, `due_date: undefined`.
//   B. [omitted] an INSERT into such a table does NOT set the aging-date column at all, and the schema
//      leaves it nullable (no NOT NULL / no DEFAULT) — so the row stores NULL by omission.
//
// GUARD (CHECKED): every INSERT into an aging-bearing money table sets the aging-date column to a
// non-null value (a required param with no `?? null`, a computed date, `addDays(...)`, `new Date(...)`).
//
// DORMANT (NOT_APPLICABLE): no money table in the schema declares an aging-date column (the app has no
// aging/overdue concept), or no insert into such a table exists in the money files.
//
// PURE SOURCE scanner (node:fs + regex, fail-closed). v4 surface-derived: only PATHS + schemaFiles come
// from the surface; the aging vocabulary lives here. `detect(forSurface(deriveMoneySurface(cwd)))`.

import { readFileSync } from "node:fs";
import { checked, finding, notApplicable, type Verdict } from "../money-system.ts";
import { deriveMoneySurface, type DerivedSurface } from "../derive.ts";
import { createTables } from "./n-card-fresh.ts";

export interface AgingConfig {
  /** Money files to scan (v4: surface.moneyPaths, concrete relative paths). */
  scanPaths: string[];
  /** Schema files (v4: surface.schemaFiles) — read to learn which money tables have an aging column. */
  schemaFiles: string[];

  // --- generic aging vocabulary (app-agnostic; stays in the detector/config) ---------------
  /** An aging / maturity / due-date column name. */
  agingColumn: RegExp;
  /** A null-ish assigned value: `null`, `?? null`, `undefined`. */
  nullish: RegExp;
  /** Repo root. Default process.cwd(). */
  cwd?: string;
}

export const AGING_VOCAB: Omit<AgingConfig, "scanPaths" | "schemaFiles" | "cwd"> = {
  agingColumn: /\b(due_date|due_at|due_on|duedate|maturity_date|maturity|payable_on|pay_by|grace_until|overdue_at|net_terms_date)\b/i,
  nullish: /:\s*(?:null\b|undefined\b|[^,}{]*\?\?\s*null\b)/,
};

// --- pure source-reading primitives ------------------------------------------------------

const lineAt = (text: string, idx: number): number => text.slice(0, idx).split("\n").length;
const flat = (re: RegExp): RegExp => new RegExp(re.source, re.flags.replace("g", ""));
const has = (re: RegExp, text: string): boolean => flat(re).test(text);

function allIdx(text: string, re: RegExp): number[] {
  const g = new RegExp(re.source, re.flags.includes("g") ? re.flags : re.flags + "g");
  const out: number[] = [];
  let m: RegExpExecArray | null;
  while ((m = g.exec(text))) {
    out.push(m.index);
    if (m.index === g.lastIndex) g.lastIndex++;
  }
  return out;
}

/** The `{ … }` object literal starting at/after `from`, matched with brace balance. Bounded. */
function objectAfter(text: string, from: number): { text: string; start: number } | null {
  const open = text.indexOf("{", from);
  if (open < 0 || open - from > 40) return null; // the object must be the insert's argument, not far away
  let depth = 0;
  for (let i = open; i < text.length && i < open + 4000; i++) {
    const c = text[i];
    if (c === "{") depth++;
    else if (c === "}") {
      depth--;
      if (depth === 0) return { text: text.slice(open, i + 1), start: open };
    }
  }
  return null;
}

// --- schema: which money tables carry an aging column, and is it nullable --------------

export interface AgingTable {
  name: string;
  /** true when the column is nullable (no NOT NULL and no DEFAULT) — omission then stores NULL. */
  nullable: boolean;
}

/** Keep the tables (from the shared schema parser) that declare an aging-date column. */
export function agingTables(schemaText: string, cfg: Pick<AgingConfig, "agingColumn">): AgingTable[] {
  const out: AgingTable[] = [];
  const col = flat(cfg.agingColumn);
  for (const [name, body] of createTables(schemaText)) {
    // the aging-date column definition: a comma-separated column def whose FIRST token is aging-like
    const line = body
      .split(/,(?![^(]*\))/)
      .find((l) => col.test(l.trim().split(/\s+/).filter(Boolean)[0] ?? ""));
    if (!line) continue;
    const nullable = !/\bnot\s+null\b/i.test(line) && !/\bdefault\b/i.test(line);
    out.push({ name, nullable });
  }
  return out;
}

// --- the aging logic -------------------------------------------------------------------

export interface AgingScan {
  violations: string[];
  guarded: string[];
  /** The invariant is live: an aging-bearing money table exists AND an insert into one was seen. */
  present: boolean;
}

export function scanAging(
  files: Array<{ path: string; text: string }>,
  schemaText: string,
  cfg: AgingConfig,
): AgingScan {
  const out: AgingScan = { violations: [], guarded: [], present: false };
  const tables = agingTables(schemaText, cfg);
  if (!tables.length) return out; // no aging concept anywhere — dormant
  const byName = new Map(tables.map((t) => [t.name.toLowerCase(), t]));
  const tableAlt = tables.map((t) => t.name).join("|");
  // `.from("t").insert(` or `insert into t`
  const insertRe = new RegExp(
    `\\.from\\(\\s*["'\`](${tableAlt})["'\`]\\s*\\)[\\s\\S]{0,80}?\\.insert\\s*\\(|insert\\s+into\\s+["'\`]?(${tableAlt})["'\`]?`,
    "gi",
  );

  for (const { path, text } of files) {
    let m: RegExpExecArray | null;
    insertRe.lastIndex = 0;
    while ((m = insertRe.exec(text))) {
      const table = (m[1] ?? m[2] ?? "").toLowerCase();
      const t = byName.get(table);
      if (!t) continue;
      out.present = true;
      const obj = objectAfter(text, m.index + m[0].length - 1);
      if (!obj) continue; // raw SQL insert without a JS object literal we can inspect — skip (fail quiet)
      const col = flat(cfg.agingColumn);
      const colMatch = col.exec(obj.text);
      const cite = `${path}:${lineAt(text, obj.start)}`;
      if (colMatch) {
        // the aging column IS set — null-ish?
        const after = obj.text.slice(colMatch.index + colMatch[0].length);
        const assigned = after.match(/^\s*:\s*[^,}]*/);
        if (assigned && flat(cfg.nullish).test(colMatch[0] + assigned[0])) {
          out.violations.push(
            `${cite} [null-default] — an insert into \`${table}\` (an aging-bearing money table) sets its ` +
              `aging/due-date column to a null-ish value (\`null\` / \`?? null\` / \`undefined\`): the ` +
              `receivable/payable is created with no clock, so it sits in the "current" bucket forever and ` +
              `never ages, never becomes overdue, never gets dunned — money owed that the books never call late`,
          );
        } else {
          out.guarded.push(`${cite} [aging] — insert into \`${table}\` sets a non-null aging/due date`);
        }
      } else if (t.nullable) {
        // the aging column is NOT set and the schema leaves it nullable -> stored NULL by omission
        out.violations.push(
          `${cite} [omitted] — an insert into \`${table}\` omits its aging/due-date column entirely and the ` +
            `schema leaves that column nullable (no NOT NULL / DEFAULT): the row stores NULL, so the ` +
            `obligation has no due date and can never age or become overdue`,
        );
      } else {
        out.guarded.push(`${cite} [aging] — insert into \`${table}\`; aging column is NOT NULL / has a DEFAULT in schema`);
      }
    }
  }
  return out;
}

export function agingViolations(
  files: Array<{ path: string; text: string }>,
  schemaText: string,
  cfg: AgingConfig,
): string[] {
  return scanAging(files, schemaText, cfg).violations;
}

// --- file plumbing ---------------------------------------------------------------------

function readFile(path: string, cwd?: string): string {
  return readFileSync(cwd ? `${cwd}/${path}` : path, "utf8");
}

// --- the v4 surface binding ------------------------------------------------------------

export function forSurface(surface: Pick<DerivedSurface, "moneyPaths" | "schemaFiles" | "cwd">): AgingConfig {
  return { ...AGING_VOCAB, scanPaths: surface.moneyPaths, schemaFiles: surface.schemaFiles, cwd: surface.cwd };
}

// --- the verdict -----------------------------------------------------------------------

export function detect(config: AgingConfig): Verdict {
  const files: Array<{ path: string; text: string }> = [];
  for (const p of config.scanPaths) {
    if (/[*?]/.test(p)) continue;
    try {
      files.push({ path: p, text: readFile(p, config.cwd) });
    } catch {
      /* absent here; skip */
    }
  }
  const schemaText = config.schemaFiles.map((p) => { try { return readFile(p, config.cwd); } catch { return ""; } }).join("\n");

  const scan = scanAging(files, schemaText, config);

  if (!scan.present) {
    return notApplicable(
      "no aging-bearing money table (one with a due_date / maturity / payable-on column) is inserted into in the " +
        "derived money files — the app has no receivable/payable aging concept here, so there is no due-date to " +
        "populate (invariant dormant)",
    );
  }
  if (scan.violations.length) {
    return finding(
      `a receivable/payable is created with no aging clock: ${scan.violations.length} insert(s) set the aging/` +
        `due-date column null (or omit it on a nullable column), so the obligation never ages, never becomes ` +
        `overdue, and never gets dunned — money owed that the books silently never call late`,
      { violations: scan.violations, guarded: scan.guarded },
    );
  }
  return checked(
    "every insert into an aging-bearing money table populates its due-date / maturity column with a non-null " +
      "value — every receivable/payable has a clock, so aging and overdue detection work",
    { guarded: scan.guarded },
  );
}

export function detectRepo(cwd: string): Verdict {
  const surface = deriveMoneySurface(cwd);
  return detect(forSurface({ ...surface, cwd }));
}

export default detect;
