// N-SCREEN-02 — portable static detector: a money/activation op for a member re-screens the
// actual card HOLDER and the funding account, not just the owner.
//
// INVARIANT: an operation that moves money for a family member, or (re)activates a member's card —
// an allowance run, a member unfreeze, an invite accept, a card replace/reissue — must re-apply the
// eligibility screen to the party that will actually transact: the card HOLDER's linked profile
// (KYC + sanctions on the real legal name) AND, where it moves the owner's money, the funding
// account's open status. Screening only the owner, or trusting a pre-call check, lets a frozen or
// unverified payer move money and lets a card reactivate for a holder who should now be blocked.
//
// This is the leg a blind behavioural run misses: on a large new PR the hand-written adapter drives
// a happy-path allowance/unfreeze with an already-approved owner and a clear holder, sees no
// violation, and reports a FALSE pass — it never stages a frozen payer against the NEW surface. A
// source scan reads the operation's body directly: the screen gate is either called there or not.
//
// GENERALITY: an independently-written build of the same spec may NAME its handlers differently
// (processAllowance, reactivateMember, …). So this does NOT look up methods by name — it keys on the
// STABLE spec ROUTE PATHS (/family/members/:id/allowance/run, /unfreeze, /family/invite/:token/accept,
// card replace), follows each route to whatever handler it dispatches to, and checks THAT handler's
// body for the repo's eligibility gates (the pre-existing `canMoveMoney` / holder-screen helpers).
// Config carries all app-specifics; the detector carries none. Dormant when a route is absent; fails
// CLOSED on a defined route whose handler omits a gate.

import { readFileSync } from "node:fs";
import { checked, finding, notApplicable, type Verdict } from "../money-system.ts";

/** One gate call that must appear in a screened operation's body. */
export interface ScreenGate {
  /** Human name of the gate, e.g. "payer KYC (canMoveMoney)". Verdict output only. */
  gate: string;
  /** Pattern proving the gate is invoked in the operation body. */
  pattern: RegExp;
}

/** A money/activation endpoint (keyed by its stable route path) whose handler must re-screen. */
export interface ScreenedRoute {
  /** Human label, e.g. "allowance run". Verdict output only. */
  name: string;
  /** The stable route path that identifies this endpoint, e.g. /\/allowance\/run\b/. */
  route: RegExp;
  /** Gates that must ALL be present in the handler the route dispatches to. */
  gates: ScreenGate[];
}

export interface ScreenConfig {
  /** Source file that registers routes (the router). */
  routerSource: string;
  /** App/service source files where the handlers are defined. */
  appSources: string[];
  /** The money/activation endpoints, keyed on their stable route paths. */
  ops: ScreenedRoute[];
  /** Repo root. Default process.cwd(). */
  cwd?: string;
}

// The gates are the repo's PRE-EXISTING (base, not v2-invented) eligibility helpers — stable
// surfaces an independent rebuild of the same repo reuses. Synonyms keep a renamed helper from
// reading as a missing gate (fail closed only on a genuine omission).
const KYC: ScreenGate = {
  gate: "payer KYC (canMoveMoney)",
  pattern: /canMoveMoney\s*\(|canPayout\s*\(/,
};
const HOLDER: ScreenGate = {
  gate: "holder screen (KYC + sanctions on the linked profile)",
  pattern:
    /assertMemberCardHolderClear\s*\(|screenSanctions\s*\(|HolderClear\s*\(|screen\w*Holder/i,
};
const ACCOUNT_OPEN: ScreenGate = {
  gate: "funding account open",
  pattern: /\bstatus\b[\s\S]{0,16}?!==\s*["']open["']|account_frozen|!isOpen|accountOpen/,
};

/** The neobank binding — all neobank specifics live here, in config, never in the detector. */
export const NEOBANK: ScreenConfig = {
  routerSource: "supabase/functions/_shared/app/router.ts",
  appSources: ["supabase/functions/_shared/app/service.ts"],
  ops: [
    // Moves the owner's money into the teen pocket: re-screen the payer and require an open account.
    {
      name: "allowance run (scheduled payout)",
      route: /\/allowance\/run\b/,
      gates: [KYC, ACCOUNT_OPEN],
    },
    // Reactivates a member's card: re-screen the owner and the actual holder.
    { name: "member unfreeze", route: /\/members\/[^/"'`]+\/unfreeze\b/, gates: [KYC, HOLDER] },
    // Creates a member + card from an invite: re-screen the owner and the invitee (the holder).
    { name: "family invite accept", route: /\/invite\/[^/"'`]+\/accept\b/, gates: [KYC, HOLDER] },
    // Mints a replacement card for a holder: re-screen the owner and the actual holder.
    { name: "card replace/reissue", route: /\/cards\/[^/"'`]+\/replace\b/, gates: [KYC, HOLDER] },
  ],
};

// --- pure source-reading primitives (repo-agnostic) -----------------------------------

const escapeRe = (s: string): string => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

/**
 * The handler method a route dispatches to: find a route path literal matching `routeRe`, then the
 * first `s.<method>(` / `this.<method>(` call shortly after (the arrow/block handler). Keys on the
 * stable path, not the method name. null when no such route is registered.
 */
export function routeHandler(routerText: string, routeRe: RegExp): string | null {
  const lit = /["'`](\/[^"'`]+)["'`]/g;
  for (const m of routerText.matchAll(lit)) {
    if (!routeRe.test(m[1])) continue;
    const win = routerText.slice(m.index, m.index + 300);
    const hm = /\b(?:s|this)\.(\w+)\s*\(/.exec(win);
    if (hm) return hm[1];
  }
  return null;
}

/**
 * The body (including braces) of a method/function DEFINITION named `fn`, brace-matched; null if
 * absent. A `.fn(` call site is skipped so a call never passes for a definition.
 */
export function methodBody(src: string, fn: string): string | null {
  const re = new RegExp(`(?:async\\s+)?\\b${escapeRe(fn)}\\s*\\(`, "g");
  for (const m of src.matchAll(re)) {
    if (src[m.index - 1] === ".") continue; // a call like `this.fn(` / `s.fn(`, not a definition
    let i = m.index + m[0].length - 1; // at the "("
    let depth = 0;
    for (; i < src.length; i++) {
      if (src[i] === "(") depth++;
      else if (src[i] === ")") {
        depth--;
        if (depth === 0) {
          i++;
          break;
        }
      }
    }
    while (i < src.length && src[i] !== "{" && src[i] !== ";") i++;
    if (src[i] !== "{") continue; // a declaration/overload/call, not a definition
    const bodyStart = i;
    let bdepth = 1;
    i = bodyStart + 1;
    for (; i < src.length && bdepth > 0; i++) {
      if (src[i] === "{") bdepth++;
      else if (src[i] === "}") bdepth--;
    }
    return src.slice(bodyStart, i);
  }
  return null;
}

// --- the holder-screen logic -----------------------------------------------------------

export interface ScreenScan {
  /** "<op> (<handler>) does not re-screen <gates>" for each defined route whose handler omits a gate. */
  violations: string[];
  /** "<handler>: <op>" for each route whose handler contains every required gate. */
  screened: string[];
  /** Ops whose route the repo does not register (dormant — skipped). */
  dormant: string[];
}

/** Pure core: given the router text and the concatenated handler sources, classify each endpoint. */
export function scanScreens(routerText: string, appText: string, cfg: ScreenConfig): ScreenScan {
  const scan: ScreenScan = { violations: [], screened: [], dormant: [] };
  for (const op of cfg.ops) {
    const handler = routeHandler(routerText, op.route);
    const body = handler ? methodBody(appText, handler) : null;
    if (!handler || body === null) {
      scan.dormant.push(op.name);
      continue;
    }
    const missing = op.gates.filter((g) => !g.pattern.test(body));
    if (missing.length) {
      scan.violations.push(
        `${op.name} (${handler}) does not re-screen ${missing.map((g) => g.gate).join(" + ")} ` +
          `inside the handler — only the owner/pre-call checks guard it`,
      );
    } else {
      scan.screened.push(`${handler}: ${op.name}`);
    }
  }
  return scan;
}

/** Convenience core, matching the other detectors' `<name>Violations(): string[]` shape. */
export function screenViolations(routerText: string, appText: string, cfg: ScreenConfig): string[] {
  return scanScreens(routerText, appText, cfg).violations;
}

function readFile(path: string, cwd?: string): string {
  return readFileSync(cwd ? `${cwd}/${path}` : path, "utf8");
}

function concatSources(paths: string[], cwd?: string): string {
  const parts: string[] = [];
  for (const f of paths) {
    try {
      parts.push(readFile(f, cwd));
    } catch {
      // a source this binding names is absent here; skip it.
    }
  }
  return parts.join("\n");
}

/** Run the detector against the live repo. */
export function detect(config: ScreenConfig): Verdict {
  let routerText: string;
  try {
    routerText = readFile(config.routerSource, config.cwd);
  } catch {
    return notApplicable(`router source not found: ${config.routerSource}`);
  }
  const appText = concatSources(config.appSources, config.cwd);
  if (!appText) return notApplicable("none of the configured app sources were found");

  const scan = scanScreens(routerText, appText, config);
  if (scan.violations.length) {
    return finding(
      `${scan.violations.length} money/activation op(s) do not re-screen the actual holder or the funding account`,
      { violations: scan.violations, screened: scan.screened, dormant: scan.dormant },
    );
  }
  if (scan.screened.length === 0) {
    return notApplicable(
      "none of the configured money/activation routes are registered in this repo yet — nothing to screen",
      { dormant: scan.dormant },
    );
  }
  return checked(
    "every registered money/activation op re-screens the actual holder (and funding account where it moves money)",
    { screened: scan.screened, dormant: scan.dormant },
  );
}

export default detect;
