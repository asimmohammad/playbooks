// N-DEPLOY-01 — portable static detector: append-only immutability of deployed artifacts.
//
// INVARIANT: a file under a protected path that ALREADY EXISTS on the base branch must
// never be modified, type-changed, renamed or deleted by a branch; change ships only as a
// NEW forward file (a new migration, a new policy version). An applied migration is a fact
// about a database that has already run — editing it in place silently diverges prod from
// what the code claims was applied.
//
// This is a SOURCE/HISTORY scanner: it does not drive a MoneySystem, it reads
// `git diff --name-status` between the base and HEAD. It is parameterised by a config
// (which paths are append-only, how to find the base ref) so it is repo-agnostic — point
// `immutablePaths` at any directory whose files must be append-only.

import { execFileSync } from "node:child_process";
import { checked, finding, notApplicable, type Verdict } from "../money-system.ts";

export interface DeployConfig {
  /** Path prefixes whose pre-existing files are append-only, e.g. ["supabase/migrations/"]. */
  immutablePaths: string[];
  /** Env var naming the base ref to diff against (CI: the PR base). Default "HELIX_BASE_REF". */
  baseRefEnv?: string;
  /** Fallback base ref when the env var is unset/empty. Default "origin/main". */
  defaultBaseRef?: string;
  /** Repo root to run git in. Default process.cwd(). */
  cwd?: string;
}

/** The neobank binding — the only neobank-specific knowledge lives here, in config. */
export const NEOBANK: DeployConfig = {
  immutablePaths: ["supabase/migrations/"],
};

/**
 * Pure core: given the output of `git diff --name-status -M` and the protected prefixes,
 * list every append-only violation. A status of "A" (added) is always allowed; "M"/"T"
 * (modified / type-changed), "R*" (renamed) and "D" (deleted) on a protected path are not.
 */
export function deployViolations(nameStatus: string, immutablePaths: string[]): string[] {
  const out: string[] = [];
  for (const line of nameStatus.split("\n").filter(Boolean)) {
    const [status, before] = line.split("\t");
    if (!before || status === "A") continue;
    if (!immutablePaths.some((p) => before.startsWith(p))) continue;
    const what = status.startsWith("R")
      ? "renamed"
      : status === "D"
        ? "deleted"
        : status === "C"
          ? "copied-over"
          : "modified";
    out.push(`${before}: ${what} (protected paths are append-only)`);
  }
  return out;
}

function resolveBaseRef(cfg: DeployConfig): string | null {
  const ref =
    process.env[cfg.baseRefEnv ?? "HELIX_BASE_REF"] || cfg.defaultBaseRef || "origin/main";
  try {
    execFileSync("git", ["rev-parse", "--verify", "--quiet", `${ref}^{commit}`], {
      stdio: "pipe",
      cwd: cfg.cwd,
    });
    return ref;
  } catch {
    return null;
  }
}

/** Run the detector against the live repo. Sync; does only git + no app code. */
export function detect(config: DeployConfig): Verdict {
  const base = resolveBaseRef(config);
  if (base === null) {
    return notApplicable(
      "base ref not resolvable — set HELIX_BASE_REF or fetch origin/main (the diff could not run)",
      {
        tried: config.baseRefEnv ?? "HELIX_BASE_REF",
        fallback: config.defaultBaseRef ?? "origin/main",
      },
    );
  }
  const nameStatus = execFileSync(
    "git",
    ["diff", "--no-color", `${base}...HEAD`, "--name-status", "-M", "--", ...config.immutablePaths],
    { encoding: "utf8", maxBuffer: 64 * 1024 * 1024, cwd: config.cwd },
  );
  const violations = deployViolations(nameStatus, config.immutablePaths);
  if (violations.length) {
    return finding(
      `${violations.length} append-only path(s) were modified/renamed/deleted since base`,
      { base, violations },
    );
  }
  return checked("no pre-existing protected file was changed since base", { base });
}

export default detect;
