// N-SOD — portable static detector: an approval that GATES money movement is performed by an
// IDENTIFIED actor who is not the submitter/beneficiary and holds an amount-scoped authority tier
// (separation of duties / maker-checker).
//
// INVARIANT: in a spend platform, an approval is the control that releases money — an approved
// expense becomes reimbursable, an approved bill becomes payable. For that control to mean anything
// the approval must be attributable and independent: (1) it is performed by an IDENTIFIED actor (the
// approver is captured, not null/anonymous), (2) that actor is NOT the one who submitted or benefits
// from the spend (a maker cannot be their own checker — otherwise anyone self-approves their own
// reimbursement), and (3) the actor holds enough AUTHORITY for the amount (an approval limit keyed by
// approver + amount, so a junior cannot wave through a six-figure bill). An approve/signoff path that
// takes no approver, stamps a constant/null actor, never compares the approver to the originator, or
// never checks an amount-scoped limit is a direct fraud/leak vector: money leaves on an approval that
// no identified, independent, authorised person actually made.
//
// Four defences make a money-gating approval separation-of-duties safe, and ALL must be present (the
// absence of ANY ONE is the smell):
//   (a) the approve/signoff method takes an ACTOR/APPROVER parameter in its signature;
//   (b) it records that actor (not a constant/null) on the approval path (e.g. the audit/actor field);
//   (c) it compares the approver against an ORIGINATOR field (employee_id/submitter/owner/created_by/
//       beneficiary) — i.e. rejects self-approval;
//   (d) it looks up an approval LIMIT keyed by actor + amount (amount-scoped authority).
//
// SMELL (any one is a FINDING): an approval surface — a method whose NAME matches /approve|signoff/,
// OR whose body performs an `UPDATE … SET … status = 'approved'` — that fails ANY of (a)–(d).
//
// Like the rest of the family this is a SOURCE scanner (fail-closed, needs no adapter, keys on stable
// surfaces — the approve/signoff method shape and the approved-status UPDATE idiom — not on one app's
// function name). It shares its source-reading MODE with N-OBLIG-DUP / N-PASSTHRU-LIAB: pmar's money
// logic is TypeScript in src/services/** (there is NO supabase/migrations dir — see adapters/pmar.ts),
// so this reads the service TS with node:fs and matches the smell with regex. It is parameterised so
// nothing app-specific — the flows, their service files, the approver/originator/limit vocabulary — is
// baked into the detector; only into the config. Dormant (NOT_APPLICABLE) until a money-gating
// approval surface is actually present.

import { readFileSync } from "node:fs";
import { checked, finding, notApplicable, type Verdict } from "../money-system.ts";
import { type DerivedSurface } from "../derive.ts";
import { type MoneySurface } from "../adapters/pmar.ts";

// DEEPEN (v4): beyond the amount-scoped maker-checker defences (a)-(d) on the expense/bill approval
// surfaces, this detector now also checks a SECOND failure class on any money decision path: the
// decision's ACTOR must be an authenticated, authorised identity — not a value the caller handed in,
// not the submitter, and not someone other than the approver the step was assigned to. Three further
// smells (PR6/9/12 separation-of-duties, 3 High):
//   (e) [request-supplied-actor] an approve/decide HANDLER takes the acting identity from the REQUEST
//       (req body/header/query, e.g. `b.actorId`) with no authenticated-principal source — any logged-in
//       caller names themselves (or anyone) as the approver of record;
//   (f) [self-approval] a decision method with an actor parameter writes the decision (decided_by /
//       status -> approved|rejected) but NEVER compares the actor to an originator/submitter field — the
//       maker approves their own spend;
//   (g) [assigned-approver-bypass] a decision method touches the step's ASSIGNED-approver field
//       (approver_id / assignee) but never constrains the action to it (no `.eq("approver_id", actor)`,
//       no actor === approver_id check) — any caller decides a step assigned to someone else.
// Smells (f)/(g) are scanned over the DERIVED money files (forSurface -> surface.moneyPaths, reaching
// src/services/policy.ts and peers); smell (e) over the derived HTTP entry. Every regex is GENERIC
// decision vocabulary; only the FILES come from the surface.

/** One approval flow (e.g. expense approval, bill approval) and where its service code lives. */
export interface ApprovalFlow {
  /** Human label for verdict output, e.g. "expense approval". */
  name: string;
  /** Service file(s) that hold this flow's approve/signoff surface. */
  serviceFiles: string[];
}

export interface SodConfig {
  /** The approval flows to check. */
  flows: ApprovalFlow[];
  /** Method-NAME signal for an approval surface, e.g. /approve|signoff/i. */
  approvalName: RegExp;
  /** Body signal for an approval surface: an `UPDATE … SET … status = 'approved'`. */
  approvedUpdate: RegExp;
  /** Recognises an approver/actor PARAMETER by name (defence a), e.g. /approver|actor|approved_by/i. */
  actorParam: RegExp;
  /** Recognises a CONSTANT/null actor being recorded (the negation of defence b), e.g. actorId: null. */
  constantActor: RegExp;
  /** The ORIGINATOR field vocabulary the approver must be compared against (defence c). */
  originatorField: RegExp;
  /** Recognises an approval-LIMIT / authority lookup (defence d), e.g. /approval_limit|approver_authority/i. */
  limitVocab: RegExp;
  /** An amount token the limit must be scoped to (defence d), e.g. /amount_minor|amountMinor/i. */
  amountField: RegExp;

  // --- v4 deepen: the actor-identity smells (e)/(f)/(g) ---------------------------------
  /**
   * Files to scan for the decision-actor smells (f)/(g). The FLOWS above carry the amount-scoped
   * maker-checker defences; this broader set (derived money paths incl. src/services/policy.ts) is
   * where any money DECISION method is checked for self-approval and assigned-approver bypass.
   */
  decisionFiles?: string[];
  /** HTTP entry file(s) where request handlers wire the acting identity into a decision call (smell e). */
  httpEntryFiles?: string[];
  /** Recognises a decision method NAME: approve / decide / signoff / authorize / reject. */
  decisionName: RegExp;
  /** Body signal that a method WRITES a decision: a decided_by / approved_by field, or status -> approved|rejected. */
  decisionWrite: RegExp;
  /** The STEP's assigned-approver column (distinct from the actor), e.g. /approver_id|assignee/ (defence g). */
  assignedApproverField: RegExp;
  /** A request-supplied acting identity on a handler argument, e.g. `b.actorId` / `req.body.approverId` (smell e). */
  actorFromRequest: RegExp;
  /** An authenticated-principal acting identity, e.g. /principal|session|claims|currentUser/ (the safe form of e). */
  principalActor: RegExp;

  /** Repo root. Default process.cwd(). */
  cwd?: string;
}

/** The pmar binding — all pmar specifics live here, in config, never in the detector. */
export const PMAR: SodConfig = {
  flows: [
    { name: "expense approval", serviceFiles: ["src/services/expenses.ts"] },
    { name: "bill approval", serviceFiles: ["src/services/ap.ts"] },
  ],
  approvalName: /\b(?:approv\w*|sign[_-]?off\w*|signoff\w*|authoriz\w*)\b/i,
  approvedUpdate: /update\s+(?:public\.)?["'`]?\w+["'`]?\s+set\b[^;]*?\bstatus\s*=\s*['"`]approved['"`]/i,
  actorParam:
    /\b(?:approver|approved[_-]?by|actor|reviewer|checker|signer|sign[_-]?off[_-]?by|authoriz\w*|approving[_-]?user)\w*\b/i,
  // "actorId: null" / "actor_id = null" / "actorId: 'system'" / actor set to a quoted/undefined/zero constant.
  constantActor:
    /\bactor(?:_?id)?\b\s*[:=]\s*(?:null\b|undefined\b|["'`][^"'`]*["'`]|0\b)/i,
  originatorField:
    /\b(?:employee[_-]?id|submitter|submitted[_-]?by|owner|created[_-]?by|requested[_-]?by|requester|beneficiary|opened[_-]?by|maker)\b/i,
  limitVocab:
    /\b(?:approval[_-]?limit\w*|approval[_-]?tier\w*|approver[_-]?authority|authority[_-]?limit|approval[_-]?authority|spend[_-]?limit\w*|signing[_-]?limit\w*|approval[_-]?threshold\w*)\b/i,
  amountField: /\bamount[_-]?minor\b|\bamountminor\b/i,

  // v4 deepen — the decision-actor smells. Static file list for the non-derived path; forSurface()
  // swaps PATHS for the derived surface. Every regex here is generic decision vocabulary.
  decisionFiles: ["src/services/policy.ts", "src/services/expenses.ts", "src/services/ap.ts"],
  httpEntryFiles: ["src/http/server.ts"],
  decisionName: /\b(?:approv\w*|decid\w*|sign[_-]?off\w*|signoff\w*|authoriz\w*|reject\w*)\b/i,
  // a decided_by / approved_by audit field, or a status set to the approved|rejected|decision terminal.
  decisionWrite:
    /\bdecided[_-]?by\b|\bapproved[_-]?by\b|status\s*[:=]\s*["'`]?(?:approved|rejected)\b|status\s*[:=]\s*\bdecision\b|\bset\b[^;]{0,80}?\bstatus\s*=\s*["'`](?:approved|rejected)["'`]/i,
  // the STEP's assigned approver column — snake form ONLY, so it never conflates with the ACTOR token
  // (an actor named `approverId` is the maker, not the assignment; the assignment is `approver_id`).
  assignedApproverField: /\bapprover_id\b|\bassigned[_-]?to\b|\bassignee\b|\bassigned[_-]?approver\b/i,
  // a request-supplied acting identity: `b.actorId`, `body.approverId`, `req.body.actorId`, … (NOT `c.principal`).
  actorFromRequest:
    /\b(?:b|body|payload|input|req|request)\b(?:\s*\.\s*\w+|\s*\[\s*["'`]\w+["'`]\s*\])*\s*[.\[]\s*["'`]?\w*(?:actor|approver|approvedby|decidedby|signer|reviewer)\w*/i,
  principalActor:
    /\b(?:principal|authUser|auth_user|session|claims|authContext|authenticatedUser|currentUser|c\.user|req\.user|ctx\.actor)\b/i,
};

/**
 * v4 — build the detector config from a DERIVED money surface instead of a frozen path list. The
 * amount-scoped maker-checker FLOWS keep their expense/bill binding (the original bug lives in
 * expenses.ts), but the decision-actor smells (f)/(g) are scanned over EVERY derived money file
 * (so src/services/policy.ts and peers are reached), and smell (e) over the derived HTTP entry.
 * Generic decision vocabulary stays in the config; only PATHS come from the surface. The runner does:
 * `detect(forSurface(deriveMoneySurface(cwd)))`.
 */
export function forSurface(surface: DerivedSurface | MoneySurface): SodConfig {
  const mp = surface.moneyPaths;
  const pick = (re: RegExp, fallback: string): string => mp.find((p) => re.test(p)) ?? fallback;
  const flows: ApprovalFlow[] = PMAR.flows.map((f) => ({
    name: f.name,
    serviceFiles: f.serviceFiles.map((sf) => {
      const base = sf.split("/").pop() ?? sf;
      return pick(new RegExp(`(?:^|/)${base.replace(/\./g, "\\.")}$`), sf);
    }),
  }));
  return {
    ...PMAR, // reuse every regex verbatim
    flows,
    decisionFiles: mp, // scan ALL derived money files for the decision-actor smells
    httpEntryFiles: [surface.httpEntry],
    cwd: surface.cwd,
  };
}

// --- pure source-reading primitives (repo-agnostic; mirror the other static detectors) -

const escapeRe = (s: string): string => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

/** 1-based line number of the character at `idx`. */
const lineAt = (text: string, idx: number): number => text.slice(0, idx).split("\n").length;

/** A global clone of `re` (for matchAll), preserving its other flags. */
const g = (re: RegExp): RegExp => new RegExp(re.source, re.flags.includes("g") ? re.flags : re.flags + "g");

/**
 * Index just past the `}` that closes the `{` at `openIdx`, skipping string and comment content so a
 * brace inside a SQL string, a template literal, or a comment cannot miscount the body boundary.
 */
export function matchBrace(text: string, openIdx: number): number {
  let depth = 0;
  const n = text.length;
  for (let i = openIdx; i < n; i++) {
    const c = text[i];
    if (c === "/" && text[i + 1] === "/") {
      const nl = text.indexOf("\n", i);
      i = nl === -1 ? n : nl;
      continue;
    }
    if (c === "/" && text[i + 1] === "*") {
      const end = text.indexOf("*/", i + 2);
      i = end === -1 ? n : end + 1;
      continue;
    }
    if (c === "'" || c === '"' || c === "`") {
      i++;
      while (i < n && text[i] !== c) {
        if (text[i] === "\\") i++;
        i++;
      }
      continue;
    }
    if (c === "{") depth++;
    else if (c === "}") {
      depth--;
      if (depth === 0) return i + 1;
    }
  }
  return n;
}

export interface Method {
  name: string;
  params: string;
  body: string;
  line: number;
}

/**
 * Every top-level class method in `text`: `(modifiers) name(params) [: ret] { body }`. Bodies are
 * brace-balanced (strings/comments skipped), and a match that falls inside an already-captured body
 * (a nested closure) is dropped so only the enclosing method is returned.
 */
export function classMethods(text: string): Method[] {
  const re =
    /(?:^|\n)[ \t]*(?:(?:public|private|protected|static|async|readonly|override|get|set)[ \t]+)*([A-Za-z_$][\w$]*)[ \t]*\(([^)]*)\)[ \t]*(?::[^\n={]*)?\{/g;
  const kw = new Set(["if", "for", "while", "switch", "catch", "return", "function", "do", "else", "typeof", "await", "new"]);
  const out: Method[] = [];
  const consumed: Array<[number, number]> = [];
  for (const m of text.matchAll(re)) {
    const name = m[1];
    if (kw.has(name)) continue;
    const idx = m.index ?? 0;
    const braceIdx = idx + m[0].length - 1; // the '{'
    if (consumed.some(([s, e]) => braceIdx > s && braceIdx < e)) continue; // nested closure
    const end = matchBrace(text, braceIdx);
    const body = text.slice(braceIdx + 1, end - 1);
    const sigStart = m[0].startsWith("\n") ? idx + 1 : idx;
    out.push({ name, params: m[2], body, line: lineAt(text, sigStart) });
    consumed.push([braceIdx, end]);
  }
  return out;
}

/** Parameter identifiers from a param list (`a: T, b = 1` → ["a", "b"]). */
export function paramNames(params: string): string[] {
  return params
    .split(",")
    .map((p) => /^[\s{]*([A-Za-z_$][\w$]*)/.exec(p.trim())?.[1] ?? "")
    .filter(Boolean);
}

/**
 * The method's own body plus, inlined ONE level deep, the bodies of same-file private helpers it calls
 * via `this.<helper>(`. pmar's `approve` delegates its UPDATE + audit to a shared `transition` helper;
 * inlining lets defences (b)/(c)/(d) be judged on the real approval path, not just the one-line wrapper.
 */
export function effectiveBody(ownBody: string, byName: Map<string, Method>): string {
  let b = ownBody;
  const seen = new Set<string>();
  for (const m of ownBody.matchAll(/\bthis\.(\w+)\s*\(/g)) {
    const h = m[1];
    if (seen.has(h)) continue;
    seen.add(h);
    const helper = byName.get(h);
    if (helper) b += "\n" + helper.body;
  }
  return b;
}

// --- the separation-of-duties logic ----------------------------------------------------

/** Defence (c): some originator-field reference sits within a comparison that also names the actor. */
export function comparesOriginator(body: string, actorToken: string | undefined, cfg: SodConfig): boolean {
  if (!actorToken) return false;
  const actorRe = new RegExp(`\\b${escapeRe(actorToken)}\\b`);
  for (const m of body.matchAll(g(cfg.originatorField))) {
    const i = m.index ?? 0;
    const w = body.slice(Math.max(0, i - 140), i + 140);
    if (actorRe.test(w) && /===|!==|==|!=|<>/.test(w)) return true;
  }
  return false;
}

/** Defence (d): an approval-limit / authority lookup scoped to BOTH the actor and an amount. */
export function looksUpLimit(body: string, actorToken: string | undefined, cfg: SodConfig): boolean {
  if (!actorToken) return false;
  return (
    cfg.limitVocab.test(body) &&
    new RegExp(`\\b${escapeRe(actorToken)}\\b`).test(body) &&
    cfg.amountField.test(body)
  );
}

/**
 * Smell (g): the decision is CONSTRAINED to the step's assigned approver. True when the acting token is
 * equated with the assigned-approver column — a `.eq("approver_id", actor)` filter, or an explicit
 * `actor === …approver_id…` comparison. If the method touches an assigned-approver field but never does
 * this, any caller can decide a step assigned to someone else.
 */
export function checksAssignedApprover(body: string, actorToken: string | undefined, cfg: SodConfig): boolean {
  if (!actorToken) return false;
  // `.eq("approver_id", actorId)` / `.match({ approver_id: actorId })` — a query filter keyed to the actor.
  const eqFilter = new RegExp(
    `\\.(?:eq|match|filter)\\s*\\(\\s*(?:\\{\\s*)?["'\`]?[a-z_]*approver_id[a-z_]*["'\`]?\\s*[,:]\\s*${escapeRe(actorToken)}\\b`,
    "i",
  );
  if (eqFilter.test(body)) return true;
  // an explicit equality between the actor token and the assigned-approver field.
  for (const m of body.matchAll(g(cfg.assignedApproverField))) {
    const i = m.index ?? 0;
    const w = body.slice(Math.max(0, i - 160), i + 160);
    if (new RegExp(`\\b${escapeRe(actorToken)}\\b`).test(w) && /===|!==|==|!=|<>/.test(w)) return true;
  }
  return false;
}

export interface DecisionScan {
  violations: string[];
  guarded: string[];
  /** At least one money decision surface was found (across decision files + http entry). */
  present: boolean;
}

/**
 * Smells (f)/(g). For each decision file, find every DECISION surface — a class method whose name
 * matches `decisionName` AND whose OWN body writes a decision (`decisionWrite`) — that carries an actor
 * parameter, then check: (f) does it compare the actor against an originator field (else self-approval
 * is possible)? and (g) if it touches the assigned-approver field, is the action constrained to that
 * approver (else any caller decides another's step)? Uses the method's OWN body (not inlined helpers),
 * so a self-approval guard or an assignment filter must sit on the decision path itself.
 */
export function scanDecisionActors(
  fileTexts: Array<{ path: string; text: string }>,
  cfg: SodConfig,
): DecisionScan {
  const out: DecisionScan = { violations: [], guarded: [], present: false };
  for (const { path, text } of fileTexts) {
    for (const m of classMethods(text)) {
      if (!cfg.decisionName.test(m.name)) continue;
      if (!cfg.decisionWrite.test(m.body)) continue; // a NAME match that writes no decision is not a surface
      out.present = true;

      const actorToken = paramNames(m.params).find((p) => cfg.actorParam.test(p));
      const cite = `${path}:${m.line} ${m.name}()`;
      if (!actorToken) continue; // "no actor at all" is defence (a) on the flows, not a decision-actor smell

      // smell (f) — self-approval not prevented.
      if (!comparesOriginator(m.body, actorToken, cfg)) {
        out.violations.push(
          `${cite} [self-approval]: the decision records an actor (\`${actorToken}\`) but never compares it ` +
            `against an originator/submitter field — the maker can approve/decide their own spend (smell f)`,
        );
      } else {
        out.guarded.push(`${cite} [self-approval]: the actor is checked against the originator (no self-approval)`);
      }

      // smell (g) — decides a step assigned to someone else.
      if (cfg.assignedApproverField.test(m.body)) {
        if (!checksAssignedApprover(m.body, actorToken, cfg)) {
          out.violations.push(
            `${cite} [assigned-approver-bypass]: the step carries an assigned-approver field but the action is ` +
              `never constrained to it (no \`.eq("approver_id", ${actorToken})\` / actor === approver_id check) — ` +
              `any caller can decide a step assigned to a different approver (smell g)`,
          );
        } else {
          out.guarded.push(`${cite} [assigned-approver-bypass]: the action is constrained to the assigned approver`);
        }
      }
    }
  }
  return out;
}

/**
 * Smell (e). In the HTTP entry, find every call to a decision method (`.<approve|decide|...>(`) and read
 * its argument list up to end of line: if the acting identity is taken from the REQUEST (`actorFromRequest`,
 * e.g. `b.actorId`) and there is no authenticated-principal source in the same call, the approver of record
 * is whatever the caller typed — a logged-in user names themselves (or anyone) as approver.
 */
export function scanRequestActor(
  fileTexts: Array<{ path: string; text: string }>,
  cfg: SodConfig,
): DecisionScan {
  const out: DecisionScan = { violations: [], guarded: [], present: false };
  const callRe = /\.([A-Za-z_$][\w$]*)\s*\(/g;
  for (const { path, text } of fileTexts) {
    for (const m of text.matchAll(callRe)) {
      const name = m[1];
      if (!cfg.decisionName.test(name)) continue;
      const idx = m.index ?? 0;
      const eol = text.indexOf("\n", idx);
      const args = text.slice(idx, eol === -1 ? text.length : eol);
      out.present = true;
      const fromReq = cfg.actorFromRequest.test(args);
      const fromPrincipal = cfg.principalActor.test(args);
      const line = lineAt(text, idx);
      if (fromReq && !fromPrincipal) {
        out.violations.push(
          `${path}:${line} ${name}(): the acting identity is read from the request (\`${args.trim().slice(0, 120)}\`) ` +
            `with no authenticated-principal source — any caller sets the approver of record to themselves or ` +
            `another user (smell e: request-supplied actor)`,
        );
      } else if (fromPrincipal) {
        out.guarded.push(`${path}:${line} ${name}(): the acting identity comes from an authenticated principal`);
      }
    }
  }
  return out;
}

export interface SodScan {
  /** "<flow>: <file>:<line> <method>() — <missing defences>" for each unsafe approval surface. */
  violations: string[];
  /** "<flow>: <file>:<line> <method>() — separation-of-duties enforced" for each safe surface. */
  guarded: string[];
  /** At least one money-gating approval surface was found (else the invariant is dormant). */
  present: boolean;
}

/**
 * Pure core. For each flow's service files, find every approval surface (a method whose name matches
 * `approvalName`, or whose own body performs an approved-status UPDATE) and check defences (a)–(d) on
 * its effective body. Any missing defence makes the surface a violation; all four present makes it
 * guarded.
 */
export function scanApprovals(fileTexts: Array<{ flow: string; path: string; text: string }>, cfg: SodConfig): SodScan {
  const out: SodScan = { violations: [], guarded: [], present: false };
  for (const { flow, path, text } of fileTexts) {
    const methods = classMethods(text);
    const byName = new Map(methods.map((m) => [m.name, m]));
    for (const m of methods) {
      const isSurface = cfg.approvalName.test(m.name) || cfg.approvedUpdate.test(m.body);
      if (!isSurface) continue;
      out.present = true;

      const eff = effectiveBody(m.body, byName);
      const actorToken = paramNames(m.params).find((p) => cfg.actorParam.test(p));

      const missing: string[] = [];
      if (!actorToken) missing.push("no approver/actor parameter in the signature (a)");
      if (cfg.constantActor.test(eff)) missing.push("records a constant/null actor on the approval path (b)");
      if (!comparesOriginator(eff, actorToken, cfg))
        missing.push("never compares the approver against an originator field — self-approval is possible (c)");
      if (!looksUpLimit(eff, actorToken, cfg))
        missing.push("no approval limit keyed by actor + amount — authority is not amount-scoped (d)");

      const cite = `${flow}: ${path}:${m.line} ${m.name}()`;
      if (missing.length) {
        out.violations.push(`${cite} — ${missing.join("; ")}`);
      } else {
        out.guarded.push(`${cite} — approver captured, checked against the originator, and amount-scoped`);
      }
    }
  }
  return out;
}

/** Convenience core, matching the other detectors' `<name>Violations(): string[]` shape. */
export function sodViolations(fileTexts: Array<{ flow: string; path: string; text: string }>, cfg: SodConfig): string[] {
  return scanApprovals(fileTexts, cfg).violations;
}

// --- file plumbing ---------------------------------------------------------------------

function readFile(path: string, cwd?: string): string {
  return readFileSync(cwd ? `${cwd}/${path}` : path, "utf8");
}

// --- the verdict -----------------------------------------------------------------------

/** Run the detector against the live repo. */
export function detect(config: SodConfig): Verdict {
  const fileTexts: Array<{ flow: string; path: string; text: string }> = [];
  for (const flow of config.flows) {
    for (const sf of flow.serviceFiles) {
      try {
        fileTexts.push({ flow: flow.name, path: sf, text: readFile(sf, config.cwd) });
      } catch {
        /* this flow's service file is absent here; skip it. */
      }
    }
  }

  const scan = scanApprovals(fileTexts, config);

  // v4 deepen — the decision-actor smells (e)/(f)/(g) over the derived money files + HTTP entry.
  const decisionTexts: Array<{ path: string; text: string }> = [];
  for (const p of config.decisionFiles ?? []) {
    try {
      decisionTexts.push({ path: p, text: readFile(p, config.cwd) });
    } catch {
      /* absent here; skip. */
    }
  }
  const httpTexts: Array<{ path: string; text: string }> = [];
  for (const p of config.httpEntryFiles ?? []) {
    try {
      httpTexts.push({ path: p, text: readFile(p, config.cwd) });
    } catch {
      /* absent here; skip. */
    }
  }
  const decisionScan = scanDecisionActors(decisionTexts, config);
  const reqScan = scanRequestActor(httpTexts, config);

  const violations = [...scan.violations, ...decisionScan.violations, ...reqScan.violations];
  const guarded = [...scan.guarded, ...decisionScan.guarded, ...reqScan.guarded];
  const present = scan.present || decisionScan.present || reqScan.present;

  if (!present) {
    return notApplicable(
      "no money-gating approval surface (an approve/signoff/decide method, or an UPDATE … status='approved') was found — the separation-of-duties invariant does not apply here",
    );
  }
  if (violations.length) {
    return finding(
      `${violations.length} money decision(s) are not separation-of-duties safe: an approve/signoff/decide ` +
        `path takes no approver, stamps a constant/null actor, never checks an amount-scoped authority limit, ` +
        `takes its acting identity from the request, never rejects self-approval, or lets any caller decide a ` +
        `step assigned to another approver — money is released on a decision no identified, independent, ` +
        `authorised person actually made`,
      { violations, guarded },
    );
  }
  return checked(
    "every money decision is made by an authenticated, identified approver who is checked against the originator " +
      "(no self-approval), is the approver the step was assigned to, and holds an amount-scoped authority limit (maker-checker)",
    { guarded },
  );
}

export default detect;
