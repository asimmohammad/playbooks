// N-CHGBK-05 — a portable behavioural rule.
//
// INVARIANT: the money recovered on a single captured charge can never exceed what was captured.
// Once a chargeback has been decided in the party's favour for the full amount, the SAME money
// cannot be recovered again — neither by a second chargeback nor by a merchant refund.
//
// This file imports ONLY the canonical interface. It captures a charge, wins a chargeback for the
// full amount, then tries to recover it a second time (chargeback and refund) and reads the balance.

import { Capability, checked, finding, notExercised, type Rule } from "../money-system.ts";

export const nChgbk05: Rule = {
  id: "N-CHGBK-05",
  title:
    "Cumulative recovery on one captured charge never exceeds the captured amount (no double recovery).",
  requires: [Capability.Charge, Capability.Chargeback, Capability.MoveMoney],

  async run(sys) {
    for (const cap of this.requires) {
      if (!sys.supports(cap)) return notExercised(`system lacks capability: ${cap}`);
    }

    const party = await sys.principal();
    const amount = 3_000;

    const charge = await sys.authorizeAndCapture(party, {
      amountCents: amount,
      category: "grocery",
    });
    if (!charge.ok || charge.capturedCents !== amount) {
      return notExercised("could not capture the probe charge", { charge });
    }

    // Baseline AFTER the capture — recovery should bring the balance back to exactly here + amount.
    const start = (await sys.balance(party)).postedCents;

    const rec1 = await sys.disputeAndRecover(charge, amount);
    if (!rec1.ok) return finding("the first full chargeback was refused", { rec1 });
    const afterWin = (await sys.balance(party)).postedCents;
    if (afterWin !== start + amount) {
      return finding("a won chargeback did not credit exactly the captured amount", {
        start,
        afterWin,
        amount,
      });
    }

    // Second recovery attempts on the SAME, already-recovered charge must both be refused.
    const rec2 = await sys.disputeAndRecover(charge, amount);
    const ref = await sys.refund(charge, amount);
    const final = (await sys.balance(party)).postedCents;

    if (rec2.ok) {
      return finding("a second chargeback recovered the already-recovered charge again", {
        final,
        start,
        amount,
      });
    }
    if (ref.ok) {
      return finding("a merchant refund recovered money already recovered by the won chargeback", {
        final,
        start,
        amount,
      });
    }
    if (final !== start + amount) {
      return finding(`cumulative recovery is ${final - start}, exceeding the captured ${amount}`, {
        start,
        final,
      });
    }

    return checked(
      "won chargeback credited the captured amount once; a second chargeback and a refund were both refused",
      { amount, recovered: final - start, rec2: rec2.refusedReason, ref: ref.refusedReason },
    );
  },
};

export default nChgbk05;
