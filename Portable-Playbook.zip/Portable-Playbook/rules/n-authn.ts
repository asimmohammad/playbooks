// N-AUTHN — a portable behavioural rule.
//
// INVARIANT: an inbound money-moving event from an UNTRUSTED channel is authenticated before it has
// any effect. A forged (bad-signature) event is rejected and moves nothing; a validly signed but
// stale/replayed event (outside the freshness window) is rejected; only a fresh, valid event is
// applied.
//
// The sealed N-AUTHN detector proves this STRUCTURALLY on the live webhook route (HMAC-SHA-256 over
// `${t}.${payload}`, missing header/secret rejected, 4xx before processing, |now-t|>300s rejected,
// constant-time compare). This file proves the OBSERVABLE consequence through the interface, for any
// adapter that exposes an untrusted external-event surface.
//
// NOTE: capability-negotiated. The neobank DIRECT adapter wraps a trusted IN-PROCESS surface and does
// not drive the untrusted webhook channel (supports(ExternalEventAuth)=false), so this rule returns
// NOT_EXERCISED — honest "not proven", never a false CHECKED. The authentic-webhook surface is the
// HTTP edge layer (guarded structurally by the sealed N-AUTHN detector); an edge adapter would bind it.
//
// This file imports ONLY the canonical interface.

import {
  Capability,
  checked,
  finding,
  notExercised,
  type ExternalEvent,
  type Rule,
} from "../money-system.ts";

const MONEY_EVENT: ExternalEvent = {
  kind: "money-authorization",
  payload: { amountCents: 4_000, reference: "N-AUTHN-probe" },
};

export const nAuthn: Rule = {
  id: "N-AUTHN",
  title:
    "An untrusted money event is authenticated before any effect: forged and stale events are rejected, only a fresh valid one is applied.",
  requires: [Capability.ExternalEventAuth],

  async run(sys) {
    for (const cap of this.requires) {
      if (!sys.supports(cap)) {
        return notExercised(
          `system exposes no authenticated external-event surface (lacks ${cap})`,
        );
      }
    }

    // 1. A forged event must be rejected and must apply no effect.
    const forged = await sys.deliverExternalEvent(MONEY_EVENT, { valid: false });
    if (forged.accepted || forged.effectApplied) {
      return finding("a forged (bad-signature) money event was accepted or applied", { forged });
    }

    // 2. A validly signed but stale event (outside the replay window) must be rejected.
    const stale = await sys.deliverExternalEvent(MONEY_EVENT, {
      valid: true,
      staleByMs: 10 * 60_000,
    });
    if (stale.accepted || stale.effectApplied) {
      return finding("a stale/replayed money event (outside the freshness window) was accepted", {
        stale,
      });
    }

    // 3. A fresh, valid event must be accepted and applied.
    const valid = await sys.deliverExternalEvent(MONEY_EVENT, { valid: true });
    if (!valid.accepted || !valid.effectApplied) {
      return finding("a fresh, validly signed money event was not accepted/applied", { valid });
    }

    return checked(
      "forged and stale money events rejected with no effect; a fresh valid event was applied",
      { forged: forged.rejectedReason, stale: stale.rejectedReason },
    );
  },
};

export default nAuthn;
