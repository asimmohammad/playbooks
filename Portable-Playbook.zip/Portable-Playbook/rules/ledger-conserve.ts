// LEDGER-CONSERVE — a portable behavioural rule.
//
// INVARIANT: after a battery of ordinary money flows, money is conserved — the trial
// balance (sum of debit - credit across ALL ledger entries) is zero, and every individual
// transaction is internally balanced (its own debits equal its own credits).
//
// This file imports ONLY the canonical interface. It does not know what the flows are or
// how the ledger is stored; it asks the MoneySystem to run its battery, then reads the
// trial balance and the per-transaction lines.

import {
  Capability,
  type Cents,
  checked,
  finding,
  type LedgerTxn,
  notExercised,
  type Rule,
} from "../money-system.ts";

/** Net (debit - credit) across a transaction's own lines; 0 means internally balanced. */
function txnImbalance(t: LedgerTxn): Cents {
  return t.lines.reduce((net, l) => net + l.debit - l.credit, 0);
}

export const ledgerConserve: Rule = {
  id: "LEDGER-CONSERVE",
  title:
    "After ordinary money flows the trial balance is 0 and every transaction is internally balanced.",
  requires: [Capability.Ledger],

  async run(sys) {
    for (const cap of this.requires) {
      if (!sys.supports(cap)) return notExercised(`system lacks capability: ${cap}`);
    }

    await sys.runMoneyFlows();

    const trial = await sys.trialBalance();
    const txns = await sys.ledgerTransactions();
    const unbalanced = txns
      .map((t) => ({ id: t.id, kind: t.kind, imbalance: txnImbalance(t) }))
      .filter((t) => t.imbalance !== 0);

    if (trial !== 0) {
      return finding(`trial balance is ${trial} (expected 0)`, {
        trialBalance: trial,
        txnCount: txns.length,
        unbalanced,
      });
    }

    if (unbalanced.length > 0) {
      return finding(`${unbalanced.length} transaction(s) are internally unbalanced`, {
        unbalanced,
      });
    }

    return checked(`trial balance 0; all ${txns.length} transactions internally balanced`, {
      txnCount: txns.length,
    });
  },
};

export default ledgerConserve;
