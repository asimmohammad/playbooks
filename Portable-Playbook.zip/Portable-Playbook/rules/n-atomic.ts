// N-ATOMIC — a portable behavioural rule.
//
// INVARIANT: a money operation is atomic and respects balance caps under its locks. A debit that
// exceeds the available balance is refused without any partial write, and two debits that compete
// for the same money — each able to cover itself, but not both — never BOTH commit, so the balance
// is never driven negative (no TOCTOU double-spend).
//
// The sealed N-ATOMIC detector proves this STRUCTURALLY (each money op is one DB call; aggregates
// are read and capped only under a FOR UPDATE / advisory lock). This file proves the OBSERVABLE
// consequence instead: it asks the MoneySystem to move money and competes two debits, with no idea
// how the system serialises them. A system that re-checks the balance under its lock passes; one
// that trusts a stale pre-read lets both debits through and overdraws.
//
// This file imports ONLY the canonical interface.

import { Capability, checked, finding, notExercised, type Rule } from "../money-system.ts";

export const nAtomic: Rule = {
  id: "N-ATOMIC",
  title:
    "A money op is atomic and lock-safe: an over-cap debit is refused, and competing debits never both commit.",
  requires: [Capability.MoveMoney],

  async run(sys) {
    for (const cap of this.requires) {
      if (!sys.supports(cap)) return notExercised(`system lacks capability: ${cap}`);
    }

    const party = await sys.principal();
    const b0 = await sys.balance(party);
    const avail = b0.availableCents;
    if (avail <= 1) return notExercised(`principal has no spendable balance (available ${avail})`);

    // Leg 1 — an over-cap debit is refused atomically and conserves money (no partial write).
    const over = await sys.move(party, avail + 1);
    const b1 = await sys.balance(party);
    if (over.ok) {
      return finding("a debit exceeding the available balance was accepted", { avail, over });
    }
    if (b1.availableCents !== avail || b1.postedCents !== b0.postedCents) {
      return finding("a refused debit still changed the balance (partial write)", { b0, b1 });
    }

    // Leg 2 — two competing debits, each 60% of the balance, so only one can be covered.
    const each = Math.floor(avail * 0.6);
    const [o1, o2] = await Promise.all([sys.move(party, each), sys.move(party, each)]);
    const wins = [o1, o2].filter((o) => o.ok).length;
    const b2 = await sys.balance(party);

    if (b2.availableCents < 0 || b2.postedCents < 0) {
      return finding("competing debits drove the balance negative (overdraw under concurrency)", {
        each,
        b2,
      });
    }
    if (wins > 1) {
      return finding("two competing debits that together exceed the balance both committed", {
        each,
        avail,
        outcomes: [o1, o2],
      });
    }
    if (wins !== 1) {
      return finding(`expected exactly one competing debit to commit, ${wins} did`, {
        outcomes: [o1, o2],
      });
    }
    if (b2.availableCents !== avail - each) {
      return finding("the one committed debit did not move exactly its amount", {
        avail,
        each,
        b2,
      });
    }

    return checked(
      "over-cap debit refused with no partial write; exactly one of two competing debits committed; no overdraw",
      { avail, each },
    );
  },
};

export default nAtomic;
