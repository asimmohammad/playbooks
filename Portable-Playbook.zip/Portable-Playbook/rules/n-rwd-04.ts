// N-RWD-04 — a portable behavioural rule.
//
// INVARIANT (reversal symmetry for fees): a per-charge fee is RECOMPUTED ON THE CAPTURED amount,
// not snapshotted from the authorisation, and a fee that the spec keeps on reversal survives a full
// merchant refund of the purchase.
//
// This file imports ONLY the canonical interface, and derives the fee rate from the system itself
// instead of hard-coding it: a reference charge where authorised == captured reveals the fee for a
// given captured amount; the test charge authorises MORE but captures the same, so its fee must
// match the reference (proving the fee follows the capture, not the authorisation). Then it refunds
// the purchase and checks the fee is kept.

import { Capability, checked, finding, notExercised, type Rule } from "../money-system.ts";

export const nRwd04: Rule = {
  id: "N-RWD-04",
  title:
    "A card fee is recomputed on the captured amount (not the authorisation) and is kept on a full refund.",
  requires: [Capability.Charge, Capability.MoveMoney],

  async run(sys) {
    for (const cap of this.requires) {
      if (!sys.supports(cap)) return notExercised(`system lacks capability: ${cap}`);
    }

    const party = await sys.principal();
    const capAmount = 8_000;
    const authAmount = 10_000; // authorise more than we capture, so a snapshot fee would differ

    // Reference: a fee-bearing charge where authorised == captured reveals the fee for `capAmount`.
    const ref = await sys.authorizeAndCapture(party, {
      amountCents: capAmount,
      captureCents: capAmount,
      foreign: true,
      category: "grocery",
    });
    if (!ref.ok) return notExercised("could not capture the reference charge", { ref });
    const feeRef = ref.feeCents;
    if (feeRef <= 0) {
      return notExercised("the system levies no fee on this charge; nothing to reverse", { ref });
    }

    const start = (await sys.balance(party)).postedCents;

    // Test: authorise 10,000 but capture 8,000. The fee must be recomputed on the captured 8,000.
    const test = await sys.authorizeAndCapture(party, {
      amountCents: authAmount,
      captureCents: capAmount,
      foreign: true,
      category: "grocery",
    });
    if (!test.ok || test.capturedCents !== capAmount) {
      return notExercised("could not partially capture the test charge", { test });
    }
    const feeTest = test.feeCents;
    const afterCapture = (await sys.balance(party)).postedCents;

    if (feeTest !== feeRef) {
      return finding(
        `fee ${feeTest} was taken from the authorisation snapshot, not recomputed on the captured amount (expected ${feeRef})`,
        { authAmount, capAmount, feeRef, feeTest },
      );
    }
    if (afterCapture !== start - (capAmount + feeTest)) {
      return finding("capture did not debit exactly captured + recomputed fee", {
        start,
        afterCapture,
        capAmount,
        feeTest,
      });
    }

    // Reverse: a full refund returns the purchase but KEEPS the fee.
    const r = await sys.refund(test, capAmount);
    if (!r.ok) return finding("a full merchant refund of the purchase was refused", { r });
    const afterRefund = (await sys.balance(party)).postedCents;
    if (afterRefund !== start - feeTest) {
      return finding("the fee was not kept on a full merchant refund (reversal asymmetry)", {
        start,
        afterRefund,
        feeTest,
      });
    }

    return checked(
      "fee recomputed on the captured amount (independent of the authorisation) and kept on a full refund",
      { feeRef, feeTest, capAmount, authAmount },
    );
  },
};

export default nRwd04;
