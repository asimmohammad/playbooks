// N-ORDER-01 — a portable behavioural rule.
//
// INVARIANT: a money operation commits its durable ledger/record BEFORE making any irreversible
// external call. If the external call came first, a failed commit would leave an external effect
// the system has no record of and cannot unwind.
//
// The sealed N-ORDER-01 detector proves this STRUCTURALLY (no providers.*.send/charge/capture/
// refund before the ledger commit in a money method). This file proves the OBSERVABLE consequence:
// it asks the system to run a terminal money operation that both commits and makes an irreversible
// external call, with the durable commit FAULTED, and checks that no irreversible external effect
// was left behind. Correct ordering => the faulted commit aborts before the external call runs.
//
// This file imports ONLY the canonical interface.

import { Capability, checked, finding, notExercised, type Rule } from "../money-system.ts";

export const nOrder01: Rule = {
  id: "N-ORDER-01",
  title:
    "A money op commits durably before any irreversible external call: a faulted commit leaves the external side untouched.",
  requires: [Capability.CommitOrdering, Capability.ExternalObjects],

  async run(sys) {
    for (const cap of this.requires) {
      if (!sys.supports(cap)) return notExercised(`system lacks capability: ${cap}`);
    }

    const probe = await sys.retireWithCommitFault();

    if (!probe.reachedCommit) {
      return notExercised("could not reach the durable-commit boundary of a terminal money op", {
        probe,
      });
    }
    if (probe.committed) {
      return notExercised(
        "the injected commit fault did not prevent the commit; cannot judge order",
        {
          probe,
        },
      );
    }
    if (probe.externalEffectsBeforeCommit.length > 0) {
      return finding(
        "an irreversible external call ran BEFORE the durable commit (which then failed)",
        {
          externalEffectsBeforeCommit: probe.externalEffectsBeforeCommit,
        },
      );
    }

    return checked(
      "the durable commit was faulted and no irreversible external effect was left behind (commit precedes the external call)",
    );
  },
};

export default nOrder01;
