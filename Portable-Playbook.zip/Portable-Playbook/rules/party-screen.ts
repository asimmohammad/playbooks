// PARTY-SCREEN — a portable behavioural rule.
//
// INVARIANT: a party that fails sanctions/KYC screening must never end up holding an
// ACTIVE money instrument, through ANY issuance path.
//
// This file imports ONLY the canonical interface. It does not know whether the system
// under test issues via a direct POST, an addFamilyMember+issueCard pair, or an
// invite+accept handshake — it asks the MoneySystem to "issue an instrument to this
// party" and reads the outcome and the party's holdings.

import { Capability, checked, finding, notExercised, type Rule } from "../money-system.ts";

export const partyScreen: Rule = {
  id: "PARTY-SCREEN",
  title:
    "A party failing sanctions/KYC must never hold an active instrument via any issuance path.",
  requires: [Capability.CreateActor, Capability.Eligibility, Capability.IssueInstrument],

  async run(sys) {
    for (const cap of this.requires) {
      if (!sys.supports(cap)) return notExercised(`system lacks capability: ${cap}`);
    }

    // A party that must be blocked: sanctions hit AND no KYC.
    const party = await sys.createActor({
      legalName: "Sanctioned Unverified Party",
      email: "blocked@screen.test",
    });
    await sys.setEligibility(party, { kyc: false, sanctioned: true });

    // Attempt issuance through whatever path the adapter binds.
    const outcome = await sys.issueInstrumentToParty(party, { instrumentKind: "virtual" });

    // The decisive signal: does the screened-out party actually hold anything ACTIVE?
    const instruments = await sys.listInstruments(party);
    const active = instruments.filter((i) => i.status === "active");

    if (active.length > 0) {
      return finding("a screened-out party holds an active instrument", {
        activeInstrumentIds: active.map((i) => i.id),
        outcome,
      });
    }

    if (outcome.ok) {
      // No active instrument, but issuance was NOT refused: the screen did not hold the
      // line. (e.g. an instrument was created inactive/scheduled and could later activate.)
      return finding("issuance was not refused for a screened-out party", {
        instrumentId: outcome.instrumentId,
        instruments,
      });
    }

    return checked("issuance refused and the party holds no active instrument", {
      refusedReason: outcome.refusedReason,
    });
  },
};

export default partyScreen;
