---
helixPlaybookFormat: helix-playbook/0.1-proposal
playbookId: portable-money-correctness
title: "Portable money-correctness playbook"
declaredVersion: 0.1.0
intent: draft
applicability:
  languages: [javascript, typescript]
  scenarios: [money-correctness]
---
# Portable money-correctness playbook

Repo: **`helix-fintech-apps/Portable-Playbook`** · branch: **`main`**

A portable, deterministic gate that catches **money-movement bugs** in any money app before
they ship. It is **22 pure static detectors** — plain `node:fs` + regex over the committed
source, SQL and migrations. No LLM, no network, no runtime: **~$0 per run**. Every detector
is deterministic (same source in → same verdict out) and **fails closed** — a match blocks
the merge. It only looks for money-correctness defects (spend past a limit, a bill paid
twice, money moved without screening the recipient, tax booked as revenue, a receivable that
never ages), nothing else.

---

## 1. What it is

Think of a car inspection: the same checklist runs against every car — *do the brakes work?
the lights? the seatbelts?* Here the checklist items are money mistakes, and the "car" is any
repo with money logic. The checks are shared and never change per app; the only thing that
differs between apps is **where the money lives** — and that is computed, not written (see
below).

The detectors are source scanners. Each one reads the repo's money files, schema and routes,
and returns one verdict per app:

| Verdict | Means | What you do |
|---|---|---|
| **FINDING** | the money mistake is present, reported with `file:line` | real bug — it blocks the PR |
| **CHECKED** | the invariant applies here and the guard is in place | nothing |
| **N/A** | the app has no such flow, so the invariant cannot apply | nothing |

`N/A` is never counted as a pass — it means "not relevant here," not "looks fine." The runner
exits non-zero if any detector returns **FINDING**.

## 2. How the binding works (the key idea)

**There is no hand-written card.** You do not tell the playbook where a given app keeps its
money. `derive.ts` does it:

```ts
const surface = deriveMoneySurface(cwd);   // deterministic: pure node:fs + regex, no model
```

`deriveMoneySurface(cwd)` scans the repo and computes its **money surface**:

- **schema** — `supabase/migrations/*.sql` + `schema.sql`, or a `.ts` file holding `create table` (auto-detected);
- **money tables** — every `create table` with a money column (`_minor` / `amount` / `balance` / `debit` / `credit` / `rate`);
- **money files** — everything under `services/` / `ledger/` / `connectors/`, every leaf money module (basename `fx` / `money` / `accounts` / `ledger` / `tax` / …), plus any file that imports a money module, calls a money verb, or touches a money table;
- the **HTTP entry** (routes / auth / tenant) and the connector **seam** (the wrapper around third-party money calls).

Derivation **fails open**: anything that looks money-ish is pulled into scope. Every detector
binds to this surface the same way — it exports `forSurface(surface)`, which builds that
check's config (paths and tables) from the derived surface, while the check's own
money-vocabulary regexes stay in the check:

```ts
const s = deriveMoneySurface(cwd);
detect(forSurface(s));   // e.g. once(forSurface(s)), lifecycle(forSurface(s)), …
```

The payoff: **a new money module is covered the moment it lands** — there is no card to
hand-write and none to rot. `N-CARD-FRESH` is a meta-check that audits the derivation itself,
confirming it caught every money-bearing table and module in both directions.

**Onboarding a new app is usually nothing:** clone it, run the gate against its path, read the
findings. If a money module is a shape the heuristics miss, you add that one signal to
`derive.ts` once — and it helps every app from then on.

## 3. How to run

Clone the playbook and point it at any app's absolute path:

```bash
git clone https://github.com/helix-fintech-apps/Portable-Playbook && cd Portable-Playbook
node --experimental-transform-types run-pmar.ts /abs/path/to/the-app
```

It prints one line per detector — `FINDING` / `CHECKED` / `N/A` — and exits non-zero if any
line is a `FINDING`. For example, against an app with live bugs:

```
FINDING  N-TENANT-ISO   src/http/server.ts:247   org id read from the x-org-id header with no auth
FINDING  N-GL-TIE       src/services/ap.ts:73     bill creation posts no ledger entry (AP never recognized)
FINDING  N-PASSTHRU-LIAB src/lib/accounts.ts      no tax-liability account; tax booked to revenue
```

A `FINDING` is a real bug to fix. `CHECKED` and `N/A` need no action. If a detector reads
`N/A` everywhere you expected it to fire, either the app genuinely has no such flow, or a
money module isn't being picked up by derivation — fix the derivation signal, don't weaken the
check.

## 4. The 22 checks

Each detector states one invariant and reports the first place the source violates it.

| ID | Invariant (one line) |
|---|---|
| **N-GL-TIE** | Every payable/receivable is fully booked — recognition posted on create, each control account booked on both sides (raw SQL **and** client-library inserts). |
| **N-PASSTHRU-LIAB** | Collected / pass-through tax is booked to a tax-payable **liability** account, never recognized as revenue or dropped. |
| **N-OBLIG-DUP** | Every obligation (payable/receivable/request/approval step) is unique on its economic key — the same invoice, booking or request can't be entered / paid / recognized twice. |
| **N-ACCOUNT-VALID** | A posting account code is validated by existence in the org's chart, not a regex — no accrual to a phantom account that vanishes from balances. |
| **N-ONCE** | A money movement/recognition is exactly-once across **every** money file: key claimed before the effect, one commit scope, provider call carries an idempotency key. |
| **N-WRITE-CHECK** | A money/approval write checks its result (`{ error }` / rows affected) before reporting success or recording an approval. |
| **N-ORDER** | A money op commits its ledger/liability-clearing entry only **after** the irreversible external call succeeds durably. |
| **N-LIFECYCLE** | A money-releasing/recognition status transition is prior-status-guarded (CAS), terminal-safe, and aggregate-clearance safe (EVERY, never some/first-match). |
| **N-REJECT-CASCADE** | A combined approve/reject decision that transitions the parent money object on the approve branch must also transition it on the reject branch — an approve-only follow-through leaves a rejected item stuck pending. |
| **N-AGG-STATUS** | A money total/variance over a status-bearing table constrains status first — draft / pending / rejected / void rows are never summed as real money. |
| **N-AGING** | An insert into an aging-bearing table (schema declares `due_date` / `maturity` / `payable_on`) must populate that column, or the receivable/payable never ages, goes overdue or gets dunned. |
| **N-SOD** | A money-gating approval is by an authenticated principal ≠ the submitter, assigned to the step, within an amount-scoped authority tier. |
| **N-TENANT-ISO** | The tenant/org key comes from an authenticated principal, never a request-supplied value; no default tenant. |
| **N-AUDIT** | Every money mutation writes an attributed audit row — actor from a principal, never request-supplied. |
| **N-ROUTE-UNIQUE** | The HTTP entry registers each (method, path) once; no money/approval route is shadowed by an unguarded duplicate. |
| **N-ENUM-FAILCLOSED** | A money-gating enum/action is validated against a closed set and fails **closed** on an unknown value — an invalid rule action can't silently stop blocking spend. |
| **N-FX-COMPARE** | Money is normalized to one currency before compare/aggregate/limit; FX uses the per-currency minor-unit scale and integer math (no hardcoded `/100`, no float rate). |
| **N-SCORE-HONEST** | A published money-health / assurance score is an amount-weighted lower bound — never perfect while open exceptions or unreconciled value remain. |
| **N-FAILCLOSED-READ** | A variance/reconciliation/assurance read fails **closed** — a missing row, DB error or empty result can't produce a benign "zero variance / all pass." |
| **N-PII-PROJECTION** | A client-facing list of a money entity excludes sensitive fields (TIN / SSN / bank / routing) — no `select("*")` leak. |
| **N-DEPLOY-BACKFILL** | A money change adding a table/column/account existing rows need ships an applied migration + backfill; no path assumes pre-deploy records carry the new data. |
| **N-CARD-FRESH** | *(meta)* The derived money surface stays in sync with the repo, both directions — every money-bearing table/module the schema defines is covered, and every covered path exists. |

## 5. How each detector is proven

A detector ships only when it passes a three-fixture gate. For a given invariant it must
return:

- **FINDING** against a fixture that contains the bug,
- **CHECKED** against the same fixture with the bug fixed, and
- **N/A** against a fixture where the flow is absent.

In short: **FINDING@vulnerable ∧ CHECKED@fixed ∧ NOT_APPLICABLE@absent**. A detector that can't
distinguish all three isn't deterministic proof and doesn't land. Changes to the check set are
deliberate and reviewed: a new detector arrives with its invariant and its three fixtures in
the same change.

This gate is **committed and runnable**, not just a convention:

```
npm run gate        # or: node --experimental-transform-types gate.ts
```

`gate.ts` + `gate/cases/*.ts` run all 22 detectors through their three fixtures in-memory
(deterministic, no fs, no LLM) and **exit non-zero if any detector regresses**. It runs in CI
(`.github/workflows/conformance.yml`) on every push, so a detector that stops catching its bug — or
starts false-positiving on a fix — blocks the merge. Current: **22/22 conformant** (see `BENCHMARK.md`
for conformance + field results vs a real reviewer, and the honest limits).

## Scope today (and the one safe failure mode)

This gate reads **TypeScript under `src/` with an SQL `create table` schema** (supabase migrations or
ts-embedded). That is its proven envelope — `pmar` and `neobank`, both TS + Supabase. Pointed at anything
outside it (a non-TypeScript app, a non-`src/` layout, a Prisma/Rails/Django schema), the derivation finds
no money surface and the runner **refuses to pass — it exits non-zero with a loud reason**, rather than
printing a false green on code it never scanned. So an unsupported stack gets a red build with an
explanation, never a silent pass. Widening the stack (per-ORM schema parsers, per-data-layer idioms) is
tracked as the portability roadmap.

## 6. Wire into CI

The gate earns its keep when it runs on every PR and blocks the merge on any `FINDING`. A
drop-in workflow lives in this repo at **`ci/pmar-money-gate.yml`**. To wire it into an app
that does not vendor the playbook:

1. Copy `ci/pmar-money-gate.yml` into the app repo as `.github/workflows/money-gate.yml`.
2. Add a repo/org secret **`MONEY_PLAYBOOK_TOKEN`** — a read-only token or deploy key with
   read access to the private `Portable-Playbook` repo, so CI can check the playbook out.
3. Keep **`ref: main`** (or pin to a tag/SHA for a fully reproducible gate).

The job checks out both repos, runs `run-pmar.ts` against the app tree, and **exits non-zero on
any FINDING**, failing the PR. It stays red until the money bugs are fixed — that is the gate
working, not broken CI.

---

## History

The check set was not guessed — it was hardened against real, independently reviewed money
PRs. Each detector was mapped finding-by-finding against what agentic code reviewers caught on
production fintech PRs, and ships only after clearing the three-fixture gate above and then
firing on the real bug site. The newest additions — `N-AGING`, `N-AGG-STATUS` and
`N-REJECT-CASCADE` — closed the last money-movement findings those reviews surfaced. Everything
now lives on `main`; there are no version branches.

# Helix review rules

Generated from the 22 checks in section 4. Invariant text is unchanged. Severity follows the gate tiers in `run-pmar.ts` (BLOCK -> HIGH, WARN -> MEDIUM). Rule ids are prefixed `PP-` because Helix ids need a first segment of at least two characters.

## Rule PP-N-GL-TIE: Every payable/receivable is fully booked
Severity: HIGH
Category: MM
Requirement: MUST
Invariant: Every payable/receivable is fully booked — recognition posted on create, each control account booked on both sides (raw SQL **and** client-library inserts).

Source check `N-GL-TIE` from section 4 of this README; gate tier BLOCK in `run-pmar.ts`.

Regulation references: RR-ACCT-001.

## Rule PP-N-PASSTHRU-LIAB: Collected / pass-through tax is booked to a tax-payable liability account, never recognized as re...
Severity: HIGH
Category: MM
Requirement: MUST
Invariant: Collected / pass-through tax is booked to a tax-payable **liability** account, never recognized as revenue or dropped.

Source check `N-PASSTHRU-LIAB` from section 4 of this README; gate tier BLOCK in `run-pmar.ts`.

Regulation references: RR-TAX-001, RR-ACCT-007.

## Rule PP-N-OBLIG-DUP: Every obligation (payable/receivable/request/approval step) is unique on its economic key
Severity: HIGH
Category: MM
Requirement: MUST
Invariant: Every obligation (payable/receivable/request/approval step) is unique on its economic key — the same invoice, booking or request can't be entered / paid / recognized twice.

Source check `N-OBLIG-DUP` from section 4 of this README; gate tier BLOCK in `run-pmar.ts`.

## Rule PP-N-ACCOUNT-VALID: A posting account code is validated by existence in the org's chart, not a regex
Severity: MEDIUM
Category: MM
Requirement: MUST
Invariant: A posting account code is validated by existence in the org's chart, not a regex — no accrual to a phantom account that vanishes from balances.

Source check `N-ACCOUNT-VALID` from section 4 of this README; gate tier WARN in `run-pmar.ts`.

## Rule PP-N-ONCE: A money movement/recognition is exactly-once across every money file: key claimed before the effe...
Severity: HIGH
Category: MM
Requirement: MUST
Invariant: A money movement/recognition is exactly-once across **every** money file: key claimed before the effect, one commit scope, provider call carries an idempotency key.

Source check `N-ONCE` from section 4 of this README; gate tier BLOCK in `run-pmar.ts`.

## Rule PP-N-WRITE-CHECK: A money/approval write checks its result ({ error } / rows affected) before reporting success or...
Severity: HIGH
Category: MM
Requirement: MUST
Invariant: A money/approval write checks its result (`{ error }` / rows affected) before reporting success or recording an approval.

Source check `N-WRITE-CHECK` from section 4 of this README; gate tier BLOCK in `run-pmar.ts`.

## Rule PP-N-ORDER: A money op commits its ledger/liability-clearing entry only after the irreversible external call...
Severity: HIGH
Category: MM
Requirement: MUST
Invariant: A money op commits its ledger/liability-clearing entry only **after** the irreversible external call succeeds durably.

Source check `N-ORDER` from section 4 of this README; gate tier BLOCK in `run-pmar.ts`.

## Rule PP-N-LIFECYCLE: A money-releasing/recognition status transition is prior-status-guarded (CAS), terminal-safe, and...
Severity: HIGH
Category: MM
Requirement: MUST
Invariant: A money-releasing/recognition status transition is prior-status-guarded (CAS), terminal-safe, and aggregate-clearance safe (EVERY, never some/first-match).

Source check `N-LIFECYCLE` from section 4 of this README; gate tier BLOCK in `run-pmar.ts`.

## Rule PP-N-REJECT-CASCADE: A combined approve/reject decision that transitions the parent money object on the approve branch...
Severity: HIGH
Category: MM
Requirement: MUST
Invariant: A combined approve/reject decision that transitions the parent money object on the approve branch must also transition it on the reject branch — an approve-only follow-through leaves a rejected item stuck pending.

Source check `N-REJECT-CASCADE` from section 4 of this README; gate tier BLOCK in `run-pmar.ts`.

## Rule PP-N-AGG-STATUS: A money total/variance over a status-bearing table constrains status first
Severity: HIGH
Category: MM
Requirement: MUST
Invariant: A money total/variance over a status-bearing table constrains status first — draft / pending / rejected / void rows are never summed as real money.

Source check `N-AGG-STATUS` from section 4 of this README; gate tier BLOCK in `run-pmar.ts`.

## Rule PP-N-AGING: An insert into an aging-bearing table (schema declares due_date / maturity / payable_on) must pop...
Severity: MEDIUM
Category: MM
Requirement: MUST
Invariant: An insert into an aging-bearing table (schema declares `due_date` / `maturity` / `payable_on`) must populate that column, or the receivable/payable never ages, goes overdue or gets dunned.

Source check `N-AGING` from section 4 of this README; gate tier WARN in `run-pmar.ts`.

## Rule PP-N-SOD: A money-gating approval is by an authenticated principal ≠ the submitter, assigned to the step, w...
Severity: HIGH
Category: MM
Requirement: MUST
Invariant: A money-gating approval is by an authenticated principal ≠ the submitter, assigned to the step, within an amount-scoped authority tier.

Source check `N-SOD` from section 4 of this README; gate tier BLOCK in `run-pmar.ts`.

Regulation references: RR-SOX-001.

## Rule PP-N-TENANT-ISO: The tenant/org key comes from an authenticated principal, never a request-supplied value
Severity: HIGH
Category: MM
Requirement: MUST
Invariant: The tenant/org key comes from an authenticated principal, never a request-supplied value; no default tenant.

Source check `N-TENANT-ISO` from section 4 of this README; gate tier BLOCK in `run-pmar.ts`.

## Rule PP-N-AUDIT: Every money mutation writes an attributed audit row
Severity: MEDIUM
Category: MM
Requirement: MUST
Invariant: Every money mutation writes an attributed audit row — actor from a principal, never request-supplied.

Source check `N-AUDIT` from section 4 of this README; gate tier WARN in `run-pmar.ts`.

Regulation references: RR-SOX-001.

## Rule PP-N-ROUTE-UNIQUE: The HTTP entry registers each (method, path) once
Severity: HIGH
Category: MM
Requirement: MUST
Invariant: The HTTP entry registers each (method, path) once; no money/approval route is shadowed by an unguarded duplicate.

Source check `N-ROUTE-UNIQUE` from section 4 of this README; gate tier BLOCK in `run-pmar.ts`.

## Rule PP-N-ENUM-FAILCLOSED: A money-gating enum/action is validated against a closed set and fails closed on an unknown value
Severity: HIGH
Category: MM
Requirement: MUST
Invariant: A money-gating enum/action is validated against a closed set and fails **closed** on an unknown value — an invalid rule action can't silently stop blocking spend.

Source check `N-ENUM-FAILCLOSED` from section 4 of this README; gate tier BLOCK in `run-pmar.ts`.

## Rule PP-N-FX-COMPARE: Money is normalized to one currency before compare/aggregate/limit
Severity: HIGH
Category: MM
Requirement: MUST
Invariant: Money is normalized to one currency before compare/aggregate/limit; FX uses the per-currency minor-unit scale and integer math (no hardcoded `/100`, no float rate).

Source check `N-FX-COMPARE` from section 4 of this README; gate tier BLOCK in `run-pmar.ts`.

## Rule PP-N-SCORE-HONEST: A published money-health / assurance score is an amount-weighted lower bound
Severity: HIGH
Category: MM
Requirement: MUST
Invariant: A published money-health / assurance score is an amount-weighted lower bound — never perfect while open exceptions or unreconciled value remain.

Source check `N-SCORE-HONEST` from section 4 of this README; gate tier BLOCK in `run-pmar.ts`.

## Rule PP-N-FAILCLOSED-READ: A variance/reconciliation/assurance read fails closed
Severity: HIGH
Category: MM
Requirement: MUST
Invariant: A variance/reconciliation/assurance read fails **closed** — a missing row, DB error or empty result can't produce a benign "zero variance / all pass."

Source check `N-FAILCLOSED-READ` from section 4 of this README; gate tier BLOCK in `run-pmar.ts`.

## Rule PP-N-PII-PROJECTION: A client-facing list of a money entity excludes sensitive fields (TIN / SSN / bank / routing)
Severity: MEDIUM
Category: NON_MM
Requirement: MUST
Invariant: A client-facing list of a money entity excludes sensitive fields (TIN / SSN / bank / routing) — no `select("*")` leak.

Source check `N-PII-PROJECTION` from section 4 of this README; gate tier WARN in `run-pmar.ts`.

## Rule PP-N-DEPLOY-BACKFILL: A money change adding a table/column/account existing rows need ships an applied migration + back...
Severity: HIGH
Category: MM
Requirement: MUST
Invariant: A money change adding a table/column/account existing rows need ships an applied migration + backfill; no path assumes pre-deploy records carry the new data.

Source check `N-DEPLOY-BACKFILL` from section 4 of this README; gate tier BLOCK in `run-pmar.ts`.

## Rule PP-N-CARD-FRESH: The derived money surface stays in sync with the repo, both directions
Severity: HIGH
Category: NON_MM
Requirement: MUST
Invariant: *(meta)* The derived money surface stays in sync with the repo, both directions — every money-bearing table/module the schema defines is covered, and every covered path exists.

Source check `N-CARD-FRESH` from section 4 of this README; gate tier BLOCK in `run-pmar.ts`.
