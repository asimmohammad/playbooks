# The ten primitive families

> The authoritative, LOCKED inventory of every shipping check (9 static + 7 behavioural) is
> **`PLAYBOOK.md`**. This file is the family map / rationale behind it. Note: **NO-ORPHAN** and
> **N-IDEMP** were converted from behavioural rules into adapter-free static detectors
> **N-ORPHAN-01** and **N-IDEMP-01** (they catch the #28 defects on paths the adapter never drove);
> references to the old behavioural names below describe the family, now covered by those static
> detectors.

Money apps differ in their routes, tables and vocabulary, but the ways they get money
_wrong_ fall into a small number of **primitive families**. A family is a cluster of defect
classes that share one underlying invariant, so one rule (written against the canonical
`MoneySystem` interface, or as a portable source scanner) covers the same defect in any app.

This file is the map: each family lists its **defect classes**, the **rules that cover it**,
and its **status**. It is how we answer "what does the playbook actually prove, and where is
it still only a design?".

### Status legend

| Status                     | Meaning                                                                                                                                 |
| -------------------------- | --------------------------------------------------------------------------------------------------------------------------------------- |
| **live behavioral**        | A rule drives a running `MoneySystem` through the interface and reads outcomes. Proven against a real adapter.                          |
| **live static**            | A rule scans source / SQL / git-diff deterministically. Proven: it flags on a known-bad input and clears a known-good one.              |
| **designed-not-validated** | The rubric and signatures exist, but **no reference implementation** does — the rule has never run against code. A design, not a proof. |

### Scorecard

**8 of 10 families are live; 2 are scaffolded (designed-not-validated).**

| #   | Family                  | Status                              | Covering rules                                                 |
| --- | ----------------------- | ----------------------------------- | -------------------------------------------------------------- |
| 1   | Ledger                  | live (behavioral + static)          | LEDGER-CONSERVE·, N-CONSERVE, N-ATOMIC, N-CAP-01·, N-STATE-01· |
| 2   | Transfer                | live (behavioral + static)          | N-IDEMP, N-ROUTE-01, N-CONSERVE, N-ATOMIC                      |
| 3   | External object         | live (behavioral + static)          | NO-ORPHAN·, N-ORDER-01, N-CHGBK-05, N-IDEMP                    |
| 4   | Party eligibility       | live (behavioral + static)          | PARTY-SCREEN·, K-SCREEN-01, N-SCREEN-02·                       |
| 5   | Events / webhooks       | live (static + behavioral)          | N-AUTHN, N-IDEMP                                               |
| 6   | Time                    | live (static + behavioral)          | N-AUTHN, N-IDEMP, N-SCHED-01·                                  |
| 7   | Units                   | live (behavioral + static), partial | N-CONSERVE, N-RWD-04                                           |
| 8   | Reconciliation          | live (behavioral + static)          | N-CONSERVE, N-CHGBK-05, N-RWD-04                               |
| 9   | **Lending & interest**  | **designed-not-validated**          | `families/lending-interest.ts` (stub)                          |
| 10  | **FX & multi-currency** | **designed-not-validated**          | `families/fx.ts` (stub)                                        |

`·` = ported to `helix-portable` (interface-driven, repo-agnostic). Cross-cutting **static
scanners** guard _every_ family rather than one primitive; see the last section.

### Verdict rubric: a pass must be _proven_

A behavioural rule reports **CHECKED only when it actually drove the guard's code path** and the
property held. When the path could not be driven — the hand-written adapter never reached the
surface, a precondition could not be staged — the rule reports **NOT_EXERCISED** (glyph `????`),
which is surfaced distinctly and **never counted as a pass**. This closes a false-green hole: on a
large new PR (e.g. Family Cards v2, #27) the adapter touches none of the new surfaces, so a rule
that silently returned CHECKED would report "safe" for code it never ran. **Static detectors are
immune** — they read the source and fire regardless of adapter coverage — which is why the
Family-Cards-v2 money-bug guards (N-SCHED-01, N-SCREEN-02, N-STATE-01, and the N-CAP-01
per-member-limit extension) are **static**, and fail _closed_ on a match.

**Generality.** Each keys on the STABLE surfaces the spec + repo conventions mandate — the
`family_members` / `cards` tables, `for update` / advisory locks, the `harbor_*` SQL function names,
and the spec's route paths (`/family/members/:id/allowance/run`, `/unfreeze`,
`/family/invite/:token/accept`, card replace) — not on #27's exact method identifiers, so they still
fire on an independently-written rebuild of the same spec that names its handlers differently (a
by-name matcher would read NOT_APPLICABLE — a silent miss). They stay fail-closed: only a genuine
missing-guard pattern is a FINDING.

---

## 1. Ledger — double-entry integrity

The books are a conserved, balanced, atomic double-entry system.

- **Defect classes:** an unbalanced transaction (debits ≠ credits); a non-zero trial
  balance; an internal move that creates or destroys customer value; a money operation that
  is not a single atomic transaction (a partial write survives a crash); reading a
  balance/limit aggregate _before_ taking the row lock (TOCTOU); raising an aggregate-cap
  guard without a lock held; an aggregate cap (a per-owner count/sum limit — e.g. max family
  members) enforced _only_ in an app-layer pre-check and never re-checked inside the atomic op
  under a lock, so two concurrent requests both pass the stale pre-check and both commit (a
  concurrent cap bypass); a per-member spend LIMIT (daily / monthly / per-transaction) checked at
  authorization against a value taken from the _request payload_ instead of the LOCKED member row,
  so a caller can raise their own cap; a per-transaction cap silently dropped on a limit update
  (recomputed from the daily/monthly figures without reading the stored value); an atomic money op
  acting on a member or their card (a scheduled allowance run, a card authorization) that does not
  re-read the member/card STATE from the LOCKED row and reject a removed/canceled subject before any
  money effect, so an op racing a member removal or a card freeze strands funds or holds a canceled
  card.
- **Rules:** **LEDGER-CONSERVE** (live behavioral, portable) — after ordinary flows the
  trial balance is 0 and every txn nets to 0. **N-CONSERVE** (live behavioral) — the same,
  asserted after _every_ step of a full money-route run. **N-ATOMIC** (live static) — each
  money op is exactly one DB call / `harbor_*` function, and no aggregate is read or capped
  before a `FOR UPDATE` / advisory lock. **N-CAP-01** (live static, portable) — the structural
  complement to N-ATOMIC from the other side: every aggregate cap the app _declares_ must be
  re-read and re-enforced INSIDE the atomic SQL op under a lock, not only in a pre-check. The
  sealed N-ATOMIC detector is keyed to a _closed_ list of balance/limit aggregates and guard
  codes, so a brand-new cap that is absent from the SQL op entirely is invisible to it; N-CAP-01
  catches exactly that absence. **Extended** (Family Cards v2) to per-row limits: at authorization
  the member's daily/monthly limit must be read as a column from the LOCKED `family_members` row
  inside the atomic op — never from a `member_limit` the request supplied — and an app-layer limit
  update must preserve the stored per-transaction cap instead of recomputing it away. **N-STATE-01**
  (live static, portable) — a TOCTOU sibling of N-CAP-01 for member/card STATE (vs caps/limits):
  once a per-member removal op exists, every atomic op that authorizes a member card or pays a
  recurring allowance must lock the `family_members` row and reject a removed/canceled/frozen subject
  before moving money. Dormant until per-member removal exists, so a repo that only tears members
  down in bulk at account closure is never faulted.
- **Status:** live (behavioral + static).

## 2. Transfer — money movement between parties and pockets

Moving money is exactly-once, lands in exactly one place, and conserves value net of fees.

- **Defect classes:** a replayed POST double-posts (missing or ignored Idempotency-Key);
  routing ambiguity — money falls to a "first returned" row, or more than one destination is
  marked primary/default; an internal transfer that does not conserve value or reports the
  wrong fee; a daily/monthly limit bypassed under concurrency.
- **Rules:** **N-IDEMP** (live behavioral + static) — every `{money:true}` POST requires an
  Idempotency-Key and a replay is inert. **N-ROUTE-01** (live static) — a routing column
  (`is_primary`/`is_default`/…) ships with a backfill _and_ a partial unique index, so each
  scope has at most one routing row. **N-CONSERVE** (live behavioral) — the transfer-
  conservation leg (a P2P transfer lowers the customers' total by exactly its fee).
  **N-ATOMIC** (live static) — limit checks hold a lock.
- **Status:** live (behavioral + static).

## 3. External object — provider-side objects (issuer cards, authorizations, captures)

Every external provider object has a consistent local counterpart, created and destroyed in
the right order.

- **Defect classes:** an **orphan** — the provider object exists but the durable record does
  not (or is not canceled) after a post-create failure; an irreversible external call made
  _before_ the ledger commit (can't be unwound); a dispute or refund that exceeds what was
  captured; a redelivered provider event applied twice.
- **Rules:** **NO-ORPHAN** (live behavioral, portable) — inject a post-create DB fault; the
  external object must end canceled, never live. **N-ORDER-01** (live static) — no
  `providers.*.send/charge/capture/refund` before the ledger commit in a money method.
  **N-CHGBK-05** (live behavioral) — new dispute ≤ captured − refunded − won disputes.
  **N-IDEMP** (live behavioral) — a reused `provider_auth_id` replays the first decision,
  and a reused id for a different amount is refused.
- **Status:** live (behavioral + static).

## 4. Party eligibility — who may hold or move money

A party that fails screening never holds an active instrument, by any path.

- **Defect classes:** a sanctions/KYC-failing party ends up with an active instrument;
  screening the _account owner_ instead of the actual card **holder**; screening a display
  name but not the linked profile (or vice versa); a money-move or card (re)activation performed
  FOR a member (allowance run, member unfreeze, invite accept, card replace) that re-screens only
  the owner — never the actual holder's linked profile (KYC + sanctions) — or that skips the
  funding-account-open check, so a frozen/unverified payer still moves money.
- **Rules:** **PARTY-SCREEN** (live behavioral, portable) — a sanctioned, un-KYC'd party is
  refused and holds nothing active, regardless of issuance path. **K-SCREEN-01** (live
  behavioral) — a family/teen member on the sanctions list (by name or linked profile) never
  holds an active card, even when the owner is approved. **N-SCREEN-02** (live static, portable) —
  each money/activation op that acts for a member must call the holder screen (KYC + sanctions on
  the linked profile) and the funding-account-open check INSIDE the op, not just on the owner or in
  a pre-call; it reads the source, so it fires even when the adapter never drives the new surface.
- **Status:** live (behavioral + static).

## 5. Events / webhooks — inbound provider notifications

An inbound money event is authentic, verified before it has any effect, and applied once.

- **Defect classes:** a forged webhook is processed; the body is parsed or an effect runs
  _before_ the signature is verified; a bad signature does not return 4xx before processing;
  the signature compare is not constant-time; a replayed event is applied twice.
- **Rules:** **N-AUTHN** (live static) — the Stripe branch verifies an HMAC-SHA-256 over
  `${t}.${payload}`, rejects a missing header/secret, returns 4xx first, and compares with
  `timingSafeEqual`. **N-IDEMP** (live behavioral) — a redelivered network authorization
  answers with the first delivery's decision.
- **Status:** live (static + behavioral).

## 6. Time — clocks, windows, periods, schedules

Time-dependent money logic is bounded, period-keyed and deterministic.

- **Defect classes:** a replay window too wide or unbounded (a timestamp far from now is
  accepted); a recurring job not keyed per period, so it accrues/posts twice; a
  scheduled-start instrument usable before its start; a scheduled start _dropped_ on card
  replacement/reissue, re-minting the card as spendable-now; non-injectable time
  (non-deterministic runs).
- **Rules:** **N-AUTHN** (live static) — rejects `|now − t| > 300 s`. **N-IDEMP** (live
  static + behavioral) — `interest_accruals` keyed by `(account, day)`, `interest_postings`
  by `(account, period)`; a second same-period run moves nothing. **N-SCHED-01** (live static,
  portable) — when a card can carry a future activation instant, the authorization path must
  decline before that instant AND the start must survive card replacement/reissue (a replaced
  scheduled card must not become spendable early). The interface's `Clock` capability makes time
  injectable for every behavioral rule.
- **Status:** live (static + behavioral). Time is enforced as an _aspect_ of the rules
  above; there is no standalone clock-skew rule yet.

## 7. Units — minor-unit integer money arithmetic

Money is integer minor units end to end; no floats, no unit confusion, no stale amounts.

- **Defect classes:** float money / rounding drift; mixing major and minor units; a fee
  taken from a stale authorization snapshot instead of recomputed; a sign error on reversal.
- **Rules:** **N-CONSERVE** (live behavioral) — exact integer-cents equality (the `Cents`
  type is integer by contract). **N-RWD-04** (live static + behavioral) — a card fee is
  _recomputed on capture_, not read from the auth snapshot; reversal rows behave per spec.
- **Status:** live (behavioral + static), **partial** — there is no dedicated float/rounding
  source scanner; unit discipline is inferred from exact-equality assertions and the integer
  `Cents` type.

## 8. Reconciliation — books tie out to balances and to external truth

What the ledger says, what the balance endpoint says, and what the provider captured all
agree.

- **Defect classes:** a posted balance (`GET /me`) that diverges from the ledger
  (credits − debits); dispute/refund totals exceeding the captured amount; a reward/fee earn
  site with no declared reversal behavior; trial-balance drift across a run.
- **Rules:** **N-CONSERVE** (live behavioral) — the reconciliation leg: each pocket's posted
  balance equals its ledger. **N-CHGBK-05** (live behavioral) — dispute amounts reconcile
  against captured−refunded−won. **N-RWD-04** (live static + behavioral) — every fee/reward
  earn site has a spec-cited reversal row.
- **Status:** live (behavioral + static).

## 9. Lending & interest — _(NEW — designed-not-validated)_

Interest and loan schedules are deterministic, correctly allocated, and legally capped.
**No reference implementation exists yet**, so these rules are designed, not proven. See
`families/lending-interest.ts`.

- **Defect classes (rule list):**
  1. **accrual determinism** — two accrual runs over the same period/basis produce the same
     cents; no float, no wall-clock dependence.
  2. **payment-allocation order** — a payment is applied fees → interest → principal (per
     policy), never silently principal-first.
  3. **schedule integrity** — amortization rows sum back to principal + total interest; the
     final payment zeroes the balance exactly (no drift, no stranded cent).
  4. **rounding of interest** — per-period interest rounds by one declared rule and the
     residual is carried, so Σ rounded periods = exact total.
  5. **APR / usury caps** — effective APR (incl. fees) never exceeds the configured cap.
  6. **no negative amortization** — a scheduled payment always covers at least the period's
     interest; the principal balance is non-increasing unless explicitly permitted.
- **Status:** designed-not-validated.

## 10. FX & multi-currency — _(NEW — designed-not-validated)_

Currencies never mix in arithmetic; conversions use a sourced, fresh rate and round once.
**No reference implementation exists yet.** See `families/fx.ts`.

- **Defect classes (rule list):**
  1. **single-currency arithmetic only** — no add/subtract/compare of amounts in different
     currencies; every `Money` carries a currency and operations assert equality.
  2. **rate sourcing / staleness** — a conversion uses a rate from the sanctioned source
     whose age is within the configured window; a stale/missing rate refuses, never defaults
     to 1.0.
  3. **rounding** — a conversion rounds exactly once, by the declared rule, at a declared
     precision for the target currency's minor unit.
  4. **netting correctness** — multi-currency netting nets per currency, then converts;
     it never sums across currencies first.
  5. **no mixed-currency ops** — a ledger transaction's lines are all one currency (or the
     cross-currency leg is modeled as an explicit conversion with its own rounding line).
- **Status:** designed-not-validated.

---

## Cross-cutting harness rules

These are the repo-agnostic **source scanners** in `helix-portable/static/` (parameterised by
config, not hard-coded to neobank). N-DEPLOY-01, N-PARITY-01 and N-TEST-01 guard the integrity of
the _whole gate_; N-CAP-01, N-STATE-01, N-CAS-01, N-UNWIND-01, N-SCHED-01, N-SCREEN-02 and
N-SCOPE-01 are per-family primitives (families 1, 1, 1, 8, 6, 4 and 4) in the same portable style,
listed here as the single static-scanner registry. All run from source with no adapter, fail
_closed_ on a match, key on stable spec/repo surfaces (so they survive an independent rebuild that
renames handlers), and are registered in `run.ts` (`ALL_STATIC_DETECTORS`), so `run-static.ts`
blocks every PR on them automatically — which is why the Family-Cards money-bug guards are static,
not behavioural: a static scan fires even when the hand-written adapter never drives the new surface
(the false-green that let #27, #28 and #29 ship). See **`PLAYBOOK.md`** for the locked 19-check
manifest.

| Rule                                      | Guards                                                                                                                                                                                                                                                                                                                                                                              | Status                |
| ----------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | --------------------- |
| **N-DEPLOY-01** (`static/n-deploy-01.ts`) | Applied artifacts are append-only — a pre-existing migration is never modified/renamed/deleted; change ships as a new forward file.                                                                                                                                                                                                                                                 | live static, portable |
| **N-PARITY-01** (`static/n-parity-01.ts`) | The in-memory and SQL stores stay in lockstep — every op implemented on both, every SQL function defined by a migration, every guard code enforced on both sides, both run in CI.                                                                                                                                                                                                   | live static, portable |
| **N-TEST-01** (`static/n-test-01.ts`)     | No branch greens the pipeline by silently weakening a money assertion (unless a spec-of-record file records the change).                                                                                                                                                                                                                                                            | live static, portable |
| **N-CAP-01** (`static/n-cap-01.ts`)       | Every aggregate cap the app declares (a per-owner count/sum limit) is re-checked INSIDE the atomic SQL op under a lock — not only in an app-layer pre-check two concurrent requests race past; and every per-member spend limit used at authorization is read from the LOCKED member row, never from the request payload, with the per-transaction cap preserved on a limit update. | live static, portable |
| **N-SCHED-01** (`static/n-sched-01.ts`)   | A card with a future activation instant declines before that instant, and the scheduled start survives card replacement/reissue — a replaced scheduled card never becomes spendable early.                                                                                                                                                                                          | live static, portable |
| **N-SCREEN-02** (`static/n-screen-02.ts`) | A money/activation op performed for a member (allowance run, unfreeze, invite accept, card replace) re-screens the actual card holder (KYC + sanctions on the linked profile) and the funding account inside the op, not just the owner.                                                                                                                                            | live static, portable |
| **N-STATE-01** (`static/n-state-01.ts`)   | Once per-member removal exists, every atomic op that authorizes a member card or pays a recurring allowance re-reads the member & card STATE from the LOCKED row and rejects a removed/canceled/frozen subject before moving money (no removal/freeze-race fund-stranding or hold on a canceled card).                                                                              | live static, portable |
| **N-CAS-01** (`static/n-cas-01.ts`)       | A status transition is a locked compare-and-set: a status-filtered read with no `FOR UPDATE` must not be followed by an unconditional by-id status write (a concurrent transition between read and write is clobbered — #29 reverse-auth race).                                                                                                                                     | live static, portable |
| **N-SCOPE-01** (`static/n-scope-01.ts`)   | A bulk state-restore (unfreeze/resume) reactivates only what its pairing op set — by provenance, not the shared state alone — so it never reactivates rows another path set to that state (#29 unfreeze reactivating individually-frozen cards).                                                                                                                                    | live static, portable |
| **N-UNWIND-01** (`static/n-unwind-01.ts`) | A terminal unwind (settle-to-zero + mark removed/closed) first asserts no unresolved money — open dispute / provisional credit / pending inbound — so a later reversal never strands funds (#29 member removal with no dispute guard).                                                                                                                                              | live static, portable |
| **N-COVER**                               | Every money route is exercised by a test that asserts a money outcome of that call.                                                                                                                                                                                                                                                                                                 | live static (meta)    |
