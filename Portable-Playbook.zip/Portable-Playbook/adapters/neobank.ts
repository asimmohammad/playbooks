// helix-portable adapter — neobank, DIRECT family-card issuance path.
//
// This is the "standard plug": it implements the canonical MoneySystem interface over
// neobank's in-process harness (createMemoryApp + app.call + app.store + demoClock + the
// fake card issuer). The three shipped rules (PARTY-SCREEN, NO-ORPHAN, LEDGER-CONSERVE)
// run through this adapter UNCHANGED — they never learn that "issue an instrument to a
// party" means, here, `POST /family` (addFamilyMember) then `POST /cards` with a
// familyMemberId. Swapping this file for an invite-flow adapter would rebind the same
// capability to invite+accept with no edit to any rule.
//
// Capability bindings:
//   - createActor          -> service.createProfile (a real neobank user/profile)
//   - setEligibility       -> kyc_state (approve vs. leave unverified) + the sanctions
//                             name list (a sanctioned party is given a listed legal name)
//   - issueInstrumentToParty -> DIRECT path: POST /family (link member_user_id to the
//                             party) then POST /cards { familyMemberId } as the owner
//   - externalObjects      -> a thin recorder wrapped around the fake issuer, so a
//                             provider card's status is observable (the fake issuer itself
//                             keeps none)
//   - injectFailure("post-create-db") -> force the `cards` row insert to throw AFTER the
//                             issuer has already minted the provider card (the orphan window)
//   - ledger               -> store.ledger() rows -> trial balance + per-txn lines

import {
  Capability,
  type ActorSpec,
  type Balance,
  type Charge,
  type ChargeSpec,
  type Clock,
  type Eligibility,
  type EventAuth,
  type EventOutcome,
  type ExternalEvent,
  type ExternalStatus,
  type FailurePoint,
  type Instrument,
  type InstrumentStatus,
  type IssueOpts,
  type IssueOutcome,
  type LedgerTxn,
  type MoneySystem,
  type MoneySystemFactory,
  type MoveOpts,
  type MoveOutcome,
  type OrderProbe,
  type Party,
  type Recovery,
  type RefundOutcome,
} from "../money-system.ts";

import {
  createMemoryApp,
  seedDemo,
  DEMO_USERS,
  type MemoryApp,
} from "../../supabase/functions/_shared/app/demo.ts";
import { type Caller } from "../../supabase/functions/_shared/app/service.ts";
import { route } from "../../supabase/functions/_shared/app/router.ts";

// A legal name that is a confirmed hit on neobank's FAKE_SANCTIONS_LIST (see domain/kyc.ts).
// The adapter realises "sanctioned" by naming the party this; the rule only states intent.
const SANCTIONED_NAME = "Oleg Embargo";

// Valid spouse spend limits (perTxn <= daily <= monthly); just enough for addFamilyMember.
const MEMBER_LIMITS = { perTxnCents: 5_000, dailyCents: 20_000, monthlyCents: 100_000 };

interface PartyRec {
  email: string; // lowercased; used to link the family member to this party's profile
  legalName: string;
  kyc: boolean;
  sanctioned: boolean;
}

const CARD_STATUS_MAP: Record<string, InstrumentStatus> = {
  active: "active",
  frozen: "inactive",
  requested: "pending",
  canceled: "canceled",
  replaced: "canceled",
};

function errCode(res: { body: unknown }): string {
  const b = res.body as { error?: { code?: string } } | undefined;
  return b?.error?.code ?? "error";
}

class NeobankDirectSystem implements MoneySystem {
  private app!: MemoryApp;
  private owner!: Caller;
  /** The seeded admin, for staff-only steps (chargeback resolution, ACH settlement). */
  private admin!: Caller;
  /** provider card id -> last-known external status (populated by the issuer wrapper). */
  private external = new Map<string, ExternalStatus>();
  /** when armed, the next `cards` insert throws (post-create-db fault). */
  private failCardsInsert = false;
  /** when armed, the next closeAccount commit throws (money-op-commit fault, for N-ORDER-01). */
  private failClosureCommit = false;
  /** set true once the closure-commit fault has actually fired (the commit boundary was reached). */
  private closureCommitFired = false;
  /** monotonic suffix so each refund attempt carries a fresh id (so refusals are not read as replays). */
  private refundSeq = 0;
  private parties = new Map<string, PartyRec>();

  private static readonly CAPS = new Set<Capability>([
    Capability.CreateActor,
    Capability.Eligibility,
    Capability.IssueInstrument,
    Capability.ExternalObjects,
    Capability.FaultInjection,
    Capability.Ledger,
    Capability.Clock,
    // behavioural ports: everything the DIRECT in-process adapter can exercise.
    Capability.MoveMoney,
    Capability.IdempotencyKeys,
    Capability.Charge,
    Capability.Chargeback,
    Capability.CommitOrdering,
    // NOT ExternalEventAuth: the untrusted-webhook surface lives in the HTTP edge layer
    // (server/handler.ts), which this in-process service/store adapter does not wrap.
  ]);

  supports(cap: Capability): boolean {
    return NeobankDirectSystem.CAPS.has(cap);
  }

  get clock(): Clock {
    return {
      now: () => this.app.clock.now(),
      advance: (ms: number) => this.app.clock.advanceHours(ms / 3_600_000),
      set: (at: Date) => this.app.clock.set(at),
    };
  }

  async reset(): Promise<void> {
    // Fresh, isolated, seeded app per run. seedDemo leaves an approved owner (Ava) with a
    // checking pocket, a settled balance and a virtual card — the baseline the rules need.
    this.app = createMemoryApp(new Date("2026-01-01T00:00:00Z"), { kycTimeoutMs: 20 });
    await seedDemo(this.app);
    this.owner = { userId: DEMO_USERS[0].id, role: "customer" };
    this.admin = { userId: DEMO_USERS[5].id, role: "admin" };
    this.external.clear();
    this.parties.clear();
    this.failCardsInsert = false;
    this.failClosureCommit = false;
    this.closureCommitFired = false;
    this.refundSeq = 0;
    this.wrapIssuer();
    this.wrapStore();
  }

  /** Record every provider card the fake issuer mints, and track its status transitions. */
  private wrapIssuer(): void {
    const issuer = (
      this.app.service as unknown as {
        providers: {
          issuer: {
            createCard: (p: {
              kind: "virtual" | "physical";
              cardId: string;
            }) => Promise<{ providerCardId: string }>;
            setStatus: (providerCardId: string, status: ExternalStatus) => Promise<void>;
          };
        };
      }
    ).providers.issuer;
    const ext = this.external;
    const origCreate = issuer.createCard.bind(issuer);
    issuer.createCard = async (p: { kind: "virtual" | "physical"; cardId: string }) => {
      const res = await origCreate(p);
      // Mirror the real issuer's initial state: virtual cards are born active, physical inactive.
      ext.set(res.providerCardId, p.kind === "virtual" ? "active" : "inactive");
      return res;
    };
    const origSet = issuer.setStatus.bind(issuer);
    issuer.setStatus = async (providerCardId: string, status: ExternalStatus) => {
      await origSet(providerCardId, status);
      if (ext.has(providerCardId)) ext.set(providerCardId, status);
    };
  }

  /**
   * Arm points for the injected faults:
   *   - post-create-db (NO-ORPHAN): throw on the durable `cards` write, after the issuer minted.
   *   - money-op-commit (N-ORDER-01): throw inside the atomic closeAccount commit, BEFORE the
   *     service's "then tell the issuer to cancel the cards" loop runs. A correctly ordered app
   *     therefore never reaches the irreversible external call when the commit is faulted.
   */
  private wrapStore(): void {
    const store = this.app.store as unknown as {
      insert: (table: string, row: unknown) => Promise<unknown>;
      closeAccount: (p: unknown) => Promise<unknown>;
    };
    const origInsert = store.insert.bind(store);
    store.insert = async (table: string, row: unknown) => {
      if (this.failCardsInsert && table === "cards") {
        this.failCardsInsert = false;
        throw new Error("injected post-create-db fault: cards insert failed");
      }
      return origInsert(table, row);
    };

    const origClose = store.closeAccount.bind(store);
    store.closeAccount = async (p: unknown) => {
      if (this.failClosureCommit) {
        this.failClosureCommit = false;
        this.closureCommitFired = true; // the commit boundary was reached, then faulted
        throw new Error("injected money-op-commit fault: close_account commit failed");
      }
      return origClose(p);
    };
  }

  async createActor(spec: ActorSpec): Promise<Party> {
    const id = crypto.randomUUID();
    const email = (spec.email ?? `${id}@helix.test`).toLowerCase();
    await this.app.service.createProfile(id, email, spec.legalName);
    this.parties.set(id, { email, legalName: spec.legalName, kyc: false, sanctioned: false });
    return { id, label: spec.legalName };
  }

  async setEligibility(party: Party, e: Eligibility): Promise<void> {
    const rec = this.parties.get(party.id);
    if (!rec) throw new Error(`unknown party ${party.id}`);
    rec.kyc = e.kyc;
    rec.sanctioned = e.sanctioned;
    const svc = this.app.service as unknown as {
      setKyc: (u: string, to: string, reason: string, by: string | null) => Promise<unknown>;
    };
    if (e.sanctioned) {
      // Realise "sanctions hit" through the screening path neobank actually uses.
      rec.legalName = SANCTIONED_NAME;
      await this.app.store.update("profiles", { id: party.id }, { legal_name: SANCTIONED_NAME });
    }
    if (e.kyc) {
      // unverified -> approved is a valid KYC transition; this is how the party "passes KYC".
      await svc.setKyc(party.id, "approved", "helix: party passed screening", null);
    }
    // kyc === false: leave the profile unverified, so canMoveMoney() is false for the holder.
  }

  async issueInstrumentToParty(party: Party, opts?: IssueOpts): Promise<IssueOutcome> {
    const rec = this.parties.get(party.id);
    if (!rec) throw new Error(`unknown party ${party.id}`);
    const kind = opts?.instrumentKind === "physical" ? "physical" : "virtual";
    const memberName = rec.sanctioned ? rec.legalName : (party.label ?? rec.legalName);

    // DIRECT path, step 1: create a family member linked to the party's own profile.
    const fam = await this.app.call(this.owner, "POST", "/family", {
      name: memberName,
      kind: "spouse",
      limits: MEMBER_LIMITS,
      memberEmail: rec.email,
    });
    if (fam.status >= 400) return { ok: false, refusedReason: errCode(fam) };
    const memberId = (fam.body as { id: string }).id;

    // DIRECT path, step 2: POST /cards with the familyMemberId, as the owner.
    const before = new Set(this.external.keys());
    const res = await this.app.call(this.owner, "POST", "/cards", {
      kind,
      familyMemberId: memberId,
    });
    const minted = [...this.external.keys()].filter((k) => !before.has(k));

    if (res.status >= 400) {
      // Per the IssueOutcome contract: surface externalId iff a provider object was created
      // before the failure (the orphan window). An expected refusal screens BEFORE createCard,
      // so `minted` is empty and externalId stays absent.
      const out: IssueOutcome = { ok: false, refusedReason: errCode(res) };
      if (minted.length) out.externalId = minted[0];
      return out;
    }
    const card = res.body as { id: string; provider_card_id: string };
    return { ok: true, instrumentId: card.id, externalId: card.provider_card_id };
  }

  async listInstruments(party: Party): Promise<Instrument[]> {
    const cards = await this.app.store.list("cards", { holder_user_id: party.id });
    return cards.map((c) => ({
      id: c.id as string,
      status: CARD_STATUS_MAP[c.status as string] ?? "pending",
      externalId: (c.provider_card_id as string) ?? undefined,
    }));
  }

  async externalObjectStatus(externalId: string): Promise<ExternalStatus | null> {
    return this.external.get(externalId) ?? null;
  }

  injectFailure(point: FailurePoint): void {
    if (point === "post-create-db") this.failCardsInsert = true;
  }

  async runMoneyFlows(): Promise<void> {
    // A small deterministic battery of ordinary flows, all via the real routes. Each posts a
    // balanced double-entry txn; the owner (Ava) is already approved and funded by seedDemo.
    const ava = this.owner;
    const admin: Caller = { userId: DEMO_USERS[5].id, role: "admin" };

    const ex = await this.app.call(ava, "POST", "/banks/exchange", {
      publicToken: "public-fake-First_Platypus_Bank-Ava_Harbor",
    });
    const bankId = (ex.body as { id?: string })?.id;
    if (bankId) {
      await this.app.call(ava, "POST", "/transfers/ach-in", { bankId, amountCents: 5_000 });
      this.app.clock.advanceHours(24 * 7); // past the ACH hold
      await this.app.call(admin, "POST", "/admin/jobs/settle-ach", {});
    }
    // An internal pocket move (checking -> savings): balanced, no external funding needed.
    await this.app.call(ava, "POST", "/transfers/pocket", {
      from: "checking",
      to: "savings",
      amountCents: 2_000,
    });
  }

  async trialBalance(): Promise<number> {
    const rows = await this.app.store.ledger();
    return rows.reduce((s, l) => s + Number(l.debit) - Number(l.credit), 0);
  }

  async ledgerTransactions(): Promise<LedgerTxn[]> {
    const rows = await this.app.store.ledger();
    const byTxn = new Map<string, LedgerTxn>();
    for (const r of rows) {
      let t = byTxn.get(r.txn_id);
      if (!t) {
        t = { id: r.txn_id, kind: r.kind, lines: [] };
        byTxn.set(r.txn_id, t);
      }
      t.lines.push({
        account: r.account,
        party: r.party ?? null,
        debit: Number(r.debit),
        credit: Number(r.credit),
      });
    }
    return [...byTxn.values()];
  }

  // ---------- behavioural-port bindings -------------------------------------------------
  //
  //   principal            -> the seeded owner (Ava): approved, funded ($2,500 checking), holds a card
  //   balance              -> service.balanceOf on the party's checking pocket
  //   move                 -> POST /transfers/pocket (checking -> savings), the generic cap-enforced debit
  //   authorizeAndCapture  -> POST /sim/cards/:id/authorize then /sim/authorizations/:id/capture
  //   refund               -> POST /sim/authorizations/:id/refund (fresh refund id per attempt)
  //   disputeAndRecover    -> POST /disputes -> /admin/disputes/:id/provisional-credit -> /resolve {won}
  //   retireWithCommitFault-> POST /accounts/close with the closeAccount commit faulted (N-ORDER-01)
  //   deliverExternalEvent -> unsupported here (no untrusted webhook surface in-process)

  private callerFor(party: Party): Caller {
    return { userId: party.id, role: "customer" };
  }

  private categoryToMcc(category?: string): string {
    const map: Record<string, string> = {
      grocery: "5411",
      restaurant: "5812",
      fuel: "5541",
      atm: "6011",
    };
    return (category && map[category]) ?? "5411";
  }

  private async checkingOf(userId: string): Promise<{ id: string } | undefined> {
    const accts = await this.app.store.list("accounts", { user_id: userId });
    return accts.find((a) => a.kind === "checking" && a.status !== "closed") as
      { id: string } | undefined;
  }

  private async primaryCardId(party: Party): Promise<string | undefined> {
    const cards = await this.app.store.list("cards", { holder_user_id: party.id });
    const live = cards.find((c) => c.status === "active") ?? cards[0];
    return live?.id as string | undefined;
  }

  async principal(): Promise<Party> {
    // The seeded owner (Ava): approved, funded, already holds a virtual card. See seedDemo.
    return { id: this.owner.userId, label: DEMO_USERS[0].legalName };
  }

  async balance(party: Party): Promise<Balance> {
    const chk = await this.checkingOf(party.id);
    if (!chk) return { postedCents: 0, availableCents: 0 };
    const b = await this.app.service.balanceOf(chk.id);
    return { postedCents: Number(b.postedCents), availableCents: Number(b.availableCents) };
  }

  async move(party: Party, cents: number, opts?: MoveOpts): Promise<MoveOutcome> {
    const body = { from: "checking", to: "savings", amountCents: cents };
    if (opts?.withoutKey) {
      // Go straight through the router with NO Idempotency-Key (app.call always defaults one).
      const res = await route(this.app.service, {
        method: "POST",
        path: "/transfers/pocket",
        body,
        caller: this.callerFor(party),
      });
      return res.status >= 400 ? { ok: false, refusedReason: errCode(res) } : { ok: true };
    }
    const key = opts?.idempotencyKey ?? crypto.randomUUID();
    const res = await this.app.call(this.callerFor(party), "POST", "/transfers/pocket", body, {
      idempotencyKey: key,
    });
    if (res.status >= 400)
      return { ok: false, refusedReason: errCode(res), replayed: !!res.replayed };
    return { ok: true, replayed: !!res.replayed };
  }

  async authorizeAndCapture(party: Party, spec: ChargeSpec): Promise<Charge> {
    const empty = { capturedCents: 0, feeCents: 0 };
    const cardId = await this.primaryCardId(party);
    if (!cardId) return { ok: false, id: "", ...empty, refusedReason: "no_card" };
    const caller = this.callerFor(party);
    const authRes = await this.app.call(caller, "POST", `/sim/cards/${cardId}/authorize`, {
      amountCents: spec.amountCents,
      mcc: this.categoryToMcc(spec.category),
      merchant: "Helix Merchant",
      foreign: !!spec.foreign,
    });
    if (authRes.status >= 400)
      return { ok: false, id: "", ...empty, refusedReason: errCode(authRes) };
    const a = authRes.body as { authorizationId: string; approved: boolean; reason?: string };
    if (!a.approved)
      return {
        ok: false,
        id: a.authorizationId ?? "",
        ...empty,
        refusedReason: a.reason ?? "declined",
      };
    const captureCents = spec.captureCents ?? spec.amountCents;
    const capRes = await this.app.call(
      caller,
      "POST",
      `/sim/authorizations/${a.authorizationId}/capture`,
      { amountCents: captureCents },
    );
    if (capRes.status >= 400)
      return { ok: false, id: a.authorizationId, ...empty, refusedReason: errCode(capRes) };
    const cap = capRes.body as { capturedCents: number; feeCents: number };
    return {
      ok: true,
      id: a.authorizationId,
      capturedCents: Number(cap.capturedCents),
      feeCents: Number(cap.feeCents),
    };
  }

  async refund(charge: Charge, cents: number): Promise<RefundOutcome> {
    const refundId = `helix-refund-${charge.id}-${this.refundSeq++}`;
    const res = await this.app.call(this.owner, "POST", `/sim/authorizations/${charge.id}/refund`, {
      refundId,
      amountCents: cents,
    });
    if (res.status >= 400) return { ok: false, refusedReason: errCode(res) };
    const b = res.body as { duplicate?: boolean };
    return b.duplicate ? { ok: false, refusedReason: "duplicate" } : { ok: true };
  }

  async disputeAndRecover(charge: Charge, cents: number): Promise<Recovery> {
    const open = await this.app.call(this.owner, "POST", "/disputes", {
      authorizationId: charge.id,
      amountCents: cents,
      reason: "helix: item not received",
    });
    if (open.status >= 400) return { ok: false, recoveredCents: 0, refusedReason: errCode(open) };
    const d = open.body as { id: string };
    const pc = await this.app.call(
      this.admin,
      "POST",
      `/admin/disputes/${d.id}/provisional-credit`,
      {},
    );
    if (pc.status >= 400) return { ok: false, recoveredCents: 0, refusedReason: errCode(pc) };
    const res = await this.app.call(this.admin, "POST", `/admin/disputes/${d.id}/resolve`, {
      outcome: "won",
    });
    if (res.status >= 400) return { ok: false, recoveredCents: 0, refusedReason: errCode(res) };
    return { ok: true, recoveredCents: cents };
  }

  deliverExternalEvent(_event: ExternalEvent, _auth: EventAuth): Promise<EventOutcome> {
    // Not reachable through the DIRECT in-process adapter: the untrusted-webhook surface is the
    // HTTP edge layer (server/handler.ts), not the service/store this adapter wraps. The rule
    // never calls this (supports(ExternalEventAuth) is false); throw to stay honest if it does.
    throw new Error("deliverExternalEvent: no untrusted external-event surface in this adapter");
  }

  async retireWithCommitFault(): Promise<OrderProbe> {
    // Snapshot the live external objects (the seeded card), arm the closure-commit fault, then run
    // the terminal money op (account closure). Closure cancels the issuer card AFTER the atomic
    // commit, so a faulted commit must leave the card untouched at the issuer.
    const liveBefore = [...this.external.entries()]
      .filter(([, status]) => status !== "canceled")
      .map(([id]) => id);

    this.closureCommitFired = false;
    this.failClosureCommit = true;
    const res = await this.app.call(this.owner, "POST", "/accounts/close", {});
    this.failClosureCommit = false;

    const committed = res.status < 400;
    const externalEffectsBeforeCommit = liveBefore.filter(
      (id) => this.external.get(id) === "canceled",
    );
    return { reachedCommit: this.closureCommitFired, committed, externalEffectsBeforeCommit };
  }
}

/** Default export: a MoneySystemFactory, as the runner expects. */
const factory: MoneySystemFactory = () => new NeobankDirectSystem();
export default factory;
