// Adapter: pmar (Ramp-class corporate spend platform).
//
// This is the per-app binding the portable playbook reads — NOT a rewrite of any check.
// It declares (A) pmar's MONEY SURFACE (used by the money-touch skip-gate AND by each static
// detector's pmar binding) and (B) the runtime function map (used by behavioral rules).
//
// IMPORTANT source-shape note: unlike neobank (money logic in `harbor_*` Postgres functions under
// supabase/migrations), pmar's money logic is TypeScript in src/services/** and its schema is
// embedded as CREATE TABLE template strings in src/lib/db.ts (there is NO supabase/migrations dir
// on feat/pmar-mvp). So pmar's static detectors scan TS + db.ts, not .sql migrations. The invariant
// (the primitive) is identical to neobank's; only the detector's source-reading mode differs.

export interface MoneySurface {
  /** How this app expresses schema: "sql-migrations" (neobank) or "ts-embedded" (pmar: db.ts). */
  schemaMode: "sql-migrations" | "ts-embedded";
  /** The file(s) holding the schema (CREATE TABLE ...). pmar: the single db.ts. */
  schemaFiles: string[];
  /** Chart-of-accounts source (for account-classification detectors: PASSTHRU-LIAB, GL-TIE). */
  chartOfAccounts: string;
  /** Money/ledger tables — the skip-gate flags any diff touching these; detectors key on them. */
  moneyTables: string[];
  /** Regex for money columns in a changed line (skip-gate secondary signal). */
  moneyColumns: RegExp;
  /** Globs: backend files that carry money logic. A diff outside all of these touches no money. */
  moneyPaths: string[];
  /** The connector seam — all third-party money I/O must cross here (SEAM completeness condition). */
  seamPaths: string[];
  /** HTTP entrypoint (tenant-isolation / auth detectors: TENANT-ISO). */
  httpEntry: string;
  /** Repo root, set per run. */
  cwd?: string;
}

/** pmar's money surface, enumerated from the 7-domain deep dive of feat/pmar-mvp. */
export const PMAR_SURFACE: MoneySurface = {
  schemaMode: "ts-embedded",
  schemaFiles: ["src/lib/db.ts"],
  chartOfAccounts: "src/lib/accounts.ts",
  moneyTables: [
    "ledger_accounts", "journal_entries", "journal_entry_lines",
    "payments",
    "bills", "bill_lines", "invoices", "invoice_lines", "invoice_payments",
    "expenses", "receipts",
    "cards", "card_transactions",
    "vendors", "bank_feed", "recon_matches",
    "idempotency_keys", "tax_rates",
  ],
  moneyColumns: /_minor\b|amount|_cents\b|balance|rate|debit|credit/i,
  moneyPaths: [
    "src/services/**",        // ap, ar, cards, expenses, recon, tax, ocr
    "src/ledger/**",          // the double-entry ledger
    "src/lib/payments.ts",    // the money-movement executor
    "src/lib/idempotency.ts", // replay guard
    "src/lib/money.ts",       // integer-minor-unit core
    "src/lib/db.ts",          // the schema
    "src/lib/accounts.ts",    // chart of accounts
    "src/connectors/**",      // provider seam
    "src/http/server.ts",     // routes + tenant/auth
  ],
  seamPaths: ["src/connectors/**"],
  httpEntry: "src/http/server.ts",
};

/**
 * The money-touch skip-gate (Stage 0 of the reordered procedure).
 * Returns true => this diff provably touches no money surface => the PAID LLM pass may be skipped.
 * Fails OPEN: any changed backend file / schema file / ambiguity => returns false (run it).
 * NOTE: the free static detectors still run regardless; this only gates the expensive LLM pass.
 */
export function touchesMoney(changedPaths: string[], changedSql: string, surface: MoneySurface): boolean {
  const inSurface = (p: string) =>
    surface.moneyPaths.some((g) => globMatch(g, p)) ||
    surface.schemaFiles.includes(p) ||
    p === surface.chartOfAccounts ||
    p === surface.httpEntry;
  if (changedPaths.some(inSurface)) return true;
  if (surface.moneyTables.some((t) => new RegExp(`\\b${t}\\b`).test(changedSql))) return true;
  if (surface.moneyColumns.test(changedSql)) return true;
  // Fail open: a brand-new backend file we don't yet map is money-surface by default.
  if (changedPaths.some((p) => /^src\/.*\.ts$/.test(p))) return true;
  return false;
}

/** Minimal glob: supports a single trailing "**" and exact prefixes. */
function globMatch(glob: string, path: string): boolean {
  if (glob.endsWith("/**")) return path.startsWith(glob.slice(0, -3) + "/") || path === glob.slice(0, -3);
  return glob === path;
}

/**
 * (B) Runtime function map for BEHAVIORAL rules (filled in when we wire pmar's in-memory harness).
 * Stubbed now; behavioral promotion (H3+) populates these against pmar's app services.
 */
export const pmarRuntime = {
  // moveMoney:    (app, a) => app.services.ap.payBill(a),
  // recordPayment:(app, a) => app.services.ar.recordPayment(a),
  // readBalance:  (app, acct) => app.ledger.getBalance(acct),
  // reverse:      (app, a) => app.services.cards.reverse(a),
};

export default PMAR_SURFACE;
