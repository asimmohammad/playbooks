# Why Portable, not Adaptive

Plain-language explainer for the team. (Interactive version: https://claude.ai/artifact/RNj64NJiTsdkMoPBWgWytu)

## In one sentence
**Portable** is one reusable checker that works on any app with a small setup file (an *adapter*).
**Adaptive** is a custom checker rebuilt from scratch for every app, with its checks encrypted.
They catch the same bugs — but Portable is far less work, so we keep Portable and drop Adaptive.

## The phone-charger picture
- **Portable = a universal charger.** One good charger; each new device needs only a cheap adapter
  tip. The checks are written once; each app adds a small adapter that says where its money code lives.
- **Adaptive = a custom charger, every time.** For every device you build a whole new charger and
  lock the blueprint away. For every app you write a brand-new set of checks and encrypt them.
  Nothing carries over.

## What it means when we add an app
| | Portable | Adaptive |
|---|---|---|
| Work for a new app | write one small adapter | build + seal a whole new checker |
| Reused across apps | yes — same checks everywhere | no — start from zero each time |
| Fix / improve a check | every app gets it right away | helps only that one app |

## Why we don't need Adaptive anymore
Adaptive was kept for two reasons. Both have gone away.
1. **Hide the checks so a developer couldn't cheat.** Gone — the static detectors read the code
   directly, like a spell-checker. You can't hide a typo from a spell-checker just because you've
   seen the dictionary. Hiding the checks buys nothing.
2. **Run the app's code to catch runtime bugs.** Gone — Portable's behavioral layer already does
   this, through the same adapter. Same depth, no extra work per app.

## The finish line: money bugs come in ~10 kinds
1. Money must balance — nothing created or lost
2. Don't charge or pay twice if a request is retried
3. Lock a record before changing it, so two requests can't collide
4. Check spending limits from the real record, not the request
5. Re-check who's allowed to move money (ID + sanctions) every time
6. A card scheduled for the future can't be used early
7. Never leave a card live at the bank with no record (or the reverse)
8. A refund can never exceed what was charged
9. The two data stores must always agree
10. Don't ship a change that quietly weakens a check

Cover all ten in Portable once, and it catches them in any app. At that point Adaptive has nothing
left to add, so it retires.

## Where this lands
- **Keep:** Portable (this playbook) — reusable, catches the bugs, far less work per app.
- **Drop:** Adaptive — the per-app sealed gate.
- **Keep as a helper:** CodeRabbit — surfaces new bug types worth adding to Portable later.
