// derive.ts — compute an app's MONEY SURFACE from the repo itself, instead of hand-declaring a static card.
//
// WHY: a hand-written card (adapters/<app>.ts) is a frozen list of money tables/paths. The moment the app
// grows a new money module — pmar added gaap.ts, fx.ts, policy.ts, travel.ts, assurance.ts and moved its
// schema from src/lib/db.ts to supabase/migrations/*.sql — the card rots: detectors bound to the old list
// never scan the new code, and coverage silently drops. That rot is exactly the Qodo-caught misses.
//
// FIX: derive the surface on every run. A new money file is in scope the moment it lands, with zero
// hand-maintenance, and the card can never drift because it is computed, not declared. FAILS OPEN — any
// source that looks money-touching is included; ambiguity means "scan it", never "skip it".
//
// The result is the SAME MoneySurface shape the detectors already consume, so nothing downstream changes
// except that `cwd => surface` is now a function of the repo, not a literal.

import { existsSync, readFileSync, readdirSync } from "node:fs";
import { join, relative } from "node:path";
import { moneyBearingTables } from "./static/n-card-fresh.ts";
import { type MoneySurface } from "./adapters/pmar.ts";

/** Money columns — a table/line carrying one of these moves money. */
const MONEY_COLUMNS = /_minor\b|amount|_cents\b|balance|rate|debit|credit/i;

/** An import of a money module (the app's own ledger/payments/accounting/connector surface). */
const IMPORT_MONEY =
  /\bfrom\s+['"][^'"]*\/(payments|idempotency|money|accounts|ledger|gaap|fx|tax|connectors|events|audit|recon|assurance)['"]/i;

/** A call into money movement / accounting / approval machinery. */
const CALL_MONEY =
  /\b(postEntry|journalEntr|ledger\.(post|entry|balance)|recogniz|accru|reimburs|settle|capture|refund|chargeback|executeMoneyMovement|payout|payBill|recordPayment|createPayment|approve(Bill|Level|Expense)?|decide|assuranceScore|reconcile)\b/i;

/** Obvious non-money infra files we never need to scan (pure plumbing). */
const INFRA = /\/(log|env|errors?|jwt|supabase|context|config)\.ts$/i;

/**
 * A file that IS a money module itself — its basename names a money domain (fx, money, accounting,
 * ledger, tax, recon, assurance…). This catches the LEAF-DEFINER case a CALL_MONEY / IMPORT_MONEY scan
 * misses: `src/lib/fx.ts` DEFINES `convertMinor`/`fxRate` but imports nothing and calls no money verb, so
 * neither import- nor call-based inclusion reaches it — yet it is exactly where the FX-scale bug lives.
 * Mirrors IMPORT_MONEY's module set (minus `connectors`, already a whole-domain dir).
 */
const MONEY_MODULE_FILE =
  /\/(payments|idempotency|money|accounts|ledger|gaap|fx|tax|events|audit|recon|assurance)\.ts$/i;

const safeRead = (p: string): string => {
  try { return readFileSync(p, "utf8"); } catch { return ""; }
};

/** Recursively collect source .ts files (skipping build/vendor/test/type-decl files). */
function walkTs(dir: string, base: string, out: string[]): void {
  let entries;
  try { entries = readdirSync(dir, { withFileTypes: true }); } catch { return; }
  for (const e of entries) {
    const full = join(dir, e.name);
    if (e.isDirectory()) {
      if (/^(node_modules|\.git|dist|build|coverage)$/.test(e.name)) continue;
      walkTs(full, base, out);
    } else if (e.name.endsWith(".ts") && !e.name.endsWith(".d.ts") && !/\.(test|spec)\.ts$/.test(e.name)) {
      out.push(relative(base, full));
    }
  }
}

/** List files in a dir matching `re`, as paths relative to base. */
function listIf(dir: string, base: string, re: RegExp): string[] {
  let entries;
  try { entries = readdirSync(dir, { withFileTypes: true }); } catch { return []; }
  return entries.filter((e) => e.isFile() && re.test(e.name)).map((e) => relative(base, join(dir, e.name))).sort();
}

export interface DerivedSurface extends MoneySurface {
  /** Provenance — which files were classified money, and why the schema was read where it was. */
  derivation: { schemaFrom: string; moneyFileCount: number; scannedTs: number };
}

/**
 * Compute the money surface of the repo at `cwd`.
 * Schema: prefer SQL migrations + schema.sql; else any .ts holding `create table` (ts-embedded).
 * Money files: every src/services|ledger file, plus any source that imports a money module, calls a money
 * verb, or reads/writes a money table/column. Fails open.
 */
export function deriveMoneySurface(cwd: string): DerivedSurface {
  // --- 1. schema discovery (handles a repo that moved ts-embedded -> sql-migrations) ---
  const sqlFiles = [
    ...listIf(join(cwd, "supabase/migrations"), cwd, /\.sql$/),
    ...(existsSync(join(cwd, "supabase/schema.sql")) ? ["supabase/schema.sql"] : []),
  ];
  const allTs: string[] = [];
  walkTs(join(cwd, "src"), cwd, allTs);

  let schemaMode: "sql-migrations" | "ts-embedded";
  let schemaFiles: string[];
  let schemaFrom: string;
  if (sqlFiles.length) {
    schemaMode = "sql-migrations";
    schemaFiles = sqlFiles;
    schemaFrom = "supabase/*.sql";
  } else {
    schemaMode = "ts-embedded";
    schemaFiles = allTs.filter((p) => /create\s+table/i.test(safeRead(join(cwd, p))));
    schemaFrom = schemaFiles.join(", ") || "(none found)";
  }
  const schemaText = schemaFiles.map((p) => safeRead(join(cwd, p))).join("\n");
  const moneyTables = moneyBearingTables(schemaText, MONEY_COLUMNS);
  const tableRe = moneyTables.length ? new RegExp(`\\b(${moneyTables.join("|")})\\b`, "i") : null;

  // --- 2. money files (fail open) ---
  const moneyPaths = allTs.filter((p) => {
    if (INFRA.test(p) || /^src\/demo/.test(p) || /\/(seed|migrate)\.ts$/.test(p)) return false;
    if (/^src\/(services|ledger|connectors)\//.test(p)) return true; // whole money domains
    if (MONEY_MODULE_FILE.test(p)) return true; // a money module itself (fx.ts/money.ts/…) — leaf definer
    const t = safeRead(join(cwd, p));
    if (IMPORT_MONEY.test(t) || CALL_MONEY.test(t)) return true;
    if (tableRe && tableRe.test(t)) return true;
    if (MONEY_COLUMNS.test(t) && /\binsert|update|from\(|\.rpc\(|VALUES/i.test(t)) return true;
    return false;
  });

  // --- 3. http entry (where per-request tenant/auth + routing live) ---
  const httpEntry =
    allTs.find((p) => /\/http\/server\.ts$/.test(p)) ||
    allTs.find((p) => /\b(addRoute|createServer|createRouter)\b/.test(safeRead(join(cwd, p)))) ||
    "src/http/server.ts";

  // --- 4. seam + chart of accounts ---
  const seamPaths = existsSync(join(cwd, "src/connectors")) ? ["src/connectors/**"] : [];
  const chartOfAccounts = allTs.find((p) => /\/accounts\.ts$/.test(p)) || "src/lib/accounts.ts";

  return {
    schemaMode,
    schemaFiles,
    chartOfAccounts,
    moneyTables,
    moneyColumns: MONEY_COLUMNS,
    moneyPaths,
    seamPaths,
    httpEntry,
    cwd,
    derivation: { schemaFrom, moneyFileCount: moneyPaths.length, scannedTs: allTs.length },
  };
}

/**
 * Is the derived surface UNUSABLE — i.e. the app was not actually scanned, so any green result would be a
 * FALSE PASS? Returns a human-readable reason, or null if the surface is sound. A caller MUST treat a
 * non-null result as a HARD ERROR (non-zero exit), never a silent pass: an empty surface is the difference
 * between "we checked and it's clean" and "we never read your code". The gate only understands TypeScript
 * under `src/` with an SQL `create table` schema (supabase migrations or ts-embedded) today; anything else
 * (Python/Go/Java/Ruby, a non-`src/` layout, a Prisma/Drizzle/Rails/Django schema) derives empty here, and
 * silently passing it is the one failure mode that actively lies to the user.
 */
export function unusableSurfaceReason(surface: DerivedSurface): string | null {
  const d = surface.derivation;
  if (d.scannedTs === 0) {
    return `no TypeScript source was found under ${surface.cwd}/src — this gate reads \`.ts\` files under \`src/\`. ` +
      `Point it at the app's root, or this stack/layout is not supported yet. NOTHING was scanned.`;
  }
  if (d.moneyFileCount === 0) {
    return `no money files were identified among ${d.scannedTs} scanned \`.ts\` file(s) — the derivation recognized ` +
      `no money module, money verb, or money table (it expects Supabase-client / SQL idioms). NOTHING money-bearing ` +
      `was checked.`;
  }
  if (surface.moneyTables.length === 0) {
    return `no money tables were derived from the schema (${d.schemaFrom}) — the schema was not found or is not in a ` +
      `supported form (SQL \`create table\` in supabase migrations, or ts-embedded). The table-keyed checks ` +
      `(duplicate-obligation, aging, aggregate-status, PII-projection) would all silently abstain.`;
  }
  return null;
}

export default deriveMoneySurface;
